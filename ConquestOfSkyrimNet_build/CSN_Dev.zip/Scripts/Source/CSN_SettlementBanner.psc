Scriptname CSN_SettlementBanner extends ObjectReference
{Conquest of SkyrimNet: a settlement's banner (the same banner as a claim's). Activating it opens the settlement's
 menu: its guards, what it makes, and the faction screen.}

Event OnActivate(ObjectReference akActionRef)
	If akActionRef == Game.GetPlayer()
		CSN_Settle.BannerMenu(Self)
	EndIf
EndEvent
