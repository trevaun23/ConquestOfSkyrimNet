Scriptname CS_StartFactionMenu extends Quest  

Message Property StartFactionMenu  Auto  

Function MenuStart(int Response = 0)
	Response = CSNP.Show(StartFactionMenu, self)
	if Response == 0
		SetStage(0)
	endif
endFunction
