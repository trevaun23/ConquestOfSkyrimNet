Scriptname CS_WarRebelsScript extends Quest
{The rebels' side of the war (quest CSN_WarRebels, always running).

 The unfinished Conquest of Skyrim build kept a CS_WarRebelsScript from an older layout (one war quest per city)
 that no quest uses. This one gives the rebels what the Imperials and Stormcloaks have in CoS 0.3.9 (CS_TMScript):
 once a day, when the economy updates (CS_EconomyVariableFunctions.UpdateEconomy), every rebel force has a chance to
 attack one of the faction's cities, and an attack is fought as CoS's own city-defence battle
 (CSN_DefendCityRebels, CS_DefendCityRebelScript).

 Rebel forces (CSN_Rebellion keeps them):
   * an UPRISING in one of the faction's hold cities: the rebels storm their own city. The chance grows each day of
     the uprising, and is higher with no garrison.
   * a FREE COMPANY (an army that broke away and isn't at peace with the faction): it attacks a city the faction
     holds in its own hold, else in a bordering hold. The chance grows with its soldiers, with an undefended target
     and once it has proclaimed its own realm.
 Like CoS's own attacks, there is at most one battle at a time: nothing is launched while any city, fort or camp is
 being attacked.

 Outcome:
   * the city holds: an uprising is broken (the leader's people go home); a free company loses the soldiers who fell
     and breaks up under 5.
   * the rebels take the city: it goes over to the side they hand it to (CSN_Rebellion.FallTo), as when an uprising
     runs its course; a free company carries off loot from the treasury.

 Villages have no city battle in CoS; their uprisings keep running by the day (CSN_Rebellion).}

CSN_Core Function M()
	Return CSN_Gov.M()
EndFunction

Bool Function AttacksOn()
	Return CSN_Config.GetBool("bRebelAttacks:Rebellion", True)
EndFunction

Int Function BaseChance()
	Return CSN_Config.ClampMin(CSN_Config.GetInt("iRebelAttackChance:Rebellion", 25), 0)
EndFunction

Quest Function DefendQuest()
	Return Game.GetFormFromFile(0xD3D880, "ConquestOfSkyrimNet.esp") as Quest   ; CSN_DefendCityRebels
EndFunction

; ---- once a day, when the economy updates -------------------------------------------------
Function EconomyUpdated()
	CSN_Core m = M()
	If !m || m.FactionStarted.GetValue() < 1
		Return
	EndIf
	; the day's unrest, morale and free companies first
	CSN_Rebellion.Daily()
	; Thanes' ventures pay their daily share
	CSN_Requests.InvestDaily()
	CSN_Requests.FlushMemories()
	If AttacksOn()
		ChooseAttack()
	EndIf
EndFunction

Bool Function BattleUnderWay()
	CSN_Core m = M()
	CS_GovScriptFunctions g = m.Gov
	If DefendQuest() && DefendQuest().IsRunning()
		Return True
	EndIf
	If SideBusy(g.TMImp) || SideBusy(g.TMSons)
		Return True
	EndIf
	Return CSN_Gov.BattleRunning()
EndFunction

Bool Function SideBusy(CS_TMScript tm)
	If !tm
		Return False
	EndIf
	Return (tm.DefendCityQuestNew && tm.DefendCityQuestNew.IsRunning()) || (tm.DefendFortQuest && tm.DefendFortQuest.IsRunning()) || (tm.DefendCampQuest && tm.DefendCampQuest.IsRunning())
EndFunction

Function ChooseAttack()
	If BattleUnderWay()
		Return
	EndIf
	; pick the most eager rebel force, like CoS picks its hold priority
	Int bestChance = 0
	Int bestKind = -1      ; 0 uprising, 1 free company
	Int bestWho = -1
	Int bestCity = -1
	Int i = 0
	While i < 9
		If CSN_Rebellion.Stage(i) == 2 && CSN_World.PlayerRules(i)
			Int c = BaseChance() + 10 * CSN_Rebellion.DaysUp(i)
			If CSN_Rebellion.Garrison(i) == 0
				c += 10
			EndIf
			c += Utility.RandomInt(0, 10)
			If c > bestChance
				bestChance = c
				bestKind = 0
				bestWho = i
				bestCity = i
			EndIf
		EndIf
		i += 1
	EndWhile
	Int w = 0
	While w < 10
		If CSN_Rebellion.BandAlive(w) && !CSN_Rebellion.Recognised(w) && CSN_Rebellion.BandTroops(w) >= 5
			Int target = BandTarget(w)
			If target >= 0
				Int c = BaseChance() + CSN_Rebellion.BandTroops(w) / 4
				If CSN_Rebellion.Garrison(target) == 0
					c += 10
				EndIf
				If CSN_Rebellion.Independent(w)
					c += 10
				EndIf
				c += Utility.RandomInt(0, 10)
				If c > bestChance
					bestChance = c
					bestKind = 1
					bestWho = w
					bestCity = target
				EndIf
			EndIf
		EndIf
		w += 1
	EndWhile
	If bestKind < 0
		Return
	EndIf
	If bestChance > 90
		bestChance = 90
	EndIf
	If Utility.RandomInt(1, 100) > bestChance
		CSN_Config.Log("rebels: no attack today (best chance " + bestChance + "%)")
		Return
	EndIf
	Launch(bestKind, bestWho, bestCity)
EndFunction

; a city the faction rules in the company's hold, else in a bordering hold (-1 none)
Int Function BandTarget(Int w)
	CSN_Core m = M()
	Int h = CSN_Rebellion.SeatHold(w)
	If CSN_Rebellion.SeatKind(w) == 2 && CSN_Rebellion.SeatIndex(w) < 9
		h = CSN_Rebellion.SeatIndex(w)
	EndIf
	If h >= 0 && h < 9 && CSN_World.PlayerRules(h)
		Return h
	EndIf
	If h < 0 || h > 8
		Return -1
	EndIf
	CS_TMScript tm = m.Gov.TMPlayer
	Int best = -1
	Int i = 0
	While i < 9
		If i != h && CSN_World.PlayerRules(i) && tm.GetIsHoldLinked(h, i, True, True)
			If best < 0 || CSN_Rebellion.Garrison(i) < CSN_Rebellion.Garrison(best)
				best = i
			EndIf
		EndIf
		i += 1
	EndWhile
	Return best
EndFunction

Function Launch(Int aiKind, Int aiWho, Int aiCity)
	CSN_Core m = M()
	Int troops
	String who
	If aiKind == 0
		troops = CSN_Rebellion.Rebels(aiWho)
		who = "The rebels of " + CSN_World.TownName(aiWho)
	Else
		troops = CSN_Rebellion.BandTroops(aiWho)
		who = CSN_Rebellion.BandName(aiWho)
	EndIf
	; uprising rebels outside the city battle are cleared away first
	If aiKind == 0
		CSN_Rebellion.DespawnTown(aiWho)
	Else
		CSN_Rebellion.DespawnBand(aiWho)
	EndIf
	StorageUtil.SetIntValue(None, "csn_rw_troops", troops)
	StorageUtil.SetIntValue(None, "csn_rw_kind", aiKind)
	StorageUtil.SetIntValue(None, "csn_rw_who", aiWho)
	StorageUtil.SetIntValue(None, "csn_rw_city", aiCity)
	Location city = CSN_World.TownVanillaLocation(aiCity)
	m.Gov.TMImp.CS_StoryDefendCity.SendStoryEvent(akLoc = city, aiValue1 = 70)
	Utility.Wait(1.0)
	If !DefendQuest().IsRunning()
		CSN_Config.Log("rebels: the city defence quest did not start for " + CSN_World.TownName(aiCity))
		StorageUtil.SetIntValue(None, "csn_rw_kind", -1)
		Return
	EndIf
	If aiKind == 0
		CSN_Journal.Unrest(aiWho, 30)
	Else
		CSN_Journal.Company(aiWho, 20)
	EndIf
	String txt = who + " (" + troops + " fighters) are attacking " + CSN_World.TownName(aiCity) + "!"
	CSN_World.AddNews(aiCity, txt, "csn_rebel_attack")
	CSN_World.AddNews(-1, txt, "csn_rebel_attack")
EndFunction

; ---- outcome, from CS_DefendCityRebelScript ------------------------------------------------
Function RebelsBeaten(Int aiCity, Int aiSurvivors)
	CSN_Core m = M()
	Int kind = StorageUtil.GetIntValue(None, "csn_rw_kind", -1)
	Int who = StorageUtil.GetIntValue(None, "csn_rw_who", -1)
	StorageUtil.SetIntValue(None, "csn_rw_kind", -1)
	String town = CSN_World.TownName(aiCity)
	If kind == 0 && who >= 0
		CSN_Journal.AssaultOver(who, True)
		CSN_Rebellion.EndUprising(who, False)
		String txt = "The uprising in " + town + " was broken when its rebels failed to take the city."
		CSN_World.AddNews(aiCity, txt, "csn_uprising_crushed")
		CSNP.Notice(txt)
	ElseIf kind == 1 && who >= 0 && CSN_Rebellion.BandAlive(who)
		Int left = aiSurvivors
		If left < 0
			left = 0
		EndIf
		If left > CSN_Rebellion.BandTroops(who)
			left = CSN_Rebellion.BandTroops(who)
		EndIf
		StorageUtil.SetIntValue(None, "csn_wb_" + who + "_troops", left)
		CSN_Journal.CompanyAssaultOver(who, True)
		String txt = CSN_Rebellion.BandName(who) + " was thrown back from " + town + " with only " + left + " soldiers left."
		CSN_World.AddNews(-1, txt, "csn_company_beaten")
		CSNP.Notice(txt)
		If left < 5
			CSN_Rebellion.Broken(who, "Too few of them survived the attack on " + town + ".")
		EndIf
	EndIf
	m.Refresh()
EndFunction

Function RebelsWon(Int aiCity, Int aiSurvivors)
	CSN_Core m = M()
	Int kind = StorageUtil.GetIntValue(None, "csn_rw_kind", -1)
	Int who = StorageUtil.GetIntValue(None, "csn_rw_who", -1)
	StorageUtil.SetIntValue(None, "csn_rw_kind", -1)
	String town = CSN_World.TownName(aiCity)
	If kind == 0 && who >= 0
		CSN_Journal.AssaultOver(who, False)
		CSN_Rebellion.LoseTown(who)
	Else
		Int side = CSN_Rebellion.FallTo(aiCity)
		If kind == 1 && who >= 0 && CSN_Rebellion.BandAlive(who)
			CSN_Journal.CompanyAssaultOver(who, False)
			Int loot = CSN_Gov.Treasury() / 10
			If loot > 0
				m.Econ().Treasury.Mod(-loot)
			EndIf
			If aiSurvivors > 0
				StorageUtil.SetIntValue(None, "csn_wb_" + who + "_troops", aiSurvivors)
			EndIf
			String txt = CSN_Rebellion.BandName(who) + " stormed " + town + ", carried off " + loot + " gold and handed the city to " + CSN_World.OwnerName(side) + "."
			CSN_World.AddNews(-1, txt, "csn_town_lost")
			CSNP.Notice(txt)
		EndIf
		CSN_Gov.CityTo(aiCity, side)
	EndIf
	m.Refresh()
EndFunction
