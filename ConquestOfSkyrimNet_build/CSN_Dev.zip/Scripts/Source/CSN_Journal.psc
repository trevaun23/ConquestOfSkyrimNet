Scriptname CSN_Journal Hidden
{Conquest of SkyrimNet - journal quests for unrest, uprisings and free companies.

 Quests in the plugin (no scripts of their own; this drives them):
   CSN_JournalUnrest1-3   "Unrest in <Town>"      aliases 0 Town (location), 1 Leader
       stages 10 unrest, 20 uprising, 30 the rebels storm the city, 100 over, 200 town lost
       objectives 10 calm it, 20 end the uprising, 21 defeat the leader (map target), 30 defend the city
   CSN_JournalCompany1-2  "Deserters at <Seat>"   aliases 0 Seat (location), 1 Leader
       stages 10 broke away, 20 attacking a city, 100 no longer a threat, 200 took a city
       objectives 10 deal with them, 11 defeat the leader (map target), 20 defend the city
 One copy per town or company at a time; StorageUtil "csn_jr_*" remembers which.}

Quest Function UnrestQuest(Int n) Global
	Return Quest.GetQuest("CSN_JournalUnrest" + (n + 1))
EndFunction

Quest Function CompanyQuest(Int n) Global
	Return Quest.GetQuest("CSN_JournalCompany" + (n + 1))
EndFunction

; Start a journal copy through the story manager, so its place (alias 0) is filled as the quest starts: names
; in the journal ("Unrest in Riften") only come out right that way; a place forced in afterwards shows as [...].
; The story manager takes the first copy in its list that isn't running, which is the one the caller freed.
Bool Function StartWith(Quest q, Int aiKeyword, Location akLoc) Global
	Keyword k = Game.GetFormFromFile(aiKeyword, "ConquestOfSkyrimNet.esp") as Keyword
	If k && akLoc
		k.SendStoryEvent(akLoc)
		Int w = 0
		While w < 30 && !q.IsRunning()
			Utility.Wait(0.1)
			w += 1
		EndWhile
	EndIf
	If !q.IsRunning() && !q.Start()
		Return False
	EndIf
	LocationAlias a = q.GetAlias(0) as LocationAlias
	If a && a.GetLocation() != akLoc
		a.ForceLocationTo(akLoc)
	EndIf
	Return True
EndFunction

; ---- unrest and uprisings ---------------------------------------------------------------------
; the copy following this town (-1 none); abNew: take a free one
Int Function UnrestSlot(Int aiTown, Bool abNew) Global
	Int n = 0
	While n < 3
		If StorageUtil.GetIntValue(None, "csn_jr_u" + n, 0) == aiTown + 1 && UnrestQuest(n) && UnrestQuest(n).IsRunning()
			Return n
		EndIf
		n += 1
	EndWhile
	If !abNew
		Return -1
	EndIf
	; a copy not following anyone (never used, or its story is over and only its journal entry is left)
	n = 0
	While n < 3
		Quest q = UnrestQuest(n)
		If q && (StorageUtil.GetIntValue(None, "csn_jr_u" + n, 0) == 0 || !q.IsRunning())
			If q.IsRunning()
				q.Stop()
				Utility.Wait(0.2)
			EndIf
			q.Reset()
			If StartWith(q, 0xD3D89E, CSN_World.TownVanillaLocation(aiTown))
				StorageUtil.SetIntValue(None, "csn_jr_u" + n, aiTown + 1)
				Return n
			EndIf
		EndIf
		n += 1
	EndWhile
	CSN_Config.Log("journal: no free unrest quest for " + CSN_World.TownName(aiTown))
	Return -1
EndFunction

; 10 unrest, 20 uprising, 30 the rebels storm the city
Function Unrest(Int aiTown, Int aiStage) Global
	Int n = UnrestSlot(aiTown, True)
	If n < 0
		Return
	EndIf
	Quest q = UnrestQuest(n)
	; a map marker on the town itself (aliases: 0 Town, 1 Leader, 2 TownMarker)
	ReferenceAlias mk = q.GetAlias(2) as ReferenceAlias
	If mk && !mk.GetReference()
		mk.ForceRefTo(CSN_Rebellion.TownMarker(aiTown))
	EndIf
	If aiStage == 10
		q.SetStage(10)
		q.SetObjectiveDisplayed(10)
	ElseIf aiStage == 20
		If q.IsObjectiveDisplayed(10)
			q.SetObjectiveFailed(10)
		EndIf
		q.SetStage(20)
		q.SetObjectiveDisplayed(20)
		Actor leader = StorageUtil.GetFormValue(None, "csn_reb_" + aiTown + "_leader") as Actor
		If leader
			Leader(aiTown, leader)
		EndIf
	ElseIf aiStage == 30
		q.SetStage(30)
		q.SetObjectiveDisplayed(30)
	EndIf
EndFunction

; the rebel leader is known (a townsperson CoS picked, or the one in the streets): a map target
Function Leader(Int aiTown, Actor akLeader) Global
	Int n = UnrestSlot(aiTown, False)
	If n < 0 || !akLeader
		Return
	EndIf
	Quest q = UnrestQuest(n)
	(q.GetAlias(1) as ReferenceAlias).ForceRefTo(akLeader)
	If q.IsObjectiveFailed(21)
		q.SetObjectiveFailed(21, False)   ; back in town: a new chance at their leader
	EndIf
	q.SetObjectiveDisplayed(21, True, True)
EndFunction

; the player left the town (or died there): the chance to strike down the leader is gone for now; the rising goes
; on (the town marker stays), and returning to the town brings the leader out again
Function LeaderGone(Int aiTown) Global
	Int n = UnrestSlot(aiTown, False)
	If n < 0
		Return
	EndIf
	Quest q = UnrestQuest(n)
	(q.GetAlias(1) as ReferenceAlias).Clear()
	If q.IsObjectiveDisplayed(21) && !q.IsObjectiveCompleted(21) && !q.IsObjectiveFailed(21)
		q.SetObjectiveFailed(21)
	EndIf
EndFunction

; the rebels' assault on the city ended (held): back to dealing with the rising, if it goes on
Function AssaultOver(Int aiTown, Bool abHeld) Global
	Int n = UnrestSlot(aiTown, False)
	If n < 0
		Return
	EndIf
	Quest q = UnrestQuest(n)
	If q.IsObjectiveDisplayed(30)
		If abHeld
			q.SetObjectiveCompleted(30)
		Else
			q.SetObjectiveFailed(30)
		EndIf
	EndIf
EndFunction

; abWon: calmed, appeased or crushed; otherwise the town was lost
Function UnrestOver(Int aiTown, Bool abWon) Global
	Int n = UnrestSlot(aiTown, False)
	If n < 0
		Return
	EndIf
	Quest q = UnrestQuest(n)
	Int[] objs = new Int[4]
	objs[0] = 10
	objs[1] = 20
	objs[2] = 21
	objs[3] = 30
	Int k = 0
	While k < objs.Length
		If q.IsObjectiveDisplayed(objs[k]) && !q.IsObjectiveCompleted(objs[k]) && !q.IsObjectiveFailed(objs[k])
			If abWon
				q.SetObjectiveCompleted(objs[k])
			Else
				q.SetObjectiveFailed(objs[k])
			EndIf
		EndIf
		k += 1
	EndWhile
	If abWon
		q.SetStage(100)
		q.CompleteQuest()
	Else
		q.SetStage(200)
	EndIf
	(q.GetAlias(1) as ReferenceAlias).Clear()
	(q.GetAlias(2) as ReferenceAlias).Clear()
	StorageUtil.SetIntValue(None, "csn_jr_u" + n, 0)
	; the entry stays in the journal until this copy is needed for another town
EndFunction

; ---- free companies ---------------------------------------------------------------------------
Int Function CompanySlot(Int aiBand, Bool abNew) Global
	Int n = 0
	While n < 2
		If StorageUtil.GetIntValue(None, "csn_jr_c" + n, 0) == aiBand + 1 && CompanyQuest(n) && CompanyQuest(n).IsRunning()
			Return n
		EndIf
		n += 1
	EndWhile
	If !abNew
		Return -1
	EndIf
	; a copy not following anyone (never used, or its story is over and only its journal entry is left)
	n = 0
	While n < 2
		Quest q = CompanyQuest(n)
		If q && (StorageUtil.GetIntValue(None, "csn_jr_c" + n, 0) == 0 || !q.IsRunning())
			If q.IsRunning()
				q.Stop()
				Utility.Wait(0.2)
			EndIf
			q.Reset()
			If StartWith(q, 0xD3D89F, CSN_Rebellion.SeatLocation(aiBand))
				StorageUtil.SetIntValue(None, "csn_jr_c" + n, aiBand + 1)
				Return n
			EndIf
		EndIf
		n += 1
	EndWhile
	CSN_Config.Log("journal: no free company quest for " + CSN_Rebellion.BandName(aiBand))
	Return -1
EndFunction

; 10 broke away (or back to that after an attack), 20 attacking a city
Function Company(Int aiBand, Int aiStage) Global
	Int n = CompanySlot(aiBand, True)
	If n < 0
		Return
	EndIf
	Quest q = CompanyQuest(n)
	If aiStage == 10
		(q.GetAlias(0) as LocationAlias).ForceLocationTo(CSN_Rebellion.SeatLocation(aiBand))
		Actor ld = CSN_Rebellion.BandLeader(aiBand)
		If ld
			(q.GetAlias(1) as ReferenceAlias).ForceRefTo(ld)
		EndIf
		q.SetStage(10)
		q.SetObjectiveDisplayed(10)
		q.SetObjectiveDisplayed(11)
	ElseIf aiStage == 20
		q.SetStage(20)
		q.SetObjectiveDisplayed(20)
	EndIf
EndFunction

Function CompanyAssaultOver(Int aiBand, Bool abHeld) Global
	Int n = CompanySlot(aiBand, False)
	If n < 0
		Return
	EndIf
	Quest q = CompanyQuest(n)
	If q.IsObjectiveDisplayed(20) && !q.IsObjectiveCompleted(20) && !q.IsObjectiveFailed(20)
		If abHeld
			q.SetObjectiveCompleted(20)
		Else
			q.SetObjectiveFailed(20)
		EndIf
	EndIf
EndFunction

; broken, paid off or recognised: the threat is over
Function CompanyOver(Int aiBand) Global
	Int n = CompanySlot(aiBand, False)
	If n < 0
		Return
	EndIf
	Quest q = CompanyQuest(n)
	Int[] objs = new Int[3]
	objs[0] = 10
	objs[1] = 11
	objs[2] = 20
	Int k = 0
	While k < objs.Length
		If q.IsObjectiveDisplayed(objs[k]) && !q.IsObjectiveCompleted(objs[k]) && !q.IsObjectiveFailed(objs[k])
			q.SetObjectiveCompleted(objs[k])
		EndIf
		k += 1
	EndWhile
	q.SetStage(100)
	q.CompleteQuest()
	(q.GetAlias(1) as ReferenceAlias).Clear()
	StorageUtil.SetIntValue(None, "csn_jr_c" + n, 0)
EndFunction

; Copies started before 2.0.0 show their place as [...]: start the ones still following trouble again.
Function Restart() Global
	Int n = 0
	While n < 3
		Quest q = UnrestQuest(n)
		If q && q.IsRunning()
			q.Stop()
		EndIf
		StorageUtil.SetIntValue(None, "csn_jr_u" + n, 0)
		n += 1
	EndWhile
	n = 0
	While n < 2
		Quest q = CompanyQuest(n)
		If q && q.IsRunning()
			q.Stop()
		EndIf
		StorageUtil.SetIntValue(None, "csn_jr_c" + n, 0)
		n += 1
	EndWhile
	CSN_Config.Log("journal: restarted the journal quests (place names)")
EndFunction

; once per load: towns and companies already in trouble before the journal quests existed get theirs
Function Sync() Global
	If StorageUtil.GetIntValue(None, "csn_jr_v", 0) < 2
		StorageUtil.SetIntValue(None, "csn_jr_v", 2)
		Restart()
	EndIf
	Int i = 0
	While i < 15
		Int st = CSN_Rebellion.Stage(i)
		If st > 0 && UnrestSlot(i, False) < 0
			Unrest(i, 10)
			If st == 2
				Unrest(i, 20)
			EndIf
		EndIf
		i += 1
	EndWhile
	Int w = 0
	While w < 10
		If CSN_Rebellion.BandAlive(w) && !CSN_Rebellion.Recognised(w) && CompanySlot(w, False) < 0
			Company(w, 10)
		EndIf
		w += 1
	EndWhile
EndFunction
