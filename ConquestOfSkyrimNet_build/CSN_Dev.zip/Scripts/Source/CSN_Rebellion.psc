Scriptname CSN_Rebellion Hidden
{Conquest of SkyrimNet - rebellions.

 Two kinds, both built on Conquest of Skyrim's own data and records (the rebel soldiers CS_SiegeRebelSoldier /
 CS_SiegeRebelArcher, CS_ArmyRebelFaction, the rebellion leaders CoS picks in CS_RebellionLeaders, the town
 keywords CoS keeps for hunger, garrisons and court cases). CoS 0.3.9 has the civilian uprising half-written in
 CS_LoyaltyCheckScript but its quest is missing, so it never starts; the unfinished development build adds a
 military rebellion with no trigger. This script runs both.

 CIVILIAN (towns the faction rules): loyalty under the threshold (MCM, default 20) plus a grievance (hunger, heavy
 taxes, no garrison, unheard court cases) -> a day of UNREST (warning) -> an UPRISING: taxes stop, loyalty falls,
 and rebels hold the town. It ends when the player meets their demands (gold, food, lower taxes), kills the rebel
 leader in person, or the garrison is twice the rebels' number. Left alone for some days (MCM, default 3) the
 rebels open the gates to the Imperials or the Stormcloaks.

 MILITARY (the faction's armies): every army has a morale (0-100). Unpaid troops (empty treasury), hunger (no
 food), refused requests and long postings away from home wear it down; stars, granted requests, pay and food
 raise it. An army under the secession threshold (MCM, default 15, lower for leaders with more stars) with a
 grievance may SECEDE: its leader and troops leave the faction as an independent company that holds the place they
 were posted, raids the faction's treasury and food, and after a few days proclaims its own free realm. The
 player can retake it (in person, or by sending a loyal army), buy the company back by paying arrears, or
 recognise its independence (no more raids).

 State is kept in StorageUtil under "csn_reb_*", "csn_mor_*" and "csn_wb_*".}

; =============================================================================
; ACCESS
; =============================================================================
CSN_Core Function M() Global
	Return CSN_Gov.M()
EndFunction

CS_LoyaltyCheckScript Function L() Global
	Return CSN_World.Loyalty()
EndFunction

Form Function F(Int aiId) Global
	Return Game.GetFormFromFile(aiId, "ConquestOfSkyrimNet.esp")
EndFunction

ActorBase Function RebelSoldier() Global
	Return F(0x31a444) as ActorBase
EndFunction

ActorBase Function RebelArcher() Global
	Return F(0x31a445) as ActorBase
EndFunction

Faction Function RebelFaction() Global
	CS_LoyaltyCheckScript l = L()
	If l && l.RebelFaction
		Return l.RebelFaction
	EndIf
	Return F(0x31a46b) as Faction
EndFunction

Faction Function PlayerArmy() Global
	Return F(0x0028a5) as Faction
EndFunction

Int Function Today() Global
	Return Utility.GetCurrentGameTime() as Int
EndFunction

Bool Function Enabled() Global
	Return CSN_Config.GetBool("bCivil:Rebellion", True)
EndFunction

Bool Function MilitaryEnabled() Global
	Return CSN_Config.GetBool("bMilitary:Rebellion", True)
EndFunction

Int Function Threshold() Global
	Return CSN_Config.ClampMin(CSN_Config.GetInt("iUnrestLoyalty:Rebellion", 20), 1)
EndFunction

Int Function UprisingDays() Global
	Return CSN_Config.ClampMin(CSN_Config.GetInt("iUprisingDays:Rebellion", 3), 1)
EndFunction

Int Function SecedeAt() Global
	Return CSN_Config.ClampMin(CSN_Config.GetInt("iSecedeMorale:Rebellion", 15), 0)
EndFunction

; =============================================================================
; DAILY AND PER-TICK HOOKS (CSN_Core.OnUpdate)
; =============================================================================
; once a minute: run the day's checks the first time a new day is seen
Function Tick() Global
	; the day's checks run when the economy updates (CS_WarRebelsScript.EconomyUpdated); this is only a fallback
	; for a day the economy update was missed
	CSN_Core m = M()
	If !m || m.FactionStarted.GetValue() < 1
		Return
	EndIf
	Int last = StorageUtil.GetIntValue(None, "csn_reb_day", -1)
	If last < 0
		StorageUtil.SetIntValue(None, "csn_reb_day", Today())
	ElseIf Today() - last >= 2
		Daily()
	EndIf
EndFunction

; once a day, at the economy update: unrest in the towns, army morale, free companies
Function Daily() Global
	Int d = Today()
	If StorageUtil.GetIntValue(None, "csn_reb_day", -1) == d
		Return
	EndIf
	StorageUtil.SetIntValue(None, "csn_reb_day", d)
	If Enabled()
		DailyTowns()
	EndIf
	If MilitaryEnabled()
		DailyArmies()
	EndIf
	DailyBands()
EndFunction

; every 5 seconds: rebels in the town or fort the player is in
Function Watch() Global
	If StorageUtil.FormListCount(None, "csn_reb_cleanup") > 0
		Cleanup()
	EndIf
	If StorageUtil.GetIntValue(None, "csn_reb_active", 0) <= 0 && StorageUtil.GetIntValue(None, "csn_wb_count", 0) <= 0
		Return
	EndIf
	Actor p = Game.GetPlayer()
	Location here = p.GetCurrentLocation()
	Int i = 0
	While i < 15
		If Stage(i) == 2
			WatchTown(i, here)
		EndIf
		i += 1
	EndWhile
	Int w = 0
	While w < 10
		If BandAlive(w)
			WatchBand(w, here)
		EndIf
		w += 1
	EndWhile
EndFunction

Bool Function At(Location akHere, Location akPlace) Global
	; Location.IsChild: the parent asks about the child (CoS: City.IsChild(akNewLoc))
	Return akHere && akPlace && (akHere == akPlace || akPlace.IsChild(akHere))
EndFunction

; =============================================================================
; CIVILIAN UNREST
; =============================================================================
String Function TK(Int i, String asKey) Global
	Return "csn_reb_" + i + "_" + asKey
EndFunction

Int Function Stage(Int i) Global
	Return StorageUtil.GetIntValue(None, TK(i, "stage"), 0)
EndFunction

Int Function Rebels(Int i) Global
	Return StorageUtil.GetIntValue(None, TK(i, "rebels"), 0)
EndFunction

Int Function DaysUp(Int i) Global
	Return Today() - StorageUtil.GetIntValue(None, TK(i, "since"), Today())
EndFunction

Function SetStage(Int i, Int aiStage) Global
	Int was = Stage(i)
	StorageUtil.SetIntValue(None, TK(i, "stage"), aiStage)
	StorageUtil.SetIntValue(None, TK(i, "since"), Today())
	If was == 2 && aiStage != 2
		StorageUtil.AdjustIntValue(None, "csn_reb_active", -1)
	ElseIf was != 2 && aiStage == 2
		StorageUtil.AdjustIntValue(None, "csn_reb_active", 1)
	EndIf
EndFunction

Bool Function Hungry(Int i) Global
	CS_LoyaltyCheckScript l = L()
	Location loc = CSN_World.TownLocation(i)
	If (l.NoFood && loc.GetKeywordData(l.NoFood) >= 1) || (l.FoodReserve && loc.GetKeywordData(l.FoodReserve) < 0)
		Return True
	EndIf
	Return M().Holdings().FoodReserve.GetValueInt() <= 0
EndFunction

; the people's complaints, as a short list ("" when they have none)
String Function Grievances(Int i) Global
	CS_LoyaltyCheckScript l = L()
	Location loc = CSN_World.TownLocation(i)
	String s = ""
	If Hungry(i)
		s = AddTo(s, "hunger")
	EndIf
	If CSN_Gov.TaxLevel(i) >= 4
		s = AddTo(s, "heavy taxes")
	EndIf
	If i < 9 && l.NoGarrison && loc.GetKeywordData(l.NoGarrison) >= 1
		s = AddTo(s, "no garrison to keep order")
	EndIf
	If i < 9 && l.NoCourt && loc.GetKeywordData(l.NoCourt) >= 1
		s = AddTo(s, "court cases nobody hears")
	EndIf
	If CSN_World.TownLoyalty(i) < 10
		s = AddTo(s, "anger at their rulers")
	EndIf
	Return s
EndFunction

String Function AddTo(String s, String asPart) Global
	If s == ""
		Return asPart
	EndIf
	Return s + ", " + asPart
EndFunction

Int Function Garrison(Int i) Global
	CS_LoyaltyCheckScript l = L()
	If i < 9 && l.Garrisons && i < l.Garrisons.GetSize()
		FormList g = l.Garrisons.GetAt(i) as FormList
		If g
			Return g.GetSize()
		EndIf
	EndIf
	Return 0
EndFunction

Function DailyTowns() Global
	Int t = Threshold()
	Int i = 0
	While i < 15
		If !CSN_World.PlayerRules(i)
			If Stage(i) != 0
				EndUprising(i, False)
			EndIf
		Else
			Int loy = CSN_World.TownLoyalty(i)
			String why = Grievances(i)
			Int st = Stage(i)
			String town = CSN_World.TownName(i)
			If st == 0
				If loy < t && why != "" && Today() >= StorageUtil.GetIntValue(None, TK(i, "calm"), 0)
					SetStage(i, 1)
					Unrest(i, why)
				EndIf
			ElseIf st == 1
				If loy >= t + 5 || why == ""
					SetStage(i, 0)
					CSN_World.AddNews(i, "The unrest in " + town + " has died down.", "csn_unrest_calm")
					CSN_Journal.UnrestOver(i, True)
				Else
					BeginUprising(i, why)
				EndIf
			ElseIf st == 2
				DailyUprising(i)
			EndIf
		EndIf
		i += 1
	EndWhile
EndFunction

Function Unrest(Int i, String asWhy) Global
	String town = CSN_World.TownName(i)
	String txt = "Unrest in " + town + ": people gather in the streets over " + asWhy + ". If nothing changes, they will rise tomorrow."
	CSN_World.AddNews(i, txt, "csn_unrest")
	CSN_Gov.Say(txt)
	CSN_Journal.Unrest(i, 10)
	StorageUtil.SetStringValue(None, TK(i, "why"), asWhy)
EndFunction

Function BeginUprising(Int i, String asWhy) Global
	CSN_Core m = M()
	Int loy = CSN_World.TownLoyalty(i)
	Int n = 6 + (Threshold() - loy) / 2
	If i < 5
		n += 6
	ElseIf i >= 9
		n -= 2
	EndIf
	If n < 4
		n = 4
	ElseIf n > 30
		n = 30
	EndIf
	SetStage(i, 2)
	StorageUtil.SetIntValue(None, TK(i, "rebels"), n)
	StorageUtil.SetStringValue(None, TK(i, "why"), asWhy)
	; no taxes reach the treasury while they hold the streets (put back when it ends)
	StorageUtil.SetIntValue(None, TK(i, "tax"), CSN_Gov.TaxLevel(i))
	CSN_Gov.SetTaxLevel(i, 0, None, False)
	Actor leader = None
	CS_LoyaltyCheckScript l = L()
	If l.RebellionLeaders && i < l.RebellionLeaders.Length && l.RebellionLeaders[i]
		leader = l.RebellionLeaders[i].GetActorRef()
	EndIf
	StorageUtil.SetFormValue(None, TK(i, "leader"), leader)
	StorageUtil.SetIntValue(None, TK(i, "leaderspawned"), 0)
	String town = CSN_World.TownName(i)
	String who = "a rebel leader"
	If leader
		who = leader.GetDisplayName()
	EndIf
	String txt = "UPRISING in " + town + "! " + n + " armed townsfolk led by " + who + " have taken the streets over " + asWhy + ". No taxes are paid while they hold the town."
	CSN_World.AddNews(i, txt, "csn_uprising", leader)
	CSN_World.AddNews(-1, "The people of " + town + " have risen against the " + m.FactionName() + ".", "csn_uprising")
	CSNP.Notice(txt)
	CSN_Journal.Unrest(i, 20)
EndFunction

Function DailyUprising(Int i) Global
	CSN_Core m = M()
	String town = CSN_World.TownName(i)
	Int n = Rebels(i)
	Int g = Garrison(i)
	If n <= 0
		EndUprising(i, True)
		Return
	EndIf
	If g >= n * 2
		m.Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(i), -5)
		CSN_World.AddNews(i, "The garrison of " + town + " (" + g + " soldiers) broke the uprising of " + n + " rebels. Order is back, but people remember the blood.", "csn_uprising_crushed")
		CSN_Gov.Say("The garrison of " + town + " crushed the uprising.")
		EndUprising(i, False)
		Return
	EndIf
	m.Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(i), -3)
	; hold cities: the rebels storm the city in CoS's own battle (CS_WarRebelsScript); with rebel attacks turned off,
	; or in a village, they hand the town over after the set days
	Bool storms = i < 9 && CSN_Config.GetBool("bRebelAttacks:Rebellion", True)
	If DaysUp(i) >= UprisingDays() && (!storms || DaysUp(i) >= UprisingDays() * 2)
		LoseTown(i)
	Else
		Int left = UprisingDays() - DaysUp(i)
		CSN_Gov.Say("The rebels still hold " + town + ". In " + left + " day(s) they will hand it to your enemies.")
	EndIf
EndFunction

; who the rebels open the gates to: a side at war with the faction, else the town's old allegiance
Int Function FallTo(Int i) Global
	CSN_Core m = M()
	If m.AtWar(1) && !m.AtWar(2)
		Return 11
	ElseIf m.AtWar(2) && !m.AtWar(1)
		Return 12
	EndIf
	; Markarth, Riften, Solitude, Whiterun, Windhelm, Dawnstar, Falkreath, Morthal, Winterhold,
	; Dragon Bridge, Ivarstead, Karthwasten, Riverwood, Rorikstead, Shor's Stone
	Int[] old = new Int[15]
	old[0] = 11
	old[1] = 12
	old[2] = 11
	old[3] = 11
	old[4] = 12
	old[5] = 12
	old[6] = 11
	old[7] = 11
	old[8] = 12
	old[9] = 11
	old[10] = 12
	old[11] = 11
	old[12] = 11
	old[13] = 11
	old[14] = 12
	Return old[i]
EndFunction

Function LoseTown(Int i) Global
	CSN_Core m = M()
	String town = CSN_World.TownName(i)
	Int side = FallTo(i)
	DespawnTown(i)
	RestoreTax(i)
	SetStage(i, 0)
	StorageUtil.SetIntValue(None, TK(i, "calm"), Today() + 5)
	CSN_Journal.UnrestOver(i, False)
	Bool ok = CSN_Gov.CityTo(i, side)
	String to = CSN_World.OwnerName(side)
	If ok
		String txt = "The rebels of " + town + " opened the gates to " + to + ". " + town + " is lost to the " + m.FactionName() + "."
		CSN_World.AddNews(i, txt, "csn_town_lost")
		CSN_World.AddNews(-1, txt, "csn_town_lost")
		CSNP.Notice(txt)
	Else
		CSN_Config.Log("uprising: transfer of " + town + " failed")
	EndIf
EndFunction

Function RestoreTax(Int i) Global
	Int tax = StorageUtil.GetIntValue(None, TK(i, "tax"), -1)
	If tax >= 0 && CSN_World.PlayerRules(i)
		CSN_Gov.SetTaxLevel(i, tax, None, False)
	EndIf
	StorageUtil.UnsetIntValue(None, TK(i, "tax"))
EndFunction

; abCalm: the people are content again (demands met), else the rising was put down
Function EndUprising(Int i, Bool abCalm) Global
	CSN_Journal.UnrestOver(i, CSN_World.PlayerRules(i))
	DespawnTown(i)
	If Stage(i) == 2
		RestoreTax(i)
	EndIf
	SetStage(i, 0)
	StorageUtil.SetIntValue(None, TK(i, "rebels"), 0)
	StorageUtil.SetIntValue(None, TK(i, "calm"), Today() + 3)
	If CSN_World.PlayerRules(i) && CSN_World.TownLoyalty(i) < Threshold()
		; a fresh start, so the next day does not start it all again
		M().Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(i), Threshold() - CSN_World.TownLoyalty(i))
	EndIf
EndFunction

; ---- meeting their demands --------------------------------------------------------
Int Function DemandGold(Int i) Global
	Int n = Rebels(i)
	If Stage(i) == 1
		n = 6
	EndIf
	Int g = 250 * n
	If i < 5
		g *= 2
	EndIf
	Return g
EndFunction

Int Function DemandFood(Int i) Global
	If !Hungry(i)
		Return 0
	EndIf
	Int n = Rebels(i)
	If n < 6
		n = 6
	EndIf
	Return n * 2
EndFunction

Bool Function Appease(Int i, Actor akVia = None) Global
	CSN_Core m = M()
	If Stage(i) == 0
		CSN_Gov.Fail("The people of " + CSN_World.TownName(i) + " are not in revolt.")
		Return False
	EndIf
	String town = CSN_World.TownName(i)
	Int g = DemandGold(i)
	Int fd = DemandFood(i)
	Int tax = CSN_Gov.TaxLevel(i)
	If Stage(i) == 2
		tax = StorageUtil.GetIntValue(None, TK(i, "tax"), tax)
	EndIf
	String text = "The people of " + town + " want: " + g + " gold for the families"
	If fd > 0
		text += ", " + fd + " food from the faction's stores"
	EndIf
	If tax > 0
		text += ", and taxes lowered from " + CSN_Gov.TaxText(tax) + " to " + CSN_Gov.TaxText(tax - 1)
	EndIf
	text += ".\n\nTreasury " + CSN_Gov.Treasury() + " gold, food " + CSN_Gov.Stock(0) + ". The rising ends and loyalty in " + town + " rises by 15."
	If !CSNP.Confirm("Meet the rebels' demands", text, "Meet their demands", "Not now")
		Return False
	EndIf
	If CSN_Gov.Treasury() < g
		CSN_Gov.Fail("The treasury holds " + CSN_Gov.Treasury() + " gold; " + g + " needed.")
		Return False
	EndIf
	If fd > 0 && !CSN_Gov.Spend(0, fd)
		Return False
	EndIf
	m.Econ().Treasury.Mod(-g)
	If Stage(i) == 2
		StorageUtil.SetIntValue(None, TK(i, "tax"), tax - 1)
		If tax <= 0
			StorageUtil.SetIntValue(None, TK(i, "tax"), 0)
		EndIf
	ElseIf tax > 0
		CSN_Gov.SetTaxLevel(i, tax - 1, None, False)
	EndIf
	EndUprising(i, True)
	m.Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(i), 15)
	String txt = Game.GetPlayer().GetDisplayName() + " met the demands of the people of " + town + ": gold for the families"
	If fd > 0
		txt += ", food"
	EndIf
	txt += " and lower taxes. The rising is over and the town is calm."
	CSN_World.AddNews(i, txt, "csn_uprising_appeased", akVia)
	CSN_Gov.Say("The people of " + town + " lay down their arms.")
	m.Refresh()
	Return True
EndFunction

; ---- rebels in the streets while the player is there -------------------------------
Function WatchTown(Int i, Location akHere) Global
	Location town = CSN_World.TownVanillaLocation(i)
	Bool inTown = At(akHere, town)
	Int spawned = StorageUtil.FormListCount(None, TK(i, "spawn"))
	If inTown && spawned == 0 && StorageUtil.GetIntValue(None, TK(i, "out"), 0) == 0
		SpawnTown(i)
	ElseIf !inTown && spawned > 0
		DespawnTown(i)
	ElseIf spawned > 0
		CountTown(i)
	EndIf
EndFunction

ObjectReference Function TownMarker(Int i) Global
	FormList fl = F(0x030040) as FormList     ; CS_AttackCityAttackMarkers (inside each town)
	If fl && i < fl.GetSize()
		Return fl.GetAt(i) as ObjectReference
	EndIf
	fl = F(0x00ecaf) as FormList               ; CS_AllGarrisonSpawnPoints
	If fl && i < fl.GetSize()
		Return fl.GetAt(i) as ObjectReference
	EndIf
	Return None
EndFunction

Function Hostile(Actor a) Global
	Faction rf = RebelFaction()
	a.AddToFaction(rf)
	rf.SetPlayerEnemy(True)
	Faction pa = PlayerArmy()
	If pa
		rf.SetEnemy(pa)
	EndIf
	a.SetActorValue("Aggression", 1)
	a.EvaluatePackage()
EndFunction

Function SpawnTown(Int i) Global
	ObjectReference mk = TownMarker(i)
	If !mk
		Return
	EndIf
	Int n = Rebels(i)
	Int cap = CSN_Gov.BattleSize()
	If cap < 6
		cap = 6
	ElseIf cap > 20
		cap = 20
	EndIf
	If n > cap
		n = cap
	EndIf
	String lk = TK(i, "spawn")
	Actor leader = StorageUtil.GetFormValue(None, TK(i, "leader")) as Actor
	If !leader || leader.IsDead()
		leader = mk.PlaceActorAtMe(RebelSoldier())
		leader.SetDisplayName("Rebel Leader of " + CSN_World.TownName(i), True)
		StorageUtil.SetFormValue(None, TK(i, "leader"), leader)
		StorageUtil.SetIntValue(None, TK(i, "leaderspawned"), 1)
	ElseIf !leader.Is3DLoaded()
		leader.MoveTo(mk)
	EndIf
	Hostile(leader)
	CSN_Journal.Leader(i, leader)
	Int k = 1
	While k < n
		ActorBase b = RebelSoldier()
		If k % 3 == 0
			b = RebelArcher()
		EndIf
		Actor r = mk.PlaceActorAtMe(b)
		Hostile(r)
		StorageUtil.FormListAdd(None, lk, r)
		k += 1
	EndWhile
	StorageUtil.FormListAdd(None, lk, leader)
	CSN_Gov.Say("The rebels of " + CSN_World.TownName(i) + " are in the streets. Strike down their leader to end the rising, or meet their demands.")
EndFunction

; dead rebels lower the count; a dead leader ends the rising
Function CountTown(Int i) Global
	String lk = TK(i, "spawn")
	Actor leader = StorageUtil.GetFormValue(None, TK(i, "leader")) as Actor
	Int dead = 0
	Int k = StorageUtil.FormListCount(None, lk) - 1
	While k >= 0
		Actor r = StorageUtil.FormListGet(None, lk, k) as Actor
		If !r || r.IsDead()
			If r != leader
				dead += 1
				StorageUtil.FormListRemoveAt(None, lk, k)
			EndIf
		EndIf
		k -= 1
	EndWhile
	If dead > 0
		StorageUtil.AdjustIntValue(None, TK(i, "rebels"), -dead)
	EndIf
	If leader && leader.IsDead()
		CSN_Core m = M()
		String town = CSN_World.TownName(i)
		Int rest = StorageUtil.FormListCount(None, lk) - 1
		; the others throw down their arms
		k = StorageUtil.FormListCount(None, lk) - 1
		While k >= 0
			Actor r = StorageUtil.FormListGet(None, lk, k) as Actor
			If r && !r.IsDead() && r != leader
				r.StopCombat()
				r.RemoveFromFaction(RebelFaction())
				r.SetActorValue("Aggression", 0)
				r.SetRelationshipRank(Game.GetPlayer(), 0)
			EndIf
			k -= 1
		EndWhile
		StorageUtil.SetIntValue(None, TK(i, "out"), 1)
		String txt = Game.GetPlayer().GetDisplayName() + " struck down the rebel leader of " + town + ". The rising is broken; the rebels lay down their arms."
		CSN_World.AddNews(i, txt, "csn_uprising_crushed")
		CSNP.Notice(txt)
		DespawnLater(i)
		EndUprisingKeep(i)
	EndIf
EndFunction

; the rising is over but the people in the streets stay until the player leaves
Function EndUprisingKeep(Int i) Global
	CSN_Journal.UnrestOver(i, True)
	RestoreTax(i)
	SetStage(i, 0)
	StorageUtil.SetIntValue(None, TK(i, "rebels"), 0)
	StorageUtil.SetIntValue(None, TK(i, "calm"), Today() + 3)
	If CSN_World.TownLoyalty(i) < Threshold()
		M().Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(i), Threshold() - CSN_World.TownLoyalty(i))
	EndIf
EndFunction

Function DespawnLater(Int i) Global
	String lk = TK(i, "spawn")
	Int k = 0
	While k < StorageUtil.FormListCount(None, lk)
		StorageUtil.FormListAdd(None, "csn_reb_cleanup", StorageUtil.FormListGet(None, lk, k))
		k += 1
	EndWhile
	StorageUtil.FormListClear(None, lk)
	StorageUtil.SetIntValue(None, TK(i, "out"), 0)
EndFunction

Function DespawnTown(Int i) Global
	String lk = TK(i, "spawn")
	Actor leader = StorageUtil.GetFormValue(None, TK(i, "leader")) as Actor
	Bool own = StorageUtil.GetIntValue(None, TK(i, "leaderspawned"), 0) == 1
	Int k = StorageUtil.FormListCount(None, lk) - 1
	While k >= 0
		Actor r = StorageUtil.FormListGet(None, lk, k) as Actor
		If r
			If r == leader && !own
				; a real townsperson leads them: they go home, not away
				r.StopCombat()
				r.RemoveFromFaction(RebelFaction())
				r.SetActorValue("Aggression", 0)
			Else
				r.Disable()
				r.Delete()
			EndIf
		EndIf
		k -= 1
	EndWhile
	StorageUtil.FormListClear(None, lk)
	StorageUtil.SetIntValue(None, TK(i, "out"), 0)
	If own && Stage(i) != 2
		StorageUtil.UnsetFormValue(None, TK(i, "leader"))
		StorageUtil.UnsetIntValue(None, TK(i, "leaderspawned"))
	EndIf
	Cleanup()
EndFunction

; rebels left standing after a rising ended go once the player is away from them
Function Cleanup() Global
	Int k = StorageUtil.FormListCount(None, "csn_reb_cleanup") - 1
	While k >= 0
		Actor r = StorageUtil.FormListGet(None, "csn_reb_cleanup", k) as Actor
		If !r
			StorageUtil.FormListRemoveAt(None, "csn_reb_cleanup", k)
		ElseIf !r.Is3DLoaded()
			If r.GetActorBase() == RebelSoldier() || r.GetActorBase() == RebelArcher()
				r.Disable()
				r.Delete()
			EndIf
			StorageUtil.FormListRemoveAt(None, "csn_reb_cleanup", k)
		EndIf
		k -= 1
	EndWhile
EndFunction

; =============================================================================
; ARMY MORALE
; =============================================================================
Int Function Morale(Int a) Global
	Return StorageUtil.GetIntValue(None, "csn_mor_" + a, 70)
EndFunction

Function SetMorale(Int a, Int v) Global
	If v < 0
		v = 0
	ElseIf v > 100
		v = 100
	EndIf
	StorageUtil.SetIntValue(None, "csn_mor_" + a, v)
EndFunction

; morale a star gives an army at once
Int Function StarMorale() Global
	Return 15
EndFunction

; one line for an army leader's own knowledge
String Function MoraleLine(Int a) Global
	String s = "Morale in their army is " + MoraleWord(Morale(a)) + " (" + Morale(a) + " out of 100); they feel it themselves and say so honestly when asked."
	String g = ArmyGrievances(a)
	If g != ""
		s += " The troops complain of " + g + "."
	EndIf
	String note = StorageUtil.GetStringValue(None, "csn_mor_note_" + a, "")
	If note != ""
		s += " Latest change: " + note + "."
	EndIf
	s += " A star for their leader lifts it at once (+" + StarMorale() + "); pay, food, rest and granted requests raise it, and if it breaks the army may leave the faction."
	Return s
EndFunction

Function ModMorale(Int a, Int aiBy, String asWhy = "") Global
	If a < 0
		Return
	EndIf
	SetMorale(a, Morale(a) + aiBy)
	If asWhy != ""
		StorageUtil.SetStringValue(None, "csn_mor_note_" + a, asWhy)
	EndIf
EndFunction

String Function MoraleWord(Int v) Global
	If v >= 80
		Return "high"
	ElseIf v >= 60
		Return "steady"
	ElseIf v >= 40
		Return "low"
	ElseIf v >= 20
		Return "very low: the troops grumble openly"
	EndIf
	Return "broken: talk of leaving the faction"
EndFunction

Bool Function Unpaid() Global
	CSN_Core m = M()
	Int t = CSN_Gov.Treasury()
	Return t < 0 || (t + m.Holdings().TreasuryPerDay.GetValueInt() < 0)
EndFunction

Bool Function Starving() Global
	CSN_Core m = M()
	Int f = m.Holdings().FoodReserve.GetValueInt()
	Return f < 0 || (f == 0 && m.Holdings().FoodPerDay.GetValueInt() < 0)
EndFunction

; days the army has been posted away from its home holding (camps, garrisons, marching with the player)
Int Function AwayDays(Int a) Global
	Return StorageUtil.GetIntValue(None, "csn_mor_away_" + a, 0)
EndFunction

String Function ArmyGrievances(Int a) Global
	String s = ""
	If Unpaid()
		s = AddTo(s, "unpaid wages")
	EndIf
	If Starving()
		s = AddTo(s, "empty bellies")
	EndIf
	If AwayDays(a) >= 10
		s = AddTo(s, AwayDays(a) + " days in the field without rest")
	EndIf
	If StorageUtil.GetIntValue(None, "csn_mor_denied_" + a, 0) > 0
		s = AddTo(s, "requests their leader made were refused")
	EndIf
	Return s
EndFunction

Function DailyArmies() Global
	CSN_Core m = M()
	CS_PatrolHoldScript ar = m.Armies()
	Int a = 0
	While a < ar.Commanders.Length
		Actor c = ar.Commanders[a].GetActorRef()
		If c && !c.IsDead()
			; away from home: anything but the home holding or hunting
			String task = m.ArmyTask(a)
			If StringUtil.Find(task, "Home") >= 0 || StringUtil.Find(task, "No orders") >= 0 || StringUtil.Find(task, "Hunt") >= 0
				StorageUtil.SetIntValue(None, "csn_mor_away_" + a, 0)
			Else
				StorageUtil.AdjustIntValue(None, "csn_mor_away_" + a, 1)
			EndIf
			Int d = 0
			Bool grief = False
			If Unpaid()
				d -= 8
				grief = True
			EndIf
			If Starving()
				d -= 8
				grief = True
			EndIf
			If AwayDays(a) >= 10
				d -= 2
				grief = True
			EndIf
			If StorageUtil.GetIntValue(None, "csn_mor_denied_" + a, 0) > 0
				StorageUtil.AdjustIntValue(None, "csn_mor_denied_" + a, -1)
				grief = True
			EndIf
			If !grief && Morale(a) < 80
				d += 3
			EndIf
			Int was = Morale(a)
			ModMorale(a, d)
			Int now = Morale(a)
			String nm = CSN_Gov.ArmyLabel(a)
			If was >= 30 && now < 30
				String txt = "The troops of " + nm + " are close to mutiny: " + ArmyGrievances(a) + "."
				CSN_Gov.Say(txt)
				CSN_SkyrimNet.LogEvent(txt, c, Game.GetPlayer())
			EndIf
			Int limit = SecedeAt() - 2 * CSN_Gov.Stars(c)
			If now < limit && grief
				If StorageUtil.GetIntValue(None, "csn_mor_low_" + a, 0) >= 1 && Utility.RandomInt(1, 100) <= 50
					Secede(a)
				Else
					StorageUtil.AdjustIntValue(None, "csn_mor_low_" + a, 1)
				EndIf
			Else
				StorageUtil.SetIntValue(None, "csn_mor_low_" + a, 0)
			EndIf
		EndIf
		a += 1
	EndWhile
EndFunction

; hooks from requests and stars
; morale change when the leader answers a request that concerns an army
; aiKind: 3 the army leader's own request, 4 a town asking for a famous army (security); aiChoice 0 accept, 1 deny, 2 middle
Int Function RequestMorale(Int aiKind, Int aiChoice) Global
	If aiKind == 3
		If aiChoice == 0
			Return 6
		ElseIf aiChoice == 2
			Return 3
		EndIf
		Return -8
	ElseIf aiKind == 4
		; honoured with a post the people asked for them by name; refused, the troops feel slighted
		If aiChoice == 1
			Return -3
		EndIf
		Return 4
	EndIf
	Return 0
EndFunction

Function RequestAnswered(Int aiArmy, Int aiKind, Int aiChoice) Global
	If aiArmy < 0
		Return
	EndIf
	Int d = RequestMorale(aiKind, aiChoice)
	If d == 0
		Return
	EndIf
	Int was = Morale(aiArmy)
	String why = "a request was granted"
	If aiChoice == 1
		why = "a request was refused"
		If aiKind == 3
			StorageUtil.SetIntValue(None, "csn_mor_denied_" + aiArmy, 3)
		EndIf
	ElseIf aiChoice == 2
		why = "a request was met halfway"
	EndIf
	If aiKind == 4
		If aiChoice == 1
			why = "the leader refused a town that asked for them by name"
		Else
			why = "a town asked for them by name and the leader sent them"
		EndIf
	EndIf
	ModMorale(aiArmy, d, why)
	CSN_Gov.Say("Morale in " + CSN_Gov.ArmyLabel(aiArmy) + ": " + was + " -> " + Morale(aiArmy) + " (" + why + ").")
EndFunction

; =============================================================================
; SECESSION: FREE COMPANIES
; =============================================================================
String Function WK(Int w, String asKey) Global
	Return "csn_wb_" + w + "_" + asKey
EndFunction

Bool Function BandAlive(Int w) Global
	Return StorageUtil.GetIntValue(None, WK(w, "on"), 0) == 1
EndFunction

Int Function FreeBand() Global
	Int w = 0
	While w < 10
		If !BandAlive(w)
			Return w
		EndIf
		w += 1
	EndWhile
	Return -1
EndFunction

String Function BandName(Int w) Global
	Return StorageUtil.GetStringValue(None, WK(w, "name"), "a free company")
EndFunction

Actor Function BandLeader(Int w) Global
	Return StorageUtil.GetFormValue(None, WK(w, "leader")) as Actor
EndFunction

Int Function BandTroops(Int w) Global
	Return StorageUtil.GetIntValue(None, WK(w, "troops"), 0)
EndFunction

; seat: kind 1 fort, 2 town, 3 hold
Int Function SeatKind(Int w) Global
	Return StorageUtil.GetIntValue(None, WK(w, "seatkind"), 3)
EndFunction

Int Function SeatIndex(Int w) Global
	Return StorageUtil.GetIntValue(None, WK(w, "seat"), 0)
EndFunction

String Function SeatName(Int w) Global
	CSN_Core m = M()
	If SeatKind(w) == 1
		Return m.FortName(SeatIndex(w))
	ElseIf SeatKind(w) == 2
		Return CSN_World.TownName(SeatIndex(w))
	EndIf
	Return m.HoldName(SeatIndex(w))
EndFunction

Location Function SeatLocation(Int w) Global
	CSN_Core m = M()
	If SeatKind(w) == 1
		Return m.Gov.AllLocationsFort.GetAt(SeatIndex(w)) as Location
	ElseIf SeatKind(w) == 2
		Return CSN_World.TownVanillaLocation(SeatIndex(w))
	EndIf
	Return m.Gov.AllHolds.GetAt(SeatIndex(w)) as Location
EndFunction

Bool Function Independent(Int w) Global
	Return StorageUtil.GetIntValue(None, WK(w, "free"), 0) == 1
EndFunction

; 0 hostile (raiding), 1 recognised (at peace)
Bool Function Recognised(Int w) Global
	Return StorageUtil.GetIntValue(None, WK(w, "peace"), 0) == 1
EndFunction

Int Function BandCount() Global
	Int n = 0
	Int w = 0
	While w < 10
		If BandAlive(w)
			n += 1
		EndIf
		w += 1
	EndWhile
	Return n
EndFunction

; the company that holds this fort (-1 none)
Int Function BandAtFort(Int f) Global
	Int w = 0
	While w < 10
		If BandAlive(w) && SeatKind(w) == 1 && SeatIndex(w) == f
			Return w
		EndIf
		w += 1
	EndWhile
	Return -1
EndFunction

Int Function BandOf(Actor a) Global
	Int w = 0
	While w < 10
		If BandAlive(w) && BandLeader(w) == a
			Return w
		EndIf
		w += 1
	EndWhile
	Return -1
EndFunction

Function Secede(Int a) Global
	CSN_Core m = M()
	Actor c = m.Commander(a)
	If !c
		Return
	EndIf
	Int w = FreeBand()
	If w < 0
		Return
	EndIf
	Int troops = m.ArmyTroops(a)
	If troops < 5
		troops = 5
	EndIf
	String label = CSN_Gov.ArmyLabel(a)
	String army = CSN_War.Name(a)
	String leaderName = m.PlainName(c)
	String name = "the Free Company of " + leaderName
	If army != ""
		name = "the Free " + army
	EndIf
	; where they were posted becomes their seat
	Location here = c.GetCurrentLocation()
	Int kind = 3
	Int seat = -1
	Int f = 0
	While f < m.FortCount() && seat < 0
		If At(here, m.Gov.AllLocationsFort.GetAt(f) as Location)
			kind = 1
			seat = f
		EndIf
		f += 1
	EndWhile
	If seat < 0
		Int t = CSN_World.TownOfLocation(here)
		If t >= 0
			kind = 2
			seat = t
		EndIf
	EndIf
	If seat < 0
		Int h = 0
		While h < m.HoldCount() && seat < 0
			If At(here, m.Gov.AllHolds.GetAt(h) as Location)
				seat = h
			EndIf
			h += 1
		EndWhile
	EndIf
	If seat < 0
		seat = 3
	EndIf
	StorageUtil.SetIntValue(None, WK(w, "on"), 1)
	StorageUtil.SetStringValue(None, WK(w, "name"), name)
	StorageUtil.SetFormValue(None, WK(w, "leader"), c)
	StorageUtil.SetIntValue(None, WK(w, "troops"), troops)
	StorageUtil.SetIntValue(None, WK(w, "seatkind"), kind)
	StorageUtil.SetIntValue(None, WK(w, "seat"), seat)
	StorageUtil.SetIntValue(None, WK(w, "since"), Today())
	StorageUtil.SetIntValue(None, WK(w, "free"), 0)
	StorageUtil.SetIntValue(None, WK(w, "peace"), 0)
	StorageUtil.SetIntValue(None, WK(w, "stars"), CSN_Gov.Stars(c))
	StorageUtil.AdjustIntValue(None, "csn_wb_count", 1)
	String why = ArmyGrievances(a)
	; out of the faction: CoS takes the army slot back
	m.FireCommander(c)
	SetMorale(a, 70)
	StorageUtil.SetIntValue(None, "csn_mor_low_" + a, 0)
	StorageUtil.SetIntValue(None, "csn_mor_away_" + a, 0)
	StorageUtil.SetStringValue(c, "csn_plainname", leaderName)
	c.SetDisplayName("Warlord " + leaderName, True)
	StorageUtil.SetIntValue(c, "csn_band", w + 1)
	Hostile(c)
	c.SetRelationshipRank(Game.GetPlayer(), -3)
	String txt = label + " has broken with the " + m.FactionName() + " over " + why + ". " + leaderName + " and " + troops + " troops now call themselves " + name + " and hold " + SeatNameFor(kind, seat) + "."
	CSN_World.AddNews(-1, txt, "csn_secession", c)
	CSNP.Notice(txt)
	CSN_SkyrimNet.LogEvent(txt, c, Game.GetPlayer())
	CSN_SkyrimNet.RefreshBio(c)
	CSN_Journal.Company(w, 10)
EndFunction

String Function SeatNameFor(Int aiKind, Int aiSeat) Global
	CSN_Core m = M()
	If aiKind == 1
		Return m.FortName(aiSeat)
	ElseIf aiKind == 2
		Return CSN_World.TownName(aiSeat)
	EndIf
	Return m.HoldName(aiSeat)
EndFunction

Function DailyBands() Global
	CSN_Core m = M()
	Int w = 0
	While w < 10
		If BandAlive(w)
			Actor ld = BandLeader(w)
			If !ld || ld.IsDead()
				Broken(w, "Their leader is dead.")
			ElseIf BandTroops(w) <= 0
				Broken(w, "Their last soldiers have deserted.")
			Else
				Int days = Today() - StorageUtil.GetIntValue(None, WK(w, "since"), Today())
				If !Independent(w) && days >= 3
					StorageUtil.SetIntValue(None, WK(w, "free"), 1)
					String realm = "the Free March of " + SeatName(w)
					StorageUtil.SetStringValue(None, WK(w, "realm"), realm)
					String txt = m.PlainName(ld) + " of " + BandName(w) + " has proclaimed " + realm + ", a realm of their own that answers to no jarl, Empire or Ulfric."
					CSN_World.AddNews(-1, txt, "csn_free_realm", ld)
					CSN_Gov.Say(txt)
				EndIf
				If Independent(w) && BandTroops(w) < 60
					StorageUtil.AdjustIntValue(None, WK(w, "troops"), 2)
				EndIf
				If !Recognised(w)
					Raid(w)
				EndIf
				; other discontented armies may join them
				Lure(w)
			EndIf
		EndIf
		w += 1
	EndWhile
EndFunction

Function Raid(Int w) Global
	CSN_Core m = M()
	Int n = BandTroops(w)
	Int gold = n * 20
	Int food = n / 2
	Int t = CSN_Gov.Treasury()
	If gold > t
		gold = t
	EndIf
	If gold < 0
		gold = 0
	EndIf
	Int fd = m.Holdings().FoodReserve.GetValueInt()
	If food > fd
		food = fd
	EndIf
	If food < 0
		food = 0
	EndIf
	m.Econ().Treasury.Mod(-gold)
	m.Holdings().FoodReserve.Mod(-food)
	If SeatKind(w) == 2 && CSN_World.PlayerRules(SeatIndex(w))
		m.Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(SeatIndex(w)), -2)
	ElseIf SeatKind(w) != 2
		Int h = SeatHold(w)
		If h >= 0 && h < 9 && CSN_World.PlayerRules(h)
			m.Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(h), -2)
		EndIf
	EndIf
	If gold + food > 0
		CSN_Gov.Say(BandName(w) + " raided your supply lines: " + gold + " gold and " + food + " food taken.")
	EndIf
EndFunction

; hold of the company's seat (forts by their hold)
Int Function SeatHold(Int w) Global
	CSN_Core m = M()
	If SeatKind(w) == 3
		Return SeatIndex(w)
	EndIf
	Location loc = SeatLocation(w)
	Int h = 0
	While h < m.HoldCount()
		If At(loc, m.Gov.AllHolds.GetAt(h) as Location)
			Return h
		EndIf
		h += 1
	EndWhile
	Return -1
EndFunction

Function Lure(Int w) Global
	If Recognised(w)
		Return
	EndIf
	CSN_Core m = M()
	CS_PatrolHoldScript ar = m.Armies()
	Int a = 0
	While a < ar.Commanders.Length
		Actor c = ar.Commanders[a].GetActorRef()
		If c && !c.IsDead() && Morale(a) < 25 && ArmyGrievances(a) != "" && Utility.RandomInt(1, 100) <= 15
			Int n = m.ArmyTroops(a)
			String label = CSN_Gov.ArmyLabel(a)
			String nm = m.PlainName(c)
			m.FireCommander(c)
			SetMorale(a, 70)
			c.SetDisplayName("Captain " + nm, True)
			StorageUtil.SetIntValue(c, "csn_band", w + 1)
			Hostile(c)
			c.SetRelationshipRank(Game.GetPlayer(), -3)
			StorageUtil.AdjustIntValue(None, WK(w, "troops"), n)
			String txt = nm + " led " + label + " (" + n + " troops) over to " + BandName(w) + "."
			CSN_World.AddNews(-1, txt, "csn_secession", c)
			CSNP.Notice(txt)
			Return
		EndIf
		a += 1
	EndWhile
EndFunction

Function Broken(Int w, String asWhy) Global
	CSN_Journal.CompanyOver(w)
	String txt = BandName(w) + " has broken up. " + asWhy
	DespawnBand(w)
	StorageUtil.SetIntValue(None, WK(w, "on"), 0)
	StorageUtil.AdjustIntValue(None, "csn_wb_count", -1)
	CSN_World.AddNews(-1, txt, "csn_company_broken")
	CSN_Gov.Say(txt)
EndFunction

; ---- fighting them in person --------------------------------------------------------
Function WatchBand(Int w, Location akHere) Global
	Bool there = At(akHere, SeatLocation(w))
	Int spawned = StorageUtil.FormListCount(None, WK(w, "spawn"))
	If there && spawned == 0 && !Recognised(w)
		SpawnBand(w)
	ElseIf !there && spawned > 0
		DespawnBand(w)
	ElseIf spawned > 0
		CountBand(w)
	EndIf
EndFunction

ObjectReference Function BandMarker(Int w, Int k) Global
	CSN_Core m = M()
	If SeatKind(w) == 1
		FormList fl = F(0x1fdace + SeatIndex(w)) as FormList   ; CS_AttackFortSpawn<Fort>
		If fl && fl.GetSize() > 0
			Return fl.GetAt(k % fl.GetSize()) as ObjectReference
		EndIf
	ElseIf SeatKind(w) == 2
		Return TownMarker(SeatIndex(w))
	EndIf
	Return Game.GetPlayer()
EndFunction

Function SpawnBand(Int w) Global
	Int n = BandTroops(w)
	Int cap = CSN_Gov.BattleSize()
	If cap < 6
		cap = 6
	ElseIf cap > 20
		cap = 20
	EndIf
	If n > cap
		n = cap
	EndIf
	String lk = WK(w, "spawn")
	Actor ld = BandLeader(w)
	If SeatKind(w) == 3
		; out in the hold: they find the player
		ld.MoveTo(Game.GetPlayer(), 1800.0, 1800.0, 0.0)
	ElseIf !ld.Is3DLoaded()
		ld.MoveTo(BandMarker(w, 0))
	EndIf
	Hostile(ld)
	ld.StartCombat(Game.GetPlayer())
	Int k = 0
	While k < n
		ActorBase b = RebelSoldier()
		If k % 3 == 2
			b = RebelArcher()
		EndIf
		ObjectReference mk = BandMarker(w, k + 1)
		Actor r
		If SeatKind(w) == 3
			r = ld.PlaceActorAtMe(b)
		Else
			r = mk.PlaceActorAtMe(b)
		EndIf
		Hostile(r)
		StorageUtil.FormListAdd(None, lk, r)
		k += 1
	EndWhile
	StorageUtil.FormListAdd(None, lk, ld)
	CSN_Gov.Say(BandName(w) + " stands against you. Kill " + M().PlainName(ld) + " to break the company.")
EndFunction

Function CountBand(Int w) Global
	String lk = WK(w, "spawn")
	Actor ld = BandLeader(w)
	Int dead = 0
	Int k = StorageUtil.FormListCount(None, lk) - 1
	While k >= 0
		Actor r = StorageUtil.FormListGet(None, lk, k) as Actor
		If r != ld && (!r || r.IsDead())
			dead += 1
			StorageUtil.FormListRemoveAt(None, lk, k)
		EndIf
		k -= 1
	EndWhile
	If dead > 0
		StorageUtil.AdjustIntValue(None, WK(w, "troops"), -dead)
	EndIf
	If ld && ld.IsDead()
		String txt = Game.GetPlayer().GetDisplayName() + " killed " + M().PlainName(ld) + "; " + BandName(w) + " is no more."
		CSN_World.AddNews(-1, txt, "csn_company_broken")
		Broken(w, "Their leader fell in battle.")
	EndIf
EndFunction

Function DespawnBand(Int w) Global
	String lk = WK(w, "spawn")
	Actor ld = BandLeader(w)
	Int k = StorageUtil.FormListCount(None, lk) - 1
	While k >= 0
		Actor r = StorageUtil.FormListGet(None, lk, k) as Actor
		If r && r != ld
			r.Disable()
			r.Delete()
		EndIf
		k -= 1
	EndWhile
	StorageUtil.FormListClear(None, lk)
EndFunction

; ---- sending a loyal army against them ---------------------------------------------
Bool Function SendArmy(Int w, Int a, Actor akVia = None) Global
	CSN_Core m = M()
	If !BandAlive(w)
		CSN_Gov.Fail("That company is gone.")
		Return False
	EndIf
	Actor c = m.Commander(a)
	If !c || c.IsDead()
		CSN_Gov.Fail("That army has no leader.")
		Return False
	EndIf
	Int ours = m.ArmyTroops(a)
	Int theirs = BandTroops(w)
	Float power = ours * (1.0 + 0.15 * CSN_Gov.Stars(c)) * (0.75 + Morale(a) / 200.0)
	Float enemy = theirs * (1.0 + 0.1 * StorageUtil.GetIntValue(None, WK(w, "stars"), 0))
	String odds = "even"
	If power > enemy * 1.5
		odds = "good"
	ElseIf power < enemy * 0.7
		odds = "poor"
	EndIf
	If !CSNP.Confirm("Send an army", "Send " + CSN_Gov.ArmyLabel(a) + " (" + ours + " troops, morale " + Morale(a) + ") against " + BandName(w) + " (" + theirs + " troops) at " + SeatName(w) + "?\n\nThe odds look " + odds + ". If they lose, the army falls back with its morale shaken.", "Send them", "Not now")
		Return False
	EndIf
	Float roll = Utility.RandomFloat(0.75, 1.25)
	Actor ld = BandLeader(w)
	If power * roll >= enemy
		String txt = CSN_Gov.ArmyLabel(a) + " routed " + BandName(w) + " at " + SeatName(w) + ". " + m.PlainName(ld) + " was killed."
		If ld && !ld.Is3DLoaded()
			ld.Kill()
		EndIf
		ModMorale(a, 10, "victory over the deserters")
		CSN_World.AddNews(-1, txt, "csn_company_broken", c)
		CSN_SkyrimNet.LogEvent(txt, c, Game.GetPlayer())
		Broken(w, "They were defeated by " + CSN_Gov.ArmyLabel(a) + ".")
		CSNP.Notice(txt)
	Else
		StorageUtil.AdjustIntValue(None, WK(w, "troops"), -(theirs / 5))
		ModMorale(a, -20, "beaten by the deserters")
		String lostTxt = CSN_Gov.ArmyLabel(a) + " was beaten back by " + BandName(w) + " at " + SeatName(w) + "."
		CSN_World.AddNews(-1, lostTxt, "csn_company_victory", c)
		CSN_SkyrimNet.LogEvent(lostTxt, c, Game.GetPlayer())
		CSNP.Notice(lostTxt)
	EndIf
	m.Refresh()
	Return True
EndFunction

; ---- paying them back into service --------------------------------------------------
Int Function ArrearsGold(Int w) Global
	Return BandTroops(w) * 150
EndFunction

Int Function ArrearsFood(Int w) Global
	Return BandTroops(w)
EndFunction

Bool Function PayArrears(Int w) Global
	CSN_Core m = M()
	Actor ld = BandLeader(w)
	If !BandAlive(w) || !ld
		Return False
	EndIf
	Int g = ArrearsGold(w)
	Int fd = ArrearsFood(w)
	If m.FreeArmySlot() < 0
		CSN_Gov.Fail("There is no free army slot to take them back. Claim another holding first.")
		Return False
	EndIf
	If !CSNP.Confirm("Pay their arrears", "Pay " + BandName(w) + " what they say they are owed: " + g + " gold and " + fd + " food?\n\n" + m.PlainName(ld) + " swears back into the faction as a Captain. Most of the men take their pay and go home, so the army is raised again from the start. Treasury " + CSN_Gov.Treasury() + ", food " + CSN_Gov.Stock(0) + ".", "Pay them", "Not now")
		Return False
	EndIf
	If CSN_Gov.Treasury() < g
		CSN_Gov.Fail("The treasury holds " + CSN_Gov.Treasury() + " gold; " + g + " needed.")
		Return False
	EndIf
	If !CSN_Gov.Spend(0, fd)
		Return False
	EndIf
	m.Econ().Treasury.Mod(-g)
	DespawnBand(w)
	CSN_Journal.CompanyOver(w)
	String name = BandName(w)
	StorageUtil.SetIntValue(None, WK(w, "on"), 0)
	StorageUtil.AdjustIntValue(None, "csn_wb_count", -1)
	ld.StopCombat()
	ld.RemoveFromFaction(RebelFaction())
	ld.SetActorValue("Aggression", 0)
	ld.SetRelationshipRank(Game.GetPlayer(), 1)
	StorageUtil.UnsetIntValue(ld, "csn_band")
	m.ClearTitle(ld)
	m.HireCommander(ld)
	Int a = m.GetArmy(ld)
	If a >= 0
		SetMorale(a, 60)
	EndIf
	String txt = Game.GetPlayer().GetDisplayName() + " paid the arrears of " + name + "; " + m.PlainName(ld) + " swore back into the " + m.FactionName() + "."
	CSN_World.AddNews(-1, txt, "csn_company_returned", ld)
	CSN_SkyrimNet.LogEvent(txt, ld, Game.GetPlayer())
	m.Refresh()
	Return True
EndFunction

; ---- recognising them ---------------------------------------------------------------
Bool Function Recognise(Int w) Global
	CSN_Core m = M()
	Actor ld = BandLeader(w)
	If !BandAlive(w) || Recognised(w)
		Return False
	EndIf
	String realm = StorageUtil.GetStringValue(None, WK(w, "realm"), BandName(w))
	If !CSNP.Confirm("Recognise their independence", "Recognise " + realm + " and make peace with " + m.PlainName(ld) + "?\n\nThe raids stop and they keep " + SeatName(w) + ". Your people may see it as weakness: loyalty in every town you rule falls by 5.", "Recognise them", "Not now")
		Return False
	EndIf
	StorageUtil.SetIntValue(None, WK(w, "peace"), 1)
	StorageUtil.SetIntValue(None, WK(w, "free"), 1)
	CSN_Journal.CompanyOver(w)
	StorageUtil.SetStringValue(None, WK(w, "realm"), realm)
	DespawnBand(w)
	If ld
		ld.StopCombat()
		ld.RemoveFromFaction(RebelFaction())
		ld.SetActorValue("Aggression", 0)
		ld.SetRelationshipRank(Game.GetPlayer(), 0)
	EndIf
	Int t = 0
	While t < 15
		If CSN_World.PlayerRules(t)
			m.Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(t), -5)
		EndIf
		t += 1
	EndWhile
	String txt = Game.GetPlayer().GetDisplayName() + " recognised " + realm + ", ruled by " + m.PlainName(ld) + ", as a free realm at peace with the " + m.FactionName() + "."
	CSN_World.AddNews(-1, txt, "csn_free_realm", ld)
	CSN_SkyrimNet.LogEvent(txt, ld, Game.GetPlayer())
	m.Refresh()
	Return True
EndFunction

; =============================================================================
; TEXT FOR THE SCREENS AND SKYRIMNET
; =============================================================================
String Function Q(String s) Global
	Return M().Q(s)
EndFunction

String Function Json() Global
	CSN_Core m = M()
	String s = "{\"threshold\":" + Threshold() + ",\"civil\":" + m.B(Enabled()) + ",\"military\":" + m.B(MilitaryEnabled()) + ",\"towns\":["
	Bool first = True
	Int i = 0
	While i < 15
		If CSN_World.PlayerRules(i)
			If !first
				s += ","
			EndIf
			first = False
			s += "{\"i\":" + i + ",\"name\":" + Q(CSN_World.TownName(i)) + ",\"loyalty\":" + CSN_World.TownLoyalty(i) + ",\"stage\":" + Stage(i)
			s += ",\"why\":" + Q(Grievances(i)) + ",\"rebels\":" + Rebels(i) + ",\"garrison\":" + Garrison(i)
			Int left = UprisingDays() - DaysUp(i)
			s += ",\"left\":" + left + ",\"gold\":" + DemandGold(i) + ",\"food\":" + DemandFood(i) + "}"
		EndIf
		i += 1
	EndWhile
	s += "],\"armies\":["
	first = True
	CS_PatrolHoldScript ar = m.Armies()
	Int a = 0
	While a < ar.Commanders.Length
		Actor c = ar.Commanders[a].GetActorRef()
		If c
			If !first
				s += ","
			EndIf
			first = False
			s += "{\"i\":" + a + ",\"name\":" + Q(CSN_Gov.ArmyLabel(a)) + ",\"leader\":" + Q(m.PlainName(c)) + ",\"troops\":" + m.ArmyTroops(a)
			s += ",\"morale\":" + Morale(a) + ",\"why\":" + Q(ArmyGrievances(a)) + ",\"limit\":" + (SecedeAt() - 2 * CSN_Gov.Stars(c)) + "}"
		EndIf
		a += 1
	EndWhile
	s += "],\"bands\":["
	first = True
	Int w = 0
	While w < 10
		If BandAlive(w)
			If !first
				s += ","
			EndIf
			first = False
			s += "{\"w\":" + w + ",\"name\":" + Q(BandName(w)) + ",\"leader\":" + Q(m.PlainName(BandLeader(w))) + ",\"troops\":" + BandTroops(w)
			s += ",\"seat\":" + Q(SeatName(w)) + ",\"free\":" + m.B(Independent(w)) + ",\"peace\":" + m.B(Recognised(w))
			s += ",\"realm\":" + Q(StorageUtil.GetStringValue(None, WK(w, "realm"), "")) + ",\"gold\":" + ArrearsGold(w) + ",\"food\":" + ArrearsFood(w) + "}"
		EndIf
		w += 1
	EndWhile
	Return s + "]}"
EndFunction

; what this NPC knows about rebellions
String Function Knowledge(Actor akActor) Global
	CSN_Core m = M()
	If !m || m.FactionStarted.GetValue() < 1 || !akActor
		Return ""
	EndIf
	String s = ""
	Int t = CSN_World.TownOf(akActor)
	If t >= 0 && CSN_World.PlayerRules(t)
		If Stage(t) == 1
			s += " There is unrest in " + CSN_World.TownName(t) + " over " + Grievances(t) + "; people talk of rising up."
		ElseIf Stage(t) == 2
			s += " The people of " + CSN_World.TownName(t) + " have risen against the " + m.FactionName() + " over " + StorageUtil.GetStringValue(None, TK(t, "why"), "their grievances") + "; " + Rebels(t) + " armed rebels hold the streets and want gold, food and lower taxes."
		EndIf
	EndIf
	Int a = m.GetArmy(akActor)
	Int role = m.GetRole(akActor)
	If a >= 0
		s += " Morale in " + CSN_Gov.ArmyLabel(a) + " is " + MoraleWord(Morale(a)) + " (" + Morale(a) + "/100)."
		String g = ArmyGrievances(a)
		If g != ""
			s += " The troops complain of " + g + "."
		EndIf
	ElseIf role == m.ROLE_GENERAL || role == m.ROLE_STEWARD
		CS_PatrolHoldScript ar = m.Armies()
		Int k = 0
		While k < ar.Commanders.Length
			If ar.Commanders[k].GetActorRef() && Morale(k) < 40
				s += " Morale in " + CSN_Gov.ArmyLabel(k) + " is " + MoraleWord(Morale(k)) + "."
			EndIf
			k += 1
		EndWhile
	EndIf
	Int w = BandOf(akActor)
	If w >= 0
		s += " " + m.PlainName(akActor) + " leads " + BandName(w) + ", " + BandTroops(w) + " soldiers who broke away from the " + m.FactionName() + " and hold " + SeatName(w) + "."
		If Independent(w)
			s += " They have proclaimed " + StorageUtil.GetStringValue(None, WK(w, "realm"), "a free realm") + " and answer to no one."
		EndIf
		If Recognised(w)
			s += " " + Game.GetPlayer().GetDisplayName() + " has recognised them; there is peace for now."
		Else
			s += " They are at war with " + Game.GetPlayer().GetDisplayName() + " and raid the faction's supplies. They would come back for their arrears (" + ArrearsGold(w) + " gold and " + ArrearsFood(w) + " food)."
		EndIf
	ElseIf BandCount() > 0 && (a >= 0 || role >= 0)
		Int kb = 0
		While kb < 10
			If BandAlive(kb)
				s += " " + BandName(kb) + " (" + BandTroops(kb) + " deserters under " + m.PlainName(BandLeader(kb)) + ") holds " + SeatName(kb) + "."
			EndIf
			kb += 1
		EndWhile
	EndIf
	Return s
EndFunction
