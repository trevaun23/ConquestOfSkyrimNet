Scriptname CS_ChooseTroopRacesScript extends Quest  conditional

Message Property MenuStart Auto
Message Property RaceAdd1 Auto
Message Property RaceAdd2 Auto
Message Property RaceRemove1 Auto
Message Property RaceRemove2 Auto
Message Property GenderAdd Auto
Message Property GenderRemove Auto

ReferenceAlias[] Property AllowedRaces Auto
ReferenceAlias[] Property AllowedGenders Auto

FormList Property AllowedRacesGlobals Auto
FormList Property AllowedGendersGlobals Auto
FormList Property AllRaces Auto
FormList Property AllowedRacesList Auto

ObjectReference[] Property AllowedRacesObjects Auto
ObjectReference[] Property AllowedGendersObjects Auto
ObjectReference Property NoneObject Auto

CS_TroopRaceUpdaterScript Property RaceUpdater Auto

int Property NumRaces Auto Conditional
int Property NumGenders Auto Conditional

bool Property ChangeDetected Auto

Function AdjustAliases()
	NumRaces = 0
	NumGenders = 0
	int i = 0
	while i < AllowedRaces.Length
		AllowedRaces[i].ForceRefTo(NoneObject)
		i += 1
	endwhile
	i = 0
	while i < AllowedGenders.Length
		AllowedGenders[i].ForceRefTo(NoneObject)
		i += 1
	endwhile
	i = 0
	while i < AllowedRacesGlobals.GetSize()
		if (AllowedRacesGlobals.GetAt(i) as GlobalVariable).GetValue() == 1
			AllowedRaces[NumRaces].ForceRefTo(AllowedRacesObjects[i])
			NumRaces += 1
		endif
		i += 1
	endwhile
	i = 0
	while i < AllowedGendersGlobals.GetSize()
		if (AllowedGendersGlobals.GetAt(i) as GlobalVariable).GetValue() == 1
			AllowedGenders[NumGenders].ForceRefTo(AllowedGendersObjects[i])
			NumGenders += 1
		endif
		i += 1
	endwhile
EndFunction

Function StartMenu(int Response = 0)
	AdjustAliases()
	Response = CSNP.Show(MenuStart, self)
	if Response == 0
		RaceAdd1Menu()
	elseif Response == 1
		RaceRemove1Menu()
	elseif Response == 2
		GenderAddMenu()
	elseif Response == 3
		GenderRemoveMenu()
	elseif Response == 4
		If ChangeDetected == true
			debug.notification("Updating Troop Races, this may take awhile...")
			RaceUpdater.UpdateRaces()
			RaceUpdater.ResetTroops()
			ChangeDetected = false
		EndIf
	endif
endFunction

Function RaceAdd1Menu(int Response = 0)
	Response = CSNP.Show(RaceAdd1, self)
	if Response < 5
		ChangeDetected = true
		(AllowedRacesGlobals.GetAt(Response) as GlobalVariable).SetValue(1)
		AllowedRacesList.AddForm(AllRaces.GetAt(Response) as Race)
		AdjustAliases()
		RaceAdd1Menu()
	elseif Response == 5
		RaceAdd2Menu()
	elseif Response == 6
		StartMenu()
	endif
endFunction

Function RaceAdd2Menu(int Response = 0)
	Response = CSNP.Show(RaceAdd2, self)
	if Response == 0
		RaceAdd1Menu()
	elseif Response > 0 && Response < 6
		ChangeDetected = true
		(AllowedRacesGlobals.GetAt(Response + 4) as GlobalVariable).SetValue(1)
		AllowedRacesList.AddForm(AllRaces.GetAt(Response + 4) as Race)
		AdjustAliases()
		RaceAdd2Menu()
	elseif Response == 6
		StartMenu()
	endif
endFunction

Function RaceRemove1Menu(int Response = 0)
	Response = CSNP.Show(RaceRemove1, self)
	if Response < 5
		ChangeDetected = true
		(AllowedRacesGlobals.GetAt(Response) as GlobalVariable).SetValue(0)
		AllowedRacesList.RemoveAddedForm(AllRaces.GetAt(Response) as Race)
		AdjustAliases()
		RaceRemove1Menu()
	elseif Response == 5
		RaceRemove2Menu()
	elseif Response == 6
		StartMenu()
	endif
endFunction

Function RaceRemove2Menu(int Response = 0)
	Response = CSNP.Show(RaceRemove2, self)
	if Response == 0
		RaceRemove1Menu()
	elseif Response > 0 && Response < 6
		ChangeDetected = true
		(AllowedRacesGlobals.GetAt(Response + 4) as GlobalVariable).SetValue(0)
		AllowedRacesList.RemoveAddedForm(AllRaces.GetAt(Response + 4) as Race)
		AdjustAliases()
		RaceRemove2Menu()
	elseif Response == 6
		StartMenu()
	endif
endFunction

Function GenderAddMenu(int Response = 0)
	Response = CSNP.Show(GenderAdd, self)
	if Response < 2
		ChangeDetected = true
		(AllowedGendersGlobals.GetAt(Response) as GlobalVariable).SetValue(1)
		AdjustAliases()
		GenderAddMenu()
	elseif Response == 2
		StartMenu()
	endif
endFunction

Function GenderRemoveMenu(int Response = 0)
	Response = CSNP.Show(GenderRemove, self)
	if Response < 2
		ChangeDetected = true
		(AllowedGendersGlobals.GetAt(Response) as GlobalVariable).SetValue(0)
		AdjustAliases()
		GenderRemoveMenu()
	elseif Response == 2
		StartMenu()
	endif
endFunction

; ---- Conquest of SkyrimNet: Blacksmith tab of the faction screen -------------
; Race 0-9 in the order of the menus (Argonian ... Wood Elf).
Function SetRace(int i, bool abOn)
	if i < 0 || i >= AllowedRacesGlobals.GetSize()
		return
	endif
	GlobalVariable g = AllowedRacesGlobals.GetAt(i) as GlobalVariable
	if (g.GetValue() == 1) == abOn
		return
	endif
	ChangeDetected = true
	if abOn
		g.SetValue(1)
		AllowedRacesList.AddForm(AllRaces.GetAt(i) as Race)
	else
		g.SetValue(0)
		AllowedRacesList.RemoveAddedForm(AllRaces.GetAt(i) as Race)
	endif
	AdjustAliases()
EndFunction

; Gender 0 male, 1 female.
Function SetGender(int i, bool abOn)
	if i < 0 || i >= AllowedGendersGlobals.GetSize()
		return
	endif
	GlobalVariable g = AllowedGendersGlobals.GetAt(i) as GlobalVariable
	if (g.GetValue() == 1) == abOn
		return
	endif
	ChangeDetected = true
	if abOn
		g.SetValue(1)
	else
		g.SetValue(0)
	endif
	AdjustAliases()
EndFunction

Function ApplyChanges()
	If ChangeDetected == true
		debug.notification("Updating Troop Races, this may take awhile...")
		RaceUpdater.UpdateRaces()
		RaceUpdater.ResetTroops()
		ChangeDetected = false
		debug.notification("Troop races and genders updated.")
	EndIf
EndFunction
