Scriptname CSN_World Hidden
{Conquest of SkyrimNet - what the common people of each town know and feel.

 * Watches Conquest of Skyrim's own data: who rules each town (AllHoldings), how loyal the town is
   (Loyalty keyword data, 0-100), who sits as Jarl, and which battles are being fought.
 * Turns changes into "news" that townsfolk remember: kept per town for a number of in-game days
   (MCM: SkyrimNet > News lasts) and logged as SkyrimNet events so NPCs who were there form memories.
 * Upgrades started from the CoS economy menus (farms, mills, mines, barracks) are reported the moment
   they are funded (hook in CS_UpgradeMenuFunctions).
 * CSN_SkyrimNet's decorators read the result, so every NPC knows who rules their town, how their
   neighbours feel about it, and what has happened there lately.

 All state is kept with PapyrusUtil StorageUtil on no form (global), under keys starting "csn_".}

; =============================================================================
; ACCESS
; =============================================================================
CSN_Core Function Main() Global
	Return Quest.GetQuest("CS_FactionGovernment") as CSN_Core
EndFunction

CS_LoyaltyCheckScript Function Loyalty() Global
	CSN_Core m = Main()
	If m && m.Gov
		Return m.Gov.LoyaltyScript
	EndIf
	Return None
EndFunction

Int Function TownCount() Global
	CS_LoyaltyCheckScript l = Loyalty()
	If !l || !l.AllLocations
		Return 0
	EndIf
	Return l.AllLocations.GetSize()
EndFunction

Location Function TownLocation(Int i) Global
	Return Loyalty().AllLocations.GetAt(i) as Location
EndFunction

Location Function TownVanillaLocation(Int i) Global
	CS_LoyaltyCheckScript l = Loyalty()
	If l.AllVanillaLocations && i < l.AllVanillaLocations.GetSize()
		Return l.AllVanillaLocations.GetAt(i) as Location
	EndIf
	Return TownLocation(i)
EndFunction

String Function TownName(Int i) Global
	Location loc = TownVanillaLocation(i)
	If !loc
		loc = TownLocation(i)
	EndIf
	If loc
		Return loc.GetName()
	EndIf
	Return "a town"
EndFunction

Int Function TownLoyalty(Int i) Global
	Location loc = TownLocation(i)
	If !loc
		Return 50
	EndIf
	Return loc.GetKeywordData(Loyalty().Loyalty) as Int
EndFunction

; CoS: 11 = Imperial Legion, 12 = Stormcloaks, player faction = TMPlayer.FactionNum
Int Function TownOwner(Int i) Global
	CSN_Core m = Main()
	If i >= m.Gov.AllHoldings.GetSize()
		Return 0
	EndIf
	GlobalVariable g = m.Gov.AllHoldings.GetAt(i) as GlobalVariable
	If g
		Return g.GetValueInt()
	EndIf
	Return 0
EndFunction

Bool Function PlayerRules(Int i) Global
	CSN_Core m = Main()
	Return m.FactionStarted.GetValue() >= 1 && TownOwner(i) == m.Gov.TMPlayer.FactionNum
EndFunction

String Function OwnerName(Int aiOwner) Global
	CSN_Core m = Main()
	If aiOwner == 11
		Return "the Imperial Legion"
	ElseIf aiOwner == 12
		Return "the Stormcloaks"
	ElseIf m.FactionStarted.GetValue() >= 1 && aiOwner == m.Gov.TMPlayer.FactionNum
		Return "the " + m.FactionName() + " (led by " + Game.GetPlayer().GetDisplayName() + ")"
	EndIf
	Return "no one in particular"
EndFunction

Actor Function TownJarl(Int i) Global
	CS_RecruitJarl r = Main().Gov.RecruitJarl
	If r && r.JarlAliases && i < r.JarlAliases.Length && r.JarlAliases[i]
		Return r.JarlAliases[i].GetActorRef()
	EndIf
	Return None
EndFunction

; Which CoS town an NPC belongs to: where they are now, else where they live. -1 if none.
Int Function TownOf(Actor akActor) Global
	If !akActor
		Return -1
	EndIf
	Int t = TownOfLocation(akActor.GetCurrentLocation())
	If t < 0
		t = TownOfLocation(akActor.GetEditorLocation())
	EndIf
	Return t
EndFunction

Int Function TownOfLocation(Location akLoc) Global
	If !akLoc
		Return -1
	EndIf
	Int n = TownCount()
	Int i = 0
	While i < n
		Location v = TownVanillaLocation(i)
		Location c = TownLocation(i)
		If (v && (akLoc == v || v.IsChild(akLoc))) || (c && (akLoc == c || c.IsChild(akLoc)))
			Return i
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

; =============================================================================
; OPINION (how the townsfolk feel)
; =============================================================================
String Function MoodWord(Int aiLoyalty) Global
	If aiLoyalty >= 80
		Return "devoted"
	ElseIf aiLoyalty >= 60
		Return "content"
	ElseIf aiLoyalty >= 40
		Return "uneasy"
	ElseIf aiLoyalty >= 20
		Return "resentful"
	EndIf
	Return "close to open revolt"
EndFunction

; How the town feels about the player's faction specifically (0-100).
Int Function PlayerFactionLiking(Int i) Global
	CSN_Core m = Main()
	If m.FactionStarted.GetValue() < 1
		Return -1
	EndIf
	If PlayerRules(i)
		Return TownLoyalty(i)
	EndIf
	Int base = 50 + StorageUtil.GetIntValue(None, "csn_goodwill_" + i, 0)
	Int owner = TownOwner(i)
	If (owner == 11 && m.AtWar(1)) || (owner == 12 && m.AtWar(2))
		; at war with their rulers: the more loyal the town, the less it likes you
		base -= (TownLoyalty(i) - 40) / 2
	EndIf
	If base < 0
		base = 0
	ElseIf base > 100
		base = 100
	EndIf
	Return base
EndFunction

String Function LikingWord(Int aiLiking) Global
	If aiLiking >= 80
		Return "admire"
	ElseIf aiLiking >= 60
		Return "think well of"
	ElseIf aiLiking >= 40
		Return "are undecided about"
	ElseIf aiLiking >= 20
		Return "distrust"
	EndIf
	Return "despise"
EndFunction

; =============================================================================
; NEWS
; =============================================================================
Float Function Now() Global
	Return Utility.GetCurrentGameTime()
EndFunction

; aiTown = -1 for news everyone in Skyrim hears about.
Function AddNews(Int aiTown, String asText, String asEventType, Actor akSource = None) Global
	; everything notable feeds the government's request study (CSN_Requests), even with town news off
	StorageUtil.AdjustIntValue(None, "csn_rq_notable", 1)
	StorageUtil.StringListAdd(None, "csn_rq_events", TownTag(aiTown) + asText)
	While StorageUtil.StringListCount(None, "csn_rq_events") > 12
		StorageUtil.StringListRemoveAt(None, "csn_rq_events", 0)
	EndWhile
	If !CSN_Config.WorldNews()
		Return
	EndIf
	String nkey = "csn_news_all"
	If aiTown >= 0
		nkey = "csn_news_" + aiTown
	EndIf
	StorageUtil.StringListAdd(None, nkey, Now() + "|" + asText)
	While StorageUtil.StringListCount(None, nkey) > 8
		StorageUtil.StringListRemoveAt(None, nkey, 0)
	EndWhile
	CSN_Config.Log("news (" + aiTown + "): " + asText)
	CSN_SkyrimNet.WorldEvent(asEventType, asText, akSource)
EndFunction

String Function TownTag(Int aiTown) Global
	If aiTown < 0
		Return ""
	EndIf
	Return "[" + TownName(aiTown) + "] "
EndFunction

; News still fresh for this town, then Skyrim-wide news, newest first, as "- when: text" lines.
String Function NewsText(Int aiTown, Int aiMax = 5) Global
	String own = NewsLines("csn_news_" + aiTown, aiMax)
	Int used = CountLines(own)
	If used >= aiMax
		Return own
	EndIf
	Return own + NewsLines("csn_news_all", aiMax - used)
EndFunction

String Function NewsLines(String asKey, Int aiMax) Global
	Float limit = CSN_Config.NewsDays() as Float
	Float t = Now()
	String s = ""
	Int shown = 0
	Int i = StorageUtil.StringListCount(None, asKey) - 1
	While i >= 0 && shown < aiMax
		String e = StorageUtil.StringListGet(None, asKey, i)
		Int bar = StringUtil.Find(e, "|")
		If bar > 0
			Float age = t - (StringUtil.Substring(e, 0, bar) as Float)
			If age <= limit
				s += "\n- " + AgeText(age) + ": " + StringUtil.Substring(e, bar + 1)
				shown += 1
			EndIf
		EndIf
		i -= 1
	EndWhile
	Return s
EndFunction

Int Function CountLines(String s) Global
	Int n = 0
	Int at = StringUtil.Find(s, "\n- ")
	While at >= 0
		n += 1
		at = StringUtil.Find(s, "\n- ", at + 3)
	EndWhile
	Return n
EndFunction

String Function AgeText(Float afDays) Global
	If afDays < 1.0
		Return "today"
	ElseIf afDays < 2.0
		Return "yesterday"
	EndIf
	Return (afDays as Int) + " days ago"
EndFunction

; =============================================================================
; UPGRADES (called from CS_UpgradeMenuFunctions)
; aiType: 0 barracks, 1 farms, 2 lumber mills, 3 mines
; =============================================================================
; A new law (conscription, punishments, religion). aiHolding = CoS law holding index, -1 = the whole faction.
Function NoteLaw(Int aiHolding, String asText) Global
	CSN_Core m = Main()
	If !m || m.FactionStarted.GetValue() < 1
		Return
	EndIf
	String where = "all lands of the " + m.FactionName()
	If aiHolding >= 0
		where = TownName(aiHolding)
	EndIf
	String txt = Game.GetPlayer().GetDisplayName() + " decreed a new law for " + where + ": " + asText
	AddNews(aiHolding, txt, "csn_new_law", None)
	CSN_Decrees.Remember(aiHolding, txt)
	If aiHolding >= 0
		CSN_SkyrimNet.AddHistory(aiHolding, txt)
	Else
		CSN_SkyrimNet.AddFactionHistory(txt)
	EndIf
EndFunction

String Function Percent(Float afAmount) Global
	If afAmount <= 1.0
		afAmount = afAmount * 100.0
	EndIf
	Return (afAmount as Int) + "%"
EndFunction

Function NoteUpgrade(Int aiTown, Int aiType, Bool abVillage, Int aiSteward) Global
	CSN_Core m = Main()
	If !m
		Return
	EndIf
	String town = TownName(aiTown)
	String what = "barracks"
	If aiType == 1
		what = "farms"
	ElseIf aiType == 2
		what = "lumber mills"
	ElseIf aiType == 3
		what = "mines"
	EndIf
	String who = OwnerName(TownOwner(aiTown))
	Actor jarl = TownJarl(aiTown)
	String text = "The " + what + " of " + town + " are being expanded, paid for by " + who
	If jarl
		text += " with the help of Jarl " + m.BaseName(jarl) + "'s court"
	EndIf
	If aiType == 1
		text += ". Farmers expect more food on the tables this season."
	ElseIf aiType == 2
		text += ". There will be work for woodcutters and carpenters."
	ElseIf aiType == 3
		text += ". Miners are being hired."
	Else
		text += ". More soldiers will be quartered in town."
	EndIf
	AddNews(aiTown, text, "csn_upgrade", jarl)
	; goodwill toward the player's faction when it is the one paying
	If PlayerRules(aiTown)
		StorageUtil.AdjustIntValue(None, "csn_goodwill_" + aiTown, 3)
	EndIf
EndFunction

; =============================================================================
; POLL (CSN_Core calls this about once a minute)
; =============================================================================
Function Poll() Global
	CSN_Core m = Main()
	If !m || !Loyalty()
		Return
	EndIf
	Int n = TownCount()
	Int stepSize = CSN_Config.LoyaltyStep()
	Bool first = StorageUtil.GetIntValue(None, "csn_world_init", 0) == 0
	Int i = 0
	While i < n
		String town = TownName(i)

		; ---- who rules the town
		Int owner = TownOwner(i)
		Int lastOwner = StorageUtil.GetIntValue(None, "csn_owner_" + i, -999)
		If lastOwner != owner
			StorageUtil.SetIntValue(None, "csn_owner_" + i, owner)
			If !first && lastOwner != -999 && owner != 0
				String taken = town + " has fallen under the control of " + OwnerName(owner) + ", taking it from " + OwnerName(lastOwner) + "."
				AddNews(-1, taken, "csn_control_change")
				CSN_SkyrimNet.AddHistory(i, taken)
				If CSN_Config.ShowNewsNotifications()
					Debug.Notification(town + " is now held by " + OwnerName(owner) + ".")
				EndIf
			EndIf
		EndIf

		; ---- loyalty (townsfolk mood)
		Int loy = TownLoyalty(i)
		Int lastLoy = StorageUtil.GetIntValue(None, "csn_loy_" + i, -1)
		If lastLoy < 0 || first
			StorageUtil.SetIntValue(None, "csn_loy_" + i, loy)
		ElseIf loy - lastLoy >= stepSize || lastLoy - loy >= stepSize
			StorageUtil.SetIntValue(None, "csn_loy_" + i, loy)
			If CSN_Config.CitizenOpinion()
				String rulers = OwnerName(owner)
				If loy > lastLoy
					AddNews(i, "The people of " + town + " have grown warmer toward " + rulers + "; most now feel " + MoodWord(loy) + ".", "csn_loyalty_rise")
				Else
					AddNews(i, "Grumbling is spreading through " + town + " against " + rulers + "; most now feel " + MoodWord(loy) + ".", "csn_loyalty_fall")
				EndIf
			EndIf
		EndIf

		; ---- jarl
		Actor jarl = TownJarl(i)
		Form lastJarl = StorageUtil.GetFormValue(None, "csn_jarl_" + i, None)
		If jarl != lastJarl as Actor
			StorageUtil.SetFormValue(None, "csn_jarl_" + i, jarl)
			If !first && jarl
				String named = m.BaseName(jarl) + " has been named Jarl of " + town + " by " + OwnerName(owner) + "."
				AddNews(i, named, "csn_jarl_change", jarl)
				CSN_SkyrimNet.AddHistory(i, named)
			ElseIf !first && lastJarl
				AddNews(i, (lastJarl as Actor).GetDisplayName() + " no longer sits as Jarl of " + town + ".", "csn_jarl_change")
			EndIf
		EndIf
		i += 1
	EndWhile
	StorageUtil.SetIntValue(None, "csn_world_init", 1)
	PollBattles(first)
EndFunction

; CoS runs each battle as a quest; report when one starts and when it ends.
Function PollBattles(Bool abFirst) Global
	String[] quests = new String[10]
	quests[0] = "CS_AttackCityNew"
	quests[1] = "CS_AttackCitySiege"
	quests[2] = "CS_AttackFortNew"
	quests[3] = "CS_DefendCityNewImp"
	quests[4] = "CS_DefendFortImp"
	quests[5] = "CS_DefendCampImp"
	quests[6] = "CS_RaidVillage"
	quests[7] = "CS_Coup"
	quests[8] = "CS_Protest"
	quests[9] = "CS_WarPatrolAmbush"
	Int i = 0
	While i < quests.Length
		Quest q = Quest.GetQuest(quests[i])
		If q
			Bool running = q.IsRunning()
			Bool was = StorageUtil.GetIntValue(None, "csn_battle_" + quests[i], 0) == 1
			If running != was
				StorageUtil.SetIntValue(None, "csn_battle_" + quests[i], running as Int)
				If !abFirst
					ReportBattle(quests[i], running)
				EndIf
			EndIf
		EndIf
		i += 1
	EndWhile
EndFunction

Function ReportBattle(String asQuest, Bool abStarted) Global
	Location loc = Game.GetPlayer().GetCurrentLocation()
	String where = "the wilds"
	If loc
		where = loc.GetName()
	EndIf
	Int town = TownOfLocation(loc)
	String kind = "A battle"
	If StringUtil.Find(asQuest, "Siege") >= 0
		kind = "A siege"
	ElseIf StringUtil.Find(asQuest, "Raid") >= 0
		kind = "A raid"
	ElseIf StringUtil.Find(asQuest, "Coup") >= 0
		kind = "A coup"
	ElseIf StringUtil.Find(asQuest, "Protest") >= 0
		kind = "A protest"
	ElseIf StringUtil.Find(asQuest, "Ambush") >= 0
		kind = "An ambush"
	EndIf
	If abStarted
		AddNews(town, kind + " has broken out near " + where + ".", "csn_battle_start", Game.GetPlayer())
		CSN_SkyrimNet.BattleAlert(kind + " has broken out near " + where + "!")
	Else
		AddNews(town, kind + " near " + where + " has ended.", "csn_battle_end", Game.GetPlayer())
	EndIf
EndFunction

; =============================================================================
; DESCRIPTION FOR AN NPC (used by the csn_town_context decorator)
; =============================================================================
String Function DescribeFor(Actor akActor) Global
	Int i = TownOf(akActor)
	If i < 0
		Return ""
	EndIf
	CSN_Core m = Main()
	String town = TownName(i)
	Int owner = TownOwner(i)
	Int loy = TownLoyalty(i)
	String s = town + " is under the control of " + OwnerName(owner) + "."
	Actor jarl = TownJarl(i)
	If jarl
		s += " " + m.BaseName(jarl) + " sits as Jarl."
	EndIf
	If CSN_Config.CitizenOpinion()
		s += " Most people here feel " + MoodWord(loy) + " toward their rulers (loyalty " + loy + " out of 100)."
		Int like = PlayerFactionLiking(i)
		If like >= 0 && !PlayerRules(i)
			s += " Locals " + LikingWord(like) + " the " + m.FactionName() + ", the faction led by " + Game.GetPlayer().GetDisplayName() + "."
		EndIf
	EndIf
	If PlayerRules(i)
		Int tax = CSN_Gov.TaxLevel(i)
		If tax == 0
			s += " Taxes in " + town + " are 0%, the lowest they can be: nobody here pays any tax, so no one complains about taxes."
		ElseIf tax == 1
			s += " Taxes in " + town + " are low (10%); few people mind them."
		ElseIf tax >= 4
			s += " Taxes in " + town + " are heavy (" + CSN_Gov.TaxText(tax) + ") and people grumble about them."
		ElseIf tax >= 0
			s += " Taxes in " + town + " are " + CSN_Gov.TaxText(tax) + ", an ordinary rate."
		EndIf
	EndIf
	String news = NewsText(i)
	If news != ""
		s += "\nWhat people in " + town + " are talking about:" + news
	EndIf
	Return s
EndFunction
