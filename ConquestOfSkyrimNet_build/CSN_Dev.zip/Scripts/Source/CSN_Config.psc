Scriptname CSN_Config Hidden
{Conquest of SkyrimNet settings. Values come from the MCM (MCM Helper: Data/MCM/Config/ConquestOfSkyrimNet,
 user changes saved in Data/MCM/Settings/ConquestOfSkyrimNet.ini). Without MCM Helper the defaults below apply.}

String Function ModName() Global
	Return "ConquestOfSkyrimNet"
EndFunction

Bool Function HasMCM() Global
	Return Game.GetModByName("MCMHelper.esp") != 255
EndFunction

Int Function GetInt(String asId, Int aiDefault) Global
	If HasMCM()
		Return MCM.GetModSettingInt(ModName(), asId)
	EndIf
	Return aiDefault
EndFunction

Bool Function GetBool(String asId, Bool abDefault) Global
	If HasMCM()
		Return MCM.GetModSettingBool(ModName(), asId)
	EndIf
	Return abDefault
EndFunction

; ---- Economy ---------------------------------------------------------------
; Gold per unit of wood, metal or food traded per day with the Imperials or Stormcloaks (CoS default was 100).
Int Function TradePrice() Global
	Return ClampMin(GetInt("iTradePrice:Economy", 10), 1)
EndFunction

; Food per soldier per day for an army that is hunting (CoS default was 3).
Int Function HuntFood() Global
	Return ClampMin(GetInt("iHuntFood:Economy", 5), 0)
EndFunction

; Treasury cost of a miner.
Int Function MinerCost() Global
	Return ClampMin(GetInt("iMinerCost:Economy", 400), 0)
EndFunction

; Gold a day for each troop in the faction's armies (soldiers, warriors, archers, crossbowmen and the rest).
Int Function TroopUpkeep() Global
	Return ClampMin(GetInt("iTroopUpkeep:Economy", 10), 0)
EndFunction

; Treasury cost of a guard.
Int Function GuardCost() Global
	Return ClampMin(GetInt("iGuardCost:Economy", 250), 0)
EndFunction

; ---- Interface -------------------------------------------------------------
Bool Function UsePrismaUI() Global
	Return GetBool("bUsePrismaUI:Interface", True)
EndFunction

Bool Function ShowNewsNotifications() Global
	Return GetBool("bNewsNotifications:Interface", True)
EndFunction

; ---- SkyrimNet / world -----------------------------------------------------
Bool Function SkyrimNetEnabled() Global
	Return GetBool("bSkyrimNet:SkyrimNet", True)
EndFunction

Bool Function WorldNews() Global
	Return GetBool("bWorldNews:SkyrimNet", True)
EndFunction

Bool Function CitizenOpinion() Global
	Return GetBool("bCitizenOpinion:SkyrimNet", True)
EndFunction

; How many in-game days townsfolk keep talking about a piece of news.
Int Function NewsDays() Global
	Return ClampMin(GetInt("iNewsDays:SkyrimNet", 14), 1)
EndFunction

; Loyalty must move at least this much before townsfolk notice.
Int Function LoyaltyStep() Global
	Return ClampMin(GetInt("iLoyaltyStep:SkyrimNet", 5), 1)
EndFunction

; The mod's version, shown on the faction screen (keep in step with fomod\info.xml and the changelog).
String Function Version() Global
	Return "2.1.15"
EndFunction

Bool Function DebugLog() Global
	Return GetBool("bDebugLog:Debug", False)
EndFunction

; Where the debug log goes (shown in the MCM and on the Settings tab).
String Function LogPath() Global
	String p = ""
	If CSN_Native.IsAvailable()
		p = CSN_Native.GetLogPath()
	EndIf
	If p == ""
		p = "Documents\\My Games\\Skyrim Special Edition\\SKSE\\ConquestOfSkyrimNet.log"
	EndIf
	Return p
EndFunction

; Debug line to ConquestOfSkyrimNet.log (only when "Debug logging" is on).
Function Log(String asText) Global
	If DebugLog()
		CSN_Native.Log(asText)
	EndIf
EndFunction

Function SetInt(String asId, Int aiValue) Global
	If HasMCM()
		MCM.SetModSettingInt(ModName(), asId, aiValue)
	EndIf
EndFunction

Function SetBool(String asId, Bool abValue) Global
	If HasMCM()
		MCM.SetModSettingBool(ModName(), asId, abValue)
	EndIf
EndFunction

; ---- Look ------------------------------------------------------------------
; 0 = dark, 1 = light
Int Function Theme() Global
	Return GetInt("iTheme:Interface", 0)
EndFunction

; How close (in game units) an officer must be for the Steward / War Table tabs to appear.
Int Function NearbyRadius() Global
	Return ClampMin(GetInt("iNearbyRadius:Interface", 1500), 200)
EndFunction

; ---- Confirmations (MCM page "Confirmations") ---------------------------------
Bool Function ConfirmDeposit() Global
	Return GetBool("bDeposit:Confirm", True)
EndFunction

Bool Function ConfirmWithdraw() Global
	Return GetBool("bWithdraw:Confirm", True)
EndFunction

Bool Function ConfirmCamp() Global
	Return GetBool("bCamp:Confirm", True)
EndFunction

; Beginning or calling off a prepared attack from conversation.
Bool Function ConfirmBattle() Global
	Return GetBool("bBattle:Confirm", True)
EndFunction

Bool Function ConfirmGarrisonCity() Global
	Return GetBool("bGarrisonCity:Confirm", True)
EndFunction

Bool Function ConfirmGarrisonFort() Global
	Return GetBool("bGarrisonFort:Confirm", True)
EndFunction

Bool Function ConfirmCityTrade() Global
	Return GetBool("bCityTrade:Confirm", True)
EndFunction

Bool Function ConfirmMedal() Global
	Return GetBool("bMedal:Confirm", True)
EndFunction

Bool Function ConfirmTax() Global
	Return GetBool("bTax:Confirm", True)
EndFunction

; ---- Requests from your government -------------------------------------------
Bool Function Requests() Global
	Return GetBool("bRequests:Requests", True)
EndFunction

; How often the government studies events to create requests, in game days.
; MCM: iStudyEvery (number) + iStudyUnit (0 = hours, 1 = days). Default: every 2 days.
Float Function StudyDays() Global
	Int n = ClampMin(GetInt("iStudyEvery:Requests", 2), 1)
	If GetInt("iStudyUnit:Requests", 1) == 0
		Return (n as Float) / 24.0
	EndIf
	Return n as Float
EndFunction

; Skip a study when nothing notable happened since the last one.
Bool Function SkipQuiet() Global
	Return GetBool("bSkipQuiet:Requests", True)
EndFunction

; Let SkyrimNet's LLM decide the requests (fixed rules otherwise, or without SkyrimNet).
Bool Function LLMRequests() Global
	Return GetBool("bLLM:Requests", True)
EndFunction

; One-time grants for a town's festival, cause or event.
Bool Function TownGrants() Global
	Return GetBool("bTownGrants:Requests", True)
EndFunction

; One-time requests from captains, commanders and the General (training, weapons...).
Bool Function ArmyRequests() Global
	Return GetBool("bArmyRequests:Requests", True)
EndFunction

; Towns ask for famous (starred) army leaders to be stationed with them, for loyalty.
Bool Function SecurityRequests() Global
	Return GetBool("bSecurityRequests:Requests", True)
EndFunction

; Send requests as Physical Letters when that mod is installed.
Bool Function UseLetters() Global
	Return GetBool("bUseLetters:Requests", True)
EndFunction

; Appointing someone General, Steward, Blacksmith, Court Wizard or Captain in conversation.
Bool Function ConfirmAppoint() Global
	Return GetBool("bAppoint:Confirm", True)
EndFunction

; Removing someone from office (General, Steward, Blacksmith, Court Wizard, Captain/Commander, a town's jarl or steward).
Bool Function ConfirmRemoval() Global
	Return GetBool("bRemoval:Confirm", True)
EndFunction

; Someone asks to step down of their own accord.
Bool Function ConfirmResign() Global
	Return GetBool("bResign:Confirm", True)
EndFunction

; Selling food, metal or wood to someone in conversation.
Bool Function ConfirmSale() Global
	Return GetBool("bSale:Confirm", True)
EndFunction

; ---- Selling supplies in conversation ---------------------------------------
Int Function SalePrice() Global
	Return ClampMin(GetInt("iSalePrice:Economy", 10), 1)
EndFunction

Int Function SaleMax() Global
	Return ClampMin(GetInt("iSaleMax:Economy", 50), 1)
EndFunction

; Buying from people in conversation: gold per unit (at least 20) and most in one purchase.
Int Function BuyPrice() Global
	Return ClampMin(GetInt("iBuyPrice:Economy", 20), 20)
EndFunction

Int Function BuyMax() Global
	Return ClampMin(GetInt("iBuyMax:Economy", 50), 1)
EndFunction

; Opening someone's outfit menu from conversation.
Bool Function ConfirmOutfit() Global
	Return GetBool("bOutfit:Confirm", True)
EndFunction

; Recruiting troops through the General in conversation asks first.
Bool Function ConfirmRecruit() Global
	Return GetBool("bRecruit:Confirm", True)
EndFunction

; Relationship rank a buyer needs with the player (0 acquaintance, 1 friend...).
Int Function SaleMinRank() Global
	Return GetInt("iSaleMinRank:Economy", 1)
EndFunction

; ---- Interface ---------------------------------------------------------------
Bool Function PauseGame() Global
	Return GetBool("bPauseGame:Interface", False)
EndFunction

Bool Function ConfirmCedeHold() Global
	Return GetBool("bCedeHold:Confirm", True)
EndFunction

; ---- Diplomacy ---------------------------------------------------------------
; Least a jarl will take to hand a major city (Whiterun, Solitude, ...) to your faction. Minor cities ask half.
Int Function CedeCityPrice() Global
	Return ClampMin(GetInt("iCedeCityPrice:Diplomacy", 500000), 500000)
EndFunction

; Least a jarl at peace with you takes for their hold's main fort (gold, or food/metal/wood at the trade price).
Int Function CedeFortPrice() Global
	Return ClampMin(GetInt("iCedeFortPrice:Diplomacy", 80000), 80000)
EndFunction

Int Function ClampMin(Int v, Int lo) Global
	If v < lo
		Return lo
	EndIf
	Return v
EndFunction
