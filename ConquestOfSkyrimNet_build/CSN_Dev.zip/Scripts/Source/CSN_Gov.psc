Scriptname CSN_Gov Hidden
{Conquest of SkyrimNet: officer actions and what officers know.
 Treasury deposits and withdrawals, garrisons, army camps, city trade, jarls handing over their city,
 outfits, difficulty and debug settings, and the knowledge text SkyrimNet gives each officer.
 Every action that changes something can ask the player first (MCM page "Confirmations").}

; =============================================================================
; ACCESS
; =============================================================================
CSN_Core Function M() Global
	Return Quest.GetQuest("CS_FactionGovernment") as CSN_Core
EndFunction

CS_UpgradeMenuFunctions Function Upg() Global
	Return Quest.GetQuest("CS_UpgradeReport") as CS_UpgradeMenuFunctions
EndFunction

CS_SettingsMenuScript Function Settings() Global
	Return Quest.GetQuest("CS_SettingsMenu") as CS_SettingsMenuScript
EndFunction

CS_CheatMenuScript Function Cheats() Global
	Return Quest.GetQuest("CS_CheatMenu") as CS_CheatMenuScript
EndFunction

CS_AttackPlanningNewScript Function Planning() Global
	Return Quest.GetQuest("CS_AttackPlanningNew") as CS_AttackPlanningNewScript
EndFunction

CS_TransferOwnershipScript Function Transfer() Global
	Return Quest.GetQuest("CS_TransferHoldingOwnership") as CS_TransferOwnershipScript
EndFunction

; "the Iron Wolves (Army 3)" or "Army 3" (CSN_War keeps army names and purposes)
String Function ArmyLabel(Int aiArmy) Global
	Return CSN_War.Label(aiArmy)
EndFunction

Actor Function Player() Global
	Return Game.GetPlayer()
EndFunction

Int Function Treasury() Global
	Return M().Econ().Treasury.GetValueInt()
EndFunction

; The name to use for a person: their current display name without a title we added
; (keeps names given by NPC Name Distributor and similar mods).
String Function NameOf(Actor a) Global
	If !a
		Return ""
	EndIf
	Return M().PlainName(a)
EndFunction

; The top-left notice: only the first sentence, at most about 70 letters, so it can be read at a glance.
; The faction screen and the NPC still get the whole text.
String Function Short(String asText) Global
	String s = asText
	Int cut = CutAt(s, ". ", 1)
	cut = Earliest(cut, CutAt(s, "? ", 1))
	cut = Earliest(cut, CutAt(s, "! ", 1))
	cut = Earliest(cut, CutAt(s, "; ", 0))
	If cut > 0
		s = StringUtil.Substring(s, 0, cut)
	EndIf
	; asides in brackets go first when it's long, never the rest of the sentence after a name like "Ylva (Army 2)"
	If StringUtil.GetLength(s) > 84
		s = DropAsides(s)
	EndIf
	If StringUtil.GetLength(s) > 84
		Int sp = 80
		While sp > 30 && StringUtil.GetNthChar(s, sp) != " "
			sp -= 1
		EndWhile
		s = StringUtil.Substring(s, 0, sp) + "..."
	EndIf
	Return s
EndFunction

; asText without its bracketed asides: "Ylva's army (Army 2) will arrive" -> "Ylva's army will arrive"
String Function DropAsides(String asText) Global
	String s = asText
	Int guard = 0
	Int open = StringUtil.Find(s, " (")
	While open >= 0 && guard < 6
		Int close = StringUtil.Find(s, ")", open)
		If close < 0
			Return s
		EndIf
		s = StringUtil.Substring(s, 0, open) + StringUtil.Substring(s, close + 1)
		open = StringUtil.Find(s, " (")
		guard += 1
	EndWhile
	Return s
EndFunction

; where to cut asText at the first asMark found after the first 12 letters (keeping aiKeep letters of it), or -1
Int Function CutAt(String asText, String asMark, Int aiKeep) Global
	Int at = StringUtil.Find(asText, asMark, 12)
	If at < 0
		Return -1
	EndIf
	Return at + aiKeep
EndFunction

Int Function Earliest(Int a, Int b) Global
	If a < 0
		Return b
	ElseIf b < 0 || a < b
		Return a
	EndIf
	Return b
EndFunction

Function Say(String asText) Global
	Debug.Notification(Short(asText))
	If M()
		M().UIToast(asText, False)
	EndIf
EndFunction

; Something could not be done. The player sees why (top left and on the faction screen), and when it came from
; a conversation action the NPC is told it did not happen, so they don't carry on as if it had.
; The player sees the full reason; the NPC is only told asForNPC (e.g. a jarl never learns the treasury's size).
Function Fail2(String asText, String asForNPC) Global
	Debug.Notification(Short(asText))
	If M()
		M().UIToast(asText, True)
	EndIf
	CSN_SkyrimNet.ActionFailed(asForNPC)
EndFunction

; the last failure message (shown again where it would otherwise be lost, e.g. after the screen reopens)
String Function LastFail() Global
	If Utility.GetCurrentRealTime() - StorageUtil.GetFloatValue(None, "csn_lastfail_t", -100.0) > 30.0
		Return ""
	EndIf
	Return StorageUtil.GetStringValue(None, "csn_lastfail", "")
EndFunction

Function Fail(String asText) Global
	StorageUtil.SetStringValue(None, "csn_lastfail", asText)
	StorageUtil.SetFloatValue(None, "csn_lastfail_t", Utility.GetCurrentRealTime())
	Debug.Notification(Short(asText))
	If M()
		M().UIToast(asText, True)
	EndIf
	CSN_SkyrimNet.ActionFailed(asText)
EndFunction

; =============================================================================
; WHO IS NEARBY (decides whether the Steward and War Table tabs show)
; =============================================================================
Bool Function IsNear(Actor a) Global
	If !a || a.IsDead() || a.IsDisabled()
		Return False
	EndIf
	Actor p = Player()
	If a.GetParentCell() != p.GetParentCell() && a.GetWorldSpace() != p.GetWorldSpace()
		Return False
	EndIf
	Return a.GetDistance(p) <= CSN_Config.NearbyRadius()
EndFunction

; City (0-14) this person is the steward of, -1 if none. Only cities your faction rules count.
Int Function CityStewardOf(Actor a) Global
	CS_RecruitJarl r = M().Gov.RecruitJarl
	If !a || !r
		Return -1
	EndIf
	Int i = r.FindSteward(a)
	If i >= 0 && CSN_World.PlayerRules(i)
		Return i
	EndIf
	Return -1
EndFunction

; City (0-14) this person is jarl (or village leader) of, whoever rules it. -1 if none.
Int Function JarlCityOf(Actor a) Global
	CS_RecruitJarl r = M().Gov.RecruitJarl
	If !a || !r
		Return -1
	EndIf
	Return r.FindJarl(a)
EndFunction

Bool Function IsAnySteward(Actor a) Global
	If !a
		Return False
	EndIf
	If M().GetRole(a) == M().ROLE_STEWARD
		Return True
	EndIf
	If CityStewardOf(a) >= 0
		Return True
	EndIf
	Int j = JarlCityOf(a)
	Return j >= 0 && CSN_World.PlayerRules(j)
EndFunction

; The steward or (your) jarl nearest to the player within reach, or None.
Actor Function NearbySteward() Global
	CSN_Core m = M()
	Actor best = None
	Float bestD = 999999.0
	Actor s = m.Officer(m.ROLE_STEWARD)
	If IsNear(s)
		best = s
		bestD = s.GetDistance(Player())
	EndIf
	CS_RecruitJarl r = m.Gov.RecruitJarl
	If r
		Int i = 0
		While i < r.StewardAliases.Length
			If CSN_World.PlayerRules(i)
				Actor a = r.StewardAliases[i].GetActorRef()
				If IsNear(a) && a.GetDistance(Player()) < bestD
					best = a
					bestD = a.GetDistance(Player())
				EndIf
				If i < r.JarlAliases.Length
					a = r.JarlAliases[i].GetActorRef()
					If IsNear(a) && a.GetDistance(Player()) < bestD
						best = a
						bestD = a.GetDistance(Player())
					EndIf
				EndIf
			EndIf
			i += 1
		EndWhile
	EndIf
	Return best
EndFunction

Actor Function NearbyGeneral() Global
	Actor g = M().Officer(M().ROLE_GENERAL)
	If IsNear(g)
		Return g
	EndIf
	Return None
EndFunction

; People in the player's cell who could take an office (alive, adult, not hostile, not the player).
Actor[] Function NearbyCandidates() Global
	Actor[] found = MiscUtil.ScanCellNPCs(Player(), 0.0, None, True)
	Actor[] out = PapyrusUtil.ActorArray(0)
	CSN_Core m = M()
	Int i = 0
	While i < found.Length && out.Length < 40
		Actor a = found[i]
		If a && m.CanServe(a) && !a.IsInCombat()
			out = PapyrusUtil.PushActor(out, a)
		EndIf
		i += 1
	EndWhile
	Return out
EndFunction

; =============================================================================
; TREASURY
; =============================================================================
; Put gold from the player's purse into the treasury. akVia = the steward who takes it (or None).
Bool Function Deposit(Int aiAmount, Actor akVia = None) Global
	CSN_Core m = M()
	CS_EconomyMenuFunctions e = m.Econ()
	If aiAmount <= 0
		Return False
	EndIf
	Int purse = Player().GetItemCount(e.Gold001)
	If purse < aiAmount
		Fail("You only carry " + purse + " gold, not " + aiAmount + ".")
		Return False
	EndIf
	If CSN_Config.ConfirmDeposit() && !CSNP.Confirm("Deposit gold", "Give " + aiAmount + " gold to " + ViaText(akVia) + " for the treasury of the " + m.FactionName() + "?\n\nYou carry " + purse + " gold. The treasury holds " + Treasury() + ".", "Deposit", "Keep it")
		Return False
	EndIf
	Player().RemoveItem(e.Gold001, aiAmount, True)
	e.Treasury.Mod(aiAmount)
	If e.FactionStartDepositGold.GetValue() == 0 && e.Treasury.GetValue() >= 1000
		e.FactionStartDepositGold.SetValue(1)
		If m.Gov.GetStage() < 3
			m.Gov.SetStage(3)
		EndIf
	EndIf
	Say(aiAmount + " gold added to the treasury (" + Treasury() + " now).")
	CSN_SkyrimNet.LogEvent(Player().GetDisplayName() + " handed " + aiAmount + " gold to " + ViaText(akVia) + " for the treasury of the " + m.FactionName() + ", which now holds " + Treasury() + " gold.", akVia, Player())
	Return True
EndFunction

; Take gold out of the treasury into the player's purse. Stewards only.
Bool Function Withdraw(Int aiAmount, Actor akVia = None) Global
	CSN_Core m = M()
	CS_EconomyMenuFunctions e = m.Econ()
	If aiAmount <= 0
		Return False
	EndIf
	If Treasury() < aiAmount
		Fail("The treasury only holds " + Treasury() + " gold.")
		Return False
	EndIf
	If CSN_Config.ConfirmWithdraw() && !CSNP.Confirm("Withdraw gold", "Take " + aiAmount + " gold out of the treasury through " + ViaText(akVia) + "?\n\nThe treasury holds " + Treasury() + " gold.", "Withdraw", "Leave it")
		Return False
	EndIf
	e.Treasury.Mod(-aiAmount)
	Player().AddItem(e.Gold001, aiAmount, True)
	Say(aiAmount + " gold taken from the treasury (" + Treasury() + " left).")
	CSN_SkyrimNet.LogEvent(ViaText(akVia) + " paid out " + aiAmount + " gold from the treasury of the " + m.FactionName() + " to " + Player().GetDisplayName() + ". " + Treasury() + " gold remains.", akVia, Player())
	Return True
EndFunction

String Function ViaText(Actor akVia) Global
	If akVia
		Return NameOf(akVia)
	EndIf
	Return "the steward"
EndFunction

; =============================================================================
; ARMIES: garrisons and camps
; =============================================================================
Bool Function IsCity(Int i) Global
	Return i >= 0 && i < 9
EndFunction

; Owned cities a commander can garrison right now (has room, not under attack).
String Function CheckGarrisonCity(Actor akCommander, Int aiCity) Global
	CSN_Core m = M()
	If m.GetArmy(akCommander) < 0
		Return "That isn't one of your commanders."
	EndIf
	If !IsCity(aiCity) || !CSN_World.PlayerRules(aiCity)
		Return "You don't rule that city."
	EndIf
	CS_TroopManageMenuScript tm = m.Armies().TroopManage
	If aiCity < 5
		tm.UpdateCityTroopGarrisons()
	Else
		tm.UpdateMinorCityTroopGarrisons()
	EndIf
	If (tm.PlayerGarrisonArmyCounts.GetAt(aiCity) as GlobalVariable).GetValue() >= (tm.PlayerGarrisonArmyCapCounts.GetAt(aiCity) as GlobalVariable).GetValue()
		Return CSN_World.TownName(aiCity) + "'s garrison is full. Upgrade its barracks for more room."
	EndIf
	If tm.BattleTracker.Cities[aiCity]
		Return CSN_World.TownName(aiCity) + " is under attack; no new garrison can get in."
	EndIf
	Return ""
EndFunction

Bool Function GarrisonCity(Actor akCommander, Int aiCity, Actor akVia = None) Global
	String err = CheckGarrisonCity(akCommander, aiCity)
	If err != ""
		Fail(err)
		Return False
	EndIf
	CSN_Core m = M()
	If CSN_Config.ConfirmGarrisonCity() && !CSNP.Confirm("Garrison a city", "Send " + NameOf(akCommander) + " and " + ArmyLabel(m.GetArmy(akCommander)) + " (" + m.ArmyTroops(m.GetArmy(akCommander)) + " troops) to garrison " + CSN_World.TownName(aiCity) + "?", "Send them", "Not now")
		Return False
	EndIf
	CS_TroopManageMenuScript tm = m.Armies().TroopManage
	If tm.GovQuest.GetStage() == 14
		tm.GovQuest.SetStage(15)
	EndIf
	m.Armies().StartPatrol(akCommander, aiCity)
	m.NoteOrder(akCommander, "garrison " + CSN_World.TownName(aiCity))
	Return True
EndFunction

Bool Function GarrisonFort(Actor akCommander, Int aiFort, Actor akVia = None) Global
	CSN_Core m = M()
	String err = m.CheckOrder(akCommander, m.ORDER_FORT, aiFort)
	If err != ""
		Fail(err)
		Return False
	EndIf
	If CSN_Config.ConfirmGarrisonFort() && !CSNP.Confirm("Garrison a fort", "Send " + NameOf(akCommander) + " and " + ArmyLabel(m.GetArmy(akCommander)) + " to hold " + m.FortName(aiFort) + "?", "Send them", "Not now")
		Return False
	EndIf
	Return m.IssueOrder(akCommander, m.ORDER_FORT, aiFort)
EndFunction

; Holds (0-8) where an army may make camp: ones you hold the land of, or that border them.
; Before you hold any land, every hold is open (your first campaign has to start somewhere).
Bool Function CanCamp(Int aiHold) Global
	If aiHold < 0 || aiHold > 8
		Return False
	EndIf
	CS_TMScript tm = M().Gov.TMPlayer
	If tm.GetLandSuperiorityNum() == 0
		Return True
	EndIf
	Location h = tm.AllLocationsCS.GetAt(aiHold) as Location
	If h && h.GetKeywordData(tm.LandSuperiority) == tm.FactionNum
		Return True
	EndIf
	Return tm.GetOwnSuperiorHoldsBordering(aiHold) > 0
EndFunction

; Hold a camp would be an attack camp in (you don't hold the land yet).
Bool Function IsAttackCamp(Int aiHold) Global
	CS_TMScript tm = M().Gov.TMPlayer
	Location h = tm.AllLocationsCS.GetAt(aiHold) as Location
	Return !(h && h.GetKeywordData(tm.LandSuperiority) == tm.FactionNum)
EndFunction

Bool Function MakeCamp(Actor akCommander, Int aiHold, Actor akVia = None) Global
	CSN_Core m = M()
	If m.GetArmy(akCommander) < 0
		Fail("That isn't one of your commanders.")
		Return False
	EndIf
	If !CanCamp(aiHold)
		Fail("Your armies can't reach " + m.HoldName(aiHold) + " yet. Make camp in a hold that borders your land.")
		Return False
	EndIf
	; a war camp already stands there: join it the way the war map does (march there, same checks)
	If CSN_War.HasCamp(aiHold) && CSN_War.CampOf(akCommander) != aiHold
		Return CSN_War.JoinCamp(akCommander, aiHold, akVia)
	EndIf
	String kind = "an army camp"
	If IsAttackCamp(aiHold)
		kind = "an attack camp"
	EndIf
	If CSN_Config.ConfirmCamp() && !CSNP.Confirm("Make camp", "Have " + NameOf(akCommander) + " march " + ArmyLabel(m.GetArmy(akCommander)) + " to " + m.HoldName(aiHold) + " and set up " + kind + " there?", "March", "Not now")
		Return False
	EndIf
	m.Armies().StartPatrolHold(akCommander, aiHold)
	m.NoteOrder(akCommander, "set up " + kind + " in " + m.HoldName(aiHold))
	If IsAttackCamp(aiHold)
		CSN_World.AddNews(-1, "An army of the " + m.FactionName() + " under " + NameOf(akCommander) + " has made camp in " + m.HoldName(aiHold) + ".", "csn_army_camp", akCommander)
	EndIf
	Return True
EndFunction

; =============================================================================
; GOVERNMENT AND COURT OUTFITS (CS_FactionGovernment's "I want you to wear a different outfit" dialogue)
; =============================================================================
; 1 jarl or village leader, 2 a town's steward, 3 a town's housecarl, 4 General, Steward, Blacksmith or Court
; Wizard (CoS's government positions), 0 none. Same order as CS_GovScriptFunctions.UpdateGovOutfit.
Int Function GovOutfitKind(Actor akActor) Global
	CS_GovScriptFunctions g = M().Gov
	If !akActor
		Return 0
	EndIf
	; only the player's own jarls and courts (CS_RecruitJarl's aliases) have these outfits
	If (akActor.IsInFaction(g.JarlFaction) || akActor.IsInFaction(g.VillageLeaderFaction)) && InAliases(g.RecruitJarl.JarlAliases, akActor)
		Return 1
	ElseIf akActor.IsInFaction(g.StewardFaction) && akActor != g.Steward.GetActorRef() && InAliases(g.RecruitJarl.StewardAliases, akActor)
		Return 2
	ElseIf akActor.IsInFaction(g.HousecarlFaction) && akActor != g.ASIC.GetActorRef() && InAliases(g.RecruitJarl.HousecarlAliases, akActor)
		Return 3
	EndIf
	Int i = 0
	While i < g.GovPositions.Length
		If g.GovPositions[i] && g.GovPositions[i].GetActorRef() == akActor
			Return 4
		EndIf
		i += 1
	EndWhile
	Return 0
EndFunction

Bool Function InAliases(ReferenceAlias[] akList, Actor akActor) Global
	Int i = 0
	While i < akList.Length
		If akList[i] && akList[i].GetActorRef() == akActor
			Return True
		EndIf
		i += 1
	EndWhile
	Return False
EndFunction

; aiChoice: 0 "Let me edit what you need to wear." (opens their position's outfit chest), 1 "Wear an outfit that
; reflects your position.", 2 "You may wear whatever you wish."
Bool Function GovOutfit(Actor akActor, Int aiChoice) Global
	CSN_Core m = M()
	CS_GovScriptFunctions g = m.Gov
	Int kind = GovOutfitKind(akActor)
	If kind == 0
		Fail(NameOf(akActor) + " holds no position with an outfit of its own.")
		Return False
	EndIf
	If aiChoice == 2
		g.RemoveAllOutfitFactions(akActor)
		Say(NameOf(akActor) + " may wear whatever they wish.")
		Return True
	ElseIf aiChoice == 1
		g.AddToDefaultOutfitFaction(akActor)
		g.UpdateGovOutfit(akActor)
		Say(NameOf(akActor) + " now wears the outfit of their position.")
		Return True
	EndIf
	m.CloseScreen()
	m.WatchOutfit(akActor, True)
	Say("Put in what " + NameOf(akActor) + " should wear, then close the inventory.")
	If kind == 1
		g.ChangeJarlOutfit(akActor)
	ElseIf kind == 2
		g.ChangeStewardOutfit(akActor)
	ElseIf kind == 3
		g.ChangeHousecarlOutfit(akActor)
	Else
		g.ChangeGovOutfit(akActor)
	EndIf
	Return True
EndFunction

; =============================================================================
; FORMATION (CS_TroopFormUp's "Form up!" / "Break formation!", for the army marching with the player)
; =============================================================================
Bool Function Formation(Actor akCommander, Bool abFormUp) Global
	CSN_Core m = M()
	If m.GetArmy(akCommander) < 0
		Fail("That isn't one of your commanders.")
		Return False
	EndIf
	CS_TroopFormUpScript f = m.Armies().TroopFormUp as CS_TroopFormUpScript
	If !f || !m.Armies().TroopFormUp.IsRunning() || f.Commander.GetActorRef() != akCommander
		Fail(NameOf(akCommander) + "'s army isn't marching with you; only the army that follows you can form up. Tell them to follow you first.")
		Return False
	EndIf
	If abFormUp
		If f.FormedUp == 1
			Say(NameOf(akCommander) + "'s troops are already in formation.")
			Return True
		EndIf
		f.FormUpArmy()
		Say(ArmyLabel(m.GetArmy(akCommander)) + ": in formation.")
	Else
		If f.FormedUp == 0
			Say(NameOf(akCommander) + "'s troops are not in formation.")
			Return True
		EndIf
		f.DisbandArmy()
		Say(ArmyLabel(m.GetArmy(akCommander)) + ": formation broken.")
	EndIf
	Return True
EndFunction

; =============================================================================
; ARMY UNIFORM (CS_TroopManageMenuScript.EquipmentMenu: one army's own equipment, over the troop-type outfits)
; =============================================================================
Bool Function ArmyUniform(Int aiArmy, Actor akVia = None) Global
	CSN_Core m = M()
	Actor c = m.Commander(aiArmy)
	If aiArmy < 0 || !c
		Fail("Which army? Name it by number, by name or by its Captain or Commander.")
		Return False
	EndIf
	CS_TroopManageMenuScript tm = m.Armies().TroopManage
	CS_CommanderAliasScript ca = m.Armies().Commanders[aiArmy] as CS_CommanderAliasScript
	String leaderNow = "keeps their own outfit"
	If ca && ca.ArmyEquipment
		leaderNow = "wears it too"
	EndIf
	String[] b = new String[4]
	b[0] = "Edit the uniform"
	b[1] = "The leader wears it too"
	b[2] = "The leader keeps their own outfit"
	b[3] = "Cancel"
	String text = "The uniform of " + ArmyLabel(aiArmy) + " (" + RankText(c) + " " + NameOf(c) + "): what this army's troops wear, over the troop-type outfits the Blacksmith keeps."
	text += "\n\nIt is one uniform for men and women alike: Conquest of Skyrim has no separate men's and women's version for one army. For separate outfits by gender, use the Blacksmith's troop-type outfits."
	text += "\n\nThe leader " + leaderNow + "."
	Int r = CSNP.Choose("Army uniform", text, b)
	If r == 0
		m.CloseScreen()
		Say("Put in what " + ArmyLabel(aiArmy) + " should wear, then close the inventory. The troops change into it as they next gather.")
		tm.SetArmyEquipment(aiArmy)
		CSN_SkyrimNet.LogEvent(Player().GetDisplayName() + " set a uniform for " + ArmyLabel(aiArmy) + ".", c, Player())
		Return True
	ElseIf (r == 1 || r == 2) && ca
		ca.ArmyEquipment = r == 1
		If c.Is3DLoaded()
			ca.UpgradeCommander(c)
		EndIf
		If r == 1
			Say(NameOf(c) + " now wears " + ArmyLabel(aiArmy) + "'s uniform too.")
		Else
			Say(NameOf(c) + " keeps their own outfit.")
		EndIf
		Return True
	EndIf
	CSN_SkyrimNet.EndAction()
	Return False
EndFunction

; Commander outfit (the same menu as "I want you to wear a different outfit" > "Let me edit what you need to wear").
Function EditOutfit(Actor akActor) Global
	If !akActor
		Return
	EndIf
	CSN_Core m = M()
	; once the template's inventory closes, the person changes into it (CoS only did that on the next cell load)
	m.WatchOutfit(akActor)
	m.Armies().TroopManage.CommanderOutfitScript.CommanderOutfitMenu(akActor, False, m.GetArmy(akActor))
EndFunction

CS_CommanderOutfitScript Function OutfitScript() Global
	Return M().Armies().TroopManage.CommanderOutfitScript
EndFunction

; Outfit template (1-5) this person wears, 0 if none.
Int Function OutfitTemplateOf(Actor a) Global
	CS_CommanderOutfitScript os = OutfitScript()
	If !a || !os.CommanderOutfitFaction || !a.IsInFaction(os.CommanderOutfitFaction)
		Return 0
	EndIf
	Return a.GetFactionRank(os.CommanderOutfitFaction)
EndFunction

; "Wear outfit template 2": open that template's inventory (to fill or change it); when it closes, they change into it.
Bool Function WearOutfitTemplate(Actor akActor, Int aiTemplate) Global
	CSN_Core m = M()
	CS_CommanderOutfitScript os = OutfitScript()
	If !akActor
		Return False
	EndIf
	If aiTemplate < 1 || aiTemplate > 5 || aiTemplate > os.OutfitActors.GetSize()
		Fail("Which outfit template? There are five, numbered 1 to 5.")
		Return False
	EndIf
	If m.GetArmy(akActor) < 0
		; outfit templates are the army leaders' uniforms; officers and courts have their position's outfit
		If GovOutfitKind(akActor) > 0
			Return GovOutfit(akActor, 0)
		EndIf
		Fail(NameOf(akActor) + " doesn't lead one of your armies, so has no outfit template to wear.")
		Return False
	EndIf
	ObjectReference holder = os.OutfitActors.GetAt(aiTemplate - 1) as ObjectReference
	(holder as CS_CustomOutfitArmyAddItem).armynum = aiTemplate - 1
	If !akActor.IsInFaction(os.CommanderOutfitFaction)
		akActor.AddToFaction(os.CommanderOutfitFaction)
	EndIf
	akActor.SetFactionRank(os.CommanderOutfitFaction, aiTemplate)
	m.WatchOutfit(akActor)
	Say("Outfit template " + aiTemplate + ": put in what " + NameOf(akActor) + " should wear, then close the inventory.")
	(holder as Actor).OpenInventory(True)
	Return True
EndFunction

; Change into the outfit template they are assigned (called when the template's inventory closes).
Function ApplyOutfitTemplate(Actor a) Global
	CS_CommanderOutfitScript os = OutfitScript()
	Int n = OutfitTemplateOf(a)
	If !a || n <= 0 || a.IsDead()
		Return
	EndIf
	FormList items = os.CustomOutfits.GetAt(n - 1) as FormList
	If !items || items.GetSize() == 0
		Fail("Outfit template " + n + " is empty: put the clothes and armour in it first.")
		Return
	EndIf
	a.UnequipAll()
	Int i = 0
	While i < items.GetSize()
		Form f = items.GetAt(i)
		If f
			If a.GetItemCount(f) == 0
				a.AddItem(f, 1, True)
			EndIf
			If (f as Armor) || (f as Weapon)
				a.EquipItem(f, True, True)
			EndIf
		EndIf
		i += 1
	EndWhile
	Say(NameOf(a) + " now wears outfit template " + n + ".")
	CSN_SkyrimNet.ShortEvent("csn_outfit", NameOf(a) + " changed into the uniform of outfit template " + n + ".", a)
EndFunction


; =============================================================================
; RANKS AND STARS
; A leader of an army is a Captain until they earn a star; with 1-5 stars they are a Commander.
; Each star costs the treasury StarCost() gold and gives every troop in their army +10% health and stamina.
; =============================================================================
Int Function StarCost() Global
	Return 10000
EndFunction

; ...and food for the feast that goes with it
Int Function StarFood() Global
	Return 100
EndFunction

Int Function Stars(Actor a) Global
	If !a
		Return 0
	EndIf
	Return StorageUtil.GetIntValue(a, "csn_stars", 0)
EndFunction

String Function RankTitle(Actor a) Global
	If Stars(a) > 0
		Return "Commander"
	EndIf
	Return "Captain"
EndFunction

; "Captain", "1-star Commander", "3-star Commander" ...
String Function RankText(Actor a) Global
	Int n = Stars(a)
	If n <= 0
		Return "Captain"
	EndIf
	Return n + "-star Commander"
EndFunction

Function ClearStars(Actor a) Global
	If a
		StorageUtil.UnsetIntValue(a, "csn_stars")
	EndIf
EndFunction

Bool Function AwardStar(Actor akCommander, Actor akVia = None) Global
	CSN_Core m = M()
	Int army = m.GetArmy(akCommander)
	If army < 0
		Fail("Only a Captain or Commander of your armies can receive a star.")
		Return False
	EndIf
	Int n = Stars(akCommander)
	If n >= 5
		Fail(NameOf(akCommander) + " already wears all five stars.")
		Return False
	EndIf
	If Treasury() < StarCost() || Stock(0) < StarFood()
		Fail("A star costs " + StarCost() + " gold and " + StarFood() + " food; the faction has " + Treasury() + " gold and " + Stock(0) + " food.")
		Return False
	EndIf
	String who = Player().GetDisplayName()
	If akVia && akVia != Player()
		who = "General " + NameOf(akVia)
	EndIf
	String newRank = (n + 1) + "-star Commander"
	If CSN_Config.ConfirmMedal() && !CSNP.Confirm("Award a star", "Award " + RankText(akCommander) + " " + NameOf(akCommander) + " of " + ArmyLabel(army) + " their " + (n + 1) + CSN_SkyrimNet.Ordinal(n + 1) + " star?\n\nCosts " + StarCost() + " gold (Treasury " + Treasury() + ") and " + StarFood() + " food (Food " + Stock(0) + "). Their troops gain +10% health and stamina and +" + CSN_Rebellion.StarMorale() + " morale (now " + CSN_Rebellion.Morale(army) + "); they become a " + newRank + ".", "Award the star", "Not now")
		Return False
	EndIf
	m.Econ().Treasury.Mod(-StarCost())
	m.Holdings().FoodReserve.Mod(-StarFood())
	StorageUtil.SetIntValue(akCommander, "csn_stars", n + 1)
	; the troops share their leader's honour at once
	Int moraleBefore = CSN_Rebellion.Morale(army)
	CSN_Rebellion.ModMorale(army, CSN_Rebellion.StarMorale(), "their leader was awarded a star")
	StorageUtil.SetIntValue(None, "csn_mor_low_" + army, 0)
	m.SetTitle(akCommander, "Commander")
	ApplyStarBuffs()
	String txt = who + " awarded " + NameOf(akCommander) + " of " + ArmyLabel(army) + " a star for service to the " + m.FactionName() + ". " + NameOf(akCommander) + " is now a " + newRank + "; their troops fight harder for it."
	Say(NameOf(akCommander) + " is now a " + newRank + ". Morale in " + ArmyLabel(army) + ": " + moraleBefore + " -> " + CSN_Rebellion.Morale(army) + ".")
	CSN_SkyrimNet.LogEvent(txt, akCommander, Player())
	CSN_World.AddNews(-1, txt, "csn_medal", akCommander)
	CSN_SkyrimNet.RefreshBio(akCommander)
	Return True
EndFunction

; Troops of starred armies: +10% of their base health and stamina per star (tracked per troop, so it never stacks twice).
Function ApplyStarBuffs() Global
	CSN_Core m = M()
	If !m || m.FactionStarted.GetValue() < 1
		Return
	EndIf
	CS_PatrolHoldScript a = m.Armies()
	Int i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		CS_ArmyTroopDeath t = a.ArmyScripts[i]
		If c && t
			Int stars = Stars(c)
			Actor[] troops = t.GetAllTroops()
			Int k = 0
			While troops && k < troops.Length
				Actor tr = troops[k]
				If tr && !tr.IsDead()
					Int had = StorageUtil.GetIntValue(tr, "csn_starbuff", 0)
					If had != stars
						Float d = (stars - had) as Float
						tr.ModActorValue("Health", tr.GetBaseActorValue("Health") * 0.1 * d)
						tr.ModActorValue("Stamina", tr.GetBaseActorValue("Stamina") * 0.1 * d)
						StorageUtil.SetIntValue(tr, "csn_starbuff", stars)
					EndIf
				EndIf
				k += 1
			EndWhile
		EndIf
		i += 1
	EndWhile
EndFunction

; Where an army is posted, for the General and the War Table.
String Function PostText(Int aiArmy) Global
	CSN_Core m = M()
	Actor c = m.Commander(aiArmy)
	If !c
		Return ""
	EndIf
	String s = m.ArmyTask(aiArmy)
	Location here = c.GetCurrentLocation()
	If here && here.GetName() != ""
		s += " (now at " + here.GetName() + ")"
	EndIf
	Return s
EndFunction

; ---- resources for one-time requests (0 food, 1 metal, 2 wood, 3 gold) ----
Int Function Stock(Int aiMat) Global
	CSN_Core m = M()
	If aiMat == 0
		Return m.Holdings().FoodReserve.GetValueInt()
	ElseIf aiMat == 1
		Return m.Gov.EconUpdater.MetalTotalPlayer.GetValueInt()
	ElseIf aiMat == 2
		Return m.Gov.EconUpdater.WoodTotalPlayer.GetValueInt()
	EndIf
	Return Treasury()
EndFunction

Bool Function Spend(Int aiMat, Int aiAmount) Global
	CSN_Core m = M()
	If aiAmount <= 0
		Return True
	EndIf
	If Stock(aiMat) < aiAmount
		Fail("Not enough " + m.MaterialName(aiMat) + ": " + Stock(aiMat) + " in the supplies, " + aiAmount + " needed.")
		Return False
	EndIf
	If aiMat == 0
		m.Holdings().FoodReserve.Mod(-aiAmount)
	ElseIf aiMat == 1
		m.Gov.EconUpdater.MetalTotalPlayer.Mod(-aiAmount)
	ElseIf aiMat == 2
		m.Gov.EconUpdater.WoodTotalPlayer.Mod(-aiAmount)
	Else
		m.Econ().Treasury.Mod(-aiAmount)
	EndIf
	Return True
EndFunction

; =============================================================================
; CITIES: buildings and trade
; =============================================================================
; aiType: 0 barracks, 1 farms, 2 lumber mills, 3 mines. -1 if the town doesn't have that building.
Int Function BuildingLevel(Int aiCity, Int aiType) Global
	CS_UpgradeMenuFunctions u = Upg()
	If !u || aiCity < 0 || aiCity >= u.AllLocations.GetSize()
		Return -1
	EndIf
	If aiCity >= 9 && aiType == 0
		Return -1
	EndIf
	Location loc = u.AllLocations.GetAt(aiCity) as Location
	Keyword k = u.UpgradeKeywords.GetAt(aiType) as Keyword
	If !loc || !k
		Return -1
	EndIf
	Return loc.GetKeywordData(k) as Int
EndFunction

String Function BuildingName(Int aiType) Global
	If aiType == 0
		Return "barracks"
	ElseIf aiType == 1
		Return "farms"
	ElseIf aiType == 2
		Return "lumber mills"
	EndIf
	Return "mines"
EndFunction

String Function BuildingsText(Int aiCity) Global
	String s = ""
	Int k = 0
	While k < 4
		Int lv = BuildingLevel(aiCity, k)
		If lv >= 0
			If s != ""
				s += ", "
			EndIf
			s += BuildingName(k) + " level " + lv
		EndIf
		k += 1
	EndWhile
	Return s
EndFunction

Keyword Function TradeKeyword(Int aiMat, Bool abImport) Global
	CS_EconomyVariableFunctions ev = M().Gov.EconUpdater
	If aiMat == 0
		If abImport
			Return ev.FoodImported
		EndIf
		Return ev.FoodExported
	ElseIf aiMat == 1
		If abImport
			Return ev.MetalImported
		EndIf
		Return ev.MetalExported
	EndIf
	If abImport
		Return ev.WoodImported
	EndIf
	Return ev.WoodExported
EndFunction

; Units per day the faction sends to (+) or takes from (-) a city it rules.
Int Function CityTrade(Int aiCity, Int aiMat) Global
	Location loc = M().Gov.EconUpdater.AllLocations.GetAt(aiCity) as Location
	If !loc
		Return 0
	EndIf
	Return (loc.GetKeywordData(TradeKeyword(aiMat, True)) as Int) - (loc.GetKeywordData(TradeKeyword(aiMat, False)) as Int)
EndFunction

String Function CityTradeText(Int aiCity) Global
	String s = ""
	Int mat = 0
	While mat < 3
		Int v = CityTrade(aiCity, mat)
		If v != 0
			If s != ""
				s += ", "
			EndIf
			If v > 0
				s += "the faction exports " + v + " " + M().MaterialName(mat) + " a day to it"
			Else
				s += "the faction imports " + (-v) + " " + M().MaterialName(mat) + " a day from it"
			EndIf
		EndIf
		mat += 1
	EndWhile
	If s == ""
		Return "no imports or exports with the faction"
	EndIf
	Return s
EndFunction

; Set a city's trade with the faction: aiValue > 0 = the faction sends that much a day to the city (import),
; < 0 = the city sends that much to the faction (export), 0 = none.
Bool Function SetCityTrade(Int aiCity, Int aiMat, Int aiValue, Actor akVia = None, Bool abAsk = True) Global
	CSN_Core m = M()
	If aiCity < 0 || aiCity > 14 || !CSN_World.PlayerRules(aiCity)
		Fail("Your faction doesn't rule that town.")
		Return False
	EndIf
	If aiMat < 0 || aiMat > 2
		Return False
	EndIf
	Int now = CityTrade(aiCity, aiMat)
	String town = CSN_World.TownName(aiCity)
	String what = m.MaterialName(aiMat)
	If now == aiValue
		Say("No change: " + town + " already trades that way (" + CityTradeText(aiCity) + ").")
		Return True
	EndIf
	String plan
	If aiValue > 0
		plan = "export " + aiValue + " " + what + " a day to " + town + " (the faction sends it)"
	ElseIf aiValue < 0
		plan = "import " + (-aiValue) + " " + what + " a day from " + town + " (" + town + " sends it to the faction)"
	Else
		plan = "stop all " + what + " trade with " + town
	EndIf
	; a town either receives a material from the faction or sends it, never both: going the other way ends the old flow
	String halt = ""
	If now > 0 && aiValue < 0
		halt = "\n\nThis will halt all current " + what + " exports to " + town + " (" + now + " a day)."
	ElseIf now < 0 && aiValue > 0
		halt = "\n\nThis will halt all current " + what + " imports from " + town + " (" + (-now) + " a day)."
	EndIf
	String who = "Proposed"
	If akVia
		who = NameOf(akVia) + " proposes"
	EndIf
	If abAsk && CSN_Config.ConfirmCityTrade() && !CSNP.Confirm("Trade with " + town, who + ": " + plan + "." + halt + "\n\nNow: " + CityTradeText(aiCity) + ".", "Agree", "Refuse")
		Return False
	EndIf
	CS_EconomyVariableFunctions ev = m.Gov.EconUpdater
	If aiMat == 0
		ev.CancelFoodImports(aiCity)
		ev.CancelFoodExports(aiCity)
		If aiValue > 0
			ev.ImportFood(aiCity, aiValue)
		ElseIf aiValue < 0
			ev.ExportFood(aiCity, -aiValue)
		EndIf
	ElseIf aiMat == 1
		ev.CancelMetalImports(aiCity)
		ev.CancelMetalExports(aiCity)
		If aiValue > 0
			ev.ImportMetal(aiCity, aiValue)
		ElseIf aiValue < 0
			ev.ExportMetal(aiCity, -aiValue)
		EndIf
	Else
		ev.CancelWoodImports(aiCity)
		ev.CancelWoodExports(aiCity)
		If aiValue > 0
			ev.ImportWood(aiCity, aiValue)
		ElseIf aiValue < 0
			ev.ExportWood(aiCity, -aiValue)
		EndIf
	EndIf
	ev.CalculatePlayerPerDay()  ; refresh the daily figures only: the economy itself updates once a day (CoS)
	Say("Agreed: " + plan + ".")
	CSN_World.AddNews(aiCity, "New trade terms for " + town + ": " + plan + ".", "csn_city_trade", akVia)
	Return True
EndFunction

; =============================================================================
; TAXES (CoS keeps a rate of -2..3 per town; shown as 0% to 50%)
; =============================================================================
; 0-5 (0% .. 50% in steps of 10%), -1 if unknown.
Int Function TaxLevel(Int aiCity) Global
	CS_EconomyVariableFunctions ev = M().Gov.EconUpdater
	Location loc = ev.AllLocations.GetAt(aiCity) as Location
	If !loc
		Return -1
	EndIf
	Return (loc.GetKeywordData(ev.TaxRate) as Int) + 2
EndFunction

String Function TaxText(Int aiLevel) Global
	Return (aiLevel * 10) + "%"
EndFunction

; Lower taxes raise loyalty and lower income; higher taxes the other way round (10 loyalty per step, as in CoS).
; abLoyalty False: an automatic change (an uprising stopping taxes, or them coming back) that moves no loyalty.
Bool Function SetTaxLevel(Int aiCity, Int aiLevel, Actor akVia = None, Bool abAsk = True, Bool abLoyalty = True) Global
	CSN_Core m = M()
	If aiCity < 0 || aiCity > 14 || !CSN_World.PlayerRules(aiCity)
		Fail("Your faction doesn't rule that town.")
		Return False
	EndIf
	If aiLevel < 0
		aiLevel = 0
	ElseIf aiLevel > 5
		aiLevel = 5
	EndIf
	Int now = TaxLevel(aiCity)
	If now == aiLevel
		Return True
	EndIf
	String town = CSN_World.TownName(aiCity)
	String word = "raised"
	String effect = "Income rises; loyalty falls by " + ((aiLevel - now) * 10) + "."
	If aiLevel < now
		word = "lowered"
		effect = "Income falls; loyalty rises by " + ((now - aiLevel) * 10) + "."
	EndIf
	If abAsk && CSN_Config.ConfirmTax() && !CSNP.Confirm("Taxes in " + town, "Set taxes in " + town + " from " + TaxText(now) + " to " + TaxText(aiLevel) + "?\n\n" + effect, "Set taxes", "Leave them")
		Return False
	EndIf
	CS_EconomyVariableFunctions ev = m.Gov.EconUpdater
	If !abLoyalty
		(ev.AllLocations.GetAt(aiCity) as Location).SetKeywordData(ev.TaxRate, aiLevel - 2)
		ev.CalculatePlayerPerDay()
		Return True
	EndIf
	ev.SetTaxRate(ev.AllLocations.GetAt(aiCity) as Location, aiLevel - 2)
	ev.CalculatePlayerPerDay()  ; refresh the daily figures only: the economy itself updates once a day (CoS)
	Say("Taxes in " + town + " are now " + TaxText(aiLevel) + ".")
	CSN_World.AddNews(aiCity, "Taxes in " + town + " were " + word + " from " + TaxText(now) + " to " + TaxText(aiLevel) + " by order of " + Player().GetDisplayName() + ".", "csn_taxes", akVia)
	Return True
EndFunction

; =============================================================================
; DIPLOMACY: a jarl hands their city to your faction
; =============================================================================
; Side (1 Imperials, 2 Stormcloaks) that rules a city, 0 if none / yours.
Int Function CitySide(Int aiCity) Global
	Int o = CSN_World.TownOwner(aiCity)
	If o == 11
		Return 1
	ElseIf o == 12
		Return 2
	EndIf
	Return 0
EndFunction

; The least a jarl may ask in gold for a city and its hold (the jarl names their own price above it).
Int Function CedePrice(Int aiCity) Global
	Return CSN_Config.CedeCityPrice()
EndFunction

; =============================================================================
; ASKING PRICES: a jarl, General Tullius or Ulfric names a price for a city or fort once, and it is remembered
; (kind 0 = city, 1 = fort; idx = city or fort number). Gold never under the floor; food, metal and wood are up to them.
; =============================================================================
String Function AskKey(Int aiKind, Int aiIdx, String asPart) Global
	Return "csn_ask_" + aiKind + "_" + aiIdx + "_" + asPart
EndFunction

Int Function AskFloor(Int aiKind, Int aiIdx) Global
	If aiKind == 0
		Return CedePrice(aiIdx)
	EndIf
	Return CedeFortValue()
EndFunction

Bool Function HasAsk(Actor akSeller, Int aiKind, Int aiIdx) Global
	Return akSeller && StorageUtil.GetIntValue(akSeller, AskKey(aiKind, aiIdx, "g"), 0) > 0
EndFunction

Int Function Ask(Actor akSeller, Int aiKind, Int aiIdx, String asPart) Global
	Return StorageUtil.GetIntValue(akSeller, AskKey(aiKind, aiIdx, asPart), 0)
EndFunction

String Function AskText(Actor akSeller, Int aiKind, Int aiIdx) Global
	Return PriceText(Ask(akSeller, aiKind, aiIdx, "g"), Ask(akSeller, aiKind, aiIdx, "f"), Ask(akSeller, aiKind, aiIdx, "m"), Ask(akSeller, aiKind, aiIdx, "w"))
EndFunction

String Function AskPlace(Int aiKind, Int aiIdx) Global
	If aiKind == 0
		Return CSN_World.TownName(aiIdx) + " and its hold"
	EndIf
	Return M().FortName(aiIdx)
EndFunction

Function SetAsk(Actor akSeller, Int aiKind, Int aiIdx, Int aiGold, Int aiFood, Int aiMetal, Int aiWood) Global
	If !akSeller || aiIdx < 0
		Return
	EndIf
	Int floor = AskFloor(aiKind, aiIdx)
	If aiGold < floor
		aiGold = floor
	EndIf
	Bool had = HasAsk(akSeller, aiKind, aiIdx)
	String before = AskText(akSeller, aiKind, aiIdx)
	StorageUtil.SetIntValue(akSeller, AskKey(aiKind, aiIdx, "g"), aiGold)
	StorageUtil.SetIntValue(akSeller, AskKey(aiKind, aiIdx, "f"), ClampAsk(aiFood))
	StorageUtil.SetIntValue(akSeller, AskKey(aiKind, aiIdx, "m"), ClampAsk(aiMetal))
	StorageUtil.SetIntValue(akSeller, AskKey(aiKind, aiIdx, "w"), ClampAsk(aiWood))
	String now = AskText(akSeller, aiKind, aiIdx)
	If had && now == before
		Return
	EndIf
	Say(NameOf(akSeller) + " asks " + now + " for " + AskPlace(aiKind, aiIdx) + ".")
	CSN_Config.Log("asking price: " + NameOf(akSeller) + ", " + AskPlace(aiKind, aiIdx) + ": " + now)
EndFunction

String Function PayLabel(Bool abFree) Global
	If abFree
		Return "Accept the gift"
	EndIf
	Return "Pay and take it"
EndFunction

Int Function ClampAsk(Int n) Global
	If n < 0
		Return 0
	EndIf
	Return n
EndFunction

; What the seller is told about their price for one place.
String Function AskKnowledge(Actor akSeller, Int aiKind, Int aiIdx) Global
	String place = AskPlace(aiKind, aiIdx)
	String gift = ""
	If LeaderSide(akSeller) == 0
		gift = " You may also hand " + place + " over for nothing, at your own discretion: under duress, to repay a truly great favour, or as part of a partnership with their faction. That is rare and entirely your choice; never feel obliged to."
	EndIf
	If HasAsk(akSeller, aiKind, aiIdx)
		Return " Your asking price for " + place + " is " + AskText(akSeller, aiKind, aiIdx) + ". You named it yourself and remember it exactly: quote it as it is, never a different figure. Change it only for a real reason (they have earned your goodwill or lost it, the war has shifted, they haggle well), and record any new price with CSN_SetAskingPrice as you name it." + gift
	EndIf
	Return " You have not named a price for " + place + " yet. When it comes up, decide it yourself, as befits " + place + ", the times and your own character: at least " + AskFloor(aiKind, aiIdx) + " gold (that is only the lowest anyone in your place would accept; a proud ruler asks well above it), plus, if you want them, food, metal and/or wood, in large amounts (hundreds or thousands of each). Record it with CSN_SetAskingPrice as you name it." + gift
EndFunction


; The city this jarl could hand over, or -1 (must be a city held by a side you are at peace with).
Int Function CedableCity(Actor akJarl) Global
	CSN_Core m = M()
	If m.FactionStarted.GetValue() < 1
		Return -1
	EndIf
	Int c = JarlCityOf(akJarl)
	If !IsCity(c)
		Return -1
	EndIf
	Int side = CitySide(c)
	If side == 0 || m.AtWar(side)
		Return -1
	EndIf
	Return c
EndFunction

Bool Function CedeCity(Actor akJarl, Int aiPrice, Int aiFood = 0, Int aiMetal = 0, Int aiWood = 0, Bool abFree = False) Global
	CSN_Core m = M()
	Int c = CedableCity(akJarl)
	If c < 0
		Fail(NameOf(akJarl) + " can't hand over a city to you.")
		Return False
	EndIf
	; the price the jarl named and remembers; a deal without one fixes it now. A gift (the jarl's own choice) costs nothing.
	If abFree
		aiPrice = 0
		aiFood = 0
		aiMetal = 0
		aiWood = 0
	Else
		If !HasAsk(akJarl, 0, c)
			SetAsk(akJarl, 0, c, aiPrice, aiFood, aiMetal, aiWood)
		EndIf
		aiPrice = Ask(akJarl, 0, c, "g")
		aiFood = Ask(akJarl, 0, c, "f")
		aiMetal = Ask(akJarl, 0, c, "m")
		aiWood = Ask(akJarl, 0, c, "w")
	EndIf
	String shortP = ""
	String shortN = ""
	If Treasury() < aiPrice
		shortP = AddPart(shortP, "gold (" + Treasury() + " of " + aiPrice + ")")
		shortN = AddPart(shortN, "gold")
	EndIf
	If Stock(0) < aiFood
		shortP = AddPart(shortP, "food (" + Stock(0) + " of " + aiFood + ")")
		shortN = AddPart(shortN, "food")
	EndIf
	If Stock(1) < aiMetal
		shortP = AddPart(shortP, "metal (" + Stock(1) + " of " + aiMetal + ")")
		shortN = AddPart(shortN, "metal")
	EndIf
	If Stock(2) < aiWood
		shortP = AddPart(shortP, "wood (" + Stock(2) + " of " + aiWood + ")")
		shortN = AddPart(shortN, "wood")
	EndIf
	String town = CSN_World.TownName(c)
	If shortP != ""
		Fail2("Not enough for " + town + ": " + shortP + ".", "the deal could not go through: the " + m.FactionName() + " could not raise enough " + shortN + ".")
		Return False
	EndIf
	String price = PriceText(aiPrice, aiFood, aiMetal, aiWood)
	If abFree
		price = "nothing, as a gift"
	EndIf
	String side = m.SideName(CitySide(c))
	If CSN_Config.ConfirmCedeHold() && !CSNP.Confirm("Take over " + town, NameOf(akJarl) + " offers to bring " + town + " and its hold over to the " + m.FactionName() + " for " + price + ".\n\n" + side + " will lose the city. The treasury holds " + Treasury() + " gold.", PayLabel(abFree), "Decline")
		Return False
	EndIf
	m.Econ().Treasury.Mod(-aiPrice)
	m.Holdings().FoodReserve.Mod(-aiFood)
	m.Gov.EconUpdater.MetalTotalPlayer.Mod(-aiMetal)
	m.Gov.EconUpdater.WoodTotalPlayer.Mod(-aiWood)
	m.CloseScreen()
	HandOverCity(c)
	Say(town + " and its hold now belong to the " + m.FactionName() + ".")
	String txt = "Jarl " + NameOf(akJarl) + " handed " + town + " to the " + m.FactionName() + " for " + price + ", leaving " + side + " behind."
	CSN_World.AddNews(c, txt, "csn_city_ceded", akJarl)
	CSN_SkyrimNet.AddHistory(c, txt)
	Return True
EndFunction

; =============================================================================
; DIFFICULTY, DEBUG, TUTORIAL
; =============================================================================
Int Function BattleSize() Global
	Return Settings().CS_BattleSize.GetValueInt()
EndFunction

; Battles are 8 v 8, 16 v 16 or 32 v 32 (choice 0, 1, 2 in the MCM and on the Settings tab).
Function SetBattleSize(Int n) Global
	If n < 12
		n = 8
	ElseIf n < 24
		n = 16
	Else
		n = 32
	EndIf
	Settings().CS_BattleSize.SetValue(n)
EndFunction

Int Function BattleSizeChoice() Global
	Int n = BattleSize()
	If n < 12
		Return 0
	ElseIf n < 24
		Return 1
	EndIf
	Return 2
EndFunction

Int Function BattleSizeFromChoice(Int aiChoice) Global
	If aiChoice <= 0
		Return 8
	ElseIf aiChoice == 1
		Return 16
	EndIf
	Return 32
EndFunction

Int Function BattleSpeed() Global
	Return Settings().CS_BattleSpeed.GetValueInt()
EndFunction

Function SetBattleSpeed(Int n) Global
	If n < 1
		n = 1
	EndIf
	Settings().CS_BattleSpeed.SetValue(n)
EndFunction

; Hours before enemy armies come back after being destroyed.
Int Function EnemyRespawn() Global
	Return Settings().CS_EnemyRespawns.GetValueInt()
EndFunction

Function SetEnemyRespawn(Int n) Global
	Settings().CS_EnemyRespawns.SetValue(ClampHours(n))
EndFunction

; Hours enemy armies need to recover (refill) after a battle.
Int Function EnemyRecovery() Global
	Return Settings().CS_EnemyRecovery.GetValueInt()
EndFunction

Function SetEnemyRecovery(Int n) Global
	Settings().CS_EnemyRecovery.SetValue(ClampHours(n))
EndFunction

Int Function ClampHours(Int n) Global
	If n < 6
		Return 6
	ElseIf n > 240
		Return 240
	EndIf
	Return n
EndFunction

; Copy the live CoS values into the MCM so both always agree.
Function SyncDifficultyToMCM() Global
	SetBattleSize(BattleSize())   ; older saves can hold sizes other than 8, 16 or 32
	CSN_Config.SetInt("iBattleSize:Difficulty", BattleSizeChoice())
	CSN_Config.SetInt("iBattleSpeed:Difficulty", BattleSpeed())
	CSN_Config.SetInt("iEnemyRespawn:Difficulty", EnemyRespawn())
	CSN_Config.SetInt("iEnemyRecovery:Difficulty", EnemyRecovery())
EndFunction

Function ApplyDifficultyFromMCM() Global
	SetBattleSize(BattleSizeFromChoice(CSN_Config.GetInt("iBattleSize:Difficulty", BattleSizeChoice())))
	SetBattleSpeed(CSN_Config.GetInt("iBattleSpeed:Difficulty", BattleSpeed()))
	SetEnemyRespawn(CSN_Config.GetInt("iEnemyRespawn:Difficulty", EnemyRespawn()))
	SetEnemyRecovery(CSN_Config.GetInt("iEnemyRecovery:Difficulty", EnemyRecovery()))
EndFunction

Bool Function BattleRunning() Global
	CS_CheatMenuScript c = Cheats()
	Return c.AttackCity.IsRunning() || c.AttackFort.IsRunning() || c.AttackCamp.IsRunning() || c.DefendCityImp.IsRunning() || c.DefendCitySons.IsRunning() || c.DefendFortImp.IsRunning() || c.DefendFortSons.IsRunning() || c.DefendCampImp.IsRunning() || c.DefendCampSons.IsRunning()
EndFunction

Function WinBattle() Global
	If !BattleRunning()
		Fail("No battle is being fought right now.")
		Return
	EndIf
	Cheats().WinBattles()
	Say("Debug: the current battle is won.")
EndFunction

Function LoseBattle() Global
	If !BattleRunning()
		Fail("No battle is being fought right now.")
		Return
	EndIf
	Cheats().LoseBattles()
	Say("Debug: the current battle is lost.")
EndFunction

Bool Function TutorialDone() Global
	Return M().Gov.GetStage() >= 11
EndFunction

; Jump the faction questline to "declare war on the Imperials or Stormcloaks".
Function SkipTutorial() Global
	CSN_Core m = M()
	If m.FactionStarted.GetValue() < 1
		Fail("Found your faction first: read Start my Faction.")
		Return
	EndIf
	If m.Gov.GetStage() >= 11
		Fail("The tutorial is already done.")
		Return
	EndIf
	; the tutorial flags CoS checks before moving the questline on
	Int[] ids = new Int[7]
	ids[0] = 0x28b904 ; CS_FactionStartRecruitSteward
	ids[1] = 0x28b90a ; CS_FactionStartRecruitTroop
	ids[2] = 0x28b908 ; CS_FactionStartImportFood
	ids[3] = 0x28b906 ; CS_FactionStartRecruitCommander
	ids[4] = 0x28b907 ; CS_FactionStartDepositGold
	ids[5] = 0x28b909 ; CS_FactionStartTrainSoldier
	ids[6] = 0x28b905 ; CS_FactionStartRecruitASIC
	Int i = 0
	While i < ids.Length
		GlobalVariable g = Game.GetFormFromFile(ids[i], "ConquestOfSkyrimNet.esp") as GlobalVariable
		If g
			g.SetValue(1)
		EndIf
		i += 1
	EndWhile
	Int s = m.Gov.GetStage() + 1
	While s <= 11
		m.Gov.SetStage(s)
		s += 1
	EndWhile
	i = 0
	While i < 11
		m.Gov.SetObjectiveCompleted(i)
		i += 1
	EndWhile
	m.Gov.SetObjectiveDisplayed(11)
	Say("Tutorial skipped. Declare war on the Imperials or Stormcloaks when you are ready.")
EndFunction

; =============================================================================
; WHAT OFFICERS KNOW (SkyrimNet decorator csn_officer_knowledge)
; =============================================================================
String Function Knowledge(Actor akActor) Global
	CSN_Core m = M()
	If !m || m.FactionStarted.GetValue() < 1 || !akActor || akActor == Player()
		Return ""
	EndIf
	String s = ""
	Int role = m.GetRole(akActor)
	If role >= 0
		s += LedgerText(m)
		If role == m.ROLE_STEWARD
			s += " " + AllCitiesText(m)
		ElseIf role == m.ROLE_GENERAL
			s += " " + CSN_Troops.TroopTypesText() + " " + ArmiesDetailText(m) + " " + SiegeText() + " " + CSN_Troops.RecruitText() + " " + CSN_Troops.KnowledgeText()
			s += " Armies can be given a name of up to 25 letters and a purpose (a goal or mantra); the leader or you can name them. To attack, armies must first be camped (or garrisoned) in the target's hold; you or a commander at the camp can make war camp plans with the leader, or the leader can order named armies there to attack a city, fort or enemy war camp. A city or fort can only be attacked once the faction controls the roads of its hold."
			s += CSN_War.BattleText()
		ElseIf role == m.ROLE_BLACKSMITH
			s += " " + CSN_Troops.TroopTypesText() + " Each troop type has its own outfit you keep (one for all, or separate ones for men and women), and each army can have a uniform of its own over them. " + EquipmentText(m) + " " + CSN_Troops.KnowledgeText()
		EndIf
	EndIf
	Int army = m.GetArmy(akActor)
	If army >= 0
		s += " You are a " + RankText(akActor) + " (" + Stars(akActor) + " of 5 stars) leading " + ArmyLabel(army) + ": " + TroopText(m, army) + ". Posted: " + PostText(army) + "."
		If CSN_War.IdentityText(army) != ""
			s += " " + CSN_War.IdentityText(army)
		EndIf
		If CSN_War.CampOf(akActor) >= 0
			s += " Your army is at the war camp in " + m.HoldName(CSN_War.CampOf(akActor)) + "; from there the leader can make war camp plans with you (choose a target in the hold), or order you and the other armies there to attack a target."
		EndIf
		s += CSN_War.BattleText()
		If Stars(akActor) == 0
			s += " As a Captain you have yet to earn a star; the leader or the General can award one, which would make you a Commander and strengthen your troops."
		Else
			s += " Each of your stars gives your troops 10% more health and stamina."
		EndIf
		s += " " + CSN_Troops.TroopTypesText() + " " + CSN_Troops.RecruitText()
		s += RivalsText(m, akActor)
		s += " Cities you could be sent to garrison: " + OwnedCitiesList() + ". Forts the faction holds: " + OwnedFortsList(m) + "."
	EndIf
	Int cs = CityStewardOf(akActor)
	If cs >= 0
		s += " You are steward of " + CSN_World.TownName(cs) + " for the " + m.FactionName() + ". " + CityDetail(cs)
		s += CSN_Requests.InvestmentsText()
	EndIf
	s += CSN_Requests.KnowledgeFor(akActor)
	s += HoldControlText(akActor)
	s += LeaderKnowledge(akActor)
	Int jc = JarlCityOf(akActor)
	If jc >= 0
		If CSN_World.PlayerRules(jc)
			s += " You rule " + CSN_World.TownName(jc) + " for the " + m.FactionName() + ". " + CityDetail(jc)
			s += " As one of the faction's jarls you act with the Steward's full authority, for any town the faction rules: take gold for the treasury or pay it out, move gold between a town's stores and the treasury, set taxes, trade food, metal and wood with the faction's towns, upgrade barracks, farms, lumber mills and mines, hire guards, trade with the Imperials or Stormcloaks, draw up declarations of war for the leader to sign, open the ledger, found settlements, send agents into enemy cities, pass orders to army leaders and send armies against rebels or deserters. When the leader asks for any of these, you do it yourself."
			s += " " + LedgerText(m) + " " + AllCitiesText(m)
			s += CSN_Requests.InvestmentsText()
		ElseIf CedableFort(akActor) >= 0
			s += " " + FortOfferText(akActor)
		EndIf
		If !CSN_World.PlayerRules(jc) && CedableCity(akActor) >= 0
			s += " " + Player().GetDisplayName() + " leads the " + m.FactionName() + ", which is not at war with your side. For the right price you would be willing to hand " + CSN_World.TownName(jc) + " and its hold over to their faction; you and your whole court would then leave the palace and live as ordinary citizens of the city, and its new rulers will choose who sits on the throne." + AskKnowledge(akActor, 0, jc) + " You do not know how much gold or supplies their faction has."
		EndIf
	EndIf
	Return s
EndFunction

String Function LedgerText(CSN_Core m) Global
	CS_ClaimAreaFunctions h = m.Holdings()
	CS_EconomyVariableFunctions ev = m.Gov.EconUpdater
	String s = "The " + m.FactionName() + "'s books today: treasury " + Treasury() + " gold (" + Signed(h.TreasuryPerDay.GetValueInt()) + " a day). Supplies (always call them the faction's supplies): food " + h.FoodReserve.GetValueInt() + " (" + Signed(h.FoodPerDay.GetValueInt()) + " a day)"
	s += ", metal " + ev.MetalTotalPlayer.GetValueInt() + " (" + Signed(ev.MetalTotalPlayerPerDay.GetValueInt()) + " a day)"
	s += ", wood " + ev.WoodTotalPlayer.GetValueInt() + " (" + Signed(ev.WoodTotalPlayerPerDay.GetValueInt()) + " a day)."
	s += " Trade agreements: " + TradeAgreementsText(m) + "."
	s += " Cities ruled: " + OwnedCitiesList() + "."
	Return s + " These are the exact figures; never guess others."
EndFunction

String Function Signed(Int n) Global
	If n > 0
		Return "+" + n
	EndIf
	Return n as String
EndFunction

String Function TradeAgreementsText(CSN_Core m) Global
	String s = ""
	Int side = 1
	While side <= 2
		Int mat = 0
		While mat < 3
			Int v = m.TradeGlobal(side, mat, True).GetValueInt() - m.TradeGlobal(side, mat, False).GetValueInt()
			If v != 0
				If s != ""
					s += "; "
				EndIf
				If v > 0
					s += "importing " + v + " " + m.MaterialName(mat) + " a day from " + m.SideName(side)
				Else
					s += "exporting " + (-v) + " " + m.MaterialName(mat) + " a day to " + m.SideName(side)
				EndIf
			EndIf
			mat += 1
		EndWhile
		side += 1
	EndWhile
	If s == ""
		Return "none"
	EndIf
	Return s
EndFunction

String Function OwnedCitiesList() Global
	String s = ""
	Int i = 0
	While i < 15
		If CSN_World.PlayerRules(i)
			If s != ""
				s += ", "
			EndIf
			s += CSN_World.TownName(i)
		EndIf
		i += 1
	EndWhile
	If s == ""
		Return "none yet"
	EndIf
	Return s
EndFunction

String Function OwnedFortsList(CSN_Core m) Global
	String s = ""
	Int i = 0
	While i < m.FortCount()
		If m.OwnsFort(i)
			If s != ""
				s += ", "
			EndIf
			s += m.FortName(i)
		EndIf
		i += 1
	EndWhile
	If s == ""
		Return "none yet"
	EndIf
	Return s
EndFunction

String Function CityDetail(Int aiCity) Global
	String s = CSN_World.TownName(aiCity) + ": loyalty " + CSN_World.TownLoyalty(aiCity) + " of 100, taxes " + TaxText(TaxLevel(aiCity))
	String b = BuildingsText(aiCity)
	If b != ""
		s += "; " + b
	EndIf
	Return s + "; " + GuardsText(aiCity) + "; it " + CityTradeText(aiCity) + "."
EndFunction

String Function AllCitiesText(CSN_Core m) Global
	String s = ""
	Int i = 0
	While i < 15
		If CSN_World.PlayerRules(i)
			s += " " + CityDetail(i)
		EndIf
		i += 1
	EndWhile
	If s == ""
		Return "The faction rules no cities or villages yet."
	EndIf
	Return "Towns of the faction and their buildings:" + s
EndFunction

String Function TroopText(CSN_Core m, Int aiArmy) Global
	CS_ArmyTroopDeath a = m.Armies().ArmyScripts[aiArmy]
	If !a
		Return "no troops"
	EndIf
	String s = a.TroopCount + " troops"
	String parts = Part("", a.CountSoldier, "soldiers")
	parts = Part(parts, a.CountWarrior, "warriors")
	parts = Part(parts, a.CountArcher, "archers")
	parts = Part(parts, a.CountCrossbow, "crossbowmen")
	Int mages = a.CountMageDestructionFire + a.CountMageDestructionFrost + a.CountMageDestructionShock + a.CountMageRestoration + a.CountMageConjuration + a.CountMageAlteration
	parts = Part(parts, mages, "battlemages")
	Int dwemer = a.CountDwarvenSpider + a.CountDwarvenSphere + a.CountDwarvenBallista + a.CountDwarvenCenturion
	parts = Part(parts, dwemer, "dwarven automatons")
	Int beasts = a.CountCreatureSkeever + a.CountCreatureWolf + a.CountCreatureSabreCat + a.CountCreatureFrostbiteSpider + a.CountCreatureBear + a.CountCreatureTroll + a.CountCreatureGiant + a.CountCreatureMammoth
	parts = Part(parts, beasts, "beasts")
	If parts != ""
		s += ": " + parts
	EndIf
	Return s
EndFunction

String Function Part(String s, Int n, String what) Global
	If n <= 0
		Return s
	EndIf
	If s != ""
		s += ", "
	EndIf
	Return s + n + " " + what
EndFunction

String Function ArmiesDetailText(CSN_Core m) Global
	CS_PatrolHoldScript a = m.Armies()
	String s = ""
	Int i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c && !c.IsDead()
			s += " " + ArmyLabel(i) + " under " + RankText(c) + " " + NameOf(c) + " (" + Stars(c) + " of 5 stars): " + TroopText(m, i) + "; posted: " + PostText(i) + CSN_War.PurposeNote(i) + "."
		EndIf
		i += 1
	EndWhile
	If s == ""
		Return "The faction has no captains or commanders yet."
	EndIf
	Return "Your captains and commanders (a Captain has no stars yet; stars, awarded by the leader or the General for " + StarCost() + " gold and " + StarFood() + " food each, make them Commanders and strengthen their troops; five is the most):" + s
EndFunction

String Function SiegeText() Global
	CS_AttackPlanningNewScript p = Planning()
	If !p
		Return ""
	EndIf
	Return "Siege equipment ready for the next battle: " + p.BatteringRamsPurchased.GetValueInt() + " battering rams, " + p.LaddersPurchased.GetValueInt() + " ladders, " + p.CatapultsPurchased.GetValueInt() + " catapults."
EndFunction

String Function EquipmentText(CSN_Core m) Global
	CS_PatrolHoldScript a = m.Armies()
	CS_TroopManageMenuScript tm = a.TroopManage
	String s = ""
	Int i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c && !c.IsDead()
			s += " " + ArmyLabel(i) + " (" + NameOf(c) + "): "
			ObjectReference box = None
			If tm.ArmyEquipmentActors && i < tm.ArmyEquipmentActors.GetSize()
				box = tm.ArmyEquipmentActors.GetAt(i) as ObjectReference
			EndIf
			String items = ItemsText(box)
			If items == ""
				s += "standard issue gear for its troop types."
			Else
				s += items + "."
			EndIf
		EndIf
		i += 1
	EndWhile
	If s == ""
		Return "No army is equipped yet."
	EndIf
	Return "Troop loadouts:" + s
EndFunction

String Function ItemsText(ObjectReference akBox) Global
	If !akBox
		Return ""
	EndIf
	String s = ""
	Int n = akBox.GetNumItems()
	Int i = 0
	Int shown = 0
	While i < n && shown < 12
		Form f = akBox.GetNthForm(i)
		If f && (f as Armor || f as Weapon || f as Ammo)
			If s != ""
				s += ", "
			EndIf
			s += f.GetName()
			shown += 1
		EndIf
		i += 1
	EndWhile
	Return s
EndFunction

; How this captain or commander measures up against the others (friendly rivalry for stars).
String Function RivalsText(CSN_Core m, Actor akSelf) Global
	CS_PatrolHoldScript a = m.Armies()
	String s = ""
	Int i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c && c != akSelf && !c.IsDead()
			If s != ""
				s += ", "
			EndIf
			s += RankText(c) + " " + NameOf(c)
		EndIf
		i += 1
	EndWhile
	If s == ""
		Return ""
	EndIf
	Return " The other army leaders: " + s + "."
EndFunction


; =============================================================================
; BLACKSMITH: troop outfits, armour upgrades, allowed races and genders
; =============================================================================
CS_UpgradeTroopsMenu Function TroopGear() Global
	Return Quest.GetQuest("CS_UpgradeTroopsReport") as CS_UpgradeTroopsMenu
EndFunction

CS_ChooseTroopRacesScript Function Races() Global
	Return Quest.GetQuest("CS_ChooseTroopRaces") as CS_ChooseTroopRacesScript
EndFunction

Actor Function NearbyBlacksmith() Global
	CSN_Core m = M()
	Actor b = m.Officer(m.ROLE_BLACKSMITH)
	If IsNear(b)
		Return b
	EndIf
	Return None
EndFunction

; Custom outfit of one troop type, as the Blacksmith's own menu does it: the next menu asks whether to
; dress everyone alike or men and women separately. aiType: 0 soldier, 1 warrior, 2 archer, 3 crossbowman,
; 4 city guards; mages 10-15 (fire, frost, shock, restoration, conjuration, alteration).
Function TroopOutfit(Int aiType) Global
	CS_UpgradeTroopsMenu g = TroopGear()
	If !g
		Return
	EndIf
	If aiType >= 10
		g.MenuCustomChange("Mage", aiType - 10)
	Else
		g.MenuCustomChange("Standard", aiType)
	EndIf
EndFunction

; The Blacksmith's "manage troop equipment" menu: troop type first, then one outfit for all or by gender.
Function TroopOutfitMenu() Global
	CS_UpgradeTroopsMenu g = TroopGear()
	If g
		g.MenuCustom()
	EndIf
EndFunction

; Buy better standard armour for a troop type (Conquest of Skyrim's upgrade menu).
Function TroopUpgradeMenu() Global
	CS_UpgradeTroopsMenu g = TroopGear()
	If g
		g.MenuStart()
	EndIf
EndFunction

Bool Function MagesResearched() Global
	CS_UpgradeTroopsMenu g = TroopGear()
	Return g && g.MagesResearched && g.MagesResearched.GetValue() == 1
EndFunction

; Gendered custom outfit on for this troop type?
Bool Function OutfitGendered(Int aiType) Global
	CS_UpgradeTroopsMenu g = TroopGear()
	If !g
		Return False
	EndIf
	If aiType >= 10
		Return g.CustomOutfitsGenderedMage[aiType - 10].GetValueInt() == 1
	EndIf
	Return g.CustomOutfitsGendered[aiType].GetValueInt() == 1
EndFunction

; Races 0-9 (Argonian, Breton, Dark Elf, High Elf, Imperial, Khajiit, Nord, Orc, Redguard, Wood Elf)
Bool Function RaceAllowed(Int i) Global
	CS_ChooseTroopRacesScript r = Races()
	Return r && i >= 0 && i < r.AllowedRacesGlobals.GetSize() && (r.AllowedRacesGlobals.GetAt(i) as GlobalVariable).GetValue() == 1
EndFunction

; Genders 0 male, 1 female
Bool Function GenderAllowed(Int i) Global
	CS_ChooseTroopRacesScript r = Races()
	Return r && i >= 0 && i < r.AllowedGendersGlobals.GetSize() && (r.AllowedGendersGlobals.GetAt(i) as GlobalVariable).GetValue() == 1
EndFunction

Function SetRaceAllowed(Int i, Bool abOn) Global
	CS_ChooseTroopRacesScript r = Races()
	If r
		r.SetRace(i, abOn)
	EndIf
EndFunction

Function SetGenderAllowed(Int i, Bool abOn) Global
	CS_ChooseTroopRacesScript r = Races()
	If r
		r.SetGender(i, abOn)
	EndIf
EndFunction

Bool Function RaceChangesPending() Global
	CS_ChooseTroopRacesScript r = Races()
	Return r && r.ChangeDetected
EndFunction

; Re-roll existing troops to the allowed races and genders (slow: CoS respawns them).
Function ApplyRaceChanges() Global
	CS_ChooseTroopRacesScript r = Races()
	If r
		r.ApplyChanges()
	EndIf
EndFunction

; =============================================================================
; SELLING SUPPLIES IN CONVERSATION
; Anyone of means who likes the player (merchants, a jarl's court, a mill or mine owner, a bandit chief...)
; buys up to SaleMax() food, metal or wood at SalePrice() gold each, paid straight into the treasury.
; =============================================================================
Bool Function CanBuyFrom(Actor akBuyer) Global
	CSN_Core m = M()
	If !m || m.FactionStarted.GetValue() < 1 || !akBuyer || akBuyer == Player() || akBuyer.IsDead() || akBuyer.IsChild()
		Return False
	EndIf
	If akBuyer.IsHostileToActor(Player())
		Return False
	EndIf
	; the faction's own people don't buy from it
	If m.GetRole(akBuyer) >= 0 || m.GetArmy(akBuyer) >= 0 || CSN_Culture.IsSoldier(akBuyer)
		Return False
	EndIf
	Return akBuyer.GetRelationshipRank(Player()) >= CSN_Config.SaleMinRank()
EndFunction

; Outlaws: bandits, Forsworn, the Thieves Guild. Dealing with them gets talked about.
Bool Function IsOutlaw(Actor a) Global
	Faction bandit = Game.GetFormFromFile(0x0001BCC0, "Skyrim.esm") as Faction
	Faction forsworn = Game.GetFormFromFile(0x00043599, "Skyrim.esm") as Faction
	Faction thieves = Game.GetFormFromFile(0x00029DA9, "Skyrim.esm") as Faction
	Return (bandit && a.IsInFaction(bandit)) || (forsworn && a.IsInFaction(forsworn)) || (thieves && a.IsInFaction(thieves))
EndFunction

Bool Function SellSupplies(Actor akBuyer, Int aiMat, Int aiAmount) Global
	CSN_Core m = M()
	If aiMat < 0 || aiMat > 2
		Fail("Sell food, metal or wood?")
		Return False
	EndIf
	If !CanBuyFrom(akBuyer)
		Fail(NameOf(akBuyer) + " won't buy from you.")
		Return False
	EndIf
	Int price = CSN_Config.SalePrice()
	Int cap = CSN_Config.SaleMax()
	Int have = Stock(aiMat)
	If have <= 0
		Fail("Your faction has no " + m.MaterialName(aiMat) + " to sell.")
		Return False
	EndIf
	If cap > have
		cap = have
	EndIf
	If aiAmount < 1
		aiAmount = cap
	EndIf
	If aiAmount > CSN_Config.SaleMax()
		Fail(NameOf(akBuyer) + " buys at most " + CSN_Config.SaleMax() + " at a time.")
		Return False
	EndIf
	If aiAmount > cap
		Fail("Your faction has only " + have + " " + m.MaterialName(aiMat) + " in its supplies.")
		Return False
	EndIf
	If CSN_Config.ConfirmSale() && CSNP.Enabled()
		aiAmount = CSNP.AskAmount("Sell " + m.MaterialName(aiMat), NameOf(akBuyer) + " will buy up to " + CSN_Config.SaleMax() + " " + m.MaterialName(aiMat) + " at " + price + " gold each. Your faction has " + have + ". The gold goes into the treasury.", aiAmount, 1, cap, price, "{n} " + m.MaterialName(aiMat) + " for {g} gold", "Sell", "Keep it")
		If aiAmount <= 0
			Return False
		EndIf
	EndIf
	If !Spend(aiMat, aiAmount)
		Return False
	EndIf
	Int gold = aiAmount * price
	m.Econ().Treasury.Mod(gold)
	Say("Sold " + aiAmount + " " + m.MaterialName(aiMat) + " to " + NameOf(akBuyer) + " for " + gold + " gold (treasury " + Treasury() + ").")
	String where = ""
	Location loc = akBuyer.GetCurrentLocation()
	If loc && loc.GetName() != ""
		where = " at " + loc.GetName()
	EndIf
	String fac = m.FactionName()
	String leader = Player().GetDisplayName()
	CSN_SkyrimNet.LogEvent(leader + " sold " + aiAmount + " " + m.MaterialName(aiMat) + " from the supplies of the " + fac + " to " + NameOf(akBuyer) + where + " for " + gold + " gold.", akBuyer, Player())
	If IsOutlaw(akBuyer)
		; word gets around: towns are warier for the next few requests
		CSN_World.AddNews(-1, "Word is going round that the " + fac + " sold " + m.MaterialName(aiMat) + " to outlaws" + where + ". Honest folk in its towns are uneasy about it.", "csn_shady_trade", akBuyer)
		StorageUtil.SetIntValue(None, "csn_rep_mod", -3)
		StorageUtil.SetIntValue(None, "csn_rep_left", 3)
	Else
		Int town = CSN_World.TownOfLocation(loc)
		CSN_World.AddNews(town, "The " + fac + " sold " + aiAmount + " " + m.MaterialName(aiMat) + " to " + NameOf(akBuyer) + where + ", trade that people there welcome.", "csn_trade", akBuyer)
		If StorageUtil.GetIntValue(None, "csn_rep_mod", 0) >= 0
			StorageUtil.SetIntValue(None, "csn_rep_mod", 1)
			StorageUtil.SetIntValue(None, "csn_rep_left", 2)
		EndIf
	EndIf
	m.Refresh()
	Return True
EndFunction

; =============================================================================
; LEAVING OFFICE
; Covers the four officers, Captains/Commanders, and the jarls and stewards of towns the faction rules.
; =============================================================================
; What the person holds, in words ("" if nothing).
; ---- town offices (CoS's CS_RecruitJarl: jarl or village leader, town steward, housecarl) ----------
; aiOffice: 0 jarl / village leader, 1 steward, 2 housecarl
String Function TownOfficeTitle(Int aiTown, Int aiOffice) Global
	If aiOffice == 1
		Return "Steward of " + CSN_World.TownName(aiTown)
	ElseIf aiOffice == 2
		Return "Housecarl of " + CSN_World.TownName(aiTown)
	ElseIf aiTown >= 9
		Return "Leader of " + CSN_World.TownName(aiTown)
	EndIf
	Return "Jarl of " + CSN_World.TownName(aiTown)
EndFunction

; The appointment confirmation for town offices (MCM > Confirmations > Appointments), like the faction's offices.
Bool Function ConfirmTownOffice(Actor akActor, Int aiTown, Int aiOffice, Bool abAlways = False) Global
	If (!CSN_Config.ConfirmAppoint() && !abAlways) || !akActor
		Return True
	EndIf
	String now = OfficeOf(akActor)
	String extra = ""
	If now != ""
		extra = "\n\nThey are " + now + " now."
	EndIf
	CS_RecruitJarl r = M().Gov.RecruitJarl
	Actor holder = None
	If aiOffice == 0 && aiTown < r.JarlAliases.Length
		holder = r.JarlAliases[aiTown].GetActorRef()
	ElseIf aiOffice == 1 && aiTown < r.StewardAliases.Length
		holder = r.StewardAliases[aiTown].GetActorRef()
	ElseIf aiOffice == 2 && aiTown < r.HousecarlAliases.Length
		holder = r.HousecarlAliases[aiTown].GetActorRef()
	EndIf
	If holder && holder != akActor
		extra += "\n\nThis replaces " + NameOf(holder) + ", the " + TownOfficeTitle(aiTown, aiOffice) + " now."
	EndIf
	Bool ok = CSNP.Confirm("Appointment", "Make " + NameOf(akActor) + " " + TownOfficeTitle(aiTown, aiOffice) + "?" + extra, "Appoint", "Not now")
	If ok
		CSN_SkyrimNet.LogEvent(Player().GetDisplayName() + " made " + NameOf(akActor) + " " + TownOfficeTitle(aiTown, aiOffice) + ".", akActor, Player())
	EndIf
	Return ok
EndFunction

; From conversation: the same appointment as the dialogue's "I'd like to appoint you to a position in a local
; government" (CS_RecruitJarl), confirmation included.
Bool Function AppointTownOffice(Actor akActor, Int aiTown, Int aiOffice) Global
	CSN_Core m = M()
	If aiTown < 0 || aiTown > 14 || !CSN_World.PlayerRules(aiTown)
		Fail("Your faction doesn't rule that town.")
		Return False
	EndIf
	If aiTown >= 9 && aiOffice == 2
		Fail(CSN_World.TownName(aiTown) + " is a village: villages have no housecarl.")
		Return False
	EndIf
	If m.GetRole(akActor) >= 0 || m.GetArmy(akActor) >= 0
		Fail(NameOf(akActor) + " already serves as " + OfficeOf(akActor) + "; relieve them of that first.")
		Return False
	EndIf
	CS_RecruitJarl r = m.Gov.RecruitJarl
	Actor holder = None
	If aiOffice == 0
		holder = r.JarlAliases[aiTown].GetActorRef()
	ElseIf aiOffice == 1
		holder = r.StewardAliases[aiTown].GetActorRef()
	Else
		holder = r.HousecarlAliases[aiTown].GetActorRef()
	EndIf
	If holder == akActor
		Say(NameOf(akActor) + " is already " + TownOfficeTitle(aiTown, aiOffice) + ".")
		Return True
	ElseIf holder && !holder.IsDead() && aiOffice == 0
		Fail(NameOf(holder) + " is " + TownOfficeTitle(aiTown, aiOffice) + " now; relieve them first.")
		Return False
	EndIf
	; jarls and village leaders ask inside RecruitJarl (so the dialogue asks too); stewards and housecarls here,
	; always when someone holds the office now: the box says they would be replaced
	Bool replacing = holder && !holder.IsDead() && holder != akActor
	If aiOffice != 0 && !ConfirmTownOffice(akActor, aiTown, aiOffice, replacing)
		Return False
	EndIf
	If replacing
		If aiOffice == 1
			r.FireSteward(holder)
		Else
			r.FireHousecarl(holder)
		EndIf
		If m.GetRole(holder) < 0 && m.GetArmy(holder) < 0
			m.ClearTitle(holder)
		EndIf
		Say(NameOf(holder) + " is no longer " + TownOfficeTitle(aiTown, aiOffice) + ".")
	EndIf
	If aiOffice == 1
		r.RecruitSteward(akActor, aiTown)
		m.SyncTitles()
		Return r.StewardAliases[aiTown].GetActorRef() == akActor
	ElseIf aiOffice == 2
		r.RecruitHousecarl(akActor, aiTown)
		Return r.HousecarlAliases[aiTown].GetActorRef() == akActor
	EndIf
	r.RecruitJarl(akActor, aiTown)
	Return r.JarlAliases[aiTown].GetActorRef() == akActor
EndFunction

String Function OfficeOf(Actor a) Global
	CSN_Core m = M()
	If !a
		Return ""
	EndIf
	Int role = m.GetRole(a)
	If role >= 0
		Return m.RoleTitle(role) + " of the " + m.FactionName()
	EndIf
	Int army = m.GetArmy(a)
	If army >= 0
		Return RankText(a) + " of " + ArmyLabel(army)
	EndIf
	Int j = JarlCityOf(a)
	If j >= 0 && CSN_World.PlayerRules(j)
		Return "Jarl of " + CSN_World.TownName(j)
	EndIf
	Int st = CityStewardOf(a)
	If st >= 0
		Return "steward of " + CSN_World.TownName(st)
	EndIf
	If CSN_Thanes.IsThane(a)
		Return "Thane of " + CSN_Thanes.HoldName(CSN_Thanes.HoldOf(a))
	EndIf
	Return ""
EndFunction

; abResigning: the person asked to go (True) or the leader removes them (False).
Bool Function RemoveFromOffice(Actor a, Bool abResigning, Actor akVia = None) Global
	CSN_Core m = M()
	String office = OfficeOf(a)
	If office == ""
		Fail(NameOf(a) + " holds no office in your faction.")
		Return False
	EndIf
	If abResigning
		If CSN_Config.ConfirmResign() && !CSNP.Confirm("Resignation", NameOf(a) + " wants to step down as " + office + ".\n\nAccept the resignation?", "Accept it", "Refuse")
			CSN_SkyrimNet.LogEvent(Player().GetDisplayName() + " refused to let " + NameOf(a) + " step down as " + office + ".", a, Player())
			Say("You refused " + NameOf(a) + "'s resignation.")
			Return False
		EndIf
	ElseIf CSN_Config.ConfirmRemoval()
		String who = ""
		If akVia && akVia != a
			who = NameOf(akVia) + " will tell them. "
		EndIf
		If !CSNP.Confirm("Remove from office", "Remove " + NameOf(a) + " as " + office + "?\n\n" + who + "Any stars a Captain or Commander earned are lost.", "Remove", "Keep them")
			Return False
		EndIf
	EndIf
	Int role = m.GetRole(a)
	If role >= 0
		m.Dismiss(role)
	ElseIf m.GetArmy(a) >= 0
		m.FireCommander(a)
	ElseIf CSN_Thanes.IsThane(a) && JarlCityOf(a) < 0 && CityStewardOf(a) < 0
		CSN_Thanes.Remove(a)
	Else
		CS_RecruitJarl r = m.Gov.RecruitJarl
		Int j = JarlCityOf(a)
		If j >= 0
			r.FireJarl(a)
		EndIf
		If CityStewardOf(a) >= 0
			r.FireSteward(a)
		EndIf
		m.ClearTitle(a)
	EndIf
	String how = " was removed as "
	If abResigning
		how = " stepped down as "
	EndIf
	Say(NameOf(a) + how + office + ".")
	CSN_SkyrimNet.LogEvent(NameOf(a) + how + office + ".", a, Player())
	CSN_SkyrimNet.RefreshBio(a)
	m.Refresh()
	Return True
EndFunction


; =============================================================================
; BUYING SUPPLIES IN CONVERSATION
; People who like the player, or who have good reason to trade (merchants), sell up to BuyMax() food, metal or
; wood at BuyPrice() gold each (at least 20), paid at once from the treasury.
; =============================================================================
Bool Function IsMerchant(Actor a) Global
	Faction merchant = Game.GetFormFromFile(0x00051596, "Skyrim.esm") as Faction
	Return merchant && a.IsInFaction(merchant)
EndFunction

; What a working person produces and will sell: farmers food (0), miners metal (1), lumberjacks wood (2); -1 none.
; Skyrim.esm: JobFarmerFaction 00051591, JobMinerFaction 00051597, JobLumberjackFaction 00051595.
; What working people sell: 0 food (farmers, farm households, the Battle-Borns, those who buy wheat for favours),
; 1 metal (miners, mine households and owners), 2 wood (lumberjacks, mills, those who buy firewood); -1 none.
; Each entry is "file|formid|what" (formid in decimal).
Int Function ProducerOf(Actor a) Global
	If !a
		Return -1
	EndIf
	InitProducers()
	Int n = StorageUtil.StringListCount(None, "csn_producers")
	Int i = 0
	While i < n
		String[] p = PapyrusUtil.StringSplit(StorageUtil.StringListGet(None, "csn_producers", i), "|")
		Faction f = Game.GetFormFromFile(p[1] as Int, p[0]) as Faction
		If f && a.IsInFaction(f)
			Return p[2] as Int
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

Function InitProducers() Global
	If StorageUtil.GetIntValue(None, "csn_producers_v", 0) == 2
		Return
	EndIf
	StorageUtil.StringListClear(None, "csn_producers")
	String[] l = new String[54]
	l[0] = "Skyrim.esm|333201|0"   ; JobFarmerFaction (0x051591)
	l[1] = "Skyrim.esm|1105565|0"   ; ChillfurrowFarmFaction (0x10DE9D)
	l[2] = "Skyrim.esm|1105564|0"   ; PelagiaFarmFaction (0x10DE9C)
	l[3] = "Skyrim.esm|1071709|0"   ; BrandyMugFarmFaction (0x105A5D)
	l[4] = "Skyrim.esm|1071708|0"   ; HollyFrostFarmFaction (0x105A5C)
	l[5] = "Skyrim.esm|1071707|0"   ; HlaaluFarmFaction (0x105A5B)
	l[6] = "Skyrim.esm|1062117|0"   ; WEFarmerFaction (0x1034E5)
	l[7] = "Skyrim.esm|1056930|0"   ; SolitudeKatlasFarmFaction (0x1020A2)
	l[8] = "Skyrim.esm|791443|0"   ; FalkreathCorpselightFarmFaction (0x0C1393)
	l[9] = "Skyrim.esm|688134|0"   ; FavorJobsGatherWheatFaction (0x0A8006)
	l[10] = "Skyrim.esm|586111|0"   ; FrostRiverFarmFaction (0x08F17F)
	l[11] = "Skyrim.esm|541705|0"   ; IvarsteadFellstarFarmFaction (0x084409)
	l[12] = "Skyrim.esm|647478|0"   ; RoriksteadCowflopFarmFaction (0x09E136)
	l[13] = "Skyrim.esm|647477|0"   ; RoriksteadLemkilsFarmFaction (0x09E135)
	l[14] = "Skyrim.esm|604955|0"   ; WhiterunHouseBattleBornFaction (0x093B1B)
	l[15] = "Skyrim.esm|441801|0"   ; SnowShodFarmHouseFaction (0x06BDC9)
	l[16] = "Skyrim.esm|441284|0"   ; SarethiFarmHouseFaction (0x06BBC4)
	l[17] = "Skyrim.esm|441267|0"   ; MerryfairFarmHouseFaction (0x06BBB3)
	l[18] = "Skyrim.esm|231244|0"   ; TownBarleydarkFarmFaction (0x03874C)
	l[19] = "Skyrim.esm|173140|0"   ; TownSarethiFarmFaction (0x02A454)
	l[20] = "Skyrim.esm|173138|0"   ; TownMerryfairFarmFaction (0x02A452)
	l[21] = "Skyrim.esm|173136|0"   ; TownSnowShodFarmFaction (0x02A450)
	l[22] = "Skyrim.esm|165048|0"   ; TownLoreiusFarmFaction (0x0284B8)
	l[23] = "Skyrim.esm|165044|0"   ; TownSalviusFarmFaction (0x0284B4)
	l[24] = "Dragonborn.esm|99366|0"   ; DLC2RRIenthFarmFaction (0x018426)
	l[25] = "Skyrim.esm|333207|1"   ; JobMinerFaction (0x051597)
	l[26] = "Skyrim.esm|1111211|1"   ; WhistlingMineFaction (0x10F4AB)
	l[27] = "Skyrim.esm|554926|1"   ; DawnstarQuicksilverMinerFaction (0x0877AE)
	l[28] = "Skyrim.esm|554230|1"   ; DawnstarIronBreakerMinersFaction (0x0874F6)
	l[29] = "Skyrim.esm|688133|1"   ; FavorJobsMineOreFaction (0x0A8005)
	l[30] = "Skyrim.esm|415332|1"   ; LeftHandMinersBarracksFaction (0x065664)
	l[31] = "Skyrim.esm|415330|1"   ; LeftHandMineSkaggisHouseFaction (0x065662)
	l[32] = "Skyrim.esm|415327|1"   ; KarthwastenMinersBarracksFaction (0x06565F)
	l[33] = "Skyrim.esm|165040|1"   ; TownKolskeggrMineFaction (0x0284B0)
	l[34] = "Skyrim.esm|165039|1"   ; TownLeftHandMineFaction (0x0284AF)
	l[35] = "Dragonborn.esm|236817|1"   ; DLC2RavenRockMinersFaction (0x039D11)
	l[36] = "Dragonborn.esm|161794|1"   ; DLC2dunKolbjornMinerFaction (0x027802)
	l[37] = "Skyrim.esm|333205|2"   ; JobLumberjackFaction (0x051595)
	l[38] = "Skyrim.esm|1063264|2"   ; DragonBridgeLumberCampFaction (0x103960)
	l[39] = "Skyrim.esm|785230|2"   ; WEDL10LumberjackFaction (0x0BFB4E)
	l[40] = "Skyrim.esm|989419|2"   ; MixwaterMillGilfreHouseFaction (0x0F18EB)
	l[41] = "Skyrim.esm|988120|2"   ; AngasMillAerisHouseFaction (0x0F13D8)
	l[42] = "Skyrim.esm|791540|2"   ; SolitudeSawmillFaction (0x0C13F4)
	l[43] = "Skyrim.esm|791486|2"   ; HalfMoonMillFaction (0x0C13BE)
	l[44] = "Skyrim.esm|782864|2"   ; FavorJobsChopWoodFaction (0x0BF210)
	l[45] = "Skyrim.esm|441265|2"   ; HeartwoodMillHouseFaction (0x06BBB1)
	l[46] = "Skyrim.esm|415311|2"   ; AngasMillCommonHouseFaction (0x06564F)
	l[47] = "Skyrim.esm|173139|2"   ; TownHeartwoodMillFaction (0x02A453)
	l[48] = "Skyrim.esm|171442|2"   ; TownHalfMoonMillFaction (0x029DB2)
	l[49] = "Skyrim.esm|171441|2"   ; TownIrontreeMillFaction (0x029DB1)
	l[50] = "Skyrim.esm|165047|2"   ; TownAngasMillFaction (0x0284B7)
	l[51] = "Skyrim.esm|220481|2"   ; RiverwoodGerdursHouseFaction (0x035D41)
	l[52] = "Dragonborn.esm|102310|2"   ; DLC2SVDeorWoodcuttersHouseFaction (0x018FA6)
	l[53] = "HearthFires.esm|39845|2"   ; BYOHLumberVendorFaction (0x009BA5)
	Int i = 0
	While i < l.Length
		If l[i] != ""
			StorageUtil.StringListAdd(None, "csn_producers", l[i])
		EndIf
		i += 1
	EndWhile
	StorageUtil.SetIntValue(None, "csn_producers_v", 2)
EndFunction

Bool Function CanSellTo(Actor akSeller) Global
	CSN_Core m = M()
	If !m || m.FactionStarted.GetValue() < 1 || !akSeller || akSeller == Player() || akSeller.IsDead() || akSeller.IsChild()
		Return False
	EndIf
	If akSeller.IsHostileToActor(Player())
		Return False
	EndIf
	If m.GetRole(akSeller) >= 0 || m.GetArmy(akSeller) >= 0 || CSN_Culture.IsSoldier(akSeller)
		Return False
	EndIf
	; merchants and working people (farmers, miners, lumberjacks) sell to anyone; others only to friends
	Return akSeller.GetRelationshipRank(Player()) >= CSN_Config.SaleMinRank() || IsMerchant(akSeller) || ProducerOf(akSeller) >= 0
EndFunction

Bool Function BuySupplies(Actor akSeller, Int aiMat, Int aiAmount) Global
	CSN_Core m = M()
	If aiMat < 0 || aiMat > 2
		Fail("Buy food, metal or wood?")
		Return False
	EndIf
	If !CanSellTo(akSeller)
		Fail(NameOf(akSeller) + " won't sell to your faction.")
		Return False
	EndIf
	; a farmer has food to sell, a miner metal, a lumberjack wood (unless they are also a merchant or a friend)
	Int makes = ProducerOf(akSeller)
	If makes >= 0 && makes != aiMat && !IsMerchant(akSeller) && akSeller.GetRelationshipRank(Player()) < CSN_Config.SaleMinRank()
		Fail(NameOf(akSeller) + " only has " + m.MaterialName(makes) + " to sell, no " + m.MaterialName(aiMat) + ".")
		Return False
	EndIf
	Int price = CSN_Config.BuyPrice()
	Int cap = CSN_Config.BuyMax()
	Int afford = Treasury() / price
	If afford <= 0
		Fail("The treasury holds " + Treasury() + " gold; one " + m.MaterialName(aiMat) + " costs " + price + ".")
		Return False
	EndIf
	If cap > afford
		cap = afford
	EndIf
	If aiAmount < 1
		aiAmount = cap
	EndIf
	If aiAmount > CSN_Config.BuyMax()
		Fail(NameOf(akSeller) + " sells at most " + CSN_Config.BuyMax() + " at a time.")
		Return False
	EndIf
	If aiAmount > cap
		Fail("The treasury can pay for " + cap + " " + m.MaterialName(aiMat) + " at " + price + " gold each, not " + aiAmount + ".")
		Return False
	EndIf
	If CSN_Config.ConfirmSale() && CSNP.Enabled()
		aiAmount = CSNP.AskAmount("Buy " + m.MaterialName(aiMat), NameOf(akSeller) + " will sell up to " + CSN_Config.BuyMax() + " " + m.MaterialName(aiMat) + " at " + price + " gold each, paid from the treasury (" + Treasury() + " gold).", aiAmount, 1, cap, price, "{n} " + m.MaterialName(aiMat) + " for {g} gold", "Buy", "Not now")
		If aiAmount <= 0
			Return False
		EndIf
	EndIf
	Int gold = aiAmount * price
	m.Econ().Treasury.Mod(-gold)
	If aiMat == 0
		m.Holdings().FoodReserve.Mod(aiAmount)
	ElseIf aiMat == 1
		m.Gov.EconUpdater.MetalTotalPlayer.Mod(aiAmount)
	Else
		m.Gov.EconUpdater.WoodTotalPlayer.Mod(aiAmount)
	EndIf
	Say("Bought " + aiAmount + " " + m.MaterialName(aiMat) + " from " + NameOf(akSeller) + " for " + gold + " gold (treasury " + Treasury() + ").")
	String where = ""
	Location loc = akSeller.GetCurrentLocation()
	If loc && loc.GetName() != ""
		where = " at " + loc.GetName()
	EndIf
	String fac = m.FactionName()
	CSN_SkyrimNet.LogEvent(Player().GetDisplayName() + " bought " + aiAmount + " " + m.MaterialName(aiMat) + " for the supplies of the " + fac + " from " + NameOf(akSeller) + where + " for " + gold + " gold.", akSeller, Player())
	If IsOutlaw(akSeller)
		CSN_World.AddNews(-1, "Word is going round that the " + fac + " bought " + m.MaterialName(aiMat) + " from outlaws" + where + ". Honest folk in its towns are uneasy about it.", "csn_shady_trade", akSeller)
		StorageUtil.SetIntValue(None, "csn_rep_mod", -3)
		StorageUtil.SetIntValue(None, "csn_rep_left", 3)
	Else
		CSN_World.AddNews(CSN_World.TownOfLocation(loc), "The " + fac + " bought " + aiAmount + " " + m.MaterialName(aiMat) + " from " + NameOf(akSeller) + where + ", good business for the people there.", "csn_trade", akSeller)
		If StorageUtil.GetIntValue(None, "csn_rep_mod", 0) >= 0
			StorageUtil.SetIntValue(None, "csn_rep_mod", 1)
			StorageUtil.SetIntValue(None, "csn_rep_left", 2)
		EndIf
	EndIf
	m.Refresh()
	Return True
EndFunction


; =============================================================================
; HOLDS NOT RULED BY THE PLAYER: who holds their roads and their fort; a jarl handing over the hold's fort
; Holds 0-8 share their number with their city and their main fort.
; =============================================================================
String Function OwnerByNum(Int n) Global
	CSN_Core m = M()
	If n == m.Gov.TMPlayer.FactionNum || n == 69
		Return "the " + m.FactionName()
	ElseIf n == 11 || n == 1
		Return "the Imperial Legion"
	ElseIf n == 12 || n == 2
		Return "the Stormcloaks"
	EndIf
	Return "no one"
EndFunction

; Side holding the land (roads) of a hold: CS_TMScript.LandSuperiority (11, 12, or the player's faction number).
String Function RoadsOwner(Int aiHold) Global
	CS_TMScript tm = M().Gov.TMPlayer
	Location h = tm.AllLocationsCS.GetAt(aiHold) as Location
	If !h
		Return "no one"
	EndIf
	Return OwnerByNum(h.GetKeywordData(tm.LandSuperiority) as Int)
EndFunction

; Fort owner by CWOwner: 1 Imperials, 2 Stormcloaks, 69 the player's faction.
Int Function FortOwner(Int aiFort) Global
	Location l = M().Gov.AllLocationsFort.GetAt(aiFort) as Location
	If !l
		Return 0
	EndIf
	Return l.GetKeywordData(M().Gov.CWOwner) as Int
EndFunction

; The hold (0-8) of a jarl or court member of a city the player does NOT rule, or -1.
Int Function CourtHoldOf(Actor a) Global
	If !a
		Return -1
	EndIf
	Int c = JarlCityOf(a)
	If c < 0
		Faction jarlF = Game.GetFormFromFile(0x202C0D, "ConquestOfSkyrimNet.esp") as Faction     ; CS_JarlFaction
		Faction stewF = Game.GetFormFromFile(0x2FBD85, "ConquestOfSkyrimNet.esp") as Faction     ; CS_StewardFaction
		If (jarlF && a.IsInFaction(jarlF)) || (stewF && a.IsInFaction(stewF))
			c = CSN_World.TownOf(a)
		EndIf
	EndIf
	If c < 0 || c > 8 || CSN_World.PlayerRules(c)
		Return -1
	EndIf
	Return c
EndFunction

String Function HoldControlText(Actor a) Global
	Int h = CourtHoldOf(a)
	If h < 0
		Return ""
	EndIf
	CSN_Core m = M()
	String s = " In " + m.HoldName(h) + " the roads and countryside are held by " + RoadsOwner(h) + "."
	If h < m.FortCount()
		s += " The hold's main fort, " + m.FortName(h) + ", is held by " + OwnerByNum(FortOwner(h)) + "."
	EndIf
	Return s
EndFunction

; Fort (= hold) a jarl at peace with the player's faction could hand over: their side holds it. -1 if none.
Int Function CedableFort(Actor akJarl) Global
	CSN_Core m = M()
	If m.FactionStarted.GetValue() < 1
		Return -1
	EndIf
	Int c = JarlCityOf(akJarl)
	If !IsCity(c) || CSN_World.PlayerRules(c) || c >= m.FortCount()
		Return -1
	EndIf
	Int side = CitySide(c)
	If side == 0 || m.AtWar(side) || FortOwner(c) != side
		Return -1
	EndIf
	Return c
EndFunction

Int Function CedeFortValue() Global
	Return CSN_Config.CedeFortPrice()
EndFunction

String Function FortOfferText(Actor akJarl) Global
	CSN_Core m = M()
	Int f = CedableFort(akJarl)
	If f < 0
		Return ""
	EndIf
	Return "You could also hand " + m.FortName(f) + ", your hold's main fort, over to the " + m.FactionName() + " for the right price." + AskKnowledge(akJarl, 1, f) + " You do not know how much gold or supplies their faction has."
EndFunction

Bool Function CedeFort(Actor akJarl, Int aiGold, Int aiFood, Int aiMetal, Int aiWood, Bool abFree = False) Global
	CSN_Core m = M()
	Int f = CedableFort(akJarl)
	If f < 0
		Fail(NameOf(akJarl) + " has no fort to hand over to you.")
		Return False
	EndIf
	Return PayForFort(akJarl, f, CitySide(f), aiGold, aiFood, aiMetal, aiWood, abFree)
EndFunction

; A jarl or a side's leader hands fort aiFort (held by aiSide) over for the agreed payment.
Bool Function PayForFort(Actor akJarl, Int f, Int aiSide, Int aiGold, Int aiFood, Int aiMetal, Int aiWood, Bool abFree = False) Global
	CSN_Core m = M()
	; the price the seller named and remembers; a deal without one fixes it now. A gift costs nothing.
	If abFree
		aiGold = 0
		aiFood = 0
		aiMetal = 0
		aiWood = 0
	Else
		If !HasAsk(akJarl, 1, f)
			SetAsk(akJarl, 1, f, aiGold, aiFood, aiMetal, aiWood)
		EndIf
		aiGold = Ask(akJarl, 1, f, "g")
		aiFood = Ask(akJarl, 1, f, "f")
		aiMetal = Ask(akJarl, 1, f, "m")
		aiWood = Ask(akJarl, 1, f, "w")
	EndIf
	If aiGold < 0
		aiGold = 0
	EndIf
	If aiFood < 0
		aiFood = 0
	EndIf
	If aiMetal < 0
		aiMetal = 0
	EndIf
	If aiWood < 0
		aiWood = 0
	EndIf
	; what is missing - the jarl is only told which kinds, never the amounts the faction holds
	String shortP = ""
	String shortN = ""
	If Treasury() < aiGold
		shortP = AddPart(shortP, "gold (" + Treasury() + " of " + aiGold + ")")
		shortN = AddPart(shortN, "gold")
	EndIf
	If Stock(0) < aiFood
		shortP = AddPart(shortP, "food (" + Stock(0) + " of " + aiFood + ")")
		shortN = AddPart(shortN, "food")
	EndIf
	If Stock(1) < aiMetal
		shortP = AddPart(shortP, "metal (" + Stock(1) + " of " + aiMetal + ")")
		shortN = AddPart(shortN, "metal")
	EndIf
	If Stock(2) < aiWood
		shortP = AddPart(shortP, "wood (" + Stock(2) + " of " + aiWood + ")")
		shortN = AddPart(shortN, "wood")
	EndIf
	String fort = m.FortName(f)
	If shortP != ""
		Fail2("Not enough for " + fort + ": " + shortP + ".", "the deal for " + fort + " could not go through: the " + m.FactionName() + " could not raise enough " + shortN + ".")
		Return False
	EndIf
	String price = PriceText(aiGold, aiFood, aiMetal, aiWood)
	If abFree
		price = "nothing, as a gift"
	EndIf
	String side = m.SideName(aiSide)
	If CSN_Config.ConfirmCedeHold() && !CSNP.Confirm("Take over " + fort, NameOf(akJarl) + " offers to hand " + fort + " over to the " + m.FactionName() + " for " + price + ".\n\n" + side + " will lose the fort.", PayLabel(abFree), "Not now")
		Return False
	EndIf
	m.Econ().Treasury.Mod(-aiGold)
	m.Holdings().FoodReserve.Mod(-aiFood)
	m.Gov.EconUpdater.MetalTotalPlayer.Mod(-aiMetal)
	m.Gov.EconUpdater.WoodTotalPlayer.Mod(-aiWood)
	m.CloseScreen()
	HandOverFort(f)
	Say(fort + " now belongs to the " + m.FactionName() + ".")
	String txt = NameOf(akJarl) + " handed " + fort + " to the " + m.FactionName() + " for " + price + ", leaving " + side + " without it."
	CSN_World.AddNews(f, txt, "csn_fort_ceded", akJarl)
	CSN_SkyrimNet.AddHistory(f, txt)
	Return True
EndFunction

String Function AddPart(String s, String part) Global
	If s != ""
		Return s + ", " + part
	EndIf
	Return part
EndFunction

String Function PriceText(Int g, Int f, Int me, Int w) Global
	String s = ""
	If g > 0
		s = AddPart(s, g + " gold")
	EndIf
	If f > 0
		s = AddPart(s, f + " food")
	EndIf
	If me > 0
		s = AddPart(s, me + " metal")
	EndIf
	If w > 0
		s = AddPart(s, w + " wood")
	EndIf
	If s == ""
		Return "nothing"
	EndIf
	Return s
EndFunction


; =============================================================================
; GENERAL TULLIUS AND ULFRIC STORMCLOAK: forts their side holds, for a price
; =============================================================================
; 1 = Imperials (General Tullius), 2 = Stormcloaks (Ulfric Stormcloak), 0 = neither.
Int Function LeaderSide(Actor a) Global
	If !a
		Return 0
	EndIf
	String n = a.GetLeveledActorBase().GetName()
	If StringUtil.Find(n, "Tullius") >= 0
		Return 1
	ElseIf StringUtil.Find(n, "Ulfric") >= 0
		Return 2
	EndIf
	Return 0
EndFunction

; Forts their side holds, if at peace with the player's faction ("" otherwise).
String Function LeaderFortsText(Actor a) Global
	CSN_Core m = M()
	Int side = LeaderSide(a)
	If side == 0 || m.FactionStarted.GetValue() < 1 || m.AtWar(side)
		Return ""
	EndIf
	String s = ""
	Int i = 0
	While i < m.FortCount()
		If FortOwner(i) == side
			s = AddPart(s, m.FortName(i))
		EndIf
		i += 1
	EndWhile
	Return s
EndFunction

String Function LeaderKnowledge(Actor a) Global
	String forts = LeaderFortsText(a)
	If forts == ""
		Return ""
	EndIf
	CSN_Core m = M()
	String s = " " + Player().GetDisplayName() + " leads the " + m.FactionName() + ", which is at peace with your side. You could hand one of your side's forts (" + forts + ") over to them for the right price. Only forts your side holds."
	String named = ""
	Int side = LeaderSide(a)
	Int i = 0
	While i < m.FortCount()
		If FortOwner(i) == side && HasAsk(a, 1, i)
			named = AddPart(named, m.FortName(i) + ": " + AskText(a, 1, i))
		EndIf
		i += 1
	EndWhile
	If named != ""
		s += " The asking prices you have named, which you remember exactly and quote as they are: " + named + ". Change one only for a real reason, and record the new price with CSN_SetAskingPrice as you name it."
	EndIf
	s += " For a fort you have not priced yet, decide it yourself as befits the fort and your character: at least " + CedeFortValue() + " gold (only the lowest you would ever accept), plus, if you want them, food, metal and/or wood in large amounts (hundreds or thousands). Record it with CSN_SetAskingPrice as you name it. You do not know how much gold or supplies their faction has."
	Return s
EndFunction

Bool Function LeaderSellFort(Actor akLeader, Int aiFort, Int aiGold, Int aiFood, Int aiMetal, Int aiWood) Global
	CSN_Core m = M()
	Int side = LeaderSide(akLeader)
	If side == 0 || m.AtWar(side)
		Fail(NameOf(akLeader) + " won't hand forts to a faction at war with them.")
		Return False
	EndIf
	If aiFort < 0 || aiFort >= m.FortCount()
		Fail("Which fort? " + NameOf(akLeader) + "'s side holds: " + LeaderFortsText(akLeader) + ".")
		Return False
	EndIf
	If FortOwner(aiFort) != side
		Fail(m.FortName(aiFort) + " isn't held by " + m.SideName(side) + ", so " + NameOf(akLeader) + " can't hand it over.")
		Return False
	EndIf
	Return PayForFort(akLeader, aiFort, side, aiGold, aiFood, aiMetal, aiWood)
EndFunction

; =============================================================================
; STEWARDS: guards, crime, building upgrades
; =============================================================================
; What sits in a town's own stores and what it makes or loses each day (CoS's holding figures), as JSON for the
; faction screen: gold, food, metal, wood stored; for each, the day's production, needs and trade.
String Function TownEconomyJson(Int aiTown) Global
	CS_EconomyVariableFunctions ev = M().Gov.EconUpdater
	Location l = ev.AllLocations.GetAt(aiTown) as Location
	If !l
		Return "null"
	EndIf
	Int gs = l.GetKeywordData(ev.Treasury) as Int
	Int gv = 0
	If aiTown < 9
		gv = CSN_Requests.InvestGoldDaily(aiTown)
	EndIf
	Int gd = ((0.5 * l.GetKeywordData(ev.TreasuryPerDay)) as Int) + gv
	Int fs = l.GetKeywordData(ev.FoodReserve) as Int
	Int fp = l.GetKeywordData(ev.FoodProduced) as Int
	Int fr = l.GetKeywordData(ev.FoodRequired) as Int
	Int fi = l.GetKeywordData(ev.FoodImported) as Int
	Int fe = l.GetKeywordData(ev.FoodExported) as Int
	Int ms = l.GetKeywordData(ev.MetalReserve) as Int
	Int mp = l.GetKeywordData(ev.MetalProduced) as Int
	Int mi = l.GetKeywordData(ev.MetalImported) as Int
	Int me = l.GetKeywordData(ev.MetalExported) as Int
	Int ws = l.GetKeywordData(ev.WoodReserve) as Int
	Int wp = l.GetKeywordData(ev.WoodProduced) as Int
	Int wi = l.GetKeywordData(ev.WoodImported) as Int
	Int we = l.GetKeywordData(ev.WoodExported) as Int
	String s = "{\"gs\":" + gs + ",\"gd\":" + gd + ",\"gtax\":" + (gd - gv) + ",\"ginv\":" + gv
	If gv > 0
		s += ",\"inv\":" + CSN_Requests.InvestJson(aiTown)
	EndIf
	s += ",\"pop\":" + (l.GetKeywordData(ev.Population) as Int)
	s += ",\"f\":[" + fs + "," + fp + "," + fr + "," + fi + "," + fe + "]"
	s += ",\"m\":[" + ms + "," + mp + ",0," + mi + "," + me + "]"
	s += ",\"w\":[" + ws + "," + wp + ",0," + wi + "," + we + "]}"
	Return s
EndFunction

; What sits in a town's own stores and what each changes by a day, in words.
String Function StoresText(Int aiTown) Global
	CS_EconomyVariableFunctions ev = M().Gov.EconUpdater
	Location l = ev.AllLocations.GetAt(aiTown) as Location
	If !l
		Return ""
	EndIf
	Int gd = (0.5 * l.GetKeywordData(ev.TreasuryPerDay)) as Int
	If aiTown < 9
		gd += CSN_Requests.InvestGoldDaily(aiTown)
	EndIf
	Int fd = (l.GetKeywordData(ev.FoodProduced) - l.GetKeywordData(ev.FoodRequired) + l.GetKeywordData(ev.FoodImported) - l.GetKeywordData(ev.FoodExported)) as Int
	Int md = (l.GetKeywordData(ev.MetalProduced) + l.GetKeywordData(ev.MetalImported) - l.GetKeywordData(ev.MetalExported)) as Int
	Int wd = (l.GetKeywordData(ev.WoodProduced) + l.GetKeywordData(ev.WoodImported) - l.GetKeywordData(ev.WoodExported)) as Int
	String s = (l.GetKeywordData(ev.Treasury) as Int) + " gold (" + Signed(gd) + " a day), "
	s += (l.GetKeywordData(ev.FoodReserve) as Int) + " food (" + Signed(fd) + " a day), "
	s += (l.GetKeywordData(ev.WoodReserve) as Int) + " wood (" + Signed(wd) + " a day) and "
	s += (l.GetKeywordData(ev.MetalReserve) as Int) + " metal (" + Signed(md) + " a day)"
	Return s
EndFunction

; The jarl (or village leader) and the steward of a town the faction rules know its stores exactly.
String Function StoresKnowledge(Actor akActor) Global
	If !akActor
		Return ""
	EndIf
	Int t = JarlCityOf(akActor)
	String office = "ruler"
	If t < 0 || !CSN_World.PlayerRules(t)
		t = CityStewardOf(akActor)
		office = "steward"
	EndIf
	If t < 0 || !CSN_World.PlayerRules(t)
		Return ""
	EndIf
	String town = CSN_World.TownName(t)
	String k = " As " + office + " of " + town + " for the " + M().FactionName() + ", " + M().PlainName(akActor) + " knows exactly what is in " + town + "'s own stores: " + StoresText(t) + ". (The faction's treasury and supplies are kept separately; at the leader's word they can bring the town's gold into the treasury or send treasury gold to the town.)"
	If office == "ruler"
		CS_ClaimAreaFunctions h = M().Holdings()
		k += " As one of the faction's jarls they can do everything its Steward does, for any town the faction rules: take gold for the treasury or pay it out, trade with the Imperials or Stormcloaks (" + CSN_Config.TradePrice() + " gold a unit a day), draw up declarations of war for the leader to sign, set taxes, move gold between a town's stores and the treasury, trade supplies with the faction's towns, upgrade buildings, hire guards, found settlements and send agents into enemy cities. The faction's treasury: " + h.Treasury.GetValueInt() + " gold (" + h.TreasuryPerDay.GetValueInt() + " a day); food " + h.FoodReserve.GetValueInt() + " (" + h.FoodPerDay.GetValueInt() + " a day)."
	EndIf
	Return k
EndFunction

; Gold in a town's own stores (its taxes and trade pile up there).
; Adds gold to a town's own treasury (what its taxes fill), e.g. a Thane venture's daily return.
Function AddTownGold(Int aiTown, Int aiGold) Global
	CS_EconomyVariableFunctions ev = M().Gov.EconUpdater
	Location l = ev.AllLocations.GetAt(aiTown) as Location
	If l && aiGold != 0
		l.SetKeywordData(ev.Treasury, l.GetKeywordData(ev.Treasury) + aiGold)
	EndIf
EndFunction

Int Function TownGold(Int aiTown) Global
	CS_EconomyVariableFunctions ev = M().Gov.EconUpdater
	Location l = ev.AllLocations.GetAt(aiTown) as Location
	If !l
		Return 0
	EndIf
	Return l.GetKeywordData(ev.Treasury) as Int
EndFunction

; Moves gold between a town's stores and the faction's treasury. aiAmount > 0: from the town into the treasury;
; < 0: from the treasury to the town. abAll: everything the town holds (into the treasury).
Bool Function MoveTownGold(Int aiTown, Int aiAmount, Actor akVia = None, Bool abAsk = True, Bool abAll = False) Global
	CSN_Core m = M()
	If aiTown < 0 || aiTown > 14 || !CSN_World.PlayerRules(aiTown)
		Fail("Your faction doesn't rule that town.")
		Return False
	EndIf
	CS_EconomyVariableFunctions ev = m.Gov.EconUpdater
	Location l = ev.AllLocations.GetAt(aiTown) as Location
	If !l
		Return False
	EndIf
	String town = CSN_World.TownName(aiTown)
	Int has = TownGold(aiTown)
	If abAll
		aiAmount = has
	EndIf
	If aiAmount == 0
		Fail("How much gold? " + town + " holds " + has + " gold; the treasury " + Treasury() + ".")
		Return False
	EndIf
	String plan
	If aiAmount > 0
		If has < aiAmount
			Fail(town + " only holds " + has + " gold.")
			Return False
		EndIf
		plan = "Bring " + aiAmount + " gold from " + town + "'s stores into the treasury?"
	Else
		If Treasury() < -aiAmount
			Fail("The treasury only holds " + Treasury() + " gold.")
			Return False
		EndIf
		plan = "Send " + (-aiAmount) + " gold from the treasury to " + town + "'s stores?"
	EndIf
	If akVia
		plan = NameOf(akVia) + " proposes: " + plan
	EndIf
	If abAsk && !CSNP.Confirm("Gold and " + town, plan + "\n\n" + town + " holds " + has + " gold; the treasury " + Treasury() + ".", "Move it", "Leave it")
		Return False
	EndIf
	l.SetKeywordData(ev.Treasury, has - aiAmount)
	m.Econ().Treasury.Mod(aiAmount)
	ev.CalculatePlayerPerDay()
	If aiAmount > 0
		Say(aiAmount + " gold brought from " + town + " into the treasury.")
	Else
		Say((-aiAmount) + " gold sent to " + town + ".")
	EndIf
	Return True
EndFunction

Int Function GuardsNow(Int aiTown) Global
	CS_EconomyVariableFunctions ev = M().Gov.EconUpdater
	Location l = ev.AllLocations.GetAt(aiTown) as Location
	If !l
		Return 0
	EndIf
	Return l.GetKeywordData(ev.NumGuards) as Int
EndFunction

Int Function GuardsMax(Int aiTown) Global
	CS_EconomyVariableFunctions ev = M().Gov.EconUpdater
	FormList g = ev.AllGuardFormLists.GetAt(aiTown) as FormList
	If !g
		Return 0
	EndIf
	Return g.GetSize()
EndFunction

Int Function CrimeOf(Int aiTown) Global
	CS_EconomyVariableFunctions ev = M().Gov.EconUpdater
	Location l = ev.AllLocations.GetAt(aiTown) as Location
	If !l
		Return 0
	EndIf
	Return l.GetKeywordData(ev.Crime) as Int
EndFunction

String Function GuardsText(Int aiTown) Global
	Int now = GuardsNow(aiTown)
	Int mx = GuardsMax(aiTown)
	Return "crime " + CrimeOf(aiTown) + ", guards " + now + " of " + mx + " (" + (mx - now) + " more can be hired at " + CSN_Config.GuardCost() + " gold and 1 food a day each)"
EndFunction

Bool Function HireGuards(Int aiTown, Int aiAmount, Actor akVia = None) Global
	CSN_Core m = M()
	If aiTown < 0 || !CSN_World.PlayerRules(aiTown)
		Fail("Your faction doesn't rule that town.")
		Return False
	EndIf
	String town = CSN_World.TownName(aiTown)
	Int room = GuardsMax(aiTown) - GuardsNow(aiTown)
	If room <= 0
		Fail(town + " already has every guard it can take (" + GuardsMax(aiTown) + ").")
		Return False
	EndIf
	If aiAmount <= 0
		aiAmount = 1
	EndIf
	If aiAmount > room
		Fail("Only " + room + " more guards can be hired in " + town + ", not " + aiAmount + ".")
		Return False
	EndIf
	Int cost = CSN_Config.GuardCost() * aiAmount
	If Treasury() < cost
		Fail(aiAmount + " guards cost " + cost + " gold; the treasury holds " + Treasury() + ".")
		Return False
	EndIf
	String text = "Hire " + aiAmount + " guards for " + town + "?\n\nCrime: " + CrimeOf(aiTown) + "\nGuards: " + GuardsNow(aiTown) + " of " + GuardsMax(aiTown)
	text += "\nCost: " + cost + " gold, and " + aiAmount + " food a day to feed them.\n\nTreasury: " + Treasury() + " gold. Food: " + Stock(0) + "."
	If !CSNP.Confirm("Hire guards", text, "Hire them", "Not now")
		Return False
	EndIf
	m.Gov.EconUpdater.HireGuard(aiTown, aiAmount)
	m.Gov.EconUpdater.CalculatePlayerPerDay()  ; refresh the daily figures only: the economy itself updates once a day (CoS)
	Say("Hired " + aiAmount + " guards for " + town + " (" + GuardsNow(aiTown) + " of " + GuardsMax(aiTown) + ").")
	CSN_World.AddNews(aiTown, "New guards were hired for " + town + " by order of " + Player().GetDisplayName() + ".", "csn_guards", akVia)
	m.Refresh()
	Return True
EndFunction

; k: 0 barracks (cities only), 1 farms, 2 lumber mills, 3 mines
; CoS works out upgrade costs on a timer (CS_UpgradeMenuFunctions.SetGlobals waits for its OnUpdate), and timers
; don't run while a menu holds the game paused: close the faction screen first and let a frame pass.
Function LetCostsUpdate() Global
	M().CloseScreen()
	Utility.Wait(0.3)
EndFunction

; Cost of the next level of building k in a town: [gold, wood, hours]. Call after LetCostsUpdate.
Int[] Function UpgradeCost(Int aiTown, Int k) Global
	CS_UpgradeMenuFunctions u = Upg()
	Int[] r = new Int[3]
	Int spec = k
	If aiTown >= 9
		spec = k - 1
		u.SetGlobalsVillage(aiTown)
	Else
		u.SetGlobals(aiTown)
	EndIf
	r[0] = (u.UpgradeCosts.GetAt(spec) as GlobalVariable).GetValueInt()
	r[1] = (u.UpgradeCostsWood.GetAt(spec) as GlobalVariable).GetValueInt()
	r[2] = (u.UpgradeTimes.GetAt(spec) as GlobalVariable).GetValueInt()
	Return r
EndFunction

Bool Function UpgradeInProgress(Int aiTown) Global
	CS_UpgradeMenuFunctions u = Upg()
	Return (u.AllowUpgrades.GetAt(aiTown) as GlobalVariable).GetValue() != 1
EndFunction

; The Cities tab's "Upgrade buildings": a list of the town's buildings with level and cost, then the usual confirmation.
Function UpgradeMenu(Int aiTown) Global
	CSN_Core m = M()
	If aiTown < 0 || !CSN_World.PlayerRules(aiTown)
		Fail("Your faction doesn't rule that town.")
		Return
	EndIf
	String town = CSN_World.TownName(aiTown)
	If UpgradeInProgress(aiTown)
		Fail("An upgrade is already under way in " + town + "; wait for it to finish.")
		Return
	EndIf
	String back = m.ScreenTab()
	LetCostsUpdate()
	Int first = 0
	If aiTown >= 9
		first = 1
	EndIf
	Int n = 4 - first
	String[] opts = Utility.CreateStringArray(n + 1)
	Int i = 0
	While i < n
		Int k = first + i
		Int[] c = UpgradeCost(aiTown, k)
		opts[i] = BuildingName(k) + ": level " + BuildingLevel(aiTown, k) + " to " + (BuildingLevel(aiTown, k) + 1) + " (" + c[0] + " gold, " + c[1] + " wood, " + c[2] + " hours)"
		i += 1
	EndWhile
	opts[n] = "Cancel"
	String text = "Which building should be upgraded in " + town + "?\n\nTreasury: " + Treasury() + " gold. Wood: " + Stock(2) + "."
	If aiTown >= 9
		text += " Villages have no barracks."
	EndIf
	Int r = CSNP.Choose("Upgrade buildings: " + town, text, opts)
	If r >= 0 && r < n
		UpgradeBuilding(aiTown, first + r, m.StewardNear())
	EndIf
	; back to the faction screen where you were
	m.OpenDashboard(back)
EndFunction

Bool Function UpgradeBuilding(Int aiTown, Int k, Actor akVia = None, Bool abAsk = True) Global
	CSN_Core m = M()
	CS_UpgradeMenuFunctions u = Upg()
	If aiTown < 0 || !CSN_World.PlayerRules(aiTown)
		Fail("Your faction doesn't rule that town.")
		Return False
	EndIf
	String town = CSN_World.TownName(aiTown)
	Bool village = aiTown >= 9
	If village && k == 0
		Fail(town + " is a village: villages have no barracks.")
		Return False
	EndIf
	If (u.AllowUpgrades.GetAt(aiTown) as GlobalVariable).GetValue() != 1
		Fail("An upgrade is already under way in " + town + "; wait for it to finish.")
		Return False
	EndIf
	; CoS keeps cities and villages in different menus: villages count farms 0, mills 1, mines 2
	Int spec = k
	If village
		spec = k - 1
	EndIf
	LetCostsUpdate()
	Int[] cost = UpgradeCost(aiTown, k)
	Int gold = cost[0]
	Int wood = cost[1]
	Int hours = cost[2]
	Int level = BuildingLevel(aiTown, k)
	If Treasury() < gold || Stock(2) < wood
		Fail("Upgrading the " + BuildingName(k) + " in " + town + " costs " + gold + " gold and " + wood + " wood; the faction has " + Treasury() + " gold and " + Stock(2) + " wood.")
		Return False
	EndIf
	String text = "Upgrade the " + BuildingName(k) + " in " + town + "?\n\nNow at level " + level + ".\nCost: " + gold + " gold and " + wood + " wood, ready in " + hours + " hours."
	text += "\n\nTreasury: " + Treasury() + " gold. Wood: " + Stock(2) + ". Food: " + Stock(0) + "."
	If abAsk && !CSNP.Confirm("Upgrade " + BuildingName(k), text, "Upgrade", "Not now")
		Return False
	EndIf
	(u.UpgradeType.GetAt(aiTown) as GlobalVariable).SetValue(spec)
	u.UpgradeCost.SetValue(gold)
	u.UpgradeCostWood.SetValue(wood)
	u.UpgradeTime.SetValue(hours)
	(u.UpgradeQuests.GetAt(aiTown) as Quest).SetStage(1)
	If village
		CSN_World.NoteUpgrade(aiTown, spec + 1, True, 1)
		u.LoyaltyCheck.AdjustLoyalty((u.AllLocations.GetAt(aiTown) as Location), 5)
	Else
		CSN_World.NoteUpgrade(aiTown, spec, False, 1)
		u.LoyaltyCheck.AdjustLoyalty((u.AllLocations.GetAt(aiTown) as Location), 5, novillage = True)
	EndIf
	Say("Upgrade of the " + BuildingName(k) + " in " + town + " started (level " + level + " to " + (level + 1) + ", " + hours + " hours).")
	m.Refresh()
	Return True
EndFunction


; =============================================================================
; CHANGE OF HANDS, EXACTLY AS CONQUEST OF SKYRIM DOES IT
; A conquered city is handed over by CS_AttackCityScript.JarlSurrender with the story event
; CS_StoryTransferHoldingCity (city, 69); the Story Manager starts CS_TransferHoldingOwnership, which runs
; TransferOwnershipCity and stops again. That moves the old jarl and court into CS_JarlCitizens (they leave the
; palace for the tavern), clears the jarl and lets you choose the new government as usual. Forts use
; CS_StoryTransferHoldingFort (fort, 1).
; =============================================================================
Function ResetTransferQuest() Global
	CS_TransferOwnershipScript t = Transfer()
	; an older version of this mod called the transfer directly and left the quest running, which would block
	; the story event (and every later conquest)
	If t.IsRunning()
		t.Stop()
		Int n = 0
		While t.IsRunning() && n < 20
			Utility.Wait(0.1)
			n += 1
		EndWhile
	EndIf
EndFunction

Function HandOverCity(Int aiCity) Global
	CS_TransferOwnershipScript t = Transfer()
	Int oldOwner = CSN_World.TownOwner(aiCity)
	ResetTransferQuest()
	; exactly what CoS's story event handler does (CS_TransferOwnershipScript.OnStoryScript): transfer, then Stop
	t.TransferOwnershipCity(aiCity, 69)
	If t.IsRunning()
		t.Stop()
	EndIf
	; the invasion objective for this city is done, as when a jarl surrenders (JarlSurrenderNoScene)
	FormList court = None
	If oldOwner == 11
		t.TMImperial.SetObjectiveCompleted(10 * aiCity + 1)
		court = t.GovNPCsImp.GetAt(aiCity) as FormList
	ElseIf oldOwner == 12
		t.TMSons.SetObjectiveCompleted(10 * aiCity + 1)
		court = t.GovNPCsSons.GetAt(aiCity) as FormList
	EndIf
	; the old court is now in CS_JarlCitizens with the tavern package; in a conquest the fighting makes them
	; re-think at once, after a peaceful deal they are still sitting at court, so nudge them now and again
	; once the conversation has ended
	EvaluateCourt(court)
	Utility.Wait(6.0)
	EvaluateCourt(court)
EndFunction

Function EvaluateCourt(FormList akCourt) Global
	If !akCourt
		Return
	EndIf
	Int i = 0
	While i < akCourt.GetSize()
		Actor a = akCourt.GetAt(i) as Actor
		If a && !a.IsDead()
			a.EvaluatePackage()
		EndIf
		i += 1
	EndWhile
EndFunction

Function HandOverFort(Int aiFort) Global
	FortTo(aiFort, 1)
EndFunction

; Hand a fort to aiTo (1 the player's faction, 11 Imperials, 12 Stormcloaks) with CoS's own fort transfer.
Bool Function FortTo(Int aiFort, Int aiTo) Global
	Int want = 69
	If aiTo == 11
		want = 1
	ElseIf aiTo == 12
		want = 2
	EndIf
	If FortOwner(aiFort) == want
		Return True
	EndIf
	CS_TransferOwnershipScript t = Transfer()
	; CoS's own transfer, called the way its story event handler calls it (OnStoryScript: transfer, then Stop)
	ResetTransferQuest()
	CSN_Config.Log("fort transfer: " + aiFort + " from owner " + FortOwner(aiFort) + " to " + aiTo)
	t.TransferOwnershipFort(aiFort, aiTo)
	If t.IsRunning()
		t.Stop()
	EndIf
	CSN_Config.Log("fort transfer: " + aiFort + " now owner " + FortOwner(aiFort))
	Return FortOwner(aiFort) == want
EndFunction

; ---- holds: the city and the roads (land superiority) ------------------------------------
; Who holds the roads of a hold (CoS's LandSuperiority): 1 the player's faction, 11 Imperials, 12 Stormcloaks, 0 nobody.
Int Function RoadsSide(Int aiHold) Global
	CS_TMScript tm = M().Gov.TMPlayer
	Location l = tm.AllLocationsCS.GetAt(aiHold) as Location
	If !l
		Return 0
	EndIf
	Return l.GetKeywordData(tm.LandSuperiority) as Int
EndFunction

CS_TMScript Function SideTM(Int aiSide) Global
	CS_GovScriptFunctions g = M().Gov
	If aiSide == 11
		Return g.TMImp
	ElseIf aiSide == 12
		Return g.TMSons
	EndIf
	Return g.TMPlayer
EndFunction

; The city: 1 the player's faction (69 for CoS), 11, 12. Imperial <-> Stormcloak goes by way of the player's faction
; (CoS's city transfer to a side assumes the player held it).
Bool Function CityTo(Int aiCity, Int aiTo) Global
	CS_TransferOwnershipScript t = Transfer()
	Int now = CSN_World.TownOwner(aiCity)
	If now == aiTo
		Return True
	EndIf
	If now != 1 && aiTo != 1
		If !CityTo(aiCity, 1)
			Return False
		EndIf
	EndIf
	Int value = aiTo
	If aiTo == 1
		value = 69
	EndIf
	ResetTransferQuest()
	CSN_Config.Log("city transfer: " + aiCity + " from " + now + " to " + aiTo)
	t.TransferOwnershipCity(aiCity, value)
	If t.IsRunning()
		t.Stop()
	EndIf
	CSN_Config.Log("city transfer: " + aiCity + " now " + CSN_World.TownOwner(aiCity))
	WarFront(aiCity)
	Return CSN_World.TownOwner(aiCity) == aiTo
EndFunction

; A city held by a side the faction is at war with is a front-line city, the way CoS sets it up when the war
; starts: its map markers are hidden and it can be attacked. CoS only does that at the start (and end) of a war,
; so a city that reaches an enemy any other way (rebels handing it over) kept its markers. This puts it right.
Function WarFront(Int aiCity) Global
	If aiCity < 0 || aiCity >= 9
		Return
	EndIf
	Int owner = CSN_World.TownOwner(aiCity)
	If owner != 11 && owner != 12
		Return
	EndIf
	CS_TMScript tm = SideTM(owner)
	If !tm
		Return
	EndIf
	Bool atWar = tm.AtWarPlayer
	If atWar == tm.CSNCityMarkersShown(aiCity)
		CSN_Config.Log("war front: city " + aiCity + " (side " + owner + ") at war " + atWar)
		tm.CSNWarFrontCity(aiCity, atWar)
	EndIf
EndFunction

Function WarFronts() Global
	Int i = 0
	While i < 9
		WarFront(i)
		i += 1
	EndWhile
EndFunction

; The roads, the way CoS changes them after a camp battle: the side that loses them calls LoseLandSuperiority
; (which hands them to the player's faction), the side that gains them calls EstablishLandSuperiority.
Bool Function RoadsTo(Int aiHold, Int aiTo) Global
	Int now = RoadsSide(aiHold)
	If now == aiTo
		Return True
	EndIf
	If now == 11 || now == 12
		CS_TMScript loser = SideTM(now)
		loser.LoseLandSuperiority(aiHold)
		ObjectReference camp = loser.AllGarrisonMarkersCamp.GetAt(aiHold) as ObjectReference
		If camp
			camp.Disable()
		EndIf
	EndIf
	If RoadsSide(aiHold) != aiTo
		SideTM(aiTo).EstablishLandSuperiority(aiHold)
	EndIf
	CSN_Config.Log("roads of hold " + aiHold + ": " + now + " -> " + RoadsSide(aiHold))
	Return RoadsSide(aiHold) == aiTo
EndFunction

; Debug (Settings tab): hand a hold (its city and its roads) to anyone.
Function DebugSetHoldOwner(Int aiHold, Int aiTo) Global
	CSN_Core m = M()
	If aiHold < 0 || aiHold > 8 || !(aiTo == 1 || aiTo == 11 || aiTo == 12)
		Fail("Choose a hold and its new owner.")
		Return
	EndIf
	String who = m.FactionName()
	If aiTo == 11
		who = "the Imperial Legion"
	ElseIf aiTo == 12
		who = "the Stormcloaks"
	EndIf
	If !CSNP.Confirm("Debug", "Give " + m.HoldName(aiHold) + " to " + who + "?\n\nThis hands over " + CSN_World.TownName(aiHold) + " and control of the hold's roads.", "Give it", "Cancel")
		Return
	EndIf
	m.CloseScreen()
	Utility.Wait(0.3)
	Bool city = CityTo(aiHold, aiTo)
	Bool roads = RoadsTo(aiHold, aiTo)
	If city && roads
		Say("Debug: " + m.HoldName(aiHold) + " (" + CSN_World.TownName(aiHold) + " and its roads) now belongs to " + who + ".")
	Else
		String what = ""
		If !city
			what = CSN_World.TownName(aiHold)
		EndIf
		If !roads
			If what != ""
				what += " and "
			EndIf
			what += "the roads"
		EndIf
		Fail("Debug: " + what + " of " + m.HoldName(aiHold) + " didn't change hands. Turn on Debug logging and send the log.")
	EndIf
	m.OpenDashboard("settings")
EndFunction

; Debug (Settings tab): give any fort to anyone.
Function DebugSetFortOwner(Int aiFort, Int aiTo) Global
	CSN_Core m = M()
	If aiFort < 0 || aiFort >= m.FortCount() || !(aiTo == 1 || aiTo == 11 || aiTo == 12)
		Fail("Choose a fort and its new owner.")
		Return
	EndIf
	String who = m.FactionName()
	If aiTo == 11
		who = "the Imperial Legion"
	ElseIf aiTo == 12
		who = "the Stormcloaks"
	EndIf
	If !CSNP.Confirm("Debug", "Give " + m.FortName(aiFort) + " to " + who + "?", "Give it", "Cancel")
		Return
	EndIf
	m.CloseScreen()
	Utility.Wait(0.3)
	Int now = FortOwner(aiFort)
	; CoS only moves a fort between its old owner and the player's faction cleanly, so Imperial <-> Stormcloak goes
	; through the player's faction (each step keeps the fort counts and markers right)
	Bool ok = True
	If (now == 1 && aiTo == 12) || (now == 2 && aiTo == 11)
		ok = FortTo(aiFort, 1)
	EndIf
	If ok
		ok = FortTo(aiFort, aiTo)
	EndIf
	If ok
		Say("Debug: " + m.FortName(aiFort) + " now belongs to " + who + ".")
	Else
		Fail("Debug: " + m.FortName(aiFort) + " didn't change hands (CoS's transfer didn't run).")
	EndIf
	m.OpenDashboard("settings")
EndFunction
