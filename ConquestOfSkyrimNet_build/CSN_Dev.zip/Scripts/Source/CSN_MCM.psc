Scriptname CSN_MCM extends MCM_ConfigBase
{Conquest of SkyrimNet MCM (MCM Helper). The menu layout lives in Data/MCM/Config/ConquestOfSkyrimNet/config.json;
 this script tells the UI plugin and the game when a setting changes, and runs the buttons.}

CSN_Core Function Core()
	Return Quest.GetQuest("CS_FactionGovernment") as CSN_Core
EndFunction

Event OnSettingChange(String a_ID)
	CSN_Native.ReloadSettings()
	CSN_Core core = Core()
	If core
		core.OnSettingsChanged(a_ID)
	EndIf
EndEvent

Event OnConfigClose()
	CSN_Native.ReloadSettings()
EndEvent

Function OpenLedgerNow()
	CSN_Core core = Core()
	If core
		core.OpenLedgerFromMenu()
	EndIf
EndFunction

Function SkipTutorial()
	CSN_Gov.SkipTutorial()
EndFunction

Function WinBattle()
	CSN_Gov.WinBattle()
EndFunction

Function LoseBattle()
	CSN_Gov.LoseBattle()
EndFunction
