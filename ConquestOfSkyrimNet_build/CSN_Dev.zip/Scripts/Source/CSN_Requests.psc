Scriptname CSN_Requests Hidden
{Conquest of SkyrimNet: requests from your own government.
 Every so often (MCM > Requests) the government studies what has happened: with SkyrimNet, its LLM decides
 whether anyone would ask the leader for something (prompt conquestofskyrimnet/requests); without it, fixed rules do.
 Kinds: 0 taxes, 1 trade with a town, 2 a one-time grant to a town (gold, food or metal for a festival,
 a cause...) with stated loyalty points, 3 a one-time request from an army leader or the General
 (training, sharpening weapons...) - a resource sink for roleplay, no other effect,
 4 security: a town asks for one of the faction's famous (starred) army leaders to be stationed in its garrison or
 at its hold's fort. Accepting moves that army there and raises the town's loyalty; denying lowers it.
 Fields for kind 4: town = the asking town, mat = 0 city garrison / 1 fort, cur = army (0-based), want = 100 + the
 city or fort.
 5 upgrade: a town asks for one of its buildings to be upgraded (mat = 0 barracks, 1 farms, 2 lumber mills,
 3 mines; cur = its level, want = the next). Accepting starts the upgrade (the usual cost confirmation follows).
 Each request is kept in a log (faction screen, Requests tab) where you Accept, Deny or Meet in the middle.
 With Physical Letters installed the request arrives as a letter from that person (CSN_Letters);
 otherwise a notification says "A new request has come in from <faction>".

 Storage (StorageUtil, global): int list "csn_rq" = request ids, newest last; per request "csn_rq_<id>_<field>".}

; status
Int Function PENDING() Global
	Return 0
EndFunction
Int Function ACCEPTED() Global
	Return 1
EndFunction
Int Function DENIED() Global
	Return 2
EndFunction
Int Function MIDDLE() Global
	Return 3
EndFunction
Int Function EXPIRED() Global
	Return 4
EndFunction

CSN_Core Function M() Global
	Return Quest.GetQuest("CS_FactionGovernment") as CSN_Core
EndFunction

String Function K(Int id, String f) Global
	Return "csn_rq_" + id + "_" + f
EndFunction

; ---- fields -------------------------------------------------------------------
Int Function Count() Global
	Return StorageUtil.IntListCount(None, "csn_rq")
EndFunction

; i-th request id, newest first
Int Function IdAt(Int i) Global
	Return StorageUtil.IntListGet(None, "csn_rq", Count() - 1 - i)
EndFunction

Int Function Kind(Int id) Global
	Return StorageUtil.GetIntValue(None, K(id, "kind"))
EndFunction
Int Function Town(Int id) Global
	Return StorageUtil.GetIntValue(None, K(id, "town"))
EndFunction
Int Function Mat(Int id) Global
	Return StorageUtil.GetIntValue(None, K(id, "mat"))
EndFunction
Int Function Cur(Int id) Global
	Return StorageUtil.GetIntValue(None, K(id, "cur"))
EndFunction
Int Function Want(Int id) Global
	Return StorageUtil.GetIntValue(None, K(id, "want"))
EndFunction
Int Function Status(Int id) Global
	Return StorageUtil.GetIntValue(None, K(id, "status"))
EndFunction
Actor Function From(Int id) Global
	Return StorageUtil.GetFormValue(None, K(id, "from")) as Actor
EndFunction
String Function FromName(Int id) Global
	Return StorageUtil.GetStringValue(None, K(id, "fromname"))
EndFunction
String Function Why(Int id) Global
	Return StorageUtil.GetStringValue(None, K(id, "why"))
EndFunction
Int Function Loy(Int id) Global
	Return StorageUtil.GetIntValue(None, K(id, "loy"))
EndFunction
String Function Cause(Int id) Global
	Return StorageUtil.GetStringValue(None, K(id, "cause"))
EndFunction

Float Function Day(Int id) Global
	Return StorageUtil.GetFloatValue(None, K(id, "day"))
EndFunction

; The compromise value, or the wanted value itself when there is no middle ground.
Int Function MiddleValue(Int id) Global
	If Kind(id) >= 4
		Return Want(id)
	EndIf
	Int c = Cur(id)
	Int w = Want(id)
	If Kind(id) >= 2
		Return w / 2
	EndIf
	If Kind(id) == 0
		Return c + (w - c) / 2
	EndIf
	Int mid = (c + w) / 2
	Return mid
EndFunction

Bool Function HasMiddle(Int id) Global
	If Kind(id) >= 4
		Return False
	EndIf
	If Kind(id) >= 2
		Return Want(id) >= 2
	EndIf
	Int mid = MiddleValue(id)
	Return mid != Cur(id) && mid != Want(id)
EndFunction

; ---- wording ------------------------------------------------------------------
String Function ValueText(Int id, Int v) Global
	If Kind(id) == 4
		Return SecurityPost(id)
	ElseIf Kind(id) == 5
		Return "level " + v
	EndIf
	If Kind(id) == 0
		Return CSN_Gov.TaxText(v)
	EndIf
	If Kind(id) >= 2
		String r = v + " " + M().MaterialName(Mat(id))
		If Kind(id) == 2 && Loy(id) > 0
			Int l = Loy(id)
			If v < Want(id)
				l = l / 2
			EndIf
			r += " (+" + l + " loyalty)"
		EndIf
		Return r
	EndIf
	String what = M().MaterialName(Mat(id))
	If v > 0
		Return "the faction sends " + v + " " + what + " a day"
	ElseIf v < 0
		Return "the town sends " + (-v) + " " + what + " a day"
	EndIf
	Return "no " + what + " trade"
EndFunction

; One line for the log and notifications.
String Function Summary(Int id) Global
	If Kind(id) == 5
		Return "Upgrade the " + CSN_Gov.BuildingName(Mat(id)) + " in " + CSN_World.TownName(Town(id)) + " (level " + Cur(id) + " to " + Want(id) + ")"
	EndIf
	If Kind(id) == 4
		Actor star = M().Commander(Cur(id))
		String famous = CSN_Gov.ArmyLabel(Cur(id))
		If star
			famous = CSN_Gov.RankText(star) + " " + M().PlainName(star) + " and " + famous
		EndIf
		Return "Station " + famous + " at " + SecurityPost(id) + " (+" + Loy(id) + " loyalty in " + CSN_World.TownName(Town(id)) + ")"
	EndIf
	If Kind(id) == 2
		Return "Fund " + Cause(id) + " in " + CSN_World.TownName(Town(id)) + ": " + Want(id) + " " + M().MaterialName(Mat(id)) + " (+" + Loy(id) + " loyalty)"
	ElseIf Kind(id) == 3
		String who = "the army"
		If Town(id) >= 0
			who = CSN_Gov.ArmyLabel(Town(id))
		EndIf
		Return Cause(id) + " for " + who + ": " + Want(id) + " " + M().MaterialName(Mat(id))
	EndIf
	String town = CSN_World.TownName(Town(id))
	If Kind(id) == 0
		String dir = "Raise"
		If Want(id) < Cur(id)
			dir = "Lower"
		EndIf
		Return dir + " taxes in " + town + " from " + CSN_Gov.TaxText(Cur(id)) + " to " + CSN_Gov.TaxText(Want(id))
	EndIf
	String what = M().MaterialName(Mat(id))
	Int w = Want(id)
	Int c = Cur(id)
	If w > 0
		Return "Send " + w + " " + what + " a day to " + town + " (now " + ValueText(id, c) + ")"
	ElseIf w < 0
		Return "Take " + (-w) + " " + what + " a day from " + town + " (now " + ValueText(id, c) + ")"
	EndIf
	Return "End " + what + " trade with " + town
EndFunction

String Function StatusText(Int s) Global
	If s == 0
		Return "Waiting for you"
	ElseIf s == 1
		Return "Accepted"
	ElseIf s == 2
		Return "Denied"
	ElseIf s == 3
		Return "Met in the middle"
	EndIf
	Return "Withdrawn"
EndFunction

; ---- making requests ----------------------------------------------------------
; Called about once a minute by CSN_Core. Every StudyDays() the government looks at what happened.
Function Tick() Global
	CSN_Core m = M()
	If !m || m.FactionStarted.GetValue() < 1 || !CSN_Config.Requests()
		Return
	EndIf
	Float now = Utility.GetCurrentGameTime()
	Float due = StorageUtil.GetFloatValue(None, "csn_rq_due", 0.0)
	If due <= 0.0 || due - now > CSN_Config.StudyDays() + 0.01
		StorageUtil.SetFloatValue(None, "csn_rq_due", now + CSN_Config.StudyDays())
		Return
	EndIf
	ExpireOld(now)
	AnnounceArrivals()
	If now < due
		Return
	EndIf
	StorageUtil.SetFloatValue(None, "csn_rq_due", now + CSN_Config.StudyDays())
	Int notable = StorageUtil.GetIntValue(None, "csn_rq_notable", 0)
	If ArmiesWithLeader() > 0
		notable += 1   ; an army on the march with the leader always has something to ask
	EndIf
	If CSN_Config.SkipQuiet() && notable <= 0
		CSN_Config.Log("requests: nothing notable since the last study, skipped")
		Return
	EndIf
	If WaitingCount() >= 6
		CSN_Config.Log("requests: 6 already waiting, skipped")
		Return
	EndIf
	StorageUtil.SetIntValue(None, "csn_rq_notable", 0)
	If CSN_Config.LLMRequests() && CSN_SkyrimNet.Installed() && Study()
		Return
	EndIf
	Generate()
EndFunction

; ---- the LLM study -------------------------------------------------------------
Bool Function Study() Global
	CSN_Core m = M()
	; keys and true/false exactly as the template expects (Papyrus can change the case of strings)
	String ctx = StudyContext(m)
	; the plugin's normaliser needs no open view, only the DLL (an empty answer means it isn't loaded)
	String norm = CSN_Native.NormalizeJson(ctx)
	If norm != ""
		ctx = norm
	EndIf
	CSN_Config.Log("requests: asking SkyrimNet, context " + StringUtil.GetLength(ctx) + " chars")
	Int r = SkyrimNetApi.SendCustomPromptToLLM("conquestofskyrimnet/requests", "dialogue", ctx, m, "CSN_Core", "OnRequestLLM")
	If r != 1
		CSN_Config.Log("requests: SendCustomPromptToLLM refused (" + r + "), using the rules instead")
		Return False
	EndIf
	Return True
EndFunction

String Function StudyContext(CSN_Core m) Global
	CS_ClaimAreaFunctions h = m.Holdings()
	CS_EconomyVariableFunctions ev = m.Gov.EconUpdater
	String s = "{\"faction\":" + m.Q(m.FactionName()) + ",\"leader\":" + m.Q(Game.GetPlayer().GetDisplayName())
	s += ",\"date\":" + m.Q(CSN_SkyrimNet.SkyrimDate())
	s += ",\"gold\":" + CSN_Gov.Treasury() + ",\"gold_day\":" + h.TreasuryPerDay.GetValueInt()
	s += ",\"food\":" + h.FoodReserve.GetValueInt() + ",\"food_day\":" + h.FoodPerDay.GetValueInt()
	s += ",\"metal\":" + ev.MetalTotalPlayer.GetValueInt() + ",\"wood\":" + ev.WoodTotalPlayer.GetValueInt()
	s += ",\"wars\":" + m.Q(CSN_SkyrimNet.WarText(m))
	s += ",\"towns\":["
	Bool first = True
	Int i = 0
	While i < 15
		If CSN_World.PlayerRules(i)
			Location loc = ev.AllLocations.GetAt(i) as Location
			Int balance = 0
			If loc
				balance = (loc.GetKeywordData(ev.FoodProduced) as Int) - (loc.GetKeywordData(ev.FoodRequired) as Int) + CSN_Gov.CityTrade(i, 0)
			EndIf
			If !first
				s += ","
			EndIf
			first = False
			s += "{\"id\":" + i + ",\"name\":" + m.Q(CSN_World.TownName(i)) + ",\"size\":" + m.Q(TownSize(i))
			s += ",\"loyalty\":" + CSN_World.TownLoyalty(i) + ",\"tax\":" + (CSN_Gov.TaxLevel(i) * 10)
			s += ",\"food_balance\":" + balance + ",\"trade\":" + m.Q(CSN_Gov.CityTradeText(i))
			s += ",\"buildings\":" + m.Q(CSN_Gov.BuildingsText(i)) + ",\"upgrading\":" + m.B(CSN_Gov.UpgradeInProgress(i)) + ",\"speaker\":" + m.Q(Signature(Speaker(i), i)) + "}"
		EndIf
		i += 1
	EndWhile
	s += "],\"armies\":["
	first = True
	CS_PatrolHoldScript a = m.Armies()
	i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c && !c.IsDead()
			If !first
				s += ","
			EndIf
			first = False
			s += "{\"id\":" + (i + 1) + ",\"leader\":" + m.Q(CSN_Gov.RankText(c) + " " + m.PlainName(c)) + ",\"troops\":" + m.ArmyTroops(i) + ",\"post\":" + m.Q(CSN_Gov.PostText(i)) + ",\"with_leader\":" + m.B(WithLeader(i)) + ",\"stars\":" + CSN_Gov.Stars(c) + "}"
		EndIf
		i += 1
	EndWhile
	s += "],\"general\":" + m.Q(m.PlainName(m.Officer(m.ROLE_GENERAL)))
	s += ",\"events\":["
	Int n = StorageUtil.StringListCount(None, "csn_rq_events")
	i = 0
	While i < n
		If i > 0
			s += ","
		EndIf
		s += m.Q(StorageUtil.StringListGet(None, "csn_rq_events", i))
		i += 1
	EndWhile
	s += "],\"open\":["
	first = True
	i = 0
	While i < Count() && i < 20
		Int id = IdAt(i)
		If Status(id) == 0
			If !first
				s += ","
			EndIf
			first = False
			s += m.Q(Summary(id))
		EndIf
		i += 1
	EndWhile
	s += "],\"forts\":["
	first = True
	i = 0
	While i < 9
		If m.OwnsFort(i)
			If !first
				s += ","
			EndIf
			first = False
			s += "{\"town\":" + i + ",\"name\":" + m.Q(m.FortName(i)) + "}"
		EndIf
		i += 1
	EndWhile
	s += "],\"allow_grants\":" + m.B(CSN_Config.TownGrants()) + ",\"allow_army\":" + m.B(CSN_Config.ArmyRequests())
	s += ",\"allow_security\":" + m.B(CSN_Config.SecurityRequests() && HasFamous()) + "}"
	Return s
EndFunction

String Function TownSize(Int i) Global
	If i < 5
		Return "major city"
	ElseIf i < 9
		Return "minor city"
	EndIf
	Return "village"
EndFunction

; SkyrimNet answered. Expected one JSON object (see the prompt); anything we can't use is dropped.
Function FromLLM(String asResponse, Int aiSuccess) Global
	CSN_Config.Log("requests: LLM answered (" + aiSuccess + "): " + asResponse)
	If aiSuccess != 1
		Generate()
		Return
	EndIf
	; up to three requests, one JSON object per line
	String[] lines = PapyrusUtil.StringSplit(asResponse, "\n")
	Int done = 0
	Int i = 0
	While i < lines.Length && done < 3
		Int a = StringUtil.Find(lines[i], "{")
		If a >= 0 && StringUtil.Find(lines[i], "}") > a
			FromOne(StringUtil.Substring(lines[i], a))
			done += 1
		EndIf
		i += 1
	EndWhile
	If done == 0
		; one object spread over several lines
		Int b = StringUtil.Find(asResponse, "{")
		If b >= 0
			FromOne(StringUtil.Substring(asResponse, b))
		EndIf
	EndIf
EndFunction

; One request from the LLM's answer.
Function FromOne(String json) Global
	If PendingCount() >= 6
		Return
	EndIf
	String kind = SkyrimNetApi.GetJsonString(json, "kind", "none")
	String why = SkyrimNetApi.GetJsonString(json, "why", "")
	String cause = SkyrimNetApi.GetJsonString(json, "cause", "")
	Int town = SkyrimNetApi.GetJsonInt(json, "town", -1)
	Int mat = MatOf(SkyrimNetApi.GetJsonString(json, "material", ""))
	If kind == "tax"
		If town < 0 || town > 14 || !CSN_World.PlayerRules(town)
			Return
		EndIf
		Int cur = CSN_Gov.TaxLevel(town)
		Int want = (SkyrimNetApi.GetJsonInt(json, "percent", cur * 10) + 5) / 10
		If want < 0
			want = 0
		ElseIf want > 5
			want = 5
		EndIf
		; never ask for lower taxes at 0% or higher at 50%
		If want == cur || (want < cur && cur <= 0) || (want > cur && cur >= 5) || HasPending(0, town, 0)
			CSN_Config.Log("requests: tax request not possible, dropped")
			Return
		EndIf
		Create(0, town, 0, cur, want, why)
	ElseIf kind == "trade"
		If town < 0 || town > 14 || !CSN_World.PlayerRules(town) || mat < 0 || mat > 2 || HasPending(1, town, mat)
			Return
		EndIf
		Int now = CSN_Gov.CityTrade(town, mat)
		Int target = Clamp(SkyrimNetApi.GetJsonInt(json, "per_day", now), -200, 200)
		Create(1, town, mat, now, target, why)
	ElseIf kind == "grant" && CSN_Config.TownGrants()
		If town < 0 || town > 14 || !CSN_World.PlayerRules(town) || HasPending(2, town, -1)
			Return
		EndIf
		If mat < 0 || mat == 2
			mat = 3
		EndIf
		Int amount = SkyrimNetApi.GetJsonInt(json, "amount", 0)
		If mat == 3
			amount = Clamp(amount, 100, 5000)
		Else
			amount = Clamp(amount, 5, 300)
		EndIf
		Int loy = Clamp(SkyrimNetApi.GetJsonInt(json, "loyalty", 3), 1, 15)
		If cause == ""
			cause = "a local celebration"
		EndIf
		Create(2, town, mat, 0, amount, why, loy, None, cause)
	ElseIf kind == "upgrade"
		String b = SkyrimNetApi.GetJsonString(json, "building", "")
		Int bk = -1
		If StringUtil.Find(b, "barrack") >= 0
			bk = 0
		ElseIf StringUtil.Find(b, "farm") >= 0
			bk = 1
		ElseIf StringUtil.Find(b, "mill") >= 0 || StringUtil.Find(b, "lumber") >= 0 || StringUtil.Find(b, "wood") >= 0
			bk = 2
		ElseIf StringUtil.Find(b, "mine") >= 0
			bk = 3
		EndIf
		If !MakeUpgrade(town, bk, why)
			CSN_Config.Log("requests: upgrade request not possible, dropped")
		EndIf
	ElseIf kind == "security"
		; "army" 1-based, "post" city or fort, "town" the asking town (its city, or its hold's fort)
		Int sarmy = SkyrimNetApi.GetJsonInt(json, "army", 0) - 1
		String post = SkyrimNetApi.GetJsonString(json, "post", "city")
		Int spost = 0
		If StringUtil.Find(post, "fort") >= 0
			spost = 1
		EndIf
		If !MakeSecurity(town, sarmy, spost, town, why)
			CSN_Config.Log("requests: security request dropped")
		EndIf
	ElseIf kind == "army" && CSN_Config.ArmyRequests()
		Int army = SkyrimNetApi.GetJsonInt(json, "army", 0) - 1
		CSN_Config.Log("requests: army request for army " + (army + 1))
		Actor who = M().Commander(army)
		If !who || who.IsDead()
			army = -1
			who = M().Officer(M().ROLE_GENERAL)
		EndIf
		If !who || HasPending(3, army, -1)
			Return
		EndIf
		If mat < 0 || mat == 2
			mat = 3
		EndIf
		Int amount = SkyrimNetApi.GetJsonInt(json, "amount", 0)
		If mat == 3
			amount = Clamp(amount, 500, 20000)
		Else
			amount = Clamp(amount, 10, 500)
		EndIf
		If cause == ""
			cause = "Extra drill and fresh gear"
		EndIf
		Create(3, army, mat, 0, amount, why, 0, who, cause)
	EndIf
EndFunction

Int Function MatOf(String s) Global
	If StringUtil.Find(s, "food") >= 0
		Return 0
	ElseIf StringUtil.Find(s, "metal") >= 0 || StringUtil.Find(s, "iron") >= 0
		Return 1
	ElseIf StringUtil.Find(s, "wood") >= 0
		Return 2
	ElseIf StringUtil.Find(s, "gold") >= 0 || StringUtil.Find(s, "coin") >= 0
		Return 3
	EndIf
	Return -1
EndFunction

Int Function Clamp(Int v, Int lo, Int hi) Global
	If v < lo
		Return lo
	ElseIf v > hi
		Return hi
	EndIf
	Return v
EndFunction

; A request sent by letter shows on the faction screen a day after it was written, or once its letter is read.
Bool Function Arrived(Int id) Global
	If Status(id) != 0 || StorageUtil.GetIntValue(None, K(id, "lettered"), 0) != 1
		Return True
	EndIf
	If StorageUtil.GetIntValue(None, K(id, "read"), 0) == 1
		Return True
	EndIf
	Return Utility.GetCurrentGameTime() - Day(id) >= 1.0
EndFunction

Function MarkRead(Int id) Global
	StorageUtil.SetIntValue(None, K(id, "read"), 1)
EndFunction

Int Function PendingCount() Global
	Int n = 0
	Int i = 0
	While i < Count() && i < 40
		If Status(IdAt(i)) == 0 && Arrived(IdAt(i))
			n += 1
		EndIf
		i += 1
	EndWhile
	Return n
EndFunction

; Every unanswered request, including those still with the courier.
Int Function WaitingCount() Global
	Int n = 0
	Int i = 0
	While i < Count() && i < 40
		If Status(IdAt(i)) == 0
			n += 1
		EndIf
		i += 1
	EndWhile
	Return n
EndFunction

; A lettered request reaches the faction screen a day after it was written: say so once.
Function AnnounceArrivals() Global
	Int i = 0
	While i < Count() && i < 40
		Int id = IdAt(i)
		If Status(id) == 0 && StorageUtil.GetIntValue(None, K(id, "lettered"), 0) == 1 && StorageUtil.GetIntValue(None, K(id, "shown"), 0) == 0 && Arrived(id)
			StorageUtil.SetIntValue(None, K(id, "shown"), 1)
			Debug.Notification("A request from " + FromName(id) + " has reached the faction screen")
			CSN_Config.Log("request " + id + " arrived on the dashboard")
		EndIf
		i += 1
	EndWhile
EndFunction

; Requests nobody answered for 10 days are withdrawn.
Function ExpireOld(Float afNow) Global
	Int i = 0
	While i < Count() && i < 40
		Int id = IdAt(i)
		If Status(id) == 0 && afNow - Day(id) > 10.0
			StorageUtil.SetIntValue(None, K(id, "status"), 4)
		EndIf
		i += 1
	EndWhile
EndFunction

; A request like this one is already waiting: same kind for the same town or army (and the same material for trade,
; the same building for upgrades, the same army for security). Also catches the same thing asked a day ago and denied.
Bool Function IsDuplicate(Int aiKind, Int aiTown, Int aiMat, Int aiCur) Global
	Float now = Utility.GetCurrentGameTime()
	Int i = 0
	While i < Count() && i < 40
		Int id = IdAt(i)
		If Kind(id) == aiKind
			Bool same = False
			If aiKind == 4
				same = Cur(id) == aiCur || Town(id) == aiTown
			ElseIf aiKind == 1 || aiKind == 5
				same = Town(id) == aiTown && Mat(id) == aiMat
			Else
				same = Town(id) == aiTown
			EndIf
			If same && (Status(id) == 0 || now - Day(id) < 1.0)
				Return True
			EndIf
		EndIf
		i += 1
	EndWhile
	Return False
EndFunction

Bool Function HasPending(Int aiKind, Int aiTown, Int aiMat) Global
	Int i = 0
	While i < Count() && i < 40
		Int id = IdAt(i)
		If Status(id) == 0 && Kind(id) == aiKind && Town(id) == aiTown && (aiKind != 1 || Mat(id) == aiMat)
			Return True
		EndIf
		i += 1
	EndWhile
	Return False
EndFunction

; Who speaks for a town: its steward, else its jarl, else the faction's Steward.
Actor Function Speaker(Int aiTown) Global
	CSN_Core m = M()
	CS_RecruitJarl r = m.Gov.RecruitJarl
	If r
		If aiTown < r.StewardAliases.Length
			Actor s = r.StewardAliases[aiTown].GetActorRef()
			If s && !s.IsDead()
				Return s
			EndIf
		EndIf
		If aiTown < r.JarlAliases.Length
			Actor j = r.JarlAliases[aiTown].GetActorRef()
			If j && !j.IsDead()
				Return j
			EndIf
		EndIf
	EndIf
	Actor st = m.Officer(m.ROLE_STEWARD)
	If st && !st.IsDead()
		Return st
	EndIf
	Return None
EndFunction

; Look at the towns you rule (starting from a random one) and ask for the first thing that is needed.
Function Generate() Global
	; an army marching with the leader asks first now and then; otherwise the towns
	If ArmiesWithLeader() > 0 && Utility.RandomInt(0, 99) < 50 && TryArmy(True)
		Return
	EndIf
	If Utility.RandomInt(0, 99) < 35 && TrySecurity()
		Return
	EndIf
	; up to two towns ask in one study (each only once, never the same thing twice)
	Int made = 0
	Int start = Utility.RandomInt(0, 14)
	Int n = 0
	While n < 15 && made < 2 && PendingCount() < 6
		Int t = (start + n) % 15
		If CSN_World.PlayerRules(t) && TryTown(t)
			made += 1
		EndIf
		n += 1
	EndWhile
	If made > 0
		Return
	EndIf
	If Utility.RandomInt(0, 99) < 40
		TryArmy(False)
	EndIf
EndFunction

; ---- armies --------------------------------------------------------------------
; The army's leader is marching with the player (CoS follower faction).
Bool Function WithLeader(Int aiArmy) Global
	CSN_Core m = M()
	Actor c = m.Commander(aiArmy)
	Faction f = m.Armies().TroopManage.ArmyFollowerFaction
	Return c && f && !c.IsDead() && c.IsInFaction(f)
EndFunction

Int Function ArmiesWithLeader() Global
	CSN_Core m = M()
	Int n = 0
	Int i = 0
	While i < m.Armies().Commanders.Length
		If WithLeader(i)
			n += 1
		EndIf
		i += 1
	EndWhile
	Return n
EndFunction

; A one-time request from an army leader (rule-based, used without SkyrimNet or when it doesn't answer).
Bool Function TryArmy(Bool abWithLeaderOnly) Global
	If !CSN_Config.ArmyRequests()
		Return False
	EndIf
	CSN_Core m = M()
	CS_PatrolHoldScript a = m.Armies()
	Int start = Utility.RandomInt(0, a.Commanders.Length - 1)
	Int n = 0
	While n < a.Commanders.Length
		Int i = (start + n) % a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c && !c.IsDead() && (!abWithLeaderOnly || WithLeader(i)) && !HasPending(3, i, -1)
			Int troops = m.ArmyTroops(i)
			If troops < 1
				troops = 1
			EndIf
			Int pick = Utility.RandomInt(0, 3)
			String cause = "Sharpening and mending weapons"
			String why = "Our blades are dull and our shields split; a smith's work now saves lives in the next fight."
			Int mat = 3
			Int amount = 150 * troops + 500
			If pick == 1
				cause = "Combat drills with a veteran instructor"
				why = "The newer recruits break formation under pressure; a few days of hard drilling would fix that."
			ElseIf pick == 2
				cause = "Rations for the march"
				why = "We are eating through what we carry faster than we can hunt."
				mat = 0
				amount = 3 * troops + 10
			ElseIf pick == 3
				cause = "Iron for repairs"
				why = "Mail and buckles need mending; the armourer is out of metal."
				mat = 1
				amount = 2 * troops + 10
			EndIf
			If WithLeader(i)
				why = "Marching at your side has worn us down. " + why
			EndIf
			Return Create(3, i, mat, 0, amount, why, 0, c, cause)
		EndIf
		n += 1
	EndWhile
	Return False
EndFunction

Bool Function TryTown(Int t) Global
	CSN_Core m = M()
	CS_EconomyVariableFunctions ev = m.Gov.EconUpdater
	Location loc = ev.AllLocations.GetAt(t) as Location
	If !loc
		Return False
	EndIf
	Int loyalty = CSN_World.TownLoyalty(t)
	Int tax = CSN_Gov.TaxLevel(t)
	String town = CSN_World.TownName(t)

	; taxes
	If !HasPending(0, t, 0)
		If loyalty < 40 && tax > 0
			Int down = 1
			If loyalty < 25 && tax > 1
				down = 2
			EndIf
			Return Create(0, t, 0, tax, tax - down, "Loyalty in " + town + " has fallen to " + loyalty + " of 100 and people blame the taxes.")
		ElseIf loyalty >= 75 && tax < 5 && m.Holdings().TreasuryPerDay.GetValueInt() < 500
			Int up = 1
			If loyalty >= 90 && tax < 4
				up = 2
			EndIf
			Return Create(0, t, 0, tax, tax + up, "People in " + town + " are content (loyalty " + loyalty + ") and the treasury could use the coin.")
		EndIf
	EndIf

	; food: does the town feed itself?
	Int foodNow = CSN_Gov.CityTrade(t, 0)
	Int balance = (loc.GetKeywordData(ev.FoodProduced) as Int) - (loc.GetKeywordData(ev.FoodRequired) as Int) + foodNow
	If !HasPending(1, t, 0)
		If balance < 0
			Int need = RoundUp5(-balance)
			Return Create(1, t, 0, foodNow, foodNow + need, town + " is short " + (-balance) + " food a day and its supplies are running down.")
		ElseIf balance >= 20 && foodNow >= 0 && m.Holdings().FoodPerDay.GetValueInt() < 0
			Int spare = RoundUp5(balance / 2)
			Return Create(1, t, 0, foodNow, foodNow - spare, town + " grows more food than it eats while the faction's supplies shrink.")
		EndIf
	EndIf

	; metal and wood the town could send
	Int mat = 1
	While mat <= 2
		If !HasPending(1, t, mat)
			Int cur = CSN_Gov.CityTrade(t, mat)
			Keyword made = ev.MetalProduced
			If mat == 2
				made = ev.WoodProduced
			EndIf
			Int produced = loc.GetKeywordData(made) as Int
			If produced >= 10 && cur == 0
				Int offer = RoundUp5(produced / 2)
				Return Create(1, t, mat, 0, -offer, town + " has " + m.MaterialName(mat) + " to spare and offers some to the faction.")
			EndIf
		EndIf
		mat += 1
	EndWhile
	Return TryUpgrade(t)
EndFunction

; ---- upgrades: a town asks for a better barracks, farms, mills or mines ------------------
Bool Function MakeUpgrade(Int aiTown, Int aiBuilding, String asWhy) Global
	If aiTown < 0 || aiTown > 14 || !CSN_World.PlayerRules(aiTown) || HasPending(5, aiTown, -1)
		Return False
	EndIf
	If aiBuilding < 0 || aiBuilding > 3 || (aiTown >= 9 && aiBuilding == 0) || CSN_Gov.UpgradeInProgress(aiTown)
		Return False
	EndIf
	Int lv = CSN_Gov.BuildingLevel(aiTown, aiBuilding)
	If lv < 0
		Return False
	EndIf
	If asWhy == ""
		asWhy = "Better " + CSN_Gov.BuildingName(aiBuilding) + " would serve " + CSN_World.TownName(aiTown) + " well, and the people would see the faction investing in them."
	EndIf
	Return Create(5, aiTown, aiBuilding, lv, lv + 1, asWhy)
EndFunction

; Rule-based: what the town most needs built up.
Bool Function TryUpgrade(Int t) Global
	CSN_Core m = M()
	If HasPending(5, t, -1) || CSN_Gov.UpgradeInProgress(t)
		Return False
	EndIf
	CS_EconomyVariableFunctions ev = m.Gov.EconUpdater
	Location loc = ev.AllLocations.GetAt(t) as Location
	If !loc
		Return False
	EndIf
	String town = CSN_World.TownName(t)
	Int balance = (loc.GetKeywordData(ev.FoodProduced) as Int) - (loc.GetKeywordData(ev.FoodRequired) as Int)
	If balance < 0
		Return MakeUpgrade(t, 1, town + " can't feed itself (" + balance + " food a day); better farms would end the shortage.")
	EndIf
	If t < 9 && CSN_World.TownLoyalty(t) < 40 && CSN_Gov.BuildingLevel(t, 0) <= CSN_Gov.BuildingLevel(t, 2)
		Return MakeUpgrade(t, 0, "With unrest in " + town + ", a larger barracks would keep the peace and give the faction's armies room.")
	EndIf
	; otherwise the least developed of mills and mines
	Int k = 2
	If CSN_Gov.BuildingLevel(t, 3) < CSN_Gov.BuildingLevel(t, 2)
		k = 3
	EndIf
	Int yields = 1
	If k == 2
		yields = 2
	EndIf
	If CSN_Gov.BuildingLevel(t, k) >= 0 && CSN_Gov.BuildingLevel(t, k) < 3 && Utility.RandomInt(0, 99) < 50
		Return MakeUpgrade(t, k, "The " + CSN_Gov.BuildingName(k) + " of " + town + " lag behind; upgraded, they would bring the faction more " + m.MaterialName(yields) + " and steady work for the people.")
	EndIf
	Return False
EndFunction

; ---- security: famous commanders stationed where the people can see them --------------
String Function SecurityPost(Int id) Global
	Int target = Want(id) - 100
	If Mat(id) == 1
		Return M().FortName(target)
	EndIf
	Return CSN_World.TownName(target) + "'s garrison"
EndFunction

; Loyalty a famous commander's presence is worth: more stars, more fame.
Int Function SecurityLoyalty(Actor akCommander) Global
	Return Clamp(2 + 2 * CSN_Gov.Stars(akCommander), 4, 12)
EndFunction

; Is this army already posted there?
Bool Function PostedAt(Actor akCommander, Int aiPost, Int aiTarget) Global
	CS_PatrolHoldScript a = M().Armies()
	If aiPost == 1
		Return a.FortCommanders.GetFortCommanderNum(akCommander) == aiTarget
	EndIf
	FormList g = a.CommandersGarrisonHolds.GetAt(aiTarget) as FormList
	Return g && g.HasForm(akCommander)
EndFunction

; Can this army be sent there now? "" if so.
String Function CheckSecurity(Int aiArmy, Int aiPost, Int aiTarget) Global
	CSN_Core m = M()
	Actor c = m.Commander(aiArmy)
	If !c || c.IsDead()
		Return CSN_Gov.ArmyLabel(aiArmy) + " has no leader."
	EndIf
	If CSN_Gov.Stars(c) < 1
		Return "Only famous commanders (with at least one star) are asked for."
	EndIf
	If PostedAt(c, aiPost, aiTarget)
		Return CSN_Gov.ArmyLabel(aiArmy) + " is already posted there."
	EndIf
	If aiPost == 1
		Return m.CheckOrder(c, m.ORDER_FORT, aiTarget)
	EndIf
	Return m.CheckOrder(c, m.ORDER_HOLD, aiTarget)
EndFunction

; Any starred army leader at all? Security requests only start once the faction has a famous commander.
Bool Function HasFamous() Global
	CSN_Core m = M()
	CS_PatrolHoldScript a = m.Armies()
	Int i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c && !c.IsDead() && CSN_Gov.Stars(c) >= 1
			Return True
		EndIf
		i += 1
	EndWhile
	Return False
EndFunction

Bool Function MakeSecurity(Int aiTown, Int aiArmy, Int aiPost, Int aiTarget, String asWhy) Global
	CSN_Core m = M()
	If !CSN_Config.SecurityRequests() || aiTown < 0 || aiTown > 14 || !CSN_World.PlayerRules(aiTown) || HasPending(4, aiTown, -1)
		Return False
	EndIf
	; one town at a time asks for the same hero
	Int k = 0
	While k < Count() && k < 40
		Int other = IdAt(k)
		If Status(other) == 0 && Kind(other) == 4 && Cur(other) == aiArmy
			Return False
		EndIf
		k += 1
	EndWhile
	If CheckSecurity(aiArmy, aiPost, aiTarget) != ""
		CSN_Config.Log("requests: security request not possible: " + CheckSecurity(aiArmy, aiPost, aiTarget))
		Return False
	EndIf
	Actor c = m.Commander(aiArmy)
	If asWhy == ""
		asWhy = "The people of " + CSN_World.TownName(aiTown) + " talk of nothing but " + m.PlainName(c) + "'s deeds; with them standing guard here, folk would sleep easier and stand by the " + m.FactionName() + "."
	EndIf
	Return Create(4, aiTown, aiPost, aiArmy, 100 + aiTarget, asWhy, SecurityLoyalty(c))
EndFunction

; Rule-based: a town that could use more loyalty asks for the most famous army leader who could come.
Bool Function TrySecurity() Global
	CSN_Core m = M()
	If !CSN_Config.SecurityRequests() || !HasFamous()
		Return False
	EndIf
	CS_PatrolHoldScript a = m.Armies()
	Int start = Utility.RandomInt(0, 8)
	Int n = 0
	While n < 9
		Int t = (start + n) % 9
		If CSN_World.PlayerRules(t) && CSN_World.TownLoyalty(t) < 70 && !HasPending(4, t, -1)
			; the most famous leader who could come, to the city's garrison or else to the hold's fort
			Int best = -1
			Int bestPost = 0
			Int i = 0
			While i < a.Commanders.Length
				Actor c = a.Commanders[i].GetActorRef()
				If c && !c.IsDead() && CSN_Gov.Stars(c) >= 1 && (best < 0 || CSN_Gov.Stars(c) > CSN_Gov.Stars(m.Commander(best)))
					If CheckSecurity(i, 0, t) == ""
						best = i
						bestPost = 0
					ElseIf m.OwnsFort(t) && CheckSecurity(i, 1, t) == ""
						best = i
						bestPost = 1
					EndIf
				EndIf
				i += 1
			EndWhile
			If best >= 0 && MakeSecurity(t, best, bestPost, t, "")
				Return True
			EndIf
		EndIf
		n += 1
	EndWhile
	Return False
EndFunction

Int Function RoundUp5(Int v) Global
	If v <= 0
		Return 5
	EndIf
	Return ((v + 4) / 5) * 5
EndFunction

Bool Function Create(Int aiKind, Int aiTown, Int aiMat, Int aiCur, Int aiWant, String asWhy, Int aiLoy = 0, Actor akWho = None, String asCause = "") Global
	If aiCur == aiWant && aiKind != 4
		Return False
	EndIf
	; taxes can't go below 0% or above 50%: never ask for that
	If aiKind == 0 && ((aiWant < aiCur && aiCur <= 0) || (aiWant > aiCur && aiCur >= 5))
		Return False
	EndIf
	If IsDuplicate(aiKind, aiTown, aiMat, aiCur)
		CSN_Config.Log("requests: duplicate of a waiting request, dropped")
		Return False
	EndIf
	CSN_Core m = M()
	Actor who = akWho
	If !who
		who = Speaker(aiTown)
	EndIf
	; recent dealings (selling supplies to outlaws, or to honest folk) shift what a town's goodwill is worth
	If aiKind == 2 && StorageUtil.GetIntValue(None, "csn_rep_left", 0) > 0
		aiLoy = Clamp(aiLoy + StorageUtil.GetIntValue(None, "csn_rep_mod", 0), 1, 20)
		StorageUtil.AdjustIntValue(None, "csn_rep_left", -1)
	EndIf
	Int id = StorageUtil.GetIntValue(None, "csn_rq_next", 1)
	StorageUtil.SetIntValue(None, "csn_rq_next", id + 1)
	StorageUtil.IntListAdd(None, "csn_rq", id)
	; keep the log to the last 40
	While StorageUtil.IntListCount(None, "csn_rq") > 40
		StorageUtil.IntListRemoveAt(None, "csn_rq", 0)
	EndWhile
	StorageUtil.SetIntValue(None, K(id, "kind"), aiKind)
	StorageUtil.SetIntValue(None, K(id, "town"), aiTown)
	StorageUtil.SetIntValue(None, K(id, "mat"), aiMat)
	StorageUtil.SetIntValue(None, K(id, "cur"), aiCur)
	StorageUtil.SetIntValue(None, K(id, "want"), aiWant)
	StorageUtil.SetIntValue(None, K(id, "status"), 0)
	StorageUtil.SetFloatValue(None, K(id, "day"), Utility.GetCurrentGameTime())
	StorageUtil.SetFormValue(None, K(id, "from"), who)
	If aiKind == 3
		StorageUtil.SetStringValue(None, K(id, "fromname"), ArmySignature(who))
	Else
		StorageUtil.SetStringValue(None, K(id, "fromname"), Signature(who, aiTown))
	EndIf
	StorageUtil.SetStringValue(None, K(id, "why"), asWhy)
	StorageUtil.SetIntValue(None, K(id, "loy"), aiLoy)
	StorageUtil.SetStringValue(None, K(id, "cause"), asCause)

	Bool lettered = False
	If who && CSN_Letters.Available()
		lettered = CSN_Letters.SendRequest(id, who, LetterNotes(id))
	EndIf
	If lettered
		; the courier needs a day: the request reaches the faction screen then (or as soon as the letter is read)
		StorageUtil.SetIntValue(None, K(id, "lettered"), 1)
	Else
		Debug.Notification("A new request has come in from " + m.FactionName())
	EndIf
	CSN_Config.Log("request " + id + " from " + FromName(id) + ": " + Summary(id))
	CSN_SkyrimNet.LogEvent(FromName(id) + " asked " + Game.GetPlayer().GetDisplayName() + ": " + Summary(id) + ". " + asWhy, who, Game.GetPlayer())
	m.Refresh()
	Return True
EndFunction

String Function ArmySignature(Actor akWho) Global
	CSN_Core m = M()
	If !akWho
		Return "Your army"
	EndIf
	If m.GetRole(akWho) == m.ROLE_GENERAL
		Return "General " + m.PlainName(akWho)
	EndIf
	Return CSN_Gov.RankTitle(akWho) + " " + m.PlainName(akWho) + " of " + CSN_Gov.ArmyLabel(m.GetArmy(akWho))
EndFunction

String Function Signature(Actor akWho, Int aiTown) Global
	If !akWho
		Return "The people of " + CSN_World.TownName(aiTown)
	EndIf
	CSN_Core m = M()
	String n = m.PlainName(akWho)
	If m.GetRole(akWho) == m.ROLE_STEWARD
		Return "Steward " + n
	ElseIf CSN_Gov.CityStewardOf(akWho) >= 0
		Return n + ", steward of " + CSN_World.TownName(aiTown)
	ElseIf CSN_Gov.JarlCityOf(akWho) >= 9
		Return n + ", Leader of " + CSN_World.TownName(CSN_Gov.JarlCityOf(akWho))
	ElseIf CSN_Gov.JarlCityOf(akWho) >= 0
		Return "Jarl " + n + " of " + CSN_World.TownName(aiTown)
	EndIf
	Return n
EndFunction

; What the writer should say (Physical Letters writes it in their own words).
String Function LetterNotes(Int id) Global
	CSN_Core m = M()
	String s = "Writes to " + Game.GetPlayer().GetDisplayName() + ", leader of the " + m.FactionName() + ", with a formal request: " + Summary(id) + ". Reason: " + Why(id)
	If HasMiddle(id)
		s += " Says they could also accept a compromise: " + ValueText(id, MiddleValue(id)) + "."
	EndIf
	Return s + " Asks the leader to accept, deny, or meet in the middle."
EndFunction

; ---- deciding -----------------------------------------------------------------
; aiChoice: 0 accept, 1 deny, 2 meet in the middle
Bool Function Decide(Int id, Int aiChoice) Global
	CSN_Core m = M()
	If Status(id) != 0
		Return False
	EndIf
	Int t = Town(id)
	If Kind(id) != 3 && !CSN_World.PlayerRules(t)
		StorageUtil.SetIntValue(None, K(id, "status"), 4)
		CSN_Gov.Fail("That request no longer applies: your faction doesn't rule " + CSN_World.TownName(t) + ".")
		Return False
	EndIf
	If aiChoice == 2 && !HasMiddle(id)
		aiChoice = 0
	EndIf
	Int value = Want(id)
	If aiChoice == 2
		value = MiddleValue(id)
	EndIf
	Actor who = From(id)
	If aiChoice != 1
		Bool ok
		If Kind(id) == 0
			ok = CSN_Gov.SetTaxLevel(t, value, who, False)
		ElseIf Kind(id) == 1
			ok = CSN_Gov.SetCityTrade(t, Mat(id), value, who, False)
		ElseIf Kind(id) == 5
			; the usual upgrade, with its cost confirmation (it needs the faction screen closed for CoS's cost
			; timers, so the screen comes back afterwards)
			Bool reopen = CSN_Native.IsScreenOpen()
			StorageUtil.SetStringValue(None, "csn_lastfail", "")
			If CSN_Gov.UpgradeInProgress(t)
				CSN_Gov.Fail("An upgrade is already under way in " + CSN_World.TownName(t) + "; this one has to wait.")
				ok = False
			Else
				ok = CSN_Gov.UpgradeBuilding(t, Mat(id), who)
			EndIf
			If !ok
				; why it couldn't be done (resources, an upgrade already under way) stays on the request's card
				StorageUtil.SetStringValue(None, K(id, "block"), CSN_Gov.LastFail())
			Else
				StorageUtil.UnsetStringValue(None, K(id, "block"))
			EndIf
			If reopen
				If ok
					StorageUtil.SetIntValue(None, K(id, "status"), 1)
				EndIf
				m.OpenDashboard("requests")
				If !ok && CSN_Gov.LastFail() != ""
					Utility.Wait(0.6)
					m.UIToast(CSN_Gov.LastFail(), True)
				EndIf
			EndIf
		ElseIf Kind(id) == 4
			; the army marches to its new post; the people's goodwill comes with it
			String err = CheckSecurity(Cur(id), Mat(id), Want(id) - 100)
			Actor leader = m.Commander(Cur(id))
			If err != ""
				CSN_Gov.Fail(err)
				ok = False
			Else
				If Mat(id) == 1
					ok = m.IssueOrder(leader, m.ORDER_FORT, Want(id) - 100)
				Else
					ok = m.IssueOrder(leader, m.ORDER_HOLD, Want(id) - 100)
				EndIf
				If ok
					m.Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(t), Loy(id))
					CSN_SkyrimNet.LogEvent(m.PlainName(leader) + " was stationed at " + SecurityPost(id) + " at the request of " + FromName(id) + "; the people of " + CSN_World.TownName(t) + " cheered the famous commander.", leader, Game.GetPlayer())
				EndIf
			EndIf
		Else
			ok = CSN_Gov.Spend(Mat(id), value)
			If ok && Kind(id) == 2 && Loy(id) > 0
				Int gain = Loy(id)
				If value < Want(id)
					gain = gain / 2
				EndIf
				m.Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(t), gain)
			EndIf
		EndIf
		If !ok
			Return False
		EndIf
	ElseIf Kind(id) <= 2 || Kind(id) == 5
		; ignored requests cost a little goodwill in that town
		m.Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(t), -2)
	ElseIf Kind(id) == 4
		; the people wanted their hero and were refused
		Int loss = Loy(id) / 2
		If loss < 2
			loss = 2
		EndIf
		m.Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(t), -loss)
	EndIf
	Int st = 1
	String verdict = "accepted"
	If aiChoice == 1
		st = 2
		verdict = "denied"
	ElseIf aiChoice == 2
		st = 3
		verdict = "met halfway (" + ValueText(id, value) + ")"
	EndIf
	StorageUtil.SetIntValue(None, K(id, "status"), st)
	; an army leader's own request: their troops notice how it was answered
	If MoraleArmy(id) >= 0
		CSN_Rebellion.RequestAnswered(MoraleArmy(id), Kind(id), aiChoice)
	EndIf
	CSN_Gov.Say("Request " + verdict + ": " + Summary(id) + ".")
	CSN_SkyrimNet.LogEvent(Game.GetPlayer().GetDisplayName() + " " + verdict + " the request of " + FromName(id) + ": " + Summary(id) + ".", who, Game.GetPlayer())
	Int newsTown = t
	If Kind(id) == 3
		newsTown = -1
	EndIf
	CSN_World.AddNews(newsTown, Game.GetPlayer().GetDisplayName() + " " + verdict + " a request from " + FromName(id) + ": " + Summary(id) + ".", "csn_request_decided", who)
	; the Requests tab (and its count) change at once, however it was answered
	m.Refresh()
	Return True
EndFunction

; ---- answering in conversation -------------------------------------------------------
; The newest waiting request this person made, or -1.
Int Function PendingFrom(Actor akWho) Global
	Int i = 0
	While i < Count() && i < 40
		Int id = IdAt(i)
		If Status(id) == 0 && From(id) == akWho
			Return id
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

; Which of this person's waiting requests is meant: the one whose wording matches asHint best, else the newest.
Int Function FindRequest(Actor akWho, String asHint) Global
	Int fallback = -1
	Int i = 0
	While i < Count() && i < 40
		Int id = IdAt(i)
		If Status(id) == 0 && From(id) == akWho
			If fallback < 0
				fallback = id
			EndIf
			If asHint != "" && (CSN_SkyrimNet.Matches(Summary(id), asHint) || (Kind(id) != 3 && CSN_SkyrimNet.Matches(asHint, CSN_World.TownName(Town(id))) && CSN_SkyrimNet.Matches(asHint, KindWord(Kind(id)))))
				Return id
			EndIf
		EndIf
		i += 1
	EndWhile
	Return fallback
EndFunction

String Function KindWord(Int aiKind) Global
	If aiKind == 0
		Return "tax"
	ElseIf aiKind == 1
		Return "trade"
	ElseIf aiKind == 2
		Return "fund"
	ElseIf aiKind == 4
		Return "station"
	ElseIf aiKind == 5
		Return "upgrade"
	EndIf
	Return "troops"
EndFunction

; Confirm box for an answer given in conversation. 0 go ahead, 1 "Not now" (the asker is told it was put off),
; 2 "Decline (silent)" or Esc (nothing happens, nothing is remembered).
Int Function AskAnswer(String asTitle, String asText, String asYes) Global
	If !CSNP.Enabled()
		Return 0
	EndIf
	Int token = CSN_Native.OpenConfirm(asTitle, asText, asYes, "Not now||Decline (silent)")
	If token < 0
		Return 0
	EndIf
	Int r = CSNP.Await(token)
	If r == 0
		Return 0
	ElseIf r == 1
		Return 1
	EndIf
	Return 2
EndFunction

; The player answered a request while talking to the person who made it. aiChoice: 0 accept, 1 deny, 2 middle.
Bool Function AnswerInConversation(Actor akWho, Int aiChoice, String asHint) Global
	Int id = FindRequest(akWho, asHint)
	If id < 0
		CSN_Gov.Fail(M().PlainName(akWho) + " has no request waiting for your answer.")
		Return False
	EndIf
	If aiChoice == 2 && !HasMiddle(id)
		CSN_Gov.Fail("There is no middle ground for this request: " + Summary(id) + ". Accept or deny it.")
		Return False
	EndIf
	String what = Summary(id)
	String title = "Accept the request"
	String text = "Accept " + FromName(id) + "'s request?\n\n" + what + ".\n\n" + Why(id)
	String yes = "Accept"
	If aiChoice == 1
		title = "Deny the request"
		text = "Deny " + FromName(id) + "'s request?\n\n" + what + "."
		If Kind(id) == 4
			text += "\n\nThe people of " + CSN_World.TownName(Town(id)) + " would lose " + DenyLoss(id) + " loyalty."
		ElseIf Kind(id) != 3
			text += "\n\nThe people of " + CSN_World.TownName(Town(id)) + " would lose 2 loyalty."
		EndIf
		yes = "Deny"
	ElseIf aiChoice == 2
		title = "Meet in the middle"
		text = "Offer " + FromName(id) + " a compromise instead?\n\n" + what + ".\n\nCompromise: " + ValueText(id, MiddleValue(id)) + "."
		yes = "Meet in the middle"
	EndIf
	If MoraleArmy(id) >= 0
		Int md = CSN_Rebellion.RequestMorale(Kind(id), aiChoice)
		String sign = ""
		If md > 0
			sign = "+"
		EndIf
		text += "\n\nMorale in " + CSN_Gov.ArmyLabel(MoraleArmy(id)) + ": " + sign + md + " (now " + CSN_Rebellion.Morale(MoraleArmy(id)) + ")."
	EndIf
	Int r = AskAnswer(title, text, yes)
	If r == 2
		CSN_SkyrimNet.EndAction()
		Return False
	ElseIf r == 1
		CSN_SkyrimNet.ActionDeclined()
		CSN_SkyrimNet.LogEvent(Game.GetPlayer().GetDisplayName() + " put off answering " + FromName(id) + "'s request for now: " + what + ".", akWho, Game.GetPlayer())
		Return False
	EndIf
	; Decide remembers the answer (events, news) for the asker and the town
	Return Decide(id, aiChoice)
EndFunction

Int Function DenyLoss(Int id) Global
	Int loss = Loy(id) / 2
	If loss < 2
		loss = 2
	EndIf
	Return loss
EndFunction

; Ask the player right away (when a request letter is read).
Function AskNow(Int id) Global
	If Status(id) != 0
		Return
	EndIf
	String[] b = new String[3]
	b[0] = "Accept"
	b[1] = "Deny"
	b[2] = ""
	If HasMiddle(id)
		b[2] = "Meet in the middle: " + ValueText(id, MiddleValue(id))
	EndIf
	Int r = CSNP.Choose("Request from " + FromName(id), Summary(id) + ".\n\n" + Why(id), b)
	If r >= 0 && r <= 2
		Decide(id, r)
	EndIf
EndFunction

; ---- screen -------------------------------------------------------------------
String Function Json(CSN_Core m) Global
	String s = "["
	Int i = 0
	Int n = Count()
	Bool first = True
	While i < n && i < 30
		Int id = IdAt(i)
		; a request still with the courier isn't shown yet
		If Arrived(id)
		If !first
			s += ","
		EndIf
		first = False
		String place = CSN_World.TownName(Town(id))
		If Kind(id) == 3
			place = "Army"
		EndIf
		s += "{\"id\":" + id + ",\"from\":" + m.Q(FromName(id)) + ",\"town\":" + m.Q(place)
		s += ",\"text\":" + m.Q(Summary(id)) + ",\"why\":" + m.Q(Why(id)) + ",\"status\":" + Status(id)
		s += ",\"canmiddle\":" + m.B(HasMiddle(id)) + ",\"middle\":" + m.Q(ValueText(id, MiddleValue(id)))
		s += ",\"kind\":" + Kind(id) + ",\"loy\":" + Loy(id)
		Int ma = MoraleArmy(id)
		If ma >= 0
			s += ",\"marmy\":" + m.Q(CSN_Gov.ArmyLabel(ma)) + ",\"mnow\":" + CSN_Rebellion.Morale(ma)
			s += ",\"mup\":" + CSN_Rebellion.RequestMorale(Kind(id), 0) + ",\"mmid\":" + CSN_Rebellion.RequestMorale(Kind(id), 2) + ",\"mdown\":" + CSN_Rebellion.RequestMorale(Kind(id), 1)
		EndIf
		s += ",\"block\":" + m.Q(StorageUtil.GetStringValue(None, K(id, "block"), ""))
		s += ",\"daysago\":" + ((Utility.GetCurrentGameTime() - Day(id)) as Int) + "}"
		EndIf
		i += 1
	EndWhile
	Return s + "]"
EndFunction

; the army whose morale a request touches (-1 none): an army leader's own request, or a town asking for an army
Int Function MoraleArmy(Int id) Global
	If Kind(id) == 3
		Return M().GetArmy(From(id))
	ElseIf Kind(id) == 4
		Return Cur(id)
	EndIf
	Return -1
EndFunction

; What a requester knows about their open requests (for SkyrimNet).
String Function KnowledgeFor(Actor akActor) Global
	String s = ""
	Int i = 0
	While i < Count() && i < 20
		Int id = IdAt(i)
		If From(id) == akActor && Status(id) <= 3 && Utility.GetCurrentGameTime() - Day(id) < 14.0
			s += " You asked the leader: " + Summary(id) + " (" + StatusText(Status(id)) + ")."
		EndIf
		i += 1
	EndWhile
	Return s
EndFunction
