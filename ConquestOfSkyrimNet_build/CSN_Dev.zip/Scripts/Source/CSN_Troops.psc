Scriptname CSN_Troops Hidden
{Conquest of SkyrimNet: recruiting troops and troop templates by name, for the General (and the Blacksmith for
 templates) in conversation and for what they know.
 "Recruit 5 archers and 10 soldiers for Army 5" / "Put 10 soldiers, 7 archers and 2 crossbowmen in template 1" /
 "Apply template 1 to Army 3". Kinds 0-20:
   0 soldier, 1 warrior, 2 archer, 3 crossbowman, 4 fire mage, 5 frost mage, 6 shock mage, 7 healer (restoration),
   8 conjurer, 9 alteration mage, 10 dwarven spider, 11 dwarven sphere, 12 dwarven ballista, 13 skeever, 14 wolf,
   15 sabre cat, 16 frostbite spider, 17 bear, 18 troll, 19 giant, 20 mammoth.}

Int Function KindCount() Global
	Return 21
EndFunction

CS_TroopManageMenuScript Function TM() Global
	Return CSN_Gov.M().Armies().TroopManage
EndFunction

; ---- the catalogue -------------------------------------------------------------
String Function KindName(Int k, Int n = 2) Global
	String[] one = new String[21]
	one[0] = "soldier"
	one[1] = "warrior"
	one[2] = "archer"
	one[3] = "crossbowman"
	one[4] = "fire mage"
	one[5] = "frost mage"
	one[6] = "shock mage"
	one[7] = "healer"
	one[8] = "conjurer"
	one[9] = "alteration mage"
	one[10] = "dwarven spider"
	one[11] = "dwarven sphere"
	one[12] = "dwarven ballista"
	one[13] = "skeever"
	one[14] = "wolf"
	one[15] = "sabre cat"
	one[16] = "frostbite spider"
	one[17] = "bear"
	one[18] = "troll"
	one[19] = "giant"
	one[20] = "mammoth"
	If k < 0 || k > 20
		Return "troops"
	EndIf
	String s = one[k]
	If n == 1
		Return s
	EndIf
	If k == 3
		Return "crossbowmen"
	ElseIf k == 14
		Return "wolves"
	ElseIf k == 20 || k == 13
		Return s + "s"
	EndIf
	Return s + "s"
EndFunction

; CoS troop type for RecruitTroop / TroopCostsInt
Int Function TypeOf(Int k) Global
	If k <= 3
		Return k
	ElseIf k <= 6
		Return 5
	ElseIf k <= 9
		Return k - 1
	ElseIf k <= 12
		Return k - 1
	EndIf
	Return k
EndFunction

; Destruction mage element (1 fire, 2 frost, 3 shock) or -1
Int Function MageOf(Int k) Global
	If k >= 4 && k <= 6
		Return k - 3
	EndIf
	Return -1
EndFunction

Bool Function EatsFood(Int k) Global
	Return k < 10 || k > 12
EndFunction

Int Function Cost(Int k) Global
	Int[] c = TM().TroopCostsInt
	Int t = TypeOf(k)
	If c && t < c.Length
		Return c[t]
	EndIf
	Return 0
EndFunction

; Can the faction raise this kind yet? Mages and Dwemer machines need their research.
Bool Function Available(Int k) Global
	If k >= 4 && k <= 9
		Return CSN_Gov.MagesResearched()
	ElseIf k >= 10 && k <= 12
		CS_ResearchMenuScript r = Quest.GetQuest("CS_ResearchMenu") as CS_ResearchMenuScript
		Return r && r.DwarvenResearched && r.DwarvenResearched.GetValue() == 1
	EndIf
	Return k >= 0 && k <= 20
EndFunction

; How many troops may still be raised today (Conquest of Skyrim's daily limit; it resets every day).
Int Function RecruitableToday() Global
	CS_TroopManageMenuScript t = TM()
	Int n = t.DailyTroopLimit.GetValueInt() - t.DailyTroopSpawned.GetValueInt()
	If n < 0
		Return 0
	EndIf
	Return n
EndFunction

Int Function DailyLimit() Global
	Return TM().DailyTroopLimit.GetValueInt()
EndFunction

; ---- reading "5 archers and 10 soldiers" -----------------------------------------
; One word (or two, for "fire mage", "sabre cat"...) to a kind, -1 if none.
Int Function KindOf(String w, String next = "") Global
	String two = w + " " + next
	If Has(two, "fire mage") || Has(two, "fire mages")
		Return 4
	ElseIf Has(two, "frost mage") || Has(two, "ice mage")
		Return 5
	ElseIf Has(two, "shock mage") || Has(two, "lightning mage") || Has(two, "storm mage")
		Return 6
	ElseIf Has(two, "alteration mage")
		Return 9
	ElseIf Has(two, "dwarven spider") || Has(two, "dwemer spider")
		Return 10
	ElseIf Has(two, "dwarven sphere") || Has(two, "dwemer sphere")
		Return 11
	ElseIf Has(two, "dwarven ballista") || Has(two, "dwemer ballista")
		Return 12
	ElseIf Has(two, "sabre cat") || Has(two, "saber cat")
		Return 15
	ElseIf Has(two, "frostbite spider")
		Return 16
	EndIf
	If Starts(w, "soldier") || Starts(w, "footm") || Starts(w, "infantr") || Starts(w, "swordsm")
		Return 0
	ElseIf Starts(w, "warrior") || Starts(w, "berserk")
		Return 1
	ElseIf Starts(w, "crossbow")
		Return 3
	ElseIf Starts(w, "archer") || Starts(w, "bowm")
		Return 2
	ElseIf Starts(w, "destruction") || Starts(w, "pyromancer")
		Return 4
	ElseIf Starts(w, "healer") || Starts(w, "restoration") || Starts(w, "cleric")
		Return 7
	ElseIf Starts(w, "conjur") || Starts(w, "summoner") || Starts(w, "necromancer")
		Return 8
	ElseIf Starts(w, "alteration")
		Return 9
	ElseIf Starts(w, "sphere") || Starts(w, "centurion")
		Return 11
	ElseIf Starts(w, "ballista")
		Return 12
	ElseIf Starts(w, "skeever")
		Return 13
	ElseIf Starts(w, "wol")
		Return 14
	ElseIf Starts(w, "sabre") || Starts(w, "saber")
		Return 15
	ElseIf Starts(w, "bear")
		Return 17
	ElseIf Starts(w, "troll")
		Return 18
	ElseIf Starts(w, "giant")
		Return 19
	ElseIf Starts(w, "mammoth")
		Return 20
	ElseIf Starts(w, "spider")
		Return 10
	EndIf
	Return -1
EndFunction

Bool Function Has(String s, String what) Global
	Return StringUtil.Find(s, what) >= 0
EndFunction

Bool Function Starts(String s, String what) Global
	Return StringUtil.Find(s, what) == 0
EndFunction

; Counts per kind from text like "5 archers, 10 soldiers and two wolves". Numbers 1-20 in words are understood.
Int[] Function Parse(String asText) Global
	Int[] counts = new Int[21]
	String[] words = PapyrusUtil.StringSplit(asText, " ")
	Int pending = 0
	Int i = 0
	While i < words.Length
		String w = Clean(words[i])
		String nx = ""
		If i + 1 < words.Length
			nx = Clean(words[i + 1])
		EndIf
		Int n = Number(w)
		If n > 0
			pending = n
		ElseIf w != ""
			Int k = KindOf(w, nx)
			If k >= 0 && pending > 0
				counts[k] = counts[k] + pending
				pending = 0
			EndIf
		EndIf
		i += 1
	EndWhile
	Return counts
EndFunction

String Function Clean(String w) Global
	; strip punctuation around a word: "archers," -> "archers"
	String out = ""
	Int n = StringUtil.GetLength(w)
	Int i = 0
	While i < n
		String ch = StringUtil.GetNthChar(w, i)
		If StringUtil.IsLetter(ch) || StringUtil.IsDigit(ch)
			out += ch
		EndIf
		i += 1
	EndWhile
	Return out
EndFunction

Int Function Number(String w) Global
	If w == ""
		Return 0
	EndIf
	If StringUtil.IsDigit(StringUtil.GetNthChar(w, 0))
		Return w as Int
	EndIf
	String[] names = new String[21]
	names[1] = "one"
	names[2] = "two"
	names[3] = "three"
	names[4] = "four"
	names[5] = "five"
	names[6] = "six"
	names[7] = "seven"
	names[8] = "eight"
	names[9] = "nine"
	names[10] = "ten"
	names[11] = "eleven"
	names[12] = "twelve"
	names[13] = "thirteen"
	names[14] = "fourteen"
	names[15] = "fifteen"
	names[16] = "sixteen"
	names[17] = "seventeen"
	names[18] = "eighteen"
	names[19] = "nineteen"
	names[20] = "twenty"
	Int i = 1
	While i <= 20
		If w == names[i]
			Return i
		EndIf
		i += 1
	EndWhile
	If w == "a" || w == "an"
		Return 1
	ElseIf w == "thirty"
		Return 30
	ElseIf w == "fifty"
		Return 50
	EndIf
	Return 0
EndFunction

Int Function Total(Int[] counts) Global
	Int t = 0
	Int i = 0
	While i < counts.Length
		t += counts[i]
		i += 1
	EndWhile
	Return t
EndFunction

; "5 archers, 10 soldiers" ("" if empty)
String Function ListText(Int[] counts, String asSep = ", ") Global
	String s = ""
	Int i = 0
	While i < counts.Length
		If counts[i] > 0
			If s != ""
				s += asSep
			EndIf
			s += counts[i] + " " + KindName(i, counts[i])
		EndIf
		i += 1
	EndWhile
	Return s
EndFunction

; Army by number ("Army 5", "5", "the fifth") or by its Captain's / Commander's name; -1 if none.
Int Function ParseArmy(String s) Global
	CSN_Core m = CSN_Gov.M()
	Actor c = CSN_SkyrimNet.ParseCommander(s)
	If c
		Return m.GetArmy(c)
	EndIf
	Int n = CSN_SkyrimNet.ParseNumber(s)
	If n <= 0
		String[] w = PapyrusUtil.StringSplit(s, " ")
		Int i = 0
		While i < w.Length && n <= 0
			n = Number(Clean(w[i]))
			i += 1
		EndWhile
	EndIf
	If n > 0 && m.Commander(n - 1)
		Return n - 1
	EndIf
	Return -1
EndFunction

; ---- recruiting -------------------------------------------------------------------
; Returns "" when it can be done, otherwise why not.
String Function CheckRecruit(Int aiArmy, Int[] counts) Global
	CSN_Core m = CSN_Gov.M()
	Actor c = m.Commander(aiArmy)
	If aiArmy < 0 || !c
		Return "Which army? Name it by number or by its Captain or Commander."
	EndIf
	If c.IsDead()
		Return CSN_Gov.ArmyLabel(aiArmy) + " has lost its leader; choose a new Captain first."
	EndIf
	Int n = Total(counts)
	If n <= 0
		Return "Which troops, and how many? For example: 5 archers and 10 soldiers."
	EndIf
	String locked = ""
	Int i = 0
	While i < counts.Length
		If counts[i] > 0 && !Available(i)
			If locked != ""
				locked += ", "
			EndIf
			locked += KindName(i)
		EndIf
		i += 1
	EndWhile
	If locked != ""
		Return "Your faction can't raise " + locked + " yet (research them first)."
	EndIf
	Int today = RecruitableToday()
	If n > today
		If today <= 0
			Return "No more troops can be recruited today (the limit is " + DailyLimit() + " a day)."
		EndIf
		Return "Only " + today + " more troops can be recruited today, not " + n + "."
	EndIf
	Int gold = GoldFor(counts)
	If gold > CSN_Gov.Treasury()
		Return "That costs " + gold + " gold; the treasury holds " + CSN_Gov.Treasury() + "."
	EndIf
	Return ""
EndFunction

Int Function GoldFor(Int[] counts) Global
	Int g = 0
	Int i = 0
	While i < counts.Length
		g += counts[i] * Cost(i)
		i += 1
	EndWhile
	Return g
EndFunction

Int Function FoodFor(Int[] counts) Global
	Int f = 0
	Int i = 0
	While i < counts.Length
		If EatsFood(i)
			f += counts[i]
		EndIf
		i += 1
	EndWhile
	Return f
EndFunction

Bool Function Recruit(Int aiArmy, String asTroops, Actor akVia = None) Global
	Return RecruitCounts(aiArmy, Parse(asTroops), akVia)
EndFunction

Bool Function RecruitCounts(Int aiArmy, Int[] counts, Actor akVia = None) Global
	String err = CheckRecruit(aiArmy, counts)
	If err != ""
		CSN_Gov.Fail(err)
		Return False
	EndIf
	CSN_Core m = CSN_Gov.M()
	Actor c = m.Commander(aiArmy)
	Int gold = GoldFor(counts)
	Int food = FoodFor(counts)
	Int n = Total(counts)
	String lines = ""
	Int i = 0
	While i < counts.Length
		If counts[i] > 0
			lines += "\n  " + counts[i] + " " + KindName(i, counts[i]) + "  -  " + (counts[i] * Cost(i)) + " gold"
		EndIf
		i += 1
	EndWhile
	String text = "Recruit for " + CSN_Gov.ArmyLabel(aiArmy) + " (" + CSN_Gov.RankText(c) + " " + m.PlainName(c) + "):" + lines
	text += "\n\nTotal: " + n + " troops for " + gold + " gold (treasury " + CSN_Gov.Treasury() + ")."
	text += "\nFood: " + food + " more a day to feed them."
	text += "\nStill possible today after this: " + (RecruitableToday() - n) + " of " + DailyLimit() + "."
	If CSN_Config.ConfirmRecruit() && !CSNP.Confirm("Recruit troops", text, "Recruit them", "Not now")
		Return False
	EndIf
	CS_TroopManageMenuScript t = TM()
	i = 0
	While i < counts.Length
		Int k = 0
		While k < counts[i]
			t.Treasury.Mod(-Cost(i))
			If EatsFood(i)
				t.FoodPerDay.Mod(-1)
			EndIf
			t.RecruitTroop(aiArmy, TypeOf(i), MageOf(i))
			k += 1
		EndWhile
		i += 1
	EndWhile
	String what = ListText(counts)
	CSN_Gov.Say("Recruited " + what + " for " + CSN_Gov.ArmyLabel(aiArmy) + " (" + gold + " gold).")
	String via = ""
	If akVia
		via = " through General " + m.PlainName(akVia)
	EndIf
	CSN_SkyrimNet.LogEvent(Game.GetPlayer().GetDisplayName() + " recruited " + what + " for " + CSN_Gov.ArmyLabel(aiArmy) + " under " + CSN_Gov.RankText(c) + " " + m.PlainName(c) + via + ", for " + gold + " gold from the treasury.", akVia, c)
	m.Refresh()
	Return True
EndFunction

; ---- templates (1-5) ---------------------------------------------------------------
CS_TroopTemplatesScript Function Template(Int aiTemplate) Global
	CS_TroopTemplatesScript[] tt = TM().TroopTemplates
	If !tt || aiTemplate < 1 || aiTemplate > tt.Length
		Return None
	EndIf
	Return tt[aiTemplate - 1]
EndFunction

Int[] Function TemplateCounts(Int aiTemplate) Global
	Int[] c = new Int[21]
	CS_TroopTemplatesScript t = Template(aiTemplate)
	If !t
		Return c
	EndIf
	c[0] = t.CountSoldier
	c[1] = t.CountWarrior
	c[2] = t.CountArcher
	c[3] = t.CountCrossbow
	c[4] = t.CountMageDestructionFire
	c[5] = t.CountMageDestructionFrost
	c[6] = t.CountMageDestructionShock
	c[7] = t.CountMageRestoration
	c[8] = t.CountMageConjuration
	c[9] = t.CountMageAlteration
	c[10] = t.CountDwarvenSpider
	c[11] = t.CountDwarvenSphere
	c[12] = t.CountDwarvenBallista
	c[13] = t.CountCreatureSkeever
	c[14] = t.CountCreatureWolf
	c[15] = t.CountCreatureSabreCat
	c[16] = t.CountCreatureFrostbiteSpider
	c[17] = t.CountCreatureBear
	c[18] = t.CountCreatureTroll
	c[19] = t.CountCreatureGiant
	c[20] = t.CountCreatureMammoth
	Return c
EndFunction

Function WriteTemplate(CS_TroopTemplatesScript t, Int[] c) Global
	t.CountSoldier = c[0]
	t.CountWarrior = c[1]
	t.CountArcher = c[2]
	t.CountCrossbow = c[3]
	t.CountMageDestructionFire = c[4]
	t.CountMageDestructionFrost = c[5]
	t.CountMageDestructionShock = c[6]
	t.CountMageRestoration = c[7]
	t.CountMageConjuration = c[8]
	t.CountMageAlteration = c[9]
	t.CountDwarvenSpider = c[10]
	t.CountDwarvenSphere = c[11]
	t.CountDwarvenBallista = c[12]
	t.CountDwarvenCenturion = 0
	t.CountCreatureSkeever = c[13]
	t.CountCreatureWolf = c[14]
	t.CountCreatureSabreCat = c[15]
	t.CountCreatureFrostbiteSpider = c[16]
	t.CountCreatureBear = c[17]
	t.CountCreatureTroll = c[18]
	t.CountCreatureGiant = c[19]
	t.CountCreatureMammoth = c[20]
	t.TroopCount = Total(c)
EndFunction

String Function TemplateText(Int aiTemplate) Global
	String s = ListText(TemplateCounts(aiTemplate))
	If s == ""
		Return "empty"
	EndIf
	Return s
EndFunction

; Replaces what was in the template (templates cost nothing: they only record a mix of troops).
Bool Function SetTemplate(Int aiTemplate, String asTroops, Actor akVia = None) Global
	CS_TroopTemplatesScript t = Template(aiTemplate)
	If !t
		CSN_Gov.Fail("Which template? There are five, numbered 1 to 5.")
		Return False
	EndIf
	Int[] c = Parse(asTroops)
	If Total(c) <= 0
		CSN_Gov.Fail("Which troops, and how many, for template " + aiTemplate + "? For example: 10 soldiers, 7 archers, 2 crossbowmen.")
		Return False
	EndIf
	String text = "Troop template " + aiTemplate + " will hold:\n  " + ListText(c, "\n  ") + "\n\n" + Total(c) + " troops in all. It replaces what the template held before (" + TemplateText(aiTemplate) + ").\nTemplates cost no gold or food; they are used when an army refills."
	If !CSNP.Confirm("Troop template " + aiTemplate, text, "Save it", "Not now")
		Return False
	EndIf
	WriteTemplate(t, c)
	CSN_Gov.Say("Troop template " + aiTemplate + " saved: " + ListText(c) + ".")
	CSN_SkyrimNet.LogEvent("Troop template " + aiTemplate + " of the " + CSN_Gov.M().FactionName() + " now holds " + ListText(c) + ".", akVia, Game.GetPlayer())
	CSN_Gov.M().Refresh()
	Return True
EndFunction

Bool Function ApplyTemplate(Int aiTemplate, Int aiArmy, Actor akVia = None) Global
	CSN_Core m = CSN_Gov.M()
	CS_TroopTemplatesScript t = Template(aiTemplate)
	Actor c = m.Commander(aiArmy)
	If !t
		CSN_Gov.Fail("Which template? There are five, numbered 1 to 5.")
		Return False
	EndIf
	If aiArmy < 0 || !c
		CSN_Gov.Fail("Which army should use template " + aiTemplate + "?")
		Return False
	EndIf
	Int[] counts = TemplateCounts(aiTemplate)
	If Total(counts) <= 0
		CSN_Gov.Fail("Troop template " + aiTemplate + " is empty. Fill it first.")
		Return False
	EndIf
	String text = "Apply troop template " + aiTemplate + " to " + CSN_Gov.ArmyLabel(aiArmy) + " (" + CSN_Gov.RankText(c) + " " + m.PlainName(c) + ")?\n\nThe army will refill to:\n  " + ListText(counts, "\n  ") + "\n\n" + Total(counts) + " troops in all."
	If !CSNP.Confirm("Apply troop template", text, "Apply", "Not now")
		Return False
	EndIf
	TM().ApplyTemplate(aiArmy, aiTemplate - 1)
	CSN_Gov.Say(CSN_Gov.ArmyLabel(aiArmy) + " now follows troop template " + aiTemplate + ".")
	CSN_SkyrimNet.LogEvent(CSN_Gov.ArmyLabel(aiArmy) + " under " + CSN_Gov.RankText(c) + " " + m.PlainName(c) + " now follows troop template " + aiTemplate + " (" + ListText(counts) + ").", akVia, c)
	m.Refresh()
	Return True
EndFunction

; What the General and the Blacksmith know about templates and recruiting.
; The faction's troop types, so nobody invents knights, cavalry, pikemen and the like.
String Function TroopTypesText() Global
	String s = "The faction's army has exactly four troop types: soldiers (one-handed weapon and shield), warriors (two-handed weapons), archers (bows) and crossbowmen (crossbows). There are no others: no knights, cavalry, pikemen, spearmen, scouts or siege crews."
	If CSN_Gov.MagesResearched()
		s += " Battlemages (fire, frost, shock, healers, conjurers, alteration) have been researched and can also be recruited."
	Else
		s += " Battlemages can only be recruited once they have been researched, which has not happened yet."
	EndIf
	If Available(10)
		s += " Dwemer machines (spiders, spheres, ballistas) have been researched and can be added too."
	EndIf
	Return s
EndFunction

String Function KnowledgeText() Global
	String s = "Troop templates: "
	Int i = 1
	While i <= 5
		If i > 1
			s += "; "
		EndIf
		s += "template " + i + ": " + TemplateText(i)
		i += 1
	EndWhile
	Return s + "."
EndFunction

String Function RecruitText() Global
	String s = "Troops that can still be recruited today: " + RecruitableToday() + " of " + DailyLimit() + " (the number resets every day)."
	s += " Costs per recruit: soldier " + Cost(0) + ", warrior " + Cost(1) + ", archer " + Cost(2) + ", crossbowman " + Cost(3) + " gold"
	If CSN_Gov.MagesResearched()
		s += ", battlemage " + Cost(4) + " gold"
	EndIf
	Return s + "; each also eats 1 food a day (Dwemer machines don't)."
EndFunction


; Once per save (2.1.5): armies that follow a troop template refill to it every day. Armies raised in a settlement's
; army slot before this could be left out of the daily refill.
Function FixAutoRecruit() Global
	If StorageUtil.GetIntValue(None, "csn_autorec_fix", 0) >= 1
		Return
	EndIf
	StorageUtil.SetIntValue(None, "csn_autorec_fix", 1)
	CS_PatrolHoldScript ar = CSN_Gov.M().Armies()
	Int i = 0
	While i < ar.ArmyScripts.Length && i < ar.Commanders.Length
		CS_ArmyTroopDeath s = ar.ArmyScripts[i]
		If s && ar.Commanders[i].GetActorRef() && s.TemplateNum >= 0 && !s.AutoRespawn
			s.AutoRespawn = True
			CSN_Config.Log("auto recruit switched on for army " + (i + 1) + " (template " + (s.TemplateNum + 1) + ")")
		EndIf
		i += 1
	EndWhile
EndFunction

; ---- recruits waiting to join their army ----------------------------------------------------------------------
; CoS counts a recruit at once but places the soldier only beside a loaded commander (when recruited, or when the
; commander's 3D loads). Recruits for an army whose commander was never reloaded stayed counted but absent, so they
; were missing from battles and marches. When an army's commander is near the player and recruits are waiting,
; a few are placed beside them each check (at most 3 every few seconds, never a crowd at once). Only recruits that
; were paid for and never placed are spawned: troops who died are never brought back.
Int Function Waiting(CS_ArmyTroopDeath s) Global
	Return s.CountUnspawnedSoldier + s.CountUnspawnedWarrior + s.CountUnspawnedArcher + s.CountUnspawnedCrossbow + s.CountUnspawnedMageDestructionFire + s.CountUnspawnedMageDestructionFrost + s.CountUnspawnedMageDestructionShock + s.CountUnspawnedMageRestoration + s.CountUnspawnedMageConjuration + s.CountUnspawnedMageAlteration + s.CountUnspawnedDwarvenSpider + s.CountUnspawnedDwarvenSphere + s.CountUnspawnedDwarvenBallista + s.CountUnspawnedDwarvenCenturion + s.CountUnspawnedCreatureSkeever + s.CountUnspawnedCreatureWolf + s.CountUnspawnedCreatureSabreCat + s.CountUnspawnedCreatureFrostbiteSpider + s.CountUnspawnedCreatureBear + s.CountUnspawnedCreatureTroll + s.CountUnspawnedCreatureGiant + s.CountUnspawnedCreatureMammoth
EndFunction

; places one waiting recruit (the first type with any); False when none are waiting
Bool Function SpawnOne(Int a, CS_ArmyTroopDeath s, CS_TroopRecruiterScript r) Global
	If s.CountUnspawnedSoldier > 0
		s.CountUnspawnedSoldier -= 1
		r.SpawnTroop(a, 0)
	ElseIf s.CountUnspawnedWarrior > 0
		s.CountUnspawnedWarrior -= 1
		r.SpawnTroop(a, 1)
	ElseIf s.CountUnspawnedArcher > 0
		s.CountUnspawnedArcher -= 1
		r.SpawnTroop(a, 2)
	ElseIf s.CountUnspawnedCrossbow > 0
		s.CountUnspawnedCrossbow -= 1
		r.SpawnTroop(a, 3)
	ElseIf s.CountUnspawnedMageDestructionFire > 0
		s.CountUnspawnedMageDestructionFire -= 1
		r.SpawnTroop(a, 5, 1)
	ElseIf s.CountUnspawnedMageDestructionFrost > 0
		s.CountUnspawnedMageDestructionFrost -= 1
		r.SpawnTroop(a, 5, 2)
	ElseIf s.CountUnspawnedMageDestructionShock > 0
		s.CountUnspawnedMageDestructionShock -= 1
		r.SpawnTroop(a, 5, 3)
	ElseIf s.CountUnspawnedMageRestoration > 0
		s.CountUnspawnedMageRestoration -= 1
		r.SpawnTroop(a, 6)
	ElseIf s.CountUnspawnedMageConjuration > 0
		s.CountUnspawnedMageConjuration -= 1
		r.SpawnTroop(a, 7)
	ElseIf s.CountUnspawnedMageAlteration > 0
		s.CountUnspawnedMageAlteration -= 1
		r.SpawnTroop(a, 8)
	ElseIf s.CountUnspawnedDwarvenSpider > 0
		s.CountUnspawnedDwarvenSpider -= 1
		r.SpawnTroop(a, 9)
	ElseIf s.CountUnspawnedDwarvenSphere > 0
		s.CountUnspawnedDwarvenSphere -= 1
		r.SpawnTroop(a, 10)
	ElseIf s.CountUnspawnedDwarvenBallista > 0
		s.CountUnspawnedDwarvenBallista -= 1
		r.SpawnTroop(a, 11)
	ElseIf s.CountUnspawnedDwarvenCenturion > 0
		s.CountUnspawnedDwarvenCenturion -= 1
		r.SpawnTroop(a, 12)
	ElseIf s.CountUnspawnedCreatureSkeever > 0
		s.CountUnspawnedCreatureSkeever -= 1
		r.SpawnTroop(a, 13)
	ElseIf s.CountUnspawnedCreatureWolf > 0
		s.CountUnspawnedCreatureWolf -= 1
		r.SpawnTroop(a, 14)
	ElseIf s.CountUnspawnedCreatureSabreCat > 0
		s.CountUnspawnedCreatureSabreCat -= 1
		r.SpawnTroop(a, 15)
	ElseIf s.CountUnspawnedCreatureFrostbiteSpider > 0
		s.CountUnspawnedCreatureFrostbiteSpider -= 1
		r.SpawnTroop(a, 16)
	ElseIf s.CountUnspawnedCreatureBear > 0
		s.CountUnspawnedCreatureBear -= 1
		r.SpawnTroop(a, 17)
	ElseIf s.CountUnspawnedCreatureTroll > 0
		s.CountUnspawnedCreatureTroll -= 1
		r.SpawnTroop(a, 18)
	ElseIf s.CountUnspawnedCreatureGiant > 0
		s.CountUnspawnedCreatureGiant -= 1
		r.SpawnTroop(a, 19)
	ElseIf s.CountUnspawnedCreatureMammoth > 0
		s.CountUnspawnedCreatureMammoth -= 1
		r.SpawnTroop(a, 20)
	Else
		Return False
	EndIf
	Return True
EndFunction

Function PlaceWaiting() Global
	CS_PatrolHoldScript ar = CSN_Gov.M().Armies()
	Int a = 0
	While a < ar.Commanders.Length && a < ar.ArmyScripts.Length
		Actor c = ar.Commanders[a].GetActorRef()
		If c && c.Is3DLoaded() && !c.IsDead()
			CS_ArmyTroopDeath s = ar.ArmyScripts[a]
			If s && Waiting(s) > 0
				CS_TroopRecruiterScript r = s.CS_TroopRecruiter as CS_TroopRecruiterScript
				If r && !r.BeingUsed
					Int n = 0
					While n < 3 && SpawnOne(a, s, r)
						n += 1
					EndWhile
				EndIf
			EndIf
		EndIf
		a += 1
	EndWhile
EndFunction

; Before an army goes into battle: every recruit still waiting is placed with it (disabled until the battle brings
; the army out), so the battle counts them like any other army's troops.
Function ReadyForBattle(Actor akCommander) Global
	CS_PatrolHoldScript ar = CSN_Gov.M().Armies()
	Int a = ar.GetCommanderArmyNum(akCommander)
	If a < 0 || a >= ar.ArmyScripts.Length
		Return
	EndIf
	CS_ArmyTroopDeath s = ar.ArmyScripts[a]
	If s && Waiting(s) > 0
		CSN_Config.Log("army " + (a + 1) + ": placing " + Waiting(s) + " waiting recruits before battle")
		s.SpawnNewUnSpawnedTroops(akCommander)
	EndIf
EndFunction
