Scriptname CSNP Hidden
{Conquest of SkyrimNet PrismaUI helpers. Drop-in replacements for the vanilla/SkyUILib menus used by the
 Conquest of Skyrim code base:

   Response = SomeMessage.Show()                     ->  Response = CSNP.Show(SomeMessage, <context quest>)
   ((self as Form) as UILIB_1).ShowTextInput(t, i)   ->  CSNP.TextInput(t, i)
   ((self as Form) as UILIB_1).ShowList(t, o, s, d)  ->  CSNP.List(t, o, s, d)
   Debug.MessageBox(s)                               ->  CSNP.Notice(s)

 They block exactly like the originals and return the same values, so menu logic is unchanged.
 If PrismaUI or the DLL is missing they fall back to the vanilla calls.}

Int Function Show(Message akMsg, Quest akContext = None, Float afArg1 = 0.0, Float afArg2 = 0.0, Float afArg3 = 0.0, Float afArg4 = 0.0, Float afArg5 = 0.0, Float afArg6 = 0.0, Float afArg7 = 0.0, Float afArg8 = 0.0, Float afArg9 = 0.0) Global
	If !akMsg
		Return -1
	EndIf
	If !CSNP.Enabled() || !CSN_Native.IsMenuMessage(akMsg)
		Return akMsg.Show(afArg1, afArg2, afArg3, afArg4, afArg5, afArg6, afArg7, afArg8, afArg9)
	EndIf

	; Resolve <Alias=Name> / <Alias.Mod=Name> tags the way the engine does: owner quest first, then the
	; caller's quest, then the faction quest. Keys arrive as "mod|name".
	Quest q = CSN_Native.GetOwnerQuest(akMsg)
	String[] names = CSN_Native.GetAliasTags(akMsg)
	String[] values = Utility.CreateStringArray(names.Length)
	Int i = 0
	While i < names.Length
		values[i] = AliasTag(q, akContext, names[i])
		i += 1
	EndWhile

	Float[] args = new Float[9]
	args[0] = afArg1
	args[1] = afArg2
	args[2] = afArg3
	args[3] = afArg4
	args[4] = afArg5
	args[5] = afArg6
	args[6] = afArg7
	args[7] = afArg8
	args[8] = afArg9

	Int token = CSN_Native.ShowMessage(akMsg, names, values, args)
	If token < 0
		Return akMsg.Show(afArg1, afArg2, afArg3, afArg4, afArg5, afArg6, afArg7, afArg8, afArg9)
	EndIf
	Return Await(token)
EndFunction

String Function TextInput(String asTitle = "", String asInitialText = "") Global
	If !CSNP.Enabled()
		Return ""
	EndIf
	Int token = CSN_Native.OpenTextInput(asTitle, asInitialText)
	If token < 0
		Return ""
	EndIf
	Int r = Await(token)
	String t = CSN_Native.PollText(token)
	If r < 0
		Return ""
	EndIf
	Return t
EndFunction

Int Function List(String asTitle, String[] asOptions, Int aiStartIndex, Int aiDefaultIndex) Global
	If !CSNP.Enabled()
		Return -1
	EndIf
	Int token = CSN_Native.OpenList(asTitle, asOptions, aiStartIndex, aiDefaultIndex)
	If token < 0
		Return -1
	EndIf
	Return Await(token)
EndFunction

; Debug.MessageBox replacement (non-blocking, like the original).
Function Notice(String asText) Global
	If CSNP.Enabled()
		CSN_Native.OpenNotice(asText)
	Else
		Debug.MessageBox(asText)
	EndIf
EndFunction

Int Function Await(Int aiToken) Global
	Int r = CSN_Native.PollResult(aiToken)
	While r == -2
		Utility.WaitMenuMode(0.05)
		r = CSN_Native.PollResult(aiToken)
	EndWhile
	Return r
EndFunction

String Function AliasText(Quest akQuest, String asName) Global
	Form f = AliasForm(akQuest, asName)
	If f
		Return FormName(f)
	EndIf
	Return ""
EndFunction

; The thing an alias points at: an ObjectReference, a Location, or None.
Form Function AliasForm(Quest akQuest, String asName) Global
	If !akQuest
		Return None
	EndIf
	Alias a = akQuest.GetAliasByName(asName)
	ReferenceAlias ra = a as ReferenceAlias
	If ra
		Return ra.GetReference()
	EndIf
	LocationAlias la = a as LocationAlias
	If la
		Return la.GetLocation()
	EndIf
	Return None
EndFunction

String Function FormName(Form f) Global
	ObjectReference r = f as ObjectReference
	If r
		Return r.GetDisplayName()
	EndIf
	Location l = f as Location
	If l
		Return l.GetName()
	EndIf
	If f
		Return f.GetName()
	EndIf
	Return ""
EndFunction

; asKey = "mod|name" (lower case), e.g. "|factionname", "cap|city", "pronounobj|jarl".
String Function AliasTag(Quest akOwner, Quest akContext, String asKey) Global
	Int bar = StringUtil.Find(asKey, "|")
	String m = ""
	String n = asKey
	If bar >= 0
		m = StringUtil.Substring(asKey, 0, bar)
		n = StringUtil.Substring(asKey, bar + 1)
	EndIf
	Form f = AliasForm(akOwner, n)
	If !f
		f = AliasForm(akContext, n)
	EndIf
	If !f
		f = AliasForm(Quest.GetQuest("CS_FactionGovernment"), n)
	EndIf
	If !f && (n == "player" || n == "playerref" || n == "playeralias")
		f = Game.GetPlayer()
	EndIf
	If !f
		Return ""
	EndIf
	Actor act = f as Actor
	If m == "pronoun" || m == "pronounobj" || m == "pronounpos" || m == "pronounposobj" || m == "pronounref" || m == "pronounint"
		Int sex = -1
		If act
			sex = act.GetLeveledActorBase().GetSex()
		EndIf
		Return Pronoun(m, sex)
	EndIf
	String t = FormName(f)
	If m == "shortname" && StringUtil.Find(t, " ") > 0 && act
		t = act.GetLeveledActorBase().GetName()
	EndIf
	; "cap": names are already capitalised.
	Return t
EndFunction

String Function Pronoun(String m, Int sex) Global
	If m == "pronoun"
		If sex == 0
			Return "he"
		ElseIf sex == 1
			Return "she"
		EndIf
		Return "they"
	ElseIf m == "pronounobj"
		If sex == 0
			Return "him"
		ElseIf sex == 1
			Return "her"
		EndIf
		Return "them"
	ElseIf m == "pronounref"
		If sex == 0
			Return "himself"
		ElseIf sex == 1
			Return "herself"
		EndIf
		Return "themselves"
	ElseIf m == "pronounposobj"
		If sex == 0
			Return "his"
		ElseIf sex == 1
			Return "hers"
		EndIf
		Return "theirs"
	EndIf
	If sex == 0
		Return "his"
	ElseIf sex == 1
		Return "her"
	EndIf
	Return "their"
EndFunction

; A question with several answers. Returns the chosen index; -1 if closed or PrismaUI menus are off.
Int Function Choose(String asTitle, String asText, String[] asButtons) Global
	If !CSNP.Enabled()
		Return -1
	EndIf
	Int token = CSN_Native.OpenChoice(asTitle, asText, asButtons)
	If token < 0
		Return -1
	EndIf
	Return Await(token)
EndFunction

; Ask for a number with a stepper. Returns the amount, or -1 if cancelled. Without PrismaUI menus: aiInitial.
Int Function AskAmount(String asTitle, String asText, Int aiInitial, Int aiMin, Int aiMax, Int aiUnitPrice = 0, String asPriceLabel = "", String asYes = "Agree", String asNo = "Cancel") Global
	If !CSNP.Enabled()
		Return aiInitial
	EndIf
	Bool talk = CSN_SkyrimNet.ActingNPC() != None
	If talk
		asNo = "Not now||Decline (silent)"
	EndIf
	Int token = CSN_Native.OpenAmount(asTitle, asText, aiInitial, aiMin, aiMax, aiUnitPrice, asPriceLabel, asYes, asNo)
	If token < 0
		Return aiInitial
	EndIf
	Int r = Await(token)
	String t = CSN_Native.PollText(token)
	If r != 0
		If r == 1 && talk
			CSN_SkyrimNet.ActionDeclined()
		Else
			CSN_SkyrimNet.EndAction()
		EndIf
		Return -1
	EndIf
	Return t as Int
EndFunction

; Yes/No confirmation. With PrismaUI menus off (or the DLL missing) there is nothing to ask with, so it says yes.
Bool Function Confirm(String asTitle, String asText, String asYes = "Yes", String asNo = "No") Global
	If !CSNP.Enabled()
		Return True
	EndIf
	; From a conversation action: "Not now" tells the NPC it was called off, "Decline (silent)" just cancels.
	Bool talk = CSN_SkyrimNet.ActingNPC() != None
	If talk
		If asNo != "Refuse"
			asNo = "Not now"
		EndIf
		asNo = asNo + "||Decline (silent)"
	EndIf
	Int token = CSN_Native.OpenConfirm(asTitle, asText, asYes, asNo)
	If token < 0
		Return True
	EndIf
	Int r = Await(token)
	If r == 0
		Return True
	EndIf
	If r == 1 && talk
		CSN_SkyrimNet.ActionDeclined()
	Else
		CSN_SkyrimNet.EndAction()
	EndIf
	Return False
EndFunction

; PrismaUI menus are on when the DLL is loaded and the MCM option "Use PrismaUI menus" is on.
Bool Function Enabled() Global
	Return CSN_Native.IsAvailable() && CSN_Config.UsePrismaUI()
EndFunction
