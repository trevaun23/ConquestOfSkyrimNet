Scriptname CSN_War Hidden
{Conquest of SkyrimNet: army names and purposes, joining war camps, war camp plans, attack orders,
 starting or calling off a prepared attack, and making every attack the faction launches known across Skyrim.
 Every attack goes through Conquest of Skyrim's own CS_AttackPlanningNew quest (SelectTarget / InvasionStart),
 so the battles themselves run exactly as they do from the war table.}

CSN_Core Function M() Global
	Return CSN_Gov.M()
EndFunction

CS_AttackPlanningNewScript Function Plan() Global
	Return CSN_Gov.Planning()
EndFunction

; =============================================================================
; ARMY NAMES AND PURPOSES
; =============================================================================
String Function Name(Int aiArmy) Global
	If aiArmy < 0
		Return ""
	EndIf
	Return StorageUtil.GetStringValue(None, "csn_army_name_" + aiArmy, "")
EndFunction

String Function Purpose(Int aiArmy) Global
	If aiArmy < 0
		Return ""
	EndIf
	Return StorageUtil.GetStringValue(None, "csn_army_motto_" + aiArmy, "")
EndFunction

; "the Iron Wolves (Army 3)", or "Army 3" while it has no name. The number stays so orders by number still work.
String Function Label(Int aiArmy) Global
	String n = Name(aiArmy)
	If n == ""
		Return "Army " + (aiArmy + 1)
	EndIf
	Return n + " (Army " + (aiArmy + 1) + ")"
EndFunction

; Strip what would break the screen's command line or the prompts.
String Function Clean(String s, Int aiMax) Global
	String o = ""
	Int i = 0
	Int n = StringUtil.GetLength(s)
	While i < n
		String c = StringUtil.GetNthChar(s, i)
		If c == "|" || c == "\n" || c == "\t" || c == "\"" || c == "\\" || c == "~"
			c = " "
		EndIf
		If !(c == " " && (o == "" || StringUtil.Substring(o, StringUtil.GetLength(o) - 1, 1) == " "))
			o += c
		EndIf
		i += 1
	EndWhile
	If StringUtil.GetLength(o) > 0 && StringUtil.Substring(o, StringUtil.GetLength(o) - 1, 1) == " "
		o = StringUtil.Substring(o, 0, StringUtil.GetLength(o) - 1)
	EndIf
	If aiMax > 0 && StringUtil.GetLength(o) > aiMax
		o = StringUtil.Substring(o, 0, aiMax)
	EndIf
	Return o
EndFunction

; Name (25 characters at most; "" puts the number back) and an optional purpose, goal or mantra.
Bool Function SetName(Int aiArmy, String asName, String asPurpose, Actor akVia = None) Global
	CSN_Core m = M()
	Actor c = m.Commander(aiArmy)
	If aiArmy < 0 || !c
		CSN_Gov.Fail("Which army? Name it by number, by its name or by its Captain or Commander.")
		Return False
	EndIf
	String old = Label(aiArmy)
	String n = Clean(asName, 25)
	String p = Clean(asPurpose, 200)
	StorageUtil.SetStringValue(None, "csn_army_name_" + aiArmy, n)
	StorageUtil.SetStringValue(None, "csn_army_motto_" + aiArmy, p)
	String txt
	If n == ""
		txt = old + " is known by its number again: Army " + (aiArmy + 1) + "."
	Else
		txt = "Army " + (aiArmy + 1) + " under " + CSN_Gov.RankText(c) + " " + m.PlainName(c) + " is now called " + n + "."
	EndIf
	If p != ""
		txt += " Its purpose: " + p
	EndIf
	CSN_Gov.Say(txt)
	CSN_SkyrimNet.LogEvent(txt, c, Game.GetPlayer())
	If akVia && akVia != c
		CSN_SkyrimNet.LogEvent(txt, akVia, Game.GetPlayer())
	EndIf
	Return True
EndFunction

; Only the purpose, keeping the name.
Bool Function SetPurpose(Int aiArmy, String asPurpose, Actor akVia = None) Global
	Return SetName(aiArmy, Name(aiArmy), asPurpose, akVia)
EndFunction

; The army a soldier serves in (CoS gives each army's troops its own group faction), or -1.
Int Function TroopArmy(Actor akActor) Global
	If !akActor
		Return -1
	EndIf
	CS_PatrolHoldScript a = M().Armies()
	Int i = 0
	While i < a.GroupFactions.GetSize()
		Faction f = a.GroupFactions.GetAt(i) as Faction
		If f && akActor.IsInFaction(f)
			Return i
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

; What a commander or soldier knows of their own army's name and purpose.
String Function IdentityText(Int aiArmy) Global
	If aiArmy < 0
		Return ""
	EndIf
	String s = ""
	If Name(aiArmy) != ""
		s = "Their army is called " + Name(aiArmy) + " (it is also Army " + (aiArmy + 1) + " on the war table); they use the name with pride."
	EndIf
	If Purpose(aiArmy) != ""
		s += " The army's purpose, as its leader set it: " + Purpose(aiArmy)
	EndIf
	Return s
EndFunction

; A short ", purpose: ..." for lists the General reads.
String Function PurposeNote(Int aiArmy) Global
	If Purpose(aiArmy) == ""
		Return ""
	EndIf
	Return "; purpose: " + Purpose(aiArmy)
EndFunction

; "Army 3", "3", "the Iron Wolves" or the name of its Captain or Commander.
Int Function ParseArmy(String s) Global
	CSN_Core m = M()
	If s == ""
		Return -1
	EndIf
	Int i = 0
	CS_PatrolHoldScript a = m.Armies()
	While i < a.Commanders.Length
		String n = Name(i)
		If n != "" && m.Commander(i) && CSN_SkyrimNet.Matches(s, n)
			Return i
		EndIf
		i += 1
	EndWhile
	Return CSN_Troops.ParseArmy(s)
EndFunction

; Several armies in one phrase: "Army 1, Army 2 and the Iron Wolves". Returns army numbers (0-based).
Int[] Function ParseArmies(String s) Global
	Int[] found = new Int[10]
	Int n = 0
	String t = s
	t = ReplaceAll(t, " and ", ",")
	t = ReplaceAll(t, "&", ",")
	t = ReplaceAll(t, ";", ",")
	t = ReplaceAll(t, "+", ",")
	String[] parts = PapyrusUtil.StringSplit(t, ",")
	Int i = 0
	While i < parts.Length && n < 10
		Int a = ParseArmy(parts[i])
		If a >= 0 && !HasArmy(found, n, a)
			found[n] = a
			n += 1
		EndIf
		i += 1
	EndWhile
	Int[] r = Utility.CreateIntArray(n)
	i = 0
	While i < n
		r[i] = found[i]
		i += 1
	EndWhile
	Return r
EndFunction

Bool Function HasArmy(Int[] list, Int aiCount, Int aiArmy) Global
	Int i = 0
	While i < aiCount
		If list[i] == aiArmy
			Return True
		EndIf
		i += 1
	EndWhile
	Return False
EndFunction

String Function ReplaceAll(String s, String a, String b) Global
	Int at = StringUtil.Find(s, a)
	While at >= 0
		s = StringUtil.Substring(s, 0, at) + b + StringUtil.Substring(s, at + StringUtil.GetLength(a))
		at = StringUtil.Find(s, a, at + StringUtil.GetLength(b))
	EndWhile
	Return s
EndFunction

; =============================================================================
; CAMPS
; =============================================================================
; The faction already has a war camp in this hold (its camp is standing or armies are camped there).
Bool Function HasCamp(Int aiHold) Global
	If aiHold < 0 || aiHold > 8
		Return False
	EndIf
	CS_AttackPlanningNewScript p = Plan()
	ObjectReference mk = p.CampMarkersPlayer.GetAt(aiHold) as ObjectReference
	If mk && mk.IsEnabled()
		Return True
	EndIf
	FormList camped = M().Armies().CommandersPatrollingHolds.GetAt(aiHold) as FormList
	Return camped && camped.GetSize() > 0
EndFunction

; The hold whose war camp this army is in (camped there, not merely garrisoned), or -1.
Int Function CampOf(Actor akCommander) Global
	If !akCommander
		Return -1
	EndIf
	CS_PatrolHoldScript a = M().Armies()
	Int i = 0
	While i < 9
		FormList camped = a.CommandersPatrollingHolds.GetAt(i) as FormList
		If camped && camped.HasForm(akCommander)
			Return i
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

; Join an existing war camp, the way the war map's "send an army to this camp" does it (CS_MapManageMenuScript):
; same checks, then the army marches there (CS_PatrolHoldScript.RegisterForMoving "Camp").
Bool Function JoinCamp(Actor akCommander, Int aiHold, Actor akVia = None) Global
	CSN_Core m = M()
	CS_PatrolHoldScript a = m.Armies()
	CS_AttackPlanningNewScript p = Plan()
	Int army = m.GetArmy(akCommander)
	String hold = m.HoldName(aiHold)
	If army < 0
		CSN_Gov.Fail("That isn't one of your commanders.")
		Return False
	EndIf
	If p.BattleTracker.PlayerCamps[aiHold]
		CSN_Gov.Fail("The camp in " + hold + " is under attack; no army can join it now.")
		Return False
	EndIf
	FormList camped = a.CommandersPatrollingHolds.GetAt(aiHold) as FormList
	If camped.HasForm(akCommander)
		CSN_Gov.Fail(Label(army) + " is already at the camp in " + hold + ".")
		Return False
	EndIf
	If a.CommanderMoving.CommandersIncomingCamp[aiHold].HasForm(akCommander)
		CSN_Gov.Fail(Label(army) + " is already marching to the camp in " + hold + ".")
		Return False
	EndIf
	CS_TMScript tm = m.Gov.TMPlayer
	If !(tm.GetOwnSuperiorHoldsBordering(aiHold) > 0 || tm.GetLandSuperiorityNum() == 0 || (tm.CityCount.GetValue() + tm.MinorCityCount.GetValue()) == 1)
		CSN_Gov.Fail(hold + " doesn't border land you hold; your armies can't reach its camp.")
		Return False
	EndIf
	If (akCommander.IsInFaction(a.PatrolFaction) || akCommander.IsInFaction(a.AttackFaction))
		Int from = a.FindPatrolHold(akCommander)
		If from >= 0 && from != aiHold && !tm.GetIsHoldLinked(from, aiHold, nofirsthold = true)
			CSN_Gov.Fail(Label(army) + " can't move through enemy lines to " + hold + ".")
			Return False
		EndIf
	EndIf
	Int there = camped.GetSize() + a.CommanderMoving.CommandersIncomingCamp[aiHold].GetSize()
	If there >= 10
		CSN_Gov.Fail("The camp in " + hold + " already has ten armies, the most it can hold.")
		Return False
	EndIf
	If CSN_Config.ConfirmCamp() && !CSNP.Confirm("Join the war camp", "The " + m.FactionName() + " already has a war camp in " + hold + " (" + there + " armies there or on the way).\n\nSend " + CSN_Gov.RankText(akCommander) + " " + m.PlainName(akCommander) + " and " + Label(army) + " (" + m.ArmyTroops(army) + " troops) to join it?", "Join the camp", "Not now")
		Return False
	EndIf
	a.RegisterForMoving(akCommander, "Camp", aiHold)
	m.NoteOrder(akCommander, "join the war camp in " + hold)
	Return True
EndFunction

; =============================================================================
; TARGETS IN A HOLD (what the war table offers for one hold)
; kind: 0 city, 1 fort, 2 Imperial camp, 3 Stormcloak camp
; =============================================================================
Location Function TargetLocation(Int aiKind, Int aiHold) Global
	CS_AttackPlanningNewScript p = Plan()
	If aiKind == 0
		Return p.AllLocations.GetAt(aiHold) as Location
	ElseIf aiKind == 1
		Return p.AllLocationsFort.GetAt(aiHold) as Location
	ElseIf aiKind == 2
		Return p.AllLocationsCampImp.GetAt(aiHold) as Location
	EndIf
	Return p.AllLocationsCampSons.GetAt(aiHold) as Location
EndFunction

String Function TargetName(Int aiKind, Int aiHold) Global
	CSN_Core m = M()
	If aiKind == 0
		Return CSN_World.TownName(aiHold)
	ElseIf aiKind == 1
		Return m.FortName(aiHold)
	ElseIf aiKind == 2
		Return "the Imperial war camp in " + m.HoldName(aiHold)
	EndIf
	Return "the Stormcloak war camp in " + m.HoldName(aiHold)
EndFunction

String Function TargetButton(Int aiKind, Int aiHold) Global
	If aiKind == 2
		Return "Imperial War Camp"
	ElseIf aiKind == 3
		Return "Stormcloak War Camp"
	EndIf
	Return TargetName(aiKind, aiHold)
EndFunction

; 11 Imperials, 12 Stormcloaks, 0 if it is the player's own or nobody's.
Int Function TargetSide(Int aiKind, Int aiHold) Global
	CS_AttackPlanningNewScript p = Plan()
	If aiKind == 2
		Return 11
	ElseIf aiKind == 3
		Return 12
	EndIf
	Location l = TargetLocation(aiKind, aiHold)
	If !l
		Return 0
	EndIf
	Int o = l.GetKeywordData(p.CWOwner) as Int
	If o == 1 || o == 2
		Return 10 + o
	EndIf
	Return 0
EndFunction

; Is this target there to be attacked at all (enemy city or fort, enemy camp standing)?
Bool Function TargetExists(Int aiKind, Int aiHold) Global
	CS_AttackPlanningNewScript p = Plan()
	If aiHold < 0 || aiHold > 8
		Return False
	EndIf
	ObjectReference mk = None
	If aiKind == 2
		mk = p.CampMarkersImp.GetAt(aiHold) as ObjectReference
		Return mk && mk.IsEnabled()
	ElseIf aiKind == 3
		mk = p.CampMarkersSons.GetAt(aiHold) as ObjectReference
		Return mk && mk.IsEnabled()
	EndIf
	Return TargetSide(aiKind, aiHold) > 0
EndFunction

; "" when the faction may attack it now; otherwise why not. The same checks as CS_AttackPlanningNewScript.SelectTarget.
String Function CheckTarget(Int aiKind, Int aiHold) Global
	CSN_Core m = M()
	CS_AttackPlanningNewScript p = Plan()
	String hold = m.HoldName(aiHold)
	If !TargetExists(aiKind, aiHold)
		If aiKind >= 2
			Return "There is no such camp in " + hold + " any more."
		EndIf
		Return TargetName(aiKind, aiHold) + " is already yours."
	EndIf
	Int side = TargetSide(aiKind, aiHold)
	If (side == 11 && p.TMImp.TrucePlayer) || (side == 12 && p.TMSons.TrucePlayer)
		Return "You have a truce with " + m.SideName(side - 10) + "; you can't attack them."
	EndIf
	If (side == 11 && !p.TMImp.AtWarPlayer) || (side == 12 && !p.TMSons.AtWarPlayer)
		Return "You are not at war with " + m.SideName(side - 10) + ". Have your Steward draw up a declaration of war first."
	EndIf
	If AttackRunning() || p.RestrictInvasion
		Return "Another attack is already under way. Finish it or call it off first."
	EndIf
	If p.BattleTracker.PlayerCamps[aiHold]
		Return "Your camp in " + hold + " is under attack; no attack can be planned there now."
	EndIf
	Location region = p.AllLocationsCS.GetAt(aiHold) as Location
	If aiKind <= 1
		If region.GetKeywordData(p.LandSuperiority) != 1
			Return "You need to control the roads of " + hold + " first: take its war camps and hold its land before you attack " + TargetName(aiKind, aiHold) + "."
		EndIf
	ElseIf !HasCamp(aiHold)
		Return "You need a war camp of your own in " + hold + " first. Have an army make camp there."
	EndIf
	Return ""
EndFunction

; Armies that may join an attack in this hold: camped or garrisoned there (CS_AttackPlanningNewScript.SetAvailableArmies).
Bool Function CanJoinAttack(Actor akCommander, Int aiHold) Global
	CS_AttackPlanningNewScript p = Plan()
	FormList camped = p.PatrolCommandersHolds.GetAt(aiHold) as FormList
	FormList garrison = p.GarrisonCommandersHolds.GetAt(aiHold) as FormList
	Return akCommander && ((camped && camped.HasForm(akCommander)) || (garrison && garrison.HasForm(akCommander)))
EndFunction

String Function ArmiesInHoldText(Int aiHold) Global
	CSN_Core m = M()
	CS_PatrolHoldScript a = m.Armies()
	String s = ""
	Int i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c && !c.IsDead() && CanJoinAttack(c, aiHold)
			If s != ""
				s += ", "
			EndIf
			s += Label(i)
		EndIf
		i += 1
	EndWhile
	Return s
EndFunction

; =============================================================================
; WAR CAMP PLANS (the war table's "discuss war plans in a hold", from conversation)
; =============================================================================
; The hold this NPC would plan for: a commander's own camp; the General needs one named (or asks).
Int Function PlanHoldFor(Actor akActor, String asHold) Global
	Int h = CSN_SkyrimNet.ParseHoldOrCity(asHold)
	If h < 0 && asHold != ""
		Int f = CSN_SkyrimNet.ParseFort(asHold)
		If f >= 0 && f < 9
			h = f
		EndIf
	EndIf
	If h >= 0
		Return h
	EndIf
	Return CampOf(akActor)
EndFunction

Function WarCampPlans(Actor akActor, Int aiHold) Global
	CSN_Core m = M()
	If aiHold < 0
		aiHold = AskHold()
		If aiHold < 0
			CSN_SkyrimNet.EndAction()
			Return
		EndIf
	EndIf
	m.CloseScreen()
	String hold = m.HoldName(aiHold)
	Int[] kinds = new Int[4]
	String[] buttons = new String[5]
	Int n = 0
	Int k = 0
	While k < 4
		If TargetExists(k, aiHold)
			kinds[n] = k
			buttons[n] = TargetButton(k, aiHold)
			n += 1
		EndIf
		k += 1
	EndWhile
	If n == 0
		CSN_Gov.Fail("There is nothing left to attack in " + hold + ": its city, fort and camps are yours.")
		Return
	EndIf
	String[] opts = Utility.CreateStringArray(n + 1)
	Int i = 0
	While i < n
		opts[i] = buttons[i]
		i += 1
	EndWhile
	opts[n] = "Cancel"
	String intro = "Choose a target in " + hold + ". Armies at the camp or in garrison there: " + ArmiesInHoldText(aiHold) + "."
	If ArmiesInHoldText(aiHold) == ""
		intro = "Choose a target in " + hold + ". No army is camped or garrisoned there yet."
	EndIf
	String msg = intro
	While True
		Int r = CSNP.Choose("War camp plans: " + hold, msg, opts)
		If r < 0 || r >= n
			CSN_SkyrimNet.EndAction()
			Return
		EndIf
		String err = CheckTarget(kinds[r], aiHold)
		If err == ""
			LaunchPlanning(akActor, kinds[r], aiHold)
			Return
		EndIf
		; the reason stays on screen, and the top-left note says it too
		Debug.Notification(err)
		msg = "Can't attack " + TargetName(kinds[r], aiHold) + ": " + err + "\n\n" + intro
	EndWhile
EndFunction

; Pick a hold where the faction has an army camped or garrisoned (for the General).
Int Function AskHold() Global
	CSN_Core m = M()
	Int[] holds = new Int[9]
	String[] names = new String[10]
	Int n = 0
	Int h = 0
	While h < 9
		If ArmiesInHoldText(h) != "" || HasCamp(h)
			holds[n] = h
			names[n] = m.HoldName(h)
			n += 1
		EndIf
		h += 1
	EndWhile
	If n == 0
		CSN_Gov.Fail("No army is camped anywhere yet. Have an army make camp in the hold you want to attack.")
		Return -1
	EndIf
	String[] opts = Utility.CreateStringArray(n + 1)
	Int i = 0
	While i < n
		opts[i] = names[i]
		i += 1
	EndWhile
	opts[n] = "Cancel"
	Int r = CSNP.Choose("War camp plans", "Which hold do you want to plan an attack in?", opts)
	If r < 0 || r >= n
		Return -1
	EndIf
	Return holds[r]
EndFunction

; Hand the chosen target to CoS's own planning (army selection, siege equipment, battle plan, confirm),
; exactly as the war table's dialogue does (CS__TIF__05AF1FD9 and friends).
Function LaunchPlanning(Actor akActor, Int aiKind, Int aiHold) Global
	CS_AttackPlanningNewScript p = Plan()
	p.Start()
	p.InvasionTarget.ForceLocationTo(TargetLocation(aiKind, aiHold))
	p.holdnum = aiHold
	p.enemyfactionnum = TargetSide(aiKind, aiHold)
	p.SelectTarget()
	p.Stop()
	If AttackRunning()
		Launched(akActor, aiKind, aiHold, "")
	Else
		CSN_SkyrimNet.ActionDeclined()
	EndIf
EndFunction

; =============================================================================
; DIRECT ATTACK ORDER: "send Army 1 and Army 2 to attack Fort Greymoor"
; =============================================================================
; Parse "Fort Greymoor", "Whiterun", "the Imperial camp in Whiterun". Returns kind * 10 + hold, or -1.
Int Function ParseTarget(String s, Int aiDefaultHold) Global
	If s == ""
		Return -1
	EndIf
	Bool camp = CSN_SkyrimNet.Matches(s, "camp")
	If camp
		Int h = CSN_SkyrimNet.ParseHoldOrCity(s)
		If h < 0
			h = aiDefaultHold
		EndIf
		If h < 0
			Return -1
		EndIf
		If CSN_SkyrimNet.Matches(s, "Imperial") || CSN_SkyrimNet.Matches(s, "Legion") || CSN_SkyrimNet.Matches(s, "Empire")
			Return 20 + h
		ElseIf CSN_SkyrimNet.Matches(s, "Stormcloak") || CSN_SkyrimNet.Matches(s, "Sons")
			Return 30 + h
		EndIf
		If TargetExists(2, h)
			Return 20 + h
		ElseIf TargetExists(3, h)
			Return 30 + h
		EndIf
		Return 20 + h
	EndIf
	Int f = CSN_SkyrimNet.ParseFort(s)
	If f >= 0 && f < 9 && (CSN_SkyrimNet.Matches(s, "Fort") || CSN_SkyrimNet.ParseTown(s) < 0)
		Return 10 + f
	EndIf
	Int c = CSN_SkyrimNet.ParseCity(s)
	If c >= 0 && c < 9
		Return c
	EndIf
	If f >= 0 && f < 9
		Return 10 + f
	EndIf
	Return -1
EndFunction

Bool Function OrderAttack(Actor akActor, String asArmies, String asTarget) Global
	CSN_Core m = M()
	Int code = ParseTarget(asTarget, CampOf(akActor))
	If code < 0
		CSN_Gov.Fail("Which target? Name a city, a fort or an enemy war camp, e.g. Fort Greymoor.")
		Return False
	EndIf
	Int kind = code / 10
	Int hold = code % 10
	String target = TargetName(kind, hold)
	String err = CheckTarget(kind, hold)
	If err != ""
		CSN_Gov.Fail(err)
		Return False
	EndIf
	Int[] armies = ParseArmies(asArmies)
	If armies.Length == 0 && m.GetArmy(akActor) >= 0
		armies = new Int[1]
		armies[0] = m.GetArmy(akActor)
	EndIf
	If armies.Length == 0
		CSN_Gov.Fail("Which armies? Name them by number, by name or by their Captain or Commander.")
		Return False
	EndIf
	String list = ""
	Int troops = 0
	Int i = 0
	While i < armies.Length
		Actor c = m.Commander(armies[i])
		If !c || c.IsDead()
			CSN_Gov.Fail(Label(armies[i]) + " has no leader to take it into battle.")
			Return False
		EndIf
		If !CanJoinAttack(c, hold)
			String here = ArmiesInHoldText(hold)
			If here == ""
				here = "none yet"
			EndIf
			CSN_Gov.Fail(Label(armies[i]) + " isn't camped or garrisoned in " + m.HoldName(hold) + ", so it can't join this attack. Armies there: " + here + ".")
			Return False
		EndIf
		list += "\n  " + Label(armies[i]) + " under " + CSN_Gov.RankText(c) + " " + m.PlainName(c) + ": " + m.ArmyTroops(armies[i]) + " troops"
		troops += m.ArmyTroops(armies[i])
		i += 1
	EndWhile
	CS_AttackPlanningNewScript p = Plan()
	String kindText = "Assault on a city"
	If kind == 1
		kindText = "Siege of a fort"
	ElseIf kind >= 2
		kindText = "Raid on an enemy war camp"
	EndIf
	String text = kindText + ": " + target + " (" + m.HoldName(hold) + "), held by " + m.SideName(TargetSide(kind, hold) - 10) + ".\n\nArmies:" + list + "\n\n" + troops + " troops in all."
	If kind <= 1
		text += "\n\nNo siege equipment goes with this order (ready: " + p.BatteringRamsPurchased.GetValueInt() + " battering rams, " + p.LaddersPurchased.GetValueInt() + " ladders, " + p.CatapultsPurchased.GetValueInt() + " catapults). Use war camp plans to bring some."
		text += "\n\nThe armies march to the staging ground; tell a commander there when to begin the attack."
	EndIf
	; this order always asks: it sends armies into battle
	If !CSNP.Confirm("Attack " + target, text, "Attack", "Not now")
		Return False
	EndIf
	m.CloseScreen()
	p.Start()
	p.InvasionTarget.ForceLocationTo(TargetLocation(kind, hold))
	p.holdnum = hold
	p.enemyfactionnum = TargetSide(kind, hold)
	; target first, so the battle plan description (SetUpMenu) matches it, as in SelectTarget
	p.FindTargetRef()
	p.SetUpMenu()
	i = 0
	While i < armies.Length && i < p.SelectedCommanders.Length
		Actor leader = m.Commander(armies[i])
		p.SelectedCommanders[i].ForceRefTo(leader)
		p.InvasionCommanders[i] = leader
		p.ChosenArmies += 1
		p.TotalTroops.Mod(m.ArmyTroops(armies[i]))
		i += 1
	EndWhile
	p.InvasionStart()
	p.Stop()
	If !AttackRunning()
		CSN_Gov.Fail("The attack on " + target + " could not be launched.")
		Return False
	EndIf
	String names = ""
	i = 0
	While i < armies.Length
		If names != ""
			names += ", "
		EndIf
		names += Label(armies[i])
		i += 1
	EndWhile
	Launched(akActor, kind, hold, names)
	Return True
EndFunction

; After any attack we launched: orders noted for each army, and the NPC who arranged it remembers the choices.
Function Launched(Actor akActor, Int aiKind, Int aiHold, String asArmies) Global
	CSN_Core m = M()
	CS_AttackPlanningNewScript p = Plan()
	String target = TargetName(aiKind, aiHold)
	Bool listThem = asArmies == ""
	Int i = 0
	While i < p.AttackCommanders.GetSize()
		Actor c = p.AttackCommanders.GetAt(i) as Actor
		If c
			If listThem
				If asArmies != ""
					asArmies += ", "
				EndIf
				asArmies += Label(m.GetArmy(c))
			EndIf
			m.NoteOrder(c, "attack " + target)
		EndIf
		i += 1
	EndWhile
	String txt = Game.GetPlayer().GetDisplayName() + " ordered an attack on " + target + " in " + m.HoldName(aiHold) + " with " + asArmies + "."
	If aiKind <= 1
		txt += " The armies march to the staging ground and wait for the order to begin."
	EndIf
	CSN_Gov.Say("Attack on " + target + ": " + asArmies + ".")
	If akActor
		CSN_SkyrimNet.LogEvent(txt, akActor, Game.GetPlayer())
	EndIf
	WatchBattles()
EndFunction

; =============================================================================
; STARTING AND CALLING OFF A PREPARED ATTACK (the commanders' "It's time to begin the attack!" and
; "Cancel the attack!" dialogue)
; =============================================================================
Bool Function AttackRunning() Global
	CS_AttackPlanningNewScript p = Plan()
	Return p.AttackCitySiege.IsRunning() || p.AttackFort.IsRunning() || p.AttackCamp.IsRunning() || p.AttackCity.IsRunning()
EndFunction

; Fort or camp attack waiting at the staging ground (CS_AttackFortNew stage 5, before stage 10).
Bool Function FortWaiting() Global
	Quest q = Plan().AttackFort
	Return q.IsRunning() && q.GetStage() < 10 && (q as CS_AttackFortCampScript).FailingQuest == 0
EndFunction

; City siege set up but not launched yet.
Bool Function CityWaiting() Global
	CS_AttackPlanningNewScript p = Plan()
	Return p.AttackCitySiege.IsRunning() && !p.AttackCity.IsRunning() && (p.AttackCitySiege as CS_AttackCitySiegeScript).CancellingAttack == 0
EndFunction

Bool Function CanStart() Global
	Return FortWaiting() || CityWaiting()
EndFunction

; Can still be called off: a city siege before it is launched, or a fort or camp attack before it is won or lost.
Bool Function CanCancel() Global
	CS_AttackPlanningNewScript p = Plan()
	If CityWaiting()
		Return True
	EndIf
	Quest q = p.AttackFort
	If q.IsRunning() && q.GetStage() < 20 && (q as CS_AttackFortCampScript).FailingQuest == 0
		Return True
	EndIf
	q = p.AttackCamp
	Return q.IsRunning() && q.GetStage() < 20 && (q as CS_AttackFortCampScript).FailingQuest == 0
EndFunction

; Who may give the word: a Captain or Commander in the attack, or the General.
Bool Function InAttack(Actor akActor) Global
	CSN_Core m = M()
	If m.GetRole(akActor) == m.ROLE_GENERAL
		Return True
	EndIf
	Return m.GetArmy(akActor) >= 0 && Plan().AttackCommanders.HasForm(akActor)
EndFunction

String Function CurrentTarget() Global
	CSN_Core m = M()
	CS_AttackPlanningNewScript p = Plan()
	If p.AttackCitySiege.IsRunning()
		Return CSN_World.TownName((p.AttackCitySiege as CS_AttackCitySiegeScript).holdnum)
	ElseIf p.AttackCity.IsRunning()
		Return CSN_World.TownName((p.AttackCity as CS_AttackCityScript).citynum)
	ElseIf p.AttackFort.IsRunning()
		Return m.FortName((p.AttackFort as CS_AttackFortCampScript).holdnum)
	ElseIf p.AttackCamp.IsRunning()
		Return "the enemy war camp in " + m.HoldName((p.AttackCamp as CS_AttackFortCampScript).holdnum)
	EndIf
	Return ""
EndFunction

Bool Function StartAttack(Actor akActor) Global
	CS_AttackPlanningNewScript p = Plan()
	If !CanStart()
		CSN_Gov.Fail("No attack is waiting for the order to begin.")
		Return False
	EndIf
	String target = CurrentTarget()
	If CSN_Config.ConfirmBattle() && !CSNP.Confirm("Begin the attack", "Give the order to begin the attack on " + target + "?", "Attack!", "Not now")
		Return False
	EndIf
	If akActor
		Utility.Wait(1.0)
		Debug.SendAnimationEvent(akActor, "IdleBlowHornStormcloak")
	EndIf
	If FortWaiting()
		Utility.Wait(4.0)
		p.AttackFort.SetStage(10)
	Else
		(p.AttackCitySiege as CS_AttackCitySiegeScript).LaunchAttack()
	EndIf
	CSN_Gov.Say("The attack on " + target + " has begun.")
	CSN_World.AddNews(-1, "The " + M().FactionName() + " has begun its assault on " + target + ".", "csn_attack_begun", akActor)
	Return True
EndFunction

Bool Function CancelAttack(Actor akActor) Global
	CS_AttackPlanningNewScript p = Plan()
	If !CanCancel()
		CSN_Gov.Fail("There is no attack that can still be called off.")
		Return False
	EndIf
	String target = CurrentTarget()
	If CSN_Config.ConfirmBattle() && !CSNP.Confirm("Call off the attack", "Call off the attack on " + target + "? The armies return to their posts.", "Call it off", "Keep going")
		Return False
	EndIf
	If CityWaiting()
		(p.AttackCitySiege as CS_AttackCitySiegeScript).CancelAttack()
	ElseIf p.AttackFort.IsRunning()
		(p.AttackFort as CS_AttackFortCampScript).FailQuest()
	Else
		(p.AttackCamp as CS_AttackFortCampScript).FailQuest()
	EndIf
	CSN_Gov.Say("The attack on " + target + " is called off.")
	CSN_World.AddNews(-1, "The " + M().FactionName() + " called off its attack on " + target + ".", "csn_attack_called_off", akActor)
	Return True
EndFunction

; =============================================================================
; EVERY ATTACK BECOMES KNOWN (however it was launched: war table, CoS dialogue or conversation)
; Called every few seconds by CSN_Core.OnUpdate.
; =============================================================================
Function WatchBattles() Global
	CSN_Core m = M()
	If !m
		Return
	EndIf
	CS_AttackPlanningNewScript p = Plan()
	If !p
		Return
	EndIf
	String now = ""
	Int town = -1
	If p.AttackCitySiege.IsRunning() || p.AttackCity.IsRunning()
		If p.AttackCitySiege.IsRunning()
			town = (p.AttackCitySiege as CS_AttackCitySiegeScript).holdnum
		Else
			town = (p.AttackCity as CS_AttackCityScript).citynum
		EndIf
		now = "city" + town
	ElseIf p.AttackFort.IsRunning()
		town = (p.AttackFort as CS_AttackFortCampScript).holdnum
		now = "fort" + town
	ElseIf p.AttackCamp.IsRunning()
		town = (p.AttackCamp as CS_AttackFortCampScript).holdnum
		now = "camp" + town
	EndIf
	String before = StorageUtil.GetStringValue(None, "csn_attack_now", "")
	If now == before
		Return
	EndIf
	StorageUtil.SetStringValue(None, "csn_attack_now", now)
	If now == ""
		Return
	EndIf
	String target = CurrentTarget()
	String side = ""
	If StringUtil.Find(now, "fort") == 0
		side = m.SideName(TargetSide(1, town) - 10)
	ElseIf StringUtil.Find(now, "city") == 0
		side = m.SideName(TargetSide(0, town) - 10)
	Else
		side = m.SideName((p.AttackCamp as CS_AttackFortCampScript).enemyfactionnum - 10)
	EndIf
	String armies = ""
	Int i = 0
	While i < p.AttackCommanders.GetSize()
		Actor c = p.AttackCommanders.GetAt(i) as Actor
		If c && m.GetArmy(c) >= 0
			If armies != ""
				armies += ", "
			EndIf
			armies += Label(m.GetArmy(c)) + " under " + CSN_Gov.RankText(c) + " " + m.PlainName(c)
		EndIf
		i += 1
	EndWhile
	String txt = "The " + m.FactionName() + ", led by " + Game.GetPlayer().GetDisplayName() + ", has launched an attack on " + target + " in " + m.HoldName(town)
	If side != ""
		txt += ", held by " + side
	EndIf
	If armies != ""
		txt += ". Marching: " + armies
	EndIf
	txt += "."
	StorageUtil.SetStringValue(None, "csn_attack_text", txt)
	; Skyrim-wide news: everyone hears of it, and the town it belongs to remembers it
	CSN_World.AddNews(-1, txt, "csn_attack_launched", Game.GetPlayer())
	If town >= 0 && town < 9
		CSN_SkyrimNet.AddHistory(town, txt)
	EndIf
EndFunction

; For officers and army leaders: the attack in progress, if any, and what can be done about it.
String Function BattleText() Global
	If !AttackRunning()
		Return ""
	EndIf
	String s = " Current attack: " + StorageUtil.GetStringValue(None, "csn_attack_text", "the faction is attacking " + CurrentTarget() + ".")
	If CanStart()
		s += " The armies are at the staging ground waiting for the order to begin; the leader can tell a commander in the attack (or the General) to begin."
	EndIf
	If CanCancel()
		s += " It can still be called off."
	EndIf
	Return s
EndFunction
