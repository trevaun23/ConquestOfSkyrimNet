Scriptname CSN_Native Hidden
{Natives from ConquestOfSkyrimNetUI.dll (SKSE plugin hosting the PrismaUI view). Use CSNP for the blocking helpers.}

Bool Function IsAvailable() Global Native

; ---- generic Message rendering (replaces vanilla message boxes)
Bool Function IsMenuMessage(Message akMsg) Global Native
Quest Function GetOwnerQuest(Message akMsg) Global Native
String[] Function GetAliasTags(Message akMsg) Global Native
Int Function ShowMessage(Message akMsg, String[] asAliasNames, String[] asAliasValues, Float[] afArgs) Global Native

; Number picker (-100..+100 steps and typing): 0 = accepted (amount via PollText), 1/-1 = cancelled.
; asPriceLabel may use {n} (amount) and {g} (amount x aiUnitPrice), e.g. "{n} food a day costs {g} gold a day".
Int Function OpenAmount(String asTitle, String asText, Int aiInitial, Int aiMin, Int aiMax, Int aiUnitPrice, String asPriceLabel, String asYes, String asNo) Global Native
; One line to Documents/My Games/Skyrim Special Edition/SKSE/ConquestOfSkyrimNet.log
Function Log(String asText) Global Native
; Full path of ConquestOfSkyrimNet.log as the DLL created it ("" if it could not).
String Function GetLogPath() Global Native
; A result line on the faction screen: green, or red when abError.
Function UIMessage(String asText, Bool abError) Global Native

; ---- text input / list (replace SkyUILib)
Int Function OpenTextInput(String asTitle, String asInitial) Global Native
Function OpenNotice(String asText) Global Native
; Yes/No question: 0 = yes, 1 = no, -1 = closed
Int Function OpenConfirm(String asTitle, String asText, String asYes, String asNo) Global Native
; Question with its own buttons (an empty label hides that button); returns the button index, -1 = closed
Int Function OpenChoice(String asTitle, String asText, String[] asButtons) Global Native
Int Function OpenList(String asTitle, String[] asOptions, Int aiStartIndex, Int aiDefaultIndex) Global Native

; -2 = still open, -1 = cancelled, otherwise the chosen index
Int Function PollResult(Int aiToken) Global Native
String Function PollText(Int aiToken) Global Native

; ---- Conquest of SkyrimNet screens
Bool Function OpenView(String asScreen, String asPayloadJson) Global Native
Bool Function PushData(String asScreen, String asPayloadJson) Global Native
Function CloseView() Global Native
; True while the faction screen is shown.
Bool Function IsScreenOpen() Global Native

; ---- settings / helpers
; Re-reads the MCM ini files (hotkey, theme).
Function ReloadSettings() Global Native
; Lower-cases JSON keys and fixes True/False/None that Papyrus string interning can produce.
String Function NormalizeJson(String asJson) Global Native

; ---- settlements
; The name a map marker shows on the world map (not saved: set it again after loading). False if akRef isn't a map marker.
Bool Function SetMapMarkerName(ObjectReference akRef, String asName) Global Native
