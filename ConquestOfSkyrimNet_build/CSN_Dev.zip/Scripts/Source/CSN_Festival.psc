Scriptname CSN_Festival Hidden
{Conquest of SkyrimNet - festivals, with the Holidays mod (isoku, Holidays.esp).

 Holidays stages the celebrations itself: on the lore's holidays the townsfolk gather in temples, inns, shops or
 outside, with decorations and fireworks. On such a day this gives the player an optional journal quest,
 "Attend the Festival in <Town>", for the nearest town the faction rules where that holiday is celebrated. Showing
 up in the town that day completes it and its people's loyalty rises a little. Without Holidays.esp nothing happens.

 Journal: CSN_JournalFestival1 (aliases 0 Town, 1 unused, 2 TownMarker; stages 10 on, 100 attended, 200 missed;
 objective 10), started through the story manager like the unrest journal (keyword CSN_StoryJournalFestival).
 State: StorageUtil "csn_fest_*".}

Bool Function Installed() Global
	Return Game.GetModByName("Holidays.esp") != 255
EndFunction

Bool Function Enabled() Global
	Return Installed() && CSN_Config.GetBool("bFestivals:General", True)
EndFunction

Int Function LoyaltyGain() Global
	Return CSN_Config.ClampMin(CSN_Config.GetInt("iFestivalLoyalty:General", 5), 0)
EndFunction

Quest Function Journal() Global
	Return Quest.GetQuest("CSN_JournalFestival1")
EndFunction

; Holidays' fixed holidays: "month|day|name|where" (month 0 = Morning Star; where: all = Holidays' usual towns,
; major = the five big cities, or one town's name)
String[] Function Table() Global
	String[] t = new String[17]
	t[0] = "0|1|the New Life Festival|all"
	t[1] = "0|15|South Wind's Prayer|all"
	t[2] = "0|16|the Festival of Lights|Dawnstar"
	t[3] = "1|13|the Feast of the Dead|Windhelm"
	t[4] = "1|16|Heart's Day|all"
	t[5] = "2|7|First Planting|all"
	t[6] = "3|28|Jester's Day|major"
	t[7] = "4|7|Second Planting|all"
	t[8] = "5|16|the Mid Year Celebration|all"
	t[9] = "6|10|the Merchant's Festival|all"
	t[10] = "6|20|Sun's Rest|all"
	t[11] = "7|27|Harvest's End|all"
	t[12] = "8|3|Tales and Tallows|all"
	t[13] = "10|20|the Warriors Festival|all"
	t[14] = "11|15|North Wind's Prayer|all"
	t[15] = "11|25|Saturalia|all"
	t[16] = "11|31|the Old Life Festival|all"
	Return t
EndFunction

; today's holiday row ("" none)
String Function Today() Global
	Int mon = (Game.GetFormFromFile(0x36, "Skyrim.esm") as GlobalVariable).GetValueInt()
	Int day = (Game.GetFormFromFile(0x37, "Skyrim.esm") as GlobalVariable).GetValueInt()
	String[] t = Table()
	Int i = 0
	While i < t.Length
		String[] f = PapyrusUtil.StringSplit(t[i], "|")
		If (f[0] as Int) == mon && (f[1] as Int) == day
			Return t[i]
		EndIf
		i += 1
	EndWhile
	Return ""
EndFunction

; Holidays celebrates in every city but Winterhold, and in Dragon Bridge, Ivarstead, Karthwasten, Riverwood,
; Rorikstead and Shor's Stone
Bool Function Celebrates(Int aiTown, String asWhere) Global
	String n = CSN_World.TownName(aiTown)
	If asWhere == "all"
		If n == "Winterhold"
			Return False
		EndIf
		If aiTown <= 8
			Return True
		EndIf
		Return n == "Dragon Bridge" || n == "Ivarstead" || n == "Karthwasten" || n == "Riverwood" || n == "Rorikstead" || n == "Shor's Stone"
	ElseIf asWhere == "major"
		Return n == "Whiterun" || n == "Solitude" || n == "Windhelm" || n == "Riften" || n == "Markarth"
	EndIf
	Return n == asWhere
EndFunction

Int Function GameDay() Global
	Return Utility.GetCurrentGameTime() as Int
EndFunction

; About once a minute (CSN_Core): a holiday starts the journal; being in the town completes it; the day ending
; without you closes it.
Function Tick() Global
	CSN_Core m = CSN_Gov.M()
	If !m || m.FactionStarted.GetValue() < 1
		Return
	EndIf
	TickScheduled()
	If !Enabled()
		TickJournal()
		Return
	EndIf
	If TickJournal()
		Return
	EndIf
	Quest q = Journal()
	If !q
		Return
	EndIf
	Int d = GameDay()
	If StorageUtil.GetIntValue(None, "csn_fest_last", -1) == d
		Return
	EndIf
	String row = Today()
	If row == ""
		Return
	EndIf
	StorageUtil.SetIntValue(None, "csn_fest_last", d)
	String[] f = PapyrusUtil.StringSplit(row, "|")
	Int town = PickTown(f[3])
	If town < 0
		Return
	EndIf
	Begin(q, town, f[2])
EndFunction

; a running attend quest: completed when you're in the town that day, closed when the day ends. True while one runs.
Bool Function TickJournal() Global
	Quest q = Journal()
	Int t = StorageUtil.GetIntValue(None, "csn_fest_town", -1)
	If !q || t < 0 || !q.IsRunning() || q.GetStage() != 10
		Return False
	EndIf
	If StorageUtil.GetIntValue(None, "csn_fest_day", -1) != GameDay()
		Missed(q, t)
	ElseIf CSN_World.TownOf(Game.GetPlayer()) == t || Game.GetPlayer().IsInLocation(CSN_World.TownVanillaLocation(t))
		Attended(q, t)
	EndIf
	Return True
EndFunction

; the nearest town the faction rules that celebrates this holiday (-1 none)
Int Function PickTown(String asWhere) Global
	Actor p = Game.GetPlayer()
	Int best = -1
	Float bestDist = 0.0
	Int i = 0
	While i < CSN_World.TownCount()
		If CSN_World.PlayerRules(i) && Celebrates(i, asWhere)
			Float dist = 9999999.0
			ObjectReference mk = CSN_Rebellion.TownMarker(i)
			If mk && mk.GetWorldSpace() == p.GetWorldSpace()
				dist = p.GetDistance(mk)
			EndIf
			If best < 0 || dist < bestDist
				best = i
				bestDist = dist
			EndIf
		EndIf
		i += 1
	EndWhile
	Return best
EndFunction

Function Begin(Quest q, Int aiTown, String asHoliday) Global
	If q.IsRunning()
		q.Stop()
		Utility.Wait(0.2)
	EndIf
	q.Reset()
	If !CSN_Journal.StartWith(q, 0xD3D8A4, CSN_World.TownVanillaLocation(aiTown))
		CSN_Config.Log("festival: journal did not start for " + CSN_World.TownName(aiTown))
		Return
	EndIf
	ReferenceAlias mk = q.GetAlias(2) as ReferenceAlias
	If mk && CSN_Rebellion.TownMarker(aiTown)
		mk.ForceRefTo(CSN_Rebellion.TownMarker(aiTown))
	EndIf
	q.SetStage(10)
	q.SetObjectiveDisplayed(10, True)
	StorageUtil.SetIntValue(None, "csn_fest_town", aiTown)
	StorageUtil.SetIntValue(None, "csn_fest_day", GameDay())
	StorageUtil.SetStringValue(None, "csn_fest_name", asHoliday)
	String town = CSN_World.TownName(aiTown)
	CSN_Gov.Say(town + " celebrates " + asHoliday + " today. Attend it (optional).")
	CSN_World.AddNews(aiTown, "The people of " + town + " celebrate " + asHoliday + " today and hope to see " + Game.GetPlayer().GetDisplayName() + " among them.", "csn_festival")
EndFunction

Function Attended(Quest q, Int aiTown) Global
	CSN_Core m = CSN_Gov.M()
	q.SetObjectiveCompleted(10, True)
	q.SetStage(100)
	String town = CSN_World.TownName(aiTown)
	String hol = StorageUtil.GetStringValue(None, "csn_fest_name", "the festival")
	m.Gov.LoyaltyScript.AdjustLoyaltySilent(CSN_World.TownLocation(aiTown), LoyaltyGain())
	CSN_Gov.Say("You joined " + hol + " in " + town + ": loyalty +" + LoyaltyGain() + ".")
	CSN_World.AddNews(aiTown, Game.GetPlayer().GetDisplayName() + " came to " + town + " for " + hol + " and celebrated with its people.", "csn_festival")
	StorageUtil.SetIntValue(None, "csn_fest_town", -1)
	q.CompleteQuest()
	q.Stop()
EndFunction

Function Missed(Quest q, Int aiTown) Global
	q.SetObjectiveDisplayed(10, False)
	q.SetStage(200)
	StorageUtil.SetIntValue(None, "csn_fest_town", -1)
	q.Stop()
EndFunction

; =============================================================================
; FESTIVALS YOU APPROVE (a town's request for a grant "for a festival"): held the next day in that town.
; With Holidays, its own festivities are switched on for that day through its Override setting (the same one its
; MCM has): its decorations go up (Holidays decorates every town it celebrates in at once) and the townsfolk of the
; town you're in gather at the temple, the shops or the town centre, as that holiday does. The day after, the
; override is put back as it was. Without Holidays, it is still a festival day: the town's attend quest and loyalty.
; =============================================================================
_holidayquestscript Function HolidaysQuest() Global
	If !Installed()
		Return None
	EndIf
	Return Game.GetFormFromFile(0x00F059, "Holidays.esp") as _holidayquestscript   ; _WetHolidayQuest
EndFunction

; is this request's cause a festival?
Bool Function IsFestivalCause(String asCause) Global
	; any one-off public event: feasts, festivals, games, ceremonies and the like (StringUtil.Find ignores case)
	String[] w = new String[40]
	w[0] = "festiv"
	w[1] = "feast"
	w[2] = "celebrat"
	w[3] = "holiday"
	w[4] = "fair"
	w[5] = "tourn"
	w[6] = "harvest"
	w[7] = "prayer"
	w[8] = "banquet"
	w[9] = "games"
	w[10] = "contest"
	w[11] = "competition"
	w[12] = "wedding"
	w[13] = "ceremon"
	w[14] = "parade"
	w[15] = "procession"
	w[16] = "gathering"
	w[17] = "revel"
	w[18] = "dance"
	w[19] = "concert"
	w[20] = "bard"
	w[21] = "music"
	w[22] = "performance"
	w[23] = "commemor"
	w[24] = "memorial"
	w[25] = "anniversar"
	w[26] = "party"
	w[27] = "jubilee"
	w[28] = "coronation"
	w[29] = "market day"
	w[30] = "horse race"
	w[31] = "gala"
	w[32] = "honour"
	w[33] = "honor"
	w[34] = "festivities"
	w[35] = "rites"
	w[36] = "vigil"
	w[37] = "pageant"
	w[38] = "fireworks"
	w[39] = "a ball"
	Int i = 0
	While i < w.Length
		If StringUtil.Find(asCause, w[i]) >= 0
			Return True
		EndIf
		i += 1
	EndWhile
	Return False
EndFunction

; which of Holidays' festivals fits the cause (its Override numbers): 16 Warriors Festival (armed townsfolk at the
; smiths and in the town centre), 11 Merchant's Festival (at the shops), 17 North Wind's Prayer (the temple),
; 13 Harvest's End (inns, then outside), 6 Heart's Day (the inns), 7 First Planting (the temple), 10 Mid Year
; Celebration (the temple, then outside) for anything else
Int Function StyleFor(String asCause) Global
	String c = asCause
	If StringUtil.Find(c, "warrior") >= 0 || StringUtil.Find(c, "tourn") >= 0 || StringUtil.Find(c, "arms") >= 0 || StringUtil.Find(c, "soldier") >= 0 || StringUtil.Find(c, "victory") >= 0
		Return 16
	ElseIf StringUtil.Find(c, "merchant") >= 0 || StringUtil.Find(c, "market") >= 0 || StringUtil.Find(c, "fair") >= 0 || StringUtil.Find(c, "trade") >= 0
		Return 11
	ElseIf StringUtil.Find(c, "prayer") >= 0 || StringUtil.Find(c, "temple") >= 0 || StringUtil.Find(c, "bless") >= 0 || StringUtil.Find(c, "divine") >= 0 || StringUtil.Find(c, "shrine") >= 0 || StringUtil.Find(c, "saint") >= 0
		Return 17
	ElseIf StringUtil.Find(c, "harvest") >= 0 || StringUtil.Find(c, "brew") >= 0 || StringUtil.Find(c, "mead") >= 0 || StringUtil.Find(c, "ale") >= 0
		Return 13
	ElseIf StringUtil.Find(c, "heart") >= 0 || StringUtil.Find(c, "wedding") >= 0 || StringUtil.Find(c, "love") >= 0
		Return 6
	ElseIf StringUtil.Find(c, "plant") >= 0 || StringUtil.Find(c, "sow") >= 0 || StringUtil.Find(c, "seed") >= 0
		Return 7
	EndIf
	Return 10
EndFunction

String Function StyleName(Int aiStyle) Global
	If aiStyle == 16
		Return "a warriors' festival"
	ElseIf aiStyle == 11
		Return "a merchants' festival"
	ElseIf aiStyle == 17
		Return "a festival of prayer"
	ElseIf aiStyle == 13
		Return "a harvest festival"
	ElseIf aiStyle == 6
		Return "a festival of hearts"
	ElseIf aiStyle == 7
		Return "a planting festival"
	EndIf
	Return "a festival"
EndFunction

; an approved festival request: the festival is held tomorrow
Function Schedule(Int aiTown, String asCause) Global
	If aiTown < 0
		Return
	EndIf
	Int style = StyleFor(asCause)
	StorageUtil.SetIntValue(None, "csn_fest_sched_town", aiTown)
	StorageUtil.SetIntValue(None, "csn_fest_sched_day", GameDay() + 1)
	StorageUtil.SetIntValue(None, "csn_fest_sched_style", style)
	StorageUtil.SetStringValue(None, "csn_fest_sched_name", asCause)
	CSN_Gov.Say(CSN_World.TownName(aiTown) + " will hold " + StyleName(style) + " tomorrow.")
	CSN_World.AddNews(aiTown, CSN_World.TownName(aiTown) + " will hold " + StyleName(style) + " tomorrow (" + asCause + "), paid for by " + Game.GetPlayer().GetDisplayName() + ".", "csn_festival")
EndFunction

; once a minute: a scheduled festival begins on its day (and ends when the day does)
Function TickScheduled() Global
	Int d = GameDay()
	Int on = StorageUtil.GetIntValue(None, "csn_fest_on_town", -1)
	If on >= 0 && d != StorageUtil.GetIntValue(None, "csn_fest_on_day", -1)
		; the festival day is over
		HolidaysOff()
		StorageUtil.SetIntValue(None, "csn_fest_on_town", -1)
	EndIf
	Int t = StorageUtil.GetIntValue(None, "csn_fest_sched_town", -1)
	If t < 0 || d < StorageUtil.GetIntValue(None, "csn_fest_sched_day", 0)
		Return
	EndIf
	StorageUtil.SetIntValue(None, "csn_fest_sched_town", -1)
	If !CSN_World.PlayerRules(t)
		Return
	EndIf
	Int style = StorageUtil.GetIntValue(None, "csn_fest_sched_style", 10)
	String cause = StorageUtil.GetStringValue(None, "csn_fest_sched_name", "the festival")
	StorageUtil.SetIntValue(None, "csn_fest_on_town", t)
	StorageUtil.SetIntValue(None, "csn_fest_on_day", d)
	StorageUtil.SetIntValue(None, "csn_fest_on_style", style)
	Quest q = Journal()
	If q && !(q.IsRunning() && q.GetStage() == 10)
		Begin(q, t, StyleName(style) + " (" + cause + ")")
	EndIf
	Watch()
EndFunction

; Every few seconds (CSN_Core): Holidays' festivities for an approved festival run only while you are in its town.
; Holidays' decorations hang off one switch for all of Skyrim and its crowds gather wherever you are, so switching
; its Override on when you walk into the festival town and off when you leave keeps the festival in that town:
; other towns you visit that day stay as they are.
Function Watch() Global
	Int t = StorageUtil.GetIntValue(None, "csn_fest_on_town", -1)
	If t < 0 || !Installed()
		Return
	EndIf
	Actor p = Game.GetPlayer()
	Bool inTown = CSN_World.TownOf(p) == t || p.IsInLocation(CSN_World.TownVanillaLocation(t))
	Bool lit = StorageUtil.GetIntValue(None, "csn_fest_lit", 0) == 1
	If inTown && !lit
		HolidaysOn(StorageUtil.GetIntValue(None, "csn_fest_on_style", 10))
	ElseIf !inTown && lit
		HolidaysOff()
	EndIf
EndFunction

Function HolidaysOn(Int aiStyle) Global
	_holidayquestscript hq = HolidaysQuest()
	If !hq
		Return
	EndIf
	If StorageUtil.GetIntValue(None, "csn_fest_lit", 0) == 0
		StorageUtil.SetIntValue(None, "csn_fest_prev_override", hq.OverrideHoliday)
	EndIf
	hq.OverrideHoliday = aiStyle
	hq.CheckDate()
	StorageUtil.SetIntValue(None, "csn_fest_lit", 1)
	CSN_Config.Log("festival: Holidays override " + aiStyle + " on")
EndFunction

Function HolidaysOff() Global
	If StorageUtil.GetIntValue(None, "csn_fest_lit", 0) == 0
		Return
	EndIf
	StorageUtil.SetIntValue(None, "csn_fest_lit", 0)
	_holidayquestscript hq = HolidaysQuest()
	If hq
		hq.OverrideHoliday = StorageUtil.GetIntValue(None, "csn_fest_prev_override", 0)
		hq.CheckDate()
	EndIf
	CSN_Config.Log("festival: Holidays override off")
EndFunction

; for townsfolk: today's holiday where they live
String Function Knowledge(Actor akActor) Global
	If !Enabled() || !akActor
		Return ""
	EndIf
	String row = Today()
	If row == ""
		Return ""
	EndIf
	String[] f = PapyrusUtil.StringSplit(row, "|")
	Int t = CSN_World.TownOf(akActor)
	If t < 0 || !Celebrates(t, f[3])
		Return ""
	EndIf
	Return " Today is " + f[2] + ", and " + CSN_World.TownName(t) + " is celebrating it."
EndFunction
