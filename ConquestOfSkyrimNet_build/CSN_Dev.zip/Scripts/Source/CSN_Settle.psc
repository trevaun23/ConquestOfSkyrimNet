Scriptname CSN_Settle Hidden
{Conquest of SkyrimNet - settlements (in the spirit of Fallout 4's).

 The unfinished Conquest of Skyrim build has a settlement system, but it sits on a new city economy that 0.3.9 does
 not have (and needs several hundred records plus its own meshes). This is a settlement system of CSN's own built
 on what 0.3.9 and the base game already have, so it works with any save:

   * FOUND a settlement anywhere outdoors in a hold whose city or roads the faction holds (not inside a town, and
     away from other settlements). A banner post marks its heart; it reaches 5,000 units around it.
   * BUILD from a catalogue of base-game buildings (Skyrim.esm / HearthFires.esm): tents, farmhouses, longhouses,
     crop fields, windmills, a lumber mill, smelter, smithy, inn, market stalls, wells, watchtowers, stockade walls
     and more. In build mode the building floats in front of you: walk and turn to move it, arrow keys rotate it and
     bring it closer or push it away, Page Up/Down raise and lower it, Enter or Activate places it, Backspace cancels.
     The cost (gold from the treasury, wood and metal from the faction's supplies) is paid when it is placed.
   * SETTLERS arrive while there are beds and the settlement is content (happiness 40+). They work the buildings.
   * Every day the settlement's food, wood, metal and gold go to the faction's stocks; settlers eat first and pay a
     little tax.
   * RAIDS: bandits come now and then; defence (towers, walls, training) keeps them out. If you are there you fight
     them; if not, the settlement holds or loses a building and some settlers.

 State: StorageUtil, keys "csn_st_*".}

CSN_Core Function M() Global
	Return CSN_Gov.M()
EndFunction

Int Function Today() Global
	Return Utility.GetCurrentGameTime() as Int
EndFunction

Bool Function Enabled() Global
	Return CSN_Config.GetBool("bSettlements:Settlements", True)
EndFunction

Int Function MaxSettlements() Global
	Return 8
EndFunction

Float Function Radius() Global
	Return 5000.0
EndFunction

Int Function FoundGold() Global
	Return CSN_Config.ClampMin(CSN_Config.GetInt("iFoundGold:Settlements", 2000), 0)
EndFunction

Int Function FoundWood() Global
	Return CSN_Config.ClampMin(CSN_Config.GetInt("iFoundWood:Settlements", 40), 0)
EndFunction

; =============================================================================
; CATALOGUE
; name|file|formid|gold|wood|metal|housing|food|wood|metal|gold|happiness|defence|workers|pieces|group
; =============================================================================
Function InitCatalogue() Global
	If StorageUtil.StringListCount(None, "csn_st_cat") == 30 && StorageUtil.GetIntValue(None, "csn_st_catv", 0) == 1
		Return
	EndIf
	StorageUtil.StringListClear(None, "csn_st_cat")
	String[] c = new String[30]
	c[0] = "Tent|S|524510|80|15|0|2|0|0|0|0|0|0|0|1|Homes"
	c[1] = "Bedroll|S|100765|10|3|0|1|0|0|0|0|0|0|0|1|Homes"
	c[2] = "Farmhouse|S|2122|300|40|0|4|0|0|0|0|1|0|0|1|Homes"
	c[3] = "Large farmhouse|S|77947|500|60|5|6|0|0|0|0|2|0|0|1|Homes"
	c[4] = "Longhouse|S|990468|900|100|10|10|0|0|0|0|3|0|0|1|Homes"
	c[5] = "Cabbage field|H|66654|100|5|0|0|2|0|0|0|0|0|2|9|Food"
	c[6] = "Potato field|H|69818|100|5|0|0|2|0|0|0|0|0|2|9|Food"
	c[7] = "Wheat field|H|69837|120|5|0|0|3|0|0|0|0|0|2|9|Food"
	c[8] = "Beehive|S|569146|40|5|0|0|1|0|0|0|0|0|0|1|Food"
	c[9] = "Windmill|S|861782|400|50|5|0|2|0|0|0|1|0|1|1|Food"
	c[10] = "Farm shed|S|725440|150|25|0|0|1|0|0|0|0|0|1|1|Food"
	c[11] = "Lumber mill|S|127488|600|60|10|0|0|4|0|0|0|0|3|1|Industry"
	c[12] = "Chopping block|S|193936|30|5|0|0|0|1|0|0|0|0|1|1|Industry"
	c[13] = "Smelter|S|640718|300|20|10|0|0|0|2|0|0|0|2|1|Industry"
	c[14] = "Smithy|S|102369|500|50|20|0|0|0|1|0|0|2|1|1|Industry"
	c[15] = "Forge|S|830987|250|10|20|0|0|0|0|0|0|1|0|1|Industry"
	c[16] = "Anvil|S|107181|100|0|15|0|0|0|0|0|0|0|0|1|Industry"
	c[17] = "Tanning rack|S|468897|60|10|0|0|0|0|0|0|0|0|0|1|Industry"
	c[18] = "Alchemy lab|S|765196|200|10|5|0|0|0|0|0|1|0|0|1|Industry"
	c[19] = "Arcane enchanter|S|765197|400|10|10|0|0|0|0|0|1|0|0|1|Industry"
	c[20] = "Inn|S|186210|800|80|10|2|0|0|0|30|10|0|2|1|Trade"
	c[21] = "Market stall|S|412551|200|20|0|0|0|0|0|15|2|0|1|1|Trade"
	c[22] = "Well|S|979750|100|10|5|0|0|0|0|0|5|0|0|1|Comfort"
	c[23] = "Campfire|S|220999|10|2|0|0|0|0|0|0|2|0|0|1|Comfort"
	c[24] = "Banner|S|393574|20|2|0|0|0|0|0|0|1|0|0|1|Comfort"
	c[25] = "Watchtower|S|309116|500|60|20|0|0|0|0|0|0|5|1|1|Defense"
	c[26] = "Stockade wall|S|455277|60|15|0|0|0|0|0|0|0|1|0|1|Defense"
	c[27] = "Barricade|S|110104|30|8|0|0|0|0|0|0|0|1|0|1|Defense"
	c[28] = "Training dummy|S|698933|40|5|0|0|0|0|0|0|0|1|0|1|Defense"
	c[29] = "Archery target|S|420598|30|5|0|0|0|0|0|0|0|1|0|1|Defense"
	Int i = 0
	While i < 30
		StorageUtil.StringListAdd(None, "csn_st_cat", c[i])
		i += 1
	EndWhile
	StorageUtil.SetIntValue(None, "csn_st_catv", 1)
EndFunction

Int Function CatCount() Global
	InitCatalogue()
	Return StorageUtil.StringListCount(None, "csn_st_cat")
EndFunction

String[] Function Row(Int t) Global
	InitCatalogue()
	Return PapyrusUtil.StringSplit(StorageUtil.StringListGet(None, "csn_st_cat", t), "|")
EndFunction

Int Function Col(Int t, Int c) Global
	String[] r = Row(t)
	If c < r.Length
		Return r[c] as Int
	EndIf
	Return 0
EndFunction

String Function TypeName(Int t) Global
	String[] r = Row(t)
	Return r[0]
EndFunction

String Function Group(Int t) Global
	String[] r = Row(t)
	If r.Length > 15
		Return r[15]
	EndIf
	Return ""
EndFunction

Form Function Base(Int t) Global
	String[] r = Row(t)
	String file = "Skyrim.esm"
	If r[1] == "H"
		file = "HearthFires.esm"
	EndIf
	Return Game.GetFormFromFile(r[2] as Int, file)
EndFunction

; how far in front of the player the piece floats while placing
Float Function Reach(Int t) Global
	If Col(t, 3) >= 300
		Return 1100.0
	ElseIf Col(t, 14) > 1
		Return 350.0
	EndIf
	Return 250.0
EndFunction

; =============================================================================
; SETTLEMENTS
; =============================================================================
String Function SK(Int k, String asKey) Global
	Return "csn_st_" + k + "_" + asKey
EndFunction

Bool Function Exists(Int k) Global
	Return StorageUtil.GetIntValue(None, SK(k, "on"), 0) == 1
EndFunction

String Function Name(Int k) Global
	Return StorageUtil.GetStringValue(None, SK(k, "name"), "Settlement " + (k + 1))
EndFunction

ObjectReference Function Heart(Int k) Global
	Return StorageUtil.GetFormValue(None, SK(k, "heart")) as ObjectReference
EndFunction

Int Function HoldOf(Int k) Global
	Return StorageUtil.GetIntValue(None, SK(k, "hold"), 0)
EndFunction

Int Function Pop(Int k) Global
	Return StorageUtil.GetIntValue(None, SK(k, "pop"), 0)
EndFunction

Int Function Count() Global
	Int n = 0
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			n += 1
		EndIf
		k += 1
	EndWhile
	Return n
EndFunction

; total of one catalogue column over a settlement's buildings (fields count once, not per plant)
Int Function Sum(Int k, Int c) Global
	Int n = 0
	Int i = 0
	Int count = StorageUtil.IntListCount(None, SK(k, "types"))
	While i < count
		Int t = StorageUtil.IntListGet(None, SK(k, "types"), i)
		If t >= 0
			n += Col(t, c)
		EndIf
		i += 1
	EndWhile
	Return n
EndFunction

Int Function Housing(Int k) Global
	Return Sum(k, 6)
EndFunction

Int Function Jobs(Int k) Global
	Return Sum(k, 13)
EndFunction

Int Function Defense(Int k) Global
	Return Sum(k, 12) + Pop(k) / 4
EndFunction

Int Function Happiness(Int k) Global
	Int h = 50 + Sum(k, 11) + StorageUtil.GetIntValue(None, SK(k, "mood"), 0)
	If Pop(k) > Housing(k)
		h -= 10 * (Pop(k) - Housing(k))
	EndIf
	If FoodNet(k) < 0
		h -= 15
	EndIf
	If h < 0
		h = 0
	ElseIf h > 100
		h = 100
	EndIf
	Return h
EndFunction

; share of jobs filled (0-100)
Int Function Staffed(Int k) Global
	Int j = Jobs(k)
	If j <= 0
		Return 100
	EndIf
	Int p = Pop(k)
	If p >= j
		Return 100
	EndIf
	Return p * 100 / j
EndFunction

; output of buildings that need workers scales with staffing; the rest always produce
Int Function Output(Int k, Int c) Global
	Int full = 0
	Int part = 0
	Int i = 0
	Int count = StorageUtil.IntListCount(None, SK(k, "types"))
	While i < count
		Int t = StorageUtil.IntListGet(None, SK(k, "types"), i)
		If t >= 0
			If Col(t, 13) > 0
				part += Col(t, c)
			Else
				full += Col(t, c)
			EndIf
		EndIf
		i += 1
	EndWhile
	Return full + part * Staffed(k) / 100
EndFunction

; food after the settlers have eaten (one for every two settlers)
Int Function FoodNet(Int k) Global
	Return Output(k, 7) - (Pop(k) + 1) / 2
EndFunction

Int Function GoldDay(Int k) Global
	Return Output(k, 10) + Pop(k) * 2
EndFunction

; ---- map markers: one spare persistent marker per slot in the plugin (CSN_SettlementMarker1-8) ----
ObjectReference Function Marker(Int k) Global
	Return Game.GetFormFromFile(0xD3D887 + k, "ConquestOfSkyrimNet.esp") as ObjectReference
EndFunction

; puts the slot's marker at the settlement, on the map (fast travel allowed) and named after it
Function ShowMarker(Int k) Global
	ObjectReference mk = Marker(k)
	ObjectReference h = Heart(k)
	If !mk || !h
		Return
	EndIf
	If StorageUtil.GetIntValue(None, SK(k, "marker"), 0) != 1
		mk.MoveTo(h, 0.0, 0.0, 0.0, False)
		mk.Enable()
		StorageUtil.SetIntValue(None, SK(k, "marker"), 1)
	ElseIf mk.IsDisabled()
		mk.Enable()
	EndIf
	mk.AddToMap(True)
	If !CSN_Native.SetMapMarkerName(mk, Name(k))
		CSN_Config.Log("settlement " + k + ": could not name its map marker")
	EndIf
EndFunction

Function HideMarker(Int k) Global
	ObjectReference mk = Marker(k)
	If mk
		mk.Disable()
	EndIf
	StorageUtil.SetIntValue(None, SK(k, "marker"), 0)
EndFunction

; every game load: marker names aren't kept in the save; settlements founded before markers existed get theirs
Function OnLoad() Global
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			ShowMarker(k)
		EndIf
		k += 1
	EndWhile
EndFunction

Int Function FreeSlot() Global
	Int k = 0
	While k < MaxSettlements()
		If !Exists(k)
			Return k
		EndIf
		k += 1
	EndWhile
	Return -1
EndFunction

; the settlement the player stands in (-1 none)
Int Function Here() Global
	Actor p = Game.GetPlayer()
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			ObjectReference h = Heart(k)
			If h && h.GetWorldSpace() == p.GetWorldSpace() && p.GetDistance(h) <= Radius()
				Return k
			EndIf
		EndIf
		k += 1
	EndWhile
	Return -1
EndFunction

; the hold the player is in (-1 none): from the current location (the hold is its parent), or, out in wild land that
; has no location, the hold whose city or fort is nearest
Int Function PlayerHold() Global
	CSN_Core m = M()
	Actor p = Game.GetPlayer()
	Location here = p.GetCurrentLocation()
	Int h = 0
	While h < m.HoldCount()
		Location hl = m.Gov.AllHolds.GetAt(h) as Location
		If here && hl && (here == hl || hl.IsChild(here))
			Return h
		EndIf
		h += 1
	EndWhile
	If p.IsInInterior()
		Return -1
	EndIf
	FormList cityMarkers = Game.GetFormFromFile(0x0342C8, "ConquestOfSkyrimNet.esp") as FormList   ; CS_MapMarkers
	FormList fortMarkers = Game.GetFormFromFile(0x1E4541, "ConquestOfSkyrimNet.esp") as FormList   ; CS_AllFortMarkersPlayer
	Int best = -1
	Float bestDist = 0.0
	h = 0
	While h < 9
		ObjectReference[] marks = new ObjectReference[2]
		If cityMarkers && h < cityMarkers.GetSize()
			marks[0] = cityMarkers.GetAt(h) as ObjectReference
		EndIf
		If fortMarkers && h < fortMarkers.GetSize()
			marks[1] = fortMarkers.GetAt(h) as ObjectReference
		EndIf
		Int k = 0
		While k < 2
			ObjectReference r = marks[k]
			If r && r.GetWorldSpace() == p.GetWorldSpace()
				Float d = p.GetDistance(r)
				If best < 0 || d < bestDist
					best = h
					bestDist = d
				EndIf
			EndIf
			k += 1
		EndWhile
		h += 1
	EndWhile
	Return best
EndFunction

; why a settlement can't be founded where the player stands ("" when it can)
String Function FoundBlock() Global
	CSN_Core m = M()
	Actor p = Game.GetPlayer()
	If !Enabled()
		Return "Settlements are turned off in the MCM."
	ElseIf m.FactionStarted.GetValue() < 1
		Return "Found your faction first."
	ElseIf FreeSlot() < 0
		Return "The faction already has " + MaxSettlements() + " settlements."
	ElseIf p.IsInInterior()
		Return "Settlements are founded outdoors."
	EndIf
	Int h = PlayerHold()
	If h < 0
		Return "You are not inside any hold."
	EndIf
	If !m.OwnsHold(h) && CSN_Gov.RoadsSide(h) != 1
		Return "Your faction must hold " + m.HoldName(h) + "'s city or its roads to settle here."
	EndIf
	If CSN_World.TownOfLocation(p.GetCurrentLocation()) >= 0
		Return "This is already a town. Find open land."
	EndIf
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			ObjectReference hr = Heart(k)
			If hr && hr.GetWorldSpace() == p.GetWorldSpace() && p.GetDistance(hr) < Radius() * 2.0
				Return "Too close to " + Name(k) + "."
			EndIf
		EndIf
		k += 1
	EndWhile
	Return ""
EndFunction

Bool Function Found(Actor akVia = None) Global
	CSN_Core m = M()
	String err = FoundBlock()
	If err != ""
		CSN_Gov.Fail(err)
		Return False
	EndIf
	Int h = PlayerHold()
	If !CSNP.Confirm("Found a settlement", "Found a settlement here in " + m.HoldName(h) + "?\n\nCosts " + FoundGold() + " gold from the treasury (" + CSN_Gov.Treasury() + ") and " + FoundWood() + " wood (" + CSN_Gov.Stock(2) + "). A banner post marks its heart; you can build within about 70 paces of it.", "Found it", "Not here")
		Return False
	EndIf
	If CSN_Gov.Treasury() < FoundGold()
		CSN_Gov.Fail("The treasury holds " + CSN_Gov.Treasury() + " gold; " + FoundGold() + " needed.")
		Return False
	EndIf
	If !CSN_Gov.Spend(2, FoundWood())
		Return False
	EndIf
	String nm = CSNP.TextInput("Name the settlement", "")
	If nm == ""
		nm = "New " + m.HoldName(h)
	EndIf
	m.Econ().Treasury.Mod(-FoundGold())
	Int k = FreeSlot()
	Actor p = Game.GetPlayer()
	Form post = Game.GetFormFromFile(0x1083d7, "Skyrim.esm")   ; FarmBannerPost01
	ObjectReference heart = p.PlaceAtMe(post, 1, True, False)
	heart.SetAngle(0.0, 0.0, p.GetAngleZ())
	StorageUtil.SetIntValue(None, SK(k, "on"), 1)
	StorageUtil.SetStringValue(None, SK(k, "name"), nm)
	StorageUtil.SetFormValue(None, SK(k, "heart"), heart)
	StorageUtil.SetIntValue(None, SK(k, "hold"), h)
	StorageUtil.SetIntValue(None, SK(k, "pop"), 0)
	StorageUtil.SetIntValue(None, SK(k, "mood"), 0)
	StorageUtil.SetIntValue(None, SK(k, "since"), Today())
	StorageUtil.FormListClear(None, SK(k, "refs"))
	StorageUtil.IntListClear(None, SK(k, "types"))
	StorageUtil.FormListClear(None, SK(k, "people"))
	StorageUtil.SetIntValue(None, SK(k, "marker"), 0)
	ShowMarker(k)
	String txt = Game.GetPlayer().GetDisplayName() + " founded " + nm + ", a new settlement of the " + m.FactionName() + " in " + m.HoldName(h) + "."
	CSN_World.AddNews(-1, txt, "csn_settlement_founded", akVia)
	CSN_Gov.Say(nm + " is founded and on your map. Build homes so settlers can come.")
	m.Refresh()
	Return True
EndFunction

Bool Function Rename(Int k) Global
	If !Exists(k)
		Return False
	EndIf
	String nm = CSNP.TextInput("Rename " + Name(k), Name(k))
	If nm == "" || nm == Name(k)
		Return False
	EndIf
	StorageUtil.SetStringValue(None, SK(k, "name"), nm)
	ShowMarker(k)
	M().Refresh()
	Return True
EndFunction

Bool Function Abandon(Int k) Global
	If !Exists(k)
		Return False
	EndIf
	If !CSNP.Confirm("Abandon " + Name(k), "Abandon " + Name(k) + "? Every building is taken down and the settlers leave. Nothing is refunded.", "Abandon it", "Keep it")
		Return False
	EndIf
	Int i = StorageUtil.FormListCount(None, SK(k, "refs")) - 1
	While i >= 0
		ObjectReference r = StorageUtil.FormListGet(None, SK(k, "refs"), i) as ObjectReference
		If r
			r.Disable()
			r.Delete()
		EndIf
		i -= 1
	EndWhile
	i = StorageUtil.FormListCount(None, SK(k, "people")) - 1
	While i >= 0
		Actor a = StorageUtil.FormListGet(None, SK(k, "people"), i) as Actor
		If a
			a.Disable()
			a.Delete()
		EndIf
		i -= 1
	EndWhile
	ObjectReference h = Heart(k)
	If h
		h.Disable()
		h.Delete()
	EndIf
	String nm = Name(k)
	StorageUtil.FormListClear(None, SK(k, "refs"))
	StorageUtil.IntListClear(None, SK(k, "types"))
	StorageUtil.FormListClear(None, SK(k, "people"))
	HideMarker(k)
	StorageUtil.SetIntValue(None, SK(k, "on"), 0)
	CSN_World.AddNews(-1, nm + " was abandoned.", "csn_settlement_abandoned")
	M().Refresh()
	Return True
EndFunction

; =============================================================================
; BUILD MODE
; =============================================================================
Bool Function Placing() Global
	Return StorageUtil.GetIntValue(None, "csn_st_placing", 0) == 1
EndFunction

; the build menu: pick a group, then a building (used by the screen and by conversation)
Function BuildMenu(Int k) Global
	If !Exists(k)
		k = Here()
	EndIf
	If k < 0
		CSN_Gov.Fail("Stand inside one of your settlements to build.")
		Return
	EndIf
	String[] groups = new String[7]
	groups[0] = "Homes"
	groups[1] = "Food"
	groups[2] = "Industry"
	groups[3] = "Trade"
	groups[4] = "Comfort"
	groups[5] = "Defense"
	groups[6] = "Close"
	Int g = CSNP.Choose("Build in " + Name(k), "Treasury " + CSN_Gov.Treasury() + " gold · wood " + CSN_Gov.Stock(2) + " · metal " + CSN_Gov.Stock(1) + "\n" + SummaryText(k), groups)
	If g < 0 || g >= 6
		Return
	EndIf
	Int[] ids = PapyrusUtil.IntArray(0)
	String[] labels = PapyrusUtil.StringArray(0)
	Int t = 0
	While t < CatCount()
		If Group(t) == groups[g]
			ids = PapyrusUtil.PushInt(ids, t)
			labels = PapyrusUtil.PushString(labels, TypeName(t) + " - " + CostText(t) + " - " + GivesText(t))
		EndIf
		t += 1
	EndWhile
	labels = PapyrusUtil.PushString(labels, "Back")
	Int pick = CSNP.Choose(groups[g], "Choose what to build. You place it yourself; it is paid for when placed.", labels)
	If pick < 0 || pick >= ids.Length
		BuildMenu(k)
		Return
	EndIf
	Build(k, ids[pick])
EndFunction

String Function CostText(Int t) Global
	String s = Col(t, 3) + " gold"
	If Col(t, 4) > 0
		s += ", " + Col(t, 4) + " wood"
	EndIf
	If Col(t, 5) > 0
		s += ", " + Col(t, 5) + " metal"
	EndIf
	Return s
EndFunction

String Function GivesText(Int t) Global
	String s = ""
	If Col(t, 6) > 0
		s = CSN_Rebellion.AddTo(s, "beds " + Col(t, 6))
	EndIf
	If Col(t, 7) > 0
		s = CSN_Rebellion.AddTo(s, "food +" + Col(t, 7))
	EndIf
	If Col(t, 8) > 0
		s = CSN_Rebellion.AddTo(s, "wood +" + Col(t, 8))
	EndIf
	If Col(t, 9) > 0
		s = CSN_Rebellion.AddTo(s, "metal +" + Col(t, 9))
	EndIf
	If Col(t, 10) > 0
		s = CSN_Rebellion.AddTo(s, "gold +" + Col(t, 10))
	EndIf
	If Col(t, 11) > 0
		s = CSN_Rebellion.AddTo(s, "happiness +" + Col(t, 11))
	EndIf
	If Col(t, 12) > 0
		s = CSN_Rebellion.AddTo(s, "defence +" + Col(t, 12))
	EndIf
	If Col(t, 13) > 0
		s = CSN_Rebellion.AddTo(s, Col(t, 13) + " workers")
	EndIf
	If s == ""
		s = "a crafting station"
	EndIf
	Return s
EndFunction

String Function AffordBlock(Int t) Global
	If CSN_Gov.Treasury() < Col(t, 3)
		Return "The treasury holds " + CSN_Gov.Treasury() + " gold; " + Col(t, 3) + " needed."
	ElseIf CSN_Gov.Stock(2) < Col(t, 4)
		Return "The faction has " + CSN_Gov.Stock(2) + " wood; " + Col(t, 4) + " needed."
	ElseIf CSN_Gov.Stock(1) < Col(t, 5)
		Return "The faction has " + CSN_Gov.Stock(1) + " metal; " + Col(t, 5) + " needed."
	EndIf
	Return ""
EndFunction

Bool Function Build(Int k, Int t) Global
	CSN_Core m = M()
	If !Exists(k) || t < 0 || t >= CatCount()
		Return False
	EndIf
	If Placing()
		CSN_Gov.Fail("You are already placing something.")
		Return False
	EndIf
	String err = AffordBlock(t)
	If err != ""
		CSN_Gov.Fail(err)
		Return False
	EndIf
	Form b = Base(t)
	If !b
		CSN_Gov.Fail("That building's base object is missing from your game.")
		Return False
	EndIf
	ObjectReference h = Heart(k)
	Actor p = Game.GetPlayer()
	If !h || h.GetWorldSpace() != p.GetWorldSpace() || p.GetDistance(h) > Radius()
		CSN_Gov.Fail("Go to " + Name(k) + " to build there.")
		Return False
	EndIf
	m.CloseScreen()
	Utility.Wait(0.3)
	; the controls first (keys only start counting once this box is closed, so closing it doesn't place anything)
	String[] go = new String[2]
	go[0] = "Start placing"
	go[1] = "Cancel"
	If CSNP.Choose("Placing: " + TypeName(t), ControlsText() + "\n\nCost when placed: " + CostText(t) + ".", go) != 0
		Return False
	EndIf
	ObjectReference ghost = p.PlaceAtMe(b, 1, True, False)
	StorageUtil.SetFormValue(None, "csn_st_ghost", ghost)
	StorageUtil.SetIntValue(None, "csn_st_placing", 1)
	StorageUtil.SetIntValue(None, "csn_st_pk", k)
	StorageUtil.SetIntValue(None, "csn_st_pt", t)
	StorageUtil.SetFloatValue(None, "csn_st_dist", Reach(t))
	StorageUtil.SetFloatValue(None, "csn_st_rot", 180.0)
	StorageUtil.SetFloatValue(None, "csn_st_z", 0.0)
	m.PlacementKeys(True)
	PlaceLoop()
	Return True
EndFunction

String Function ControlsText() Global
	Return "The building floats in front of you, outlined so it is easy to see.\n\n- Move it: walk, and turn to aim it.\n- Rotate: Left / Right arrow (15 degrees a press).\n- Nearer / farther: Down / Up arrow.\n- Lower / raise: Page Down / Page Up.\n- Place it: Enter, or your Activate key.\n- Cancel: Backspace.\n\nIt has to stay within about 70 paces of the settlement's banner post."
EndFunction

String Function ControlsShort() Global
	Return "Placing: arrows rotate / nearer-farther, PgUp/PgDn height, Enter or Activate place, Backspace cancel"
EndFunction

; Moves the building smoothly (TranslateTo) and only when where it should be has changed: setting its position
; every frame reloaded its 3D, which made it flash and fade.
Function PlaceLoop() Global
	Actor p = Game.GetPlayer()
	ObjectReference ghost = StorageUtil.GetFormValue(None, "csn_st_ghost") as ObjectReference
	Int k = StorageUtil.GetIntValue(None, "csn_st_pk", 0)
	ObjectReference h = Heart(k)
	EffectShader glow = Game.GetFormFromFile(0x000146, "Skyrim.esm") as EffectShader   ; LifeDetected: a bright edge, not see-through
	Bool warned = False
	Float lx = 0.0
	Float ly = 0.0
	Float lz = 0.0
	Float la = -999.0
	Float lastTip = Utility.GetCurrentRealTime()
	Bool first = True
	If ghost && glow
		glow.Play(ghost, -1.0)
	EndIf
	Debug.Notification(ControlsShort())
	While Placing() && ghost
		Float az = p.GetAngleZ()
		Float d = StorageUtil.GetFloatValue(None, "csn_st_dist", 300.0)
		Float x = p.GetPositionX() + d * Math.Sin(az)
		Float y = p.GetPositionY() + d * Math.Cos(az)
		Float z = p.GetPositionZ() + StorageUtil.GetFloatValue(None, "csn_st_z", 0.0)
		Float ang = az + StorageUtil.GetFloatValue(None, "csn_st_rot", 180.0)
		If first
			ghost.SetPosition(x, y, z)
			ghost.SetAngle(0.0, 0.0, ang)
			first = False
		ElseIf Math.Abs(x - lx) > 6.0 || Math.Abs(y - ly) > 6.0 || Math.Abs(z - lz) > 4.0 || Math.Abs(ang - la) > 0.5
			ghost.TranslateTo(x, y, z, 0.0, 0.0, ang, 3000.0, 720.0)
		EndIf
		lx = x
		ly = y
		lz = z
		la = ang
		If h && ghost.GetDistance(h) > Radius()
			If !warned
				Debug.Notification("Outside " + Name(k) + ": move closer to place it.")
				warned = True
			EndIf
		Else
			warned = False
		EndIf
		If Utility.GetCurrentRealTime() - lastTip > 12.0
			Debug.Notification(ControlsShort())
			lastTip = Utility.GetCurrentRealTime()
		EndIf
		Utility.Wait(0.1)
	EndWhile
	If ghost
		ghost.StopTranslation()
		If glow
			glow.Stop(ghost)
		EndIf
		; settle it exactly where it was aimed
		ghost.SetPosition(lx, ly, lz)
		ghost.SetAngle(0.0, 0.0, la)
	EndIf
	Int result = StorageUtil.GetIntValue(None, "csn_st_placing", 0)
	StorageUtil.SetIntValue(None, "csn_st_placing", 0)
	M().PlacementKeys(False)
	If result == 2 && ghost && h && ghost.GetDistance(h) <= Radius()
		Place(k, StorageUtil.GetIntValue(None, "csn_st_pt", 0), ghost)
	Else
		If result == 2
			Debug.Notification("Too far from " + Name(k) + ": not placed.")
		Else
			Debug.Notification("Building cancelled.")
		EndIf
		If ghost
			ghost.Disable()
			ghost.Delete()
		EndIf
	EndIf
	StorageUtil.UnsetFormValue(None, "csn_st_ghost")
EndFunction

; keys while placing (forwarded by CSN_Core)
Function PlaceKey(Int aiCode) Global
	If !Placing()
		Return
	EndIf
	If aiCode == 28 || aiCode == 156 || aiCode == Input.GetMappedKey("Activate")
		StorageUtil.SetIntValue(None, "csn_st_placing", 2)
	ElseIf aiCode == 14
		StorageUtil.SetIntValue(None, "csn_st_placing", 3)
	ElseIf aiCode == 203
		StorageUtil.AdjustFloatValue(None, "csn_st_rot", -15.0)
	ElseIf aiCode == 205
		StorageUtil.AdjustFloatValue(None, "csn_st_rot", 15.0)
	ElseIf aiCode == 200
		StorageUtil.AdjustFloatValue(None, "csn_st_dist", 100.0)
	ElseIf aiCode == 208
		If StorageUtil.GetFloatValue(None, "csn_st_dist", 300.0) > 150.0
			StorageUtil.AdjustFloatValue(None, "csn_st_dist", -100.0)
		EndIf
	ElseIf aiCode == 201
		StorageUtil.AdjustFloatValue(None, "csn_st_z", 20.0)
	ElseIf aiCode == 209
		StorageUtil.AdjustFloatValue(None, "csn_st_z", -20.0)
	EndIf
EndFunction

Function Place(Int k, Int t, ObjectReference akGhost) Global
	CSN_Core m = M()
	String err = AffordBlock(t)
	If err != ""
		CSN_Gov.Fail(err)
		akGhost.Disable()
		akGhost.Delete()
		Return
	EndIf
	m.Econ().Treasury.Mod(-Col(t, 3))
	CSN_Gov.Spend(2, Col(t, 4))
	CSN_Gov.Spend(1, Col(t, 5))
	; refresh collision where it now stands
	akGhost.Disable()
	akGhost.Enable()
	StorageUtil.FormListAdd(None, SK(k, "refs"), akGhost)
	StorageUtil.IntListAdd(None, SK(k, "types"), t)
	; a field: eight more plants around the first, in a square
	Int pieces = Col(t, 14)
	If pieces > 1
		Form b = Base(t)
		Float a = akGhost.GetAngleZ()
		Int n = 1
		Int row = -1
		While row <= 1
			Int col = -1
			While col <= 1
				If row != 0 || col != 0
					Float ox = (col * 90.0) * Math.Cos(a) + (row * 90.0) * Math.Sin(a)
					Float oy = (row * 90.0) * Math.Cos(a) - (col * 90.0) * Math.Sin(a)
					ObjectReference pl = akGhost.PlaceAtMe(b, 1, True, False)
					pl.SetPosition(akGhost.GetPositionX() + ox, akGhost.GetPositionY() + oy, akGhost.GetPositionZ())
					StorageUtil.FormListAdd(None, SK(k, "refs"), pl)
					StorageUtil.IntListAdd(None, SK(k, "types"), -1)   ; part of the field above
					n += 1
				EndIf
				col += 1
			EndWhile
			row += 1
		EndWhile
	EndIf
	CSN_Gov.Say(TypeName(t) + " built in " + Name(k) + ".")
	CSN_SkyrimNet.LogEvent(Game.GetPlayer().GetDisplayName() + " built a " + TypeName(t) + " in the settlement of " + Name(k) + ".", None, Game.GetPlayer())
EndFunction

; list of a settlement's buildings for removal: "index|name" (fields count as one)
Bool Function RemoveMenu(Int k) Global
	If !Exists(k)
		Return False
	EndIf
	Int[] at = PapyrusUtil.IntArray(0)
	String[] labels = PapyrusUtil.StringArray(0)
	Int i = 0
	Int count = StorageUtil.IntListCount(None, SK(k, "types"))
	While i < count
		Int t = StorageUtil.IntListGet(None, SK(k, "types"), i)
		If t >= 0
			at = PapyrusUtil.PushInt(at, i)
			ObjectReference r = StorageUtil.FormListGet(None, SK(k, "refs"), i) as ObjectReference
			String dist = ""
			If r && r.Is3DLoaded()
				dist = " (" + ((Game.GetPlayer().GetDistance(r) / 70.0) as Int) + " paces away)"
			EndIf
			labels = PapyrusUtil.PushString(labels, TypeName(t) + dist)
		EndIf
		i += 1
	EndWhile
	If at.Length == 0
		CSN_Gov.Fail(Name(k) + " has no buildings yet.")
		Return False
	EndIf
	labels = PapyrusUtil.PushString(labels, "Cancel")
	Int pick = CSNP.Choose("Take down a building", "Half of its gold, wood and metal comes back.", labels)
	If pick < 0 || pick >= at.Length
		Return False
	EndIf
	RemoveAt(k, at[pick])
	M().Refresh()
	Return True
EndFunction

Function RemoveAt(Int k, Int aiIndex) Global
	CSN_Core m = M()
	Int t = StorageUtil.IntListGet(None, SK(k, "types"), aiIndex)
	Int pieces = 1
	If t >= 0
		pieces = Col(t, 14)
		m.Econ().Treasury.Mod(Col(t, 3) / 2)
		m.Gov.EconUpdater.WoodTotalPlayer.Mod(Col(t, 4) / 2)
		m.Gov.EconUpdater.MetalTotalPlayer.Mod(Col(t, 5) / 2)
	EndIf
	Int n = 0
	While n < pieces
		ObjectReference r = StorageUtil.FormListGet(None, SK(k, "refs"), aiIndex) as ObjectReference
		If r
			r.Disable()
			r.Delete()
		EndIf
		StorageUtil.FormListRemoveAt(None, SK(k, "refs"), aiIndex)
		StorageUtil.IntListRemoveAt(None, SK(k, "types"), aiIndex)
		n += 1
	EndWhile
	If t >= 0
		CSN_Gov.Say(TypeName(t) + " taken down in " + Name(k) + ".")
	EndIf
EndFunction

; =============================================================================
; DAILY LIFE
; =============================================================================
Function Tick() Global
	If Count() <= 0
		Return
	EndIf
	Int d = Today()
	If StorageUtil.GetIntValue(None, "csn_st_day", -1) == d
		Return
	EndIf
	StorageUtil.SetIntValue(None, "csn_st_day", d)
	CSN_Core m = M()
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			Daily(k)
		EndIf
		k += 1
	EndWhile
	m.Gov.EconUpdater.CalculatePlayerPerDay()
EndFunction

Function Daily(Int k) Global
	CSN_Core m = M()
	; mood from events fades by a third each day
	Int mood = StorageUtil.GetIntValue(None, SK(k, "mood"), 0)
	StorageUtil.SetIntValue(None, SK(k, "mood"), mood * 2 / 3)
	Int happy = Happiness(k)
	Int pop = Pop(k)
	Int beds = Housing(k)
	; settlers come while there are beds and people are content; they leave when unhappy
	If pop < beds && happy >= 40
		Int n = 1
		If happy >= 70 && beds - pop >= 2
			n = 2
		EndIf
		Arrive(k, n)
	ElseIf happy < 25 && pop > 0
		Leave(k, 1)
		CSN_Gov.Say("A family left " + Name(k) + ": people there are unhappy.")
	EndIf
	; production to the faction's stocks
	Int food = FoodNet(k)
	Int wood = Output(k, 8)
	Int metal = Output(k, 9)
	Int gold = GoldDay(k)
	m.Holdings().FoodReserve.Mod(food)
	m.Gov.EconUpdater.WoodTotalPlayer.Mod(wood)
	m.Gov.EconUpdater.MetalTotalPlayer.Mod(metal)
	m.Econ().Treasury.Mod(gold)
	StorageUtil.SetStringValue(None, SK(k, "last"), "food " + Signed(food) + ", wood +" + wood + ", metal +" + metal + ", gold +" + gold)
	; raids
	Int chance = RaidChance(k)
	If chance > 0 && Utility.RandomInt(1, 100) <= chance
		Raid(k)
	EndIf
EndFunction

; daily chance (%) of a bandit raid: 10, minus the defence, plus 1 for every 10 happiness under 50; at least 2 once
; anything is built; none within 3 days of the last raid
Int Function RaidChance(Int k) Global
	If Pop(k) <= 0 && StorageUtil.IntListCount(None, SK(k, "types")) == 0
		Return 0
	EndIf
	If Today() - StorageUtil.GetIntValue(None, SK(k, "raid"), -10) < 3
		Return 0
	EndIf
	Int chance = 10 - Defense(k) + (50 - Happiness(k)) / 10
	If chance < 2
		chance = 2
	EndIf
	Return chance
EndFunction

String Function Signed(Int n) Global
	If n >= 0
		Return "+" + n
	EndIf
	Return "" + n
EndFunction

Function Arrive(Int k, Int n) Global
	StorageUtil.AdjustIntValue(None, SK(k, "pop"), n)
	; a few settlers are there to see (up to eight), the rest are counted
	Int shown = StorageUtil.FormListCount(None, SK(k, "people"))
	ObjectReference h = Heart(k)
	Int i = 0
	While i < n && shown < 8 && h
		Int pick = Utility.RandomInt(0, 2)
		Int id = 0x1034e4      ; WEFarmerMale
		If pick == 1
			id = 0x1034e6      ; WEFarmerFemale
		ElseIf pick == 2
			id = 0x106a61      ; WEFarmerMale02
		EndIf
		ActorBase b = Game.GetFormFromFile(id, "Skyrim.esm") as ActorBase
		If b
			Actor a = h.PlaceActorAtMe(b)
			StorageUtil.SetIntValue(a, "csn_settler", k + 1)
			StorageUtil.FormListAdd(None, SK(k, "people"), a)
			shown += 1
		EndIf
		i += 1
	EndWhile
	If n > 0
		CSN_Gov.Say(n + " settler(s) arrived in " + Name(k) + ".")
	EndIf
EndFunction

Function Leave(Int k, Int n) Global
	Int pop = Pop(k) - n
	If pop < 0
		pop = 0
	EndIf
	StorageUtil.SetIntValue(None, SK(k, "pop"), pop)
	While StorageUtil.FormListCount(None, SK(k, "people")) > pop
		Int last = StorageUtil.FormListCount(None, SK(k, "people")) - 1
		Actor a = StorageUtil.FormListGet(None, SK(k, "people"), last) as Actor
		If a && !a.Is3DLoaded()
			a.Disable()
			a.Delete()
		EndIf
		StorageUtil.FormListRemoveAt(None, SK(k, "people"), last)
	EndWhile
EndFunction

Function Raid(Int k) Global
	StorageUtil.SetIntValue(None, SK(k, "raid"), Today())
	String nm = Name(k)
	Int bandits = 3 + Utility.RandomInt(0, 4)
	If Here() == k
		; the player is there: a real fight
		ObjectReference h = Heart(k)
		ActorBase melee = Game.GetFormFromFile(0x01af77, "Skyrim.esm") as ActorBase   ; LvlBanditMeleeCommonerM
		ActorBase bow = Game.GetFormFromFile(0x01b0be, "Skyrim.esm") as ActorBase     ; LvlBanditMissileCommonerM
		Int i = 0
		While i < bandits
			ActorBase b = melee
			If i % 3 == 2
				b = bow
			EndIf
			Actor r = h.PlaceActorAtMe(b)
			r.MoveTo(h, 2500.0 * Math.Sin(i * 60.0), 2500.0 * Math.Cos(i * 60.0), 0.0)
			r.StartCombat(Game.GetPlayer())
			i += 1
		EndWhile
		CSNP.Notice("Bandits are raiding " + nm + "!")
		StorageUtil.AdjustIntValue(None, SK(k, "mood"), 5)
		Return
	EndIf
	Int def = Defense(k)
	If def * 3 + Utility.RandomInt(0, 10) >= bandits * 4
		StorageUtil.AdjustIntValue(None, SK(k, "mood"), 8)
		CSN_Gov.Say("Bandits attacked " + nm + " and were driven off.")
		CSN_World.AddNews(-1, "The settlers of " + nm + " drove off a bandit raid.", "csn_settlement_raid")
		Return
	EndIf
	; lost: a building burns and some settlers flee
	Int count = StorageUtil.IntListCount(None, SK(k, "types"))
	String lost = ""
	If count > 0
		Int tries = 0
		While tries < 6 && lost == ""
			Int at = Utility.RandomInt(0, count - 1)
			Int t = StorageUtil.IntListGet(None, SK(k, "types"), at)
			If t >= 0
				lost = TypeName(t)
				RemoveBurnt(k, at, t)
			EndIf
			tries += 1
		EndWhile
	EndIf
	Leave(k, 2)
	StorageUtil.AdjustIntValue(None, SK(k, "mood"), -15)
	String txt = "Bandits raided " + nm + "."
	If lost != ""
		txt += " The " + lost + " was burnt down."
	EndIf
	txt += " Build watchtowers and walls to keep them out."
	CSN_Gov.Say(txt)
	CSN_World.AddNews(-1, "Bandits raided the settlement of " + nm + ".", "csn_settlement_raid")
EndFunction

Function RemoveBurnt(Int k, Int aiIndex, Int t) Global
	Int pieces = Col(t, 14)
	Int n = 0
	While n < pieces
		ObjectReference r = StorageUtil.FormListGet(None, SK(k, "refs"), aiIndex) as ObjectReference
		If r
			r.Disable()
			r.Delete()
		EndIf
		StorageUtil.FormListRemoveAt(None, SK(k, "refs"), aiIndex)
		StorageUtil.IntListRemoveAt(None, SK(k, "types"), aiIndex)
		n += 1
	EndWhile
EndFunction

; every 5 seconds: settlers who wandered off are brought home while nobody is looking
Function Watch() Global
	If Count() <= 0
		Return
	EndIf
	Int k = Here()
	If k < 0
		Return
	EndIf
	ObjectReference h = Heart(k)
	Int i = StorageUtil.FormListCount(None, SK(k, "people")) - 1
	While i >= 0
		Actor a = StorageUtil.FormListGet(None, SK(k, "people"), i) as Actor
		If a && !a.IsDead() && a.GetDistance(h) > Radius() && !Game.GetPlayer().HasLOS(a)
			a.MoveTo(h, Utility.RandomFloat(-600.0, 600.0), Utility.RandomFloat(-600.0, 600.0), 0.0)
		ElseIf a && a.IsDead()
			StorageUtil.FormListRemoveAt(None, SK(k, "people"), i)
			StorageUtil.AdjustIntValue(None, SK(k, "pop"), -1)
		EndIf
		i -= 1
	EndWhile
EndFunction

; =============================================================================
; TEXT FOR THE SCREENS AND SKYRIMNET
; =============================================================================
String Function SummaryText(Int k) Global
	Return "Settlers " + Pop(k) + "/" + Housing(k) + " beds · happiness " + Happiness(k) + " · defence " + Defense(k) + " · jobs " + Jobs(k) + " (" + Staffed(k) + "% filled)"
EndFunction

String Function Json() Global
	CSN_Core m = M()
	String s = "{\"on\":" + m.B(Enabled()) + ",\"here\":" + Here() + ",\"block\":" + m.Q(FoundBlock()) + ",\"gold\":" + FoundGold() + ",\"wood\":" + FoundWood() + ",\"list\":["
	Bool first = True
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			If !first
				s += ","
			EndIf
			first = False
			s += "{\"k\":" + k + ",\"name\":" + m.Q(Name(k)) + ",\"hold\":" + m.Q(m.HoldName(HoldOf(k))) + ",\"pop\":" + Pop(k) + ",\"beds\":" + Housing(k)
			s += ",\"happy\":" + Happiness(k) + ",\"def\":" + Defense(k) + ",\"jobs\":" + Jobs(k) + ",\"staffed\":" + Staffed(k)
			s += ",\"food\":" + FoodNet(k) + ",\"woodDay\":" + Output(k, 8) + ",\"metalDay\":" + Output(k, 9) + ",\"goldDay\":" + GoldDay(k)
			s += ",\"buildings\":" + m.Q(BuildingsText(k)) + "}"
		EndIf
		k += 1
	EndWhile
	Return s + "]}"
EndFunction

String Function BuildingsText(Int k) Global
	Int[] counts = Utility.CreateIntArray(CatCount())
	Int i = 0
	Int n = StorageUtil.IntListCount(None, SK(k, "types"))
	While i < n
		Int t = StorageUtil.IntListGet(None, SK(k, "types"), i)
		If t >= 0
			counts[t] = counts[t] + 1
		EndIf
		i += 1
	EndWhile
	String s = ""
	Int t2 = 0
	While t2 < counts.Length
		If counts[t2] > 0
			String part = TypeName(t2)
			If counts[t2] > 1
				part = counts[t2] + " x " + part
			EndIf
			s = CSN_Rebellion.AddTo(s, part)
		EndIf
		t2 += 1
	EndWhile
	If s == ""
		s = "nothing built yet"
	EndIf
	Return s
EndFunction

String Function ListText() Global
	String s = ""
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			s = CSN_Rebellion.AddTo(s, Name(k) + " in " + M().HoldName(HoldOf(k)) + " (" + Pop(k) + " settlers, " + BuildingsText(k) + ")")
		EndIf
		k += 1
	EndWhile
	Return s
EndFunction

; how settlements and raids work, for those who run the faction's lands
String Function RulesText() Global
	String s = " How the faction's settlements work: the leader founds one on open land in a hold whose city or roads the faction holds (" + FoundGold() + " gold and " + FoundWood() + " wood), and builds within about 70 paces of its banner post: homes give beds, fields, beehives, windmills and sheds give food, the lumber mill and chopping block wood, the smelter and smithy metal, the inn and market stalls gold, wells, campfires and banners happiness, and watchtowers (+5), stockade walls, barricades, training dummies and archery targets (+1 each) defence. Every four settlers add 1 defence too."
	s += " Settlers come while there are free beds and happiness is 40 or more, and leave below 25; they fill the jobs, and buildings with jobs produce only as far as they are staffed. Each day the food left after the settlers eat, the wood, the metal and the gold (plus 2 gold tax per settler) go to the faction's stores."
	s += " Raids: bandits can strike a settlement once a day at most every three days; the chance is 10% minus its defence, higher when people are unhappy (never under 2% once anything is built). If the leader is there they fight the bandits; otherwise the settlers hold if their defence is strong enough, or a building is burnt and two settlers flee. Driving raiders off cheers people up; losing to them does the opposite."
	s += " Separately, a free company of deserters raids the faction's own supply lines every day (20 gold and half a food for each of its soldiers) and may storm one of the faction's cities, as rebels in a city that has risen may."
	Return s
EndFunction

String Function StatusText(Int k) Global
	String s = Name(k) + " in " + M().HoldName(HoldOf(k)) + ": " + SummaryText(k) + "; a day: " + StorageUtil.GetStringValue(None, SK(k, "last"), "nothing yet")
	Int c = RaidChance(k)
	s += "; raid risk " + c + "% a day"
	Int last = StorageUtil.GetIntValue(None, SK(k, "raid"), -1)
	If last >= 0
		s += " (last raid " + (Today() - last) + " day(s) ago)"
	EndIf
	Return s + "; buildings: " + BuildingsText(k)
EndFunction

; town leaders (jarls, village leaders and their stewards) of the faction's towns, and the faction's Steward and General
Bool Function RunsLand(Actor akActor) Global
	CSN_Core m = M()
	Int role = m.GetRole(akActor)
	If role == m.ROLE_STEWARD || role == m.ROLE_GENERAL
		Return True
	EndIf
	Int i = 0
	While i < 15
		If CSN_World.PlayerRules(i) && CSN_World.TownJarl(i) == akActor
			Return True
		EndIf
		i += 1
	EndWhile
	Int c = CSN_Gov.CityStewardOf(akActor)
	Return c >= 0 && CSN_World.PlayerRules(c)
EndFunction

String Function Knowledge(Actor akActor) Global
	CSN_Core m = M()
	If !m || m.FactionStarted.GetValue() < 1 || !akActor || !Enabled()
		Return ""
	EndIf
	Int mine = StorageUtil.GetIntValue(akActor, "csn_settler", 0) - 1
	If mine >= 0 && Exists(mine)
		Return " " + m.PlainName(akActor) + " is a settler of " + StatusText(mine) + "." + RulesText()
	EndIf
	If !RunsLand(akActor)
		Return ""
	EndIf
	String s = RulesText()
	If Count() <= 0
		Return s + " The faction has no settlements yet."
	EndIf
	s += " The faction's settlements now:"
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			s += " " + StatusText(k) + "."
		EndIf
		k += 1
	EndWhile
	Return s
EndFunction
