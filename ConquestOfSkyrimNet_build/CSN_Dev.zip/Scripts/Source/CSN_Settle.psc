Scriptname CSN_Settle Hidden
{Conquest of SkyrimNet - settlements (in the spirit of Fallout 4's).

 The unfinished Conquest of Skyrim build has a settlement system, but it sits on a new city economy that 0.3.9 does
 not have (and needs several hundred records plus its own meshes). This is a settlement system of CSN's own built
 on what 0.3.9 and the base game already have, so it works with any save:

   * FOUND a settlement anywhere outdoors in a hold whose city or roads the faction holds (not inside a town, and
     away from other settlements). A banner post marks its heart; it reaches 5,000 units around it.
   * BUILD from a catalogue of base-game buildings (Skyrim.esm / HearthFires.esm): tents, farmhouses, longhouses,
     crop fields, windmills, a lumber mill, smelter, smithy, inn, market stalls, wells, watchtowers, stockade walls
     and more. In build mode the building floats in front of you: walk and turn to move it, arrow keys rotate it and
     bring it closer or push it away, Page Up/Down raise and lower it, Enter or Activate places it, Backspace cancels.
     The cost (gold from the treasury, wood and metal from the faction's supplies) is paid when it is placed.
   * SETTLERS arrive while there are beds and the settlement is content (happiness 40+). They work the buildings.
   * Every day the settlement's food, wood, metal and gold go to the faction's stocks; settlers eat first and pay a
     little tax.
   * RAIDS: bandits come now and then; defence (towers, walls, training) keeps them out. If you are there you fight
     them; if not, the settlement holds or loses a building and some settlers.

 State: StorageUtil, keys "csn_st_*".}

CSN_Core Function M() Global
	Return CSN_Gov.M()
EndFunction

Int Function Today() Global
	Return Utility.GetCurrentGameTime() as Int
EndFunction

Bool Function Enabled() Global
	Return CSN_Config.GetBool("bSettlements:Settlements", True)
EndFunction

Int Function MaxSettlements() Global
	Return 8
EndFunction

Float Function Radius() Global
	Return 5000.0
EndFunction

Int Function FoundGold() Global
	Return CSN_Config.ClampMin(CSN_Config.GetInt("iFoundGold:Settlements", 2000), 0)
EndFunction

Int Function FoundWood() Global
	Return CSN_Config.ClampMin(CSN_Config.GetInt("iFoundWood:Settlements", 40), 0)
EndFunction

; =============================================================================
; CATALOGUE
; name|file|formid|gold|wood|metal|housing|food|wood|metal|gold|happiness|defence|workers|pieces|group
; =============================================================================
Function InitCatalogue() Global
	If StorageUtil.StringListCount(None, "csn_st_cat") == 34 && StorageUtil.GetIntValue(None, "csn_st_catv", 0) == 3
		Return
	EndIf
	StorageUtil.StringListClear(None, "csn_st_cat")
	; every building gives the settlement something it can count: beds, food, wood, metal or gold
	String[] c = new String[34]
	c[0] = "Tent|S|524510|80|15|0|2|0|0|0|0|0|0|0|1|Homes"
	c[1] = "Bedroll|S|100765|10|3|0|1|0|0|0|0|0|0|0|1|Homes"
	c[2] = "Farmhouse|S|2122|300|40|0|4|0|0|0|0|1|0|0|1|Homes"
	c[3] = "Large farmhouse|S|77947|500|60|5|6|0|0|0|0|2|0|0|1|Homes"
	c[4] = "Longhouse|S|990468|900|100|10|10|0|0|0|0|3|0|0|1|Homes"
	c[5] = "Cabbage field|H|66654|100|5|0|0|2|0|0|0|0|0|2|9|Food"
	c[6] = "Potato field|H|69818|100|5|0|0|2|0|0|0|0|0|2|9|Food"
	c[7] = "Wheat field|H|69837|120|5|0|0|3|0|0|0|0|0|2|9|Food"
	c[8] = "Beehive|S|569146|40|5|0|0|1|0|0|0|0|0|0|1|Food"
	c[9] = "Windmill|S|861782|400|50|5|0|2|0|0|0|1|0|1|1|Food"
	c[10] = "Farm shed|S|725440|150|25|0|0|1|0|0|0|0|0|1|1|Food"
	c[11] = "Lumber mill|S|127488|600|60|10|0|0|4|0|0|0|0|3|1|Industry"
	c[12] = "Chopping block|S|193936|30|5|0|0|0|1|0|0|0|0|1|1|Industry"
	c[13] = "Smelter|S|640718|300|20|10|0|0|0|2|0|0|0|2|1|Industry"
	c[14] = "Smithy|S|102369|500|50|20|0|0|0|1|0|0|2|1|1|Industry"
	c[15] = "Forge|S|830987|250|10|20|0|0|0|1|0|0|1|1|1|Industry"
	c[16] = "Anvil|S|107181|100|0|15|0|0|0|0|2|0|0|0|1|Industry"
	c[17] = "Tanning rack|S|468897|60|10|0|0|0|0|0|3|0|0|1|1|Industry"
	c[18] = "Alchemy lab|S|765196|200|10|5|0|0|0|0|4|1|0|1|1|Industry"
	c[19] = "Arcane enchanter|S|765197|400|10|10|0|0|0|0|6|1|0|1|1|Industry"
	c[20] = "Inn|S|186210|800|80|10|2|0|0|0|30|10|0|2|1|Trade"
	c[21] = "Market stall|S|412551|200|20|0|0|0|0|0|15|2|0|1|1|Trade"
	c[22] = "Well|S|979750|100|10|5|0|1|0|0|0|5|0|0|1|Comfort"
	c[23] = "Campfire|S|220999|10|2|0|0|1|0|0|0|2|0|0|1|Comfort"
	c[24] = "Banner|C|13883555|20|2|0|0|0|0|0|1|1|0|0|1|Comfort"
	c[25] = "Watchtower|S|309116|500|60|20|0|0|0|0|3|0|5|1|1|Defense"
	c[26] = "Stockade wall|S|455277|60|15|0|0|0|0|0|1|0|1|0|1|Defense"
	c[27] = "Barricade|S|110104|30|8|0|0|0|0|0|1|0|1|0|1|Defense"
	c[28] = "Training dummy|S|698933|40|5|0|0|0|0|0|1|0|1|0|1|Defense"
	c[29] = "Archery target|S|420598|30|5|0|0|0|0|0|1|0|1|0|1|Defense"
	c[30] = "Storage chest|S|959129|40|8|0|0|1|1|0|0|0|0|0|1|Storage"
	c[31] = "Fine chest|S|997667|120|10|2|0|0|0|0|2|1|0|0|1|Storage"
	c[32] = "Strongbox|H|39016|80|0|6|0|0|0|0|3|0|0|0|1|Storage"
	c[33] = "Weapon rack|C|13883554|60|10|4|0|0|0|0|1|0|2|0|1|Storage"
	Int i = 0
	While i < 34
		StorageUtil.StringListAdd(None, "csn_st_cat", c[i])
		i += 1
	EndWhile
	StorageUtil.SetIntValue(None, "csn_st_catv", 3)
	StorageUtil.UnsetStringValue(None, "csn_st_catjson3")
	StorageUtil.UnsetStringValue(None, "csn_st_layjson3")
EndFunction

Int Function CatCount() Global
	InitCatalogue()
	Return StorageUtil.StringListCount(None, "csn_st_cat")
EndFunction

String[] Function Row(Int t) Global
	InitCatalogue()
	Return PapyrusUtil.StringSplit(StorageUtil.StringListGet(None, "csn_st_cat", t), "|")
EndFunction

Int Function Col(Int t, Int c) Global
	String[] r = Row(t)
	If c < r.Length
		Return r[c] as Int
	EndIf
	Return 0
EndFunction

String Function TypeName(Int t) Global
	String[] r = Row(t)
	Return r[0]
EndFunction

String Function Group(Int t) Global
	String[] r = Row(t)
	If r.Length > 15
		Return r[15]
	EndIf
	Return ""
EndFunction

Form Function Base(Int t) Global
	String[] r = Row(t)
	String file = "Skyrim.esm"
	If r[1] == "H"
		file = "HearthFires.esm"
	ElseIf r[1] == "C"
		file = "ConquestOfSkyrimNet.esp"
	EndIf
	Return Game.GetFormFromFile(r[2] as Int, file)
EndFunction

; how far in front of the player the piece floats while placing
Float Function Reach(Int t) Global
	If Col(t, 3) >= 300
		Return 1100.0
	ElseIf Col(t, 14) > 1
		Return 350.0
	EndIf
	Return 250.0
EndFunction

; =============================================================================
; SETTLEMENTS
; =============================================================================
String Function SK(Int k, String asKey) Global
	Return "csn_st_" + k + "_" + asKey
EndFunction

Bool Function Exists(Int k) Global
	Return StorageUtil.GetIntValue(None, SK(k, "on"), 0) == 1
EndFunction

String Function Name(Int k) Global
	Return StorageUtil.GetStringValue(None, SK(k, "name"), "Settlement " + (k + 1))
EndFunction

ObjectReference Function Heart(Int k) Global
	Return StorageUtil.GetFormValue(None, SK(k, "heart")) as ObjectReference
EndFunction

Int Function HoldOf(Int k) Global
	Return StorageUtil.GetIntValue(None, SK(k, "hold"), 0)
EndFunction

Int Function Pop(Int k) Global
	Return StorageUtil.GetIntValue(None, SK(k, "pop"), 0)
EndFunction

Int Function Count() Global
	Int n = 0
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			n += 1
		EndIf
		k += 1
	EndWhile
	Return n
EndFunction

; total of one catalogue column over a settlement's buildings (fields count once, not per plant)
Int Function Sum(Int k, Int c) Global
	Int n = 0
	Int i = 0
	Int count = StorageUtil.IntListCount(None, SK(k, "types"))
	While i < count
		Int t = StorageUtil.IntListGet(None, SK(k, "types"), i)
		If t >= 0
			n += Col(t, c)
		EndIf
		i += 1
	EndWhile
	Return n
EndFunction

Int Function Housing(Int k) Global
	Return Sum(k, 6)
EndFunction

Int Function Jobs(Int k) Global
	Return Sum(k, 13)
EndFunction

Int Function Defense(Int k) Global
	Return Sum(k, 12) + Pop(k) / 4 + 3 * Guards(k)
EndFunction

Int Function Happiness(Int k) Global
	Int h = 50 + Sum(k, 11) + StorageUtil.GetIntValue(None, SK(k, "mood"), 0)
	If Pop(k) > Housing(k)
		h -= 10 * (Pop(k) - Housing(k))
	EndIf
	If FoodNet(k) < 0
		h -= 15
	EndIf
	If h < 0
		h = 0
	ElseIf h > 100
		h = 100
	EndIf
	Return h
EndFunction

; share of jobs filled (0-100)
Int Function Staffed(Int k) Global
	Int j = Jobs(k)
	If j <= 0
		Return 100
	EndIf
	Int p = Pop(k)
	If p >= j
		Return 100
	EndIf
	Return p * 100 / j
EndFunction

; output of buildings that need workers scales with staffing; the rest always produce
Int Function Output(Int k, Int c) Global
	Int full = 0
	Int part = 0
	Int i = 0
	Int count = StorageUtil.IntListCount(None, SK(k, "types"))
	While i < count
		Int t = StorageUtil.IntListGet(None, SK(k, "types"), i)
		If t >= 0
			If Col(t, 13) > 0
				part += Col(t, c)
			Else
				full += Col(t, c)
			EndIf
		EndIf
		i += 1
	EndWhile
	Return full + part * Staffed(k) / 100
EndFunction

; food after the settlers have eaten (one for every two settlers)
Int Function FoodNet(Int k) Global
	Return Output(k, 7) - (Pop(k) + 1) / 2 - Guards(k)
EndFunction

Int Function GoldDay(Int k) Global
	Return Output(k, 10) + Pop(k) * 2
EndFunction

; ---- map markers: one spare persistent marker per slot in the plugin (CSN_SettlementMarker1-8) ----
ObjectReference Function Marker(Int k) Global
	Return Game.GetFormFromFile(0xD3D887 + k, "ConquestOfSkyrimNet.esp") as ObjectReference
EndFunction

; puts the slot's marker at the settlement, on the map (fast travel allowed) and named after it
Function ShowMarker(Int k) Global
	ObjectReference mk = Marker(k)
	ObjectReference h = Heart(k)
	If !mk || !h
		Return
	EndIf
	If StorageUtil.GetIntValue(None, SK(k, "marker"), 0) != 1
		mk.MoveTo(h, 0.0, 0.0, 0.0, False)
		mk.Enable()
		StorageUtil.SetIntValue(None, SK(k, "marker"), 1)
	ElseIf mk.IsDisabled()
		mk.Enable()
	EndIf
	mk.AddToMap(True)
	If !CSN_Native.SetMapMarkerName(mk, Name(k))
		CSN_Config.Log("settlement " + k + ": could not name its map marker")
	EndIf
EndFunction

Function HideMarker(Int k) Global
	ObjectReference mk = Marker(k)
	If mk
		mk.Disable()
	EndIf
	StorageUtil.SetIntValue(None, SK(k, "marker"), 0)
EndFunction

; every game load: marker names aren't kept in the save; settlements founded before markers existed get theirs
Function OnLoad() Global
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			ShowMarker(k)
			; settlements from before 2.0.17: their extra army place
			If StorageUtil.GetIntValue(None, SK(k, "armyslot"), -2) == -2
				StorageUtil.SetIntValue(None, SK(k, "armyslot"), UnlockArmySlot())
			EndIf
			HomeArmy(k)
		EndIf
		k += 1
	EndWhile
EndFunction

; The army this settlement gave lives there: CoS's home marker and home place for that army, as a claim's banner
; is for the army it gave (only when nothing else holds them).
Function HomeArmy(Int k) Global
	Int a = ArmySlot(k)
	ObjectReference h = Heart(k)
	If a < 0 || !h
		Return
	EndIf
	CS_ClaimAreaFunctions c = M().Holdings()
	If a < c.CommanderMarkers.Length && !c.CommanderMarkers[a].GetReference()
		c.CommanderMarkers[a].ForceRefTo(h)
		Location l = h.GetCurrentLocation()
		If l && a < c.CommanderHoldings.Length && !c.CommanderHoldings[a].GetLocation()
			c.CommanderHoldings[a].ForceLocationTo(l)
		EndIf
		c.RefreshCommanderPackages(a)
	EndIf
EndFunction

; ---- the banner: the same as a claim's (CS_PlayerBanner's model), scripted to open the settlement's menu ----
Form Function BannerBase() Global
	Return Game.GetFormFromFile(0xD3D8A3, "ConquestOfSkyrimNet.esp")   ; CSN_SettlementBanner
EndFunction

; settlements from before 2.0.17 had a farm banner post: it becomes the claim banner where it stood
Function UpgradeBanner(Int k) Global
	ObjectReference h = Heart(k)
	Form b = BannerBase()
	If !h || !b || h.GetBaseObject() == b || !h.Is3DLoaded()
		Return
	EndIf
	ObjectReference nb = h.PlaceAtMe(b, 1, True, False)
	nb.SetPosition(h.GetPositionX(), h.GetPositionY(), h.GetPositionZ())
	nb.SetAngle(0.0, 0.0, h.GetAngleZ())
	StorageUtil.SetFormValue(None, SK(k, "heart"), nb)
	h.Disable()
	h.Delete()
EndFunction

; the settlement a banner belongs to (its own banner post, or any banner built inside one)
Int Function SettlementOfBanner(ObjectReference akBanner) Global
	Int k = 0
	While k < MaxSettlements()
		If Exists(k) && Heart(k) == akBanner
			Return k
		EndIf
		k += 1
	EndWhile
	Return Here()
EndFunction

; activating the banner: guards and the settlement at a glance
Function BannerMenu(ObjectReference akBanner) Global
	Int k = SettlementOfBanner(akBanner)
	If k < 0
		Return
	EndIf
	Bool again = True
	While again
		again = False
		Int g = Guards(k)
		String body = SummaryText(k) + "\n\nGuards: " + g + " of " + MaxGuards() + ". Each costs " + CSN_Config.GuardCost() + " gold to hire, then " + CSN_Config.TroopUpkeep() + " gold and 1 food a day, and adds 3 defence."
		body += "\nTreasury: " + CSN_Gov.Treasury() + " gold."
		If ArmySlot(k) >= 0
			If ArmyRaised(k)
				body += "\n" + CSN_Gov.ArmyLabel(ArmySlot(k)) + " was raised thanks to " + Name(k) + ": raids here lower its morale."
			Else
				body += "\n" + Name(k) + " lets you raise one more army."
			EndIf
		EndIf
		String[] opts = new String[4]
		opts[0] = "Hire a guard (" + CSN_Config.GuardCost() + " gold)"
		opts[1] = "Dismiss a guard"
		opts[2] = "Open the Settlements tab"
		opts[3] = "Close"
		Int pick = CSNP.Choose(Name(k), body, opts)
		If pick == 0
			HireGuard(k)
			again = True
		ElseIf pick == 1
			DismissGuard(k)
			again = True
		ElseIf pick == 2
			M().OpenDashboard("settle")
		EndIf
	EndWhile
EndFunction

; ---- guards (up to five at each settlement, paid like troops) ----
Int Function MaxGuards() Global
	Return 5
EndFunction

Int Function Guards(Int k) Global
	Int n = 0
	Int i = 0
	While i < StorageUtil.FormListCount(None, SK(k, "guards"))
		Actor a = StorageUtil.FormListGet(None, SK(k, "guards"), i) as Actor
		If a && !a.IsDead()
			n += 1
		EndIf
		i += 1
	EndWhile
	Return n
EndFunction

; every settlement's guards, for the daily pay
Int Function GuardTotal() Global
	Int n = 0
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			n += Guards(k)
		EndIf
		k += 1
	EndWhile
	Return n
EndFunction

Bool Function HireGuard(Int k) Global
	CSN_Core m = M()
	If !Exists(k)
		Return False
	EndIf
	If Guards(k) >= MaxGuards()
		CSN_Gov.Fail(Name(k) + " already has " + MaxGuards() + " guards.")
		Return False
	EndIf
	If CSN_Gov.Treasury() < CSN_Config.GuardCost()
		CSN_Gov.Fail("A guard costs " + CSN_Config.GuardCost() + " gold; the treasury holds " + CSN_Gov.Treasury() + ".")
		Return False
	EndIf
	ObjectReference h = Heart(k)
	ActorBase gb = m.Holdings().GuardMisc   ; the claims' guard
	If !h || !gb
		Return False
	EndIf
	m.Econ().Treasury.Mod(-CSN_Config.GuardCost())
	; the dead leave the list first
	Int i = StorageUtil.FormListCount(None, SK(k, "guards")) - 1
	While i >= 0
		Actor d = StorageUtil.FormListGet(None, SK(k, "guards"), i) as Actor
		If !d || d.IsDead()
			StorageUtil.FormListRemoveAt(None, SK(k, "guards"), i)
		EndIf
		i -= 1
	EndWhile
	Actor gd = h.PlaceActorAtMe(gb)
	gd.MoveTo(h, Utility.RandomFloat(-300.0, 300.0), Utility.RandomFloat(-300.0, 300.0), 0.0)
	StorageUtil.SetIntValue(gd, "csn_settleguard", k + 1)
	StorageUtil.FormListAdd(None, SK(k, "guards"), gd)
	Sandbox(gd)
	m.Gov.EconUpdater.CalculatePlayerPerDay()
	CSN_Gov.Say("Guard hired at " + Name(k) + ": " + Guards(k) + " of " + MaxGuards() + ". Keeps: " + CSN_Config.TroopUpkeep() + " gold, 1 food a day.")
	Return True
EndFunction

Bool Function DismissGuard(Int k) Global
	Int i = StorageUtil.FormListCount(None, SK(k, "guards")) - 1
	While i >= 0
		Actor a = StorageUtil.FormListGet(None, SK(k, "guards"), i) as Actor
		StorageUtil.FormListRemoveAt(None, SK(k, "guards"), i)
		If a && !a.IsDead()
			a.Disable()
			a.Delete()
			M().Gov.EconUpdater.CalculatePlayerPerDay()
			CSN_Gov.Say("A guard of " + Name(k) + " was dismissed: " + Guards(k) + " left.")
			Return True
		EndIf
		i -= 1
	EndWhile
	CSN_Gov.Fail(Name(k) + " has no guards.")
	Return False
EndFunction

Function DismissGuards(Int k) Global
	Int i = StorageUtil.FormListCount(None, SK(k, "guards")) - 1
	While i >= 0
		Actor a = StorageUtil.FormListGet(None, SK(k, "guards"), i) as Actor
		If a
			a.Disable()
			a.Delete()
		EndIf
		i -= 1
	EndWhile
	StorageUtil.FormListClear(None, SK(k, "guards"))
EndFunction

; ---- one more army for each settlement (Conquest of Skyrim's army places: -1 locked, 1 open, 0 an army) ----
Int Function UnlockArmySlot() Global
	FormList slots = M().Armies().RecruitCommanders
	Int i = 0
	While slots && i < slots.GetSize()
		GlobalVariable g = slots.GetAt(i) as GlobalVariable
		If g && g.GetValue() == -1
			g.SetValue(1)
			Return i
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

Int Function ArmySlot(Int k) Global
	Return StorageUtil.GetIntValue(None, SK(k, "armyslot"), -1)
EndFunction

; an army stands in the place this settlement gave
Bool Function ArmyRaised(Int k) Global
	Int a = ArmySlot(k)
	If a < 0
		Return False
	EndIf
	CSN_Core m = M()
	Return a < m.Armies().Commanders.Length && m.Armies().Commanders[a].GetActorRef() != None
EndFunction

Function LockArmySlot(Int k) Global
	Int a = ArmySlot(k)
	FormList slots = M().Armies().RecruitCommanders
	If a >= 0 && slots && a < slots.GetSize() && !ArmyRaised(k)
		GlobalVariable g = slots.GetAt(a) as GlobalVariable
		If g && g.GetValue() == 1
			g.SetValue(-1)
		EndIf
	EndIf
	StorageUtil.SetIntValue(None, SK(k, "armyslot"), -1)
EndFunction

Int Function FreeSlot() Global
	Int k = 0
	While k < MaxSettlements()
		If !Exists(k)
			Return k
		EndIf
		k += 1
	EndWhile
	Return -1
EndFunction

; the settlement the player stands in (-1 none)
Int Function Here() Global
	Actor p = Game.GetPlayer()
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			ObjectReference h = Heart(k)
			If h && h.GetWorldSpace() == p.GetWorldSpace() && p.GetDistance(h) <= Radius()
				Return k
			EndIf
		EndIf
		k += 1
	EndWhile
	Return -1
EndFunction

; the hold the player is in (-1 none): from the current location (the hold is its parent), or, out in wild land that
; has no location, the hold whose city or fort is nearest
Int Function PlayerHold() Global
	CSN_Core m = M()
	Actor p = Game.GetPlayer()
	Location here = p.GetCurrentLocation()
	Int h = 0
	While h < m.HoldCount()
		Location hl = m.Gov.AllHolds.GetAt(h) as Location
		If here && hl && (here == hl || hl.IsChild(here))
			Return h
		EndIf
		h += 1
	EndWhile
	If p.IsInInterior()
		Return -1
	EndIf
	FormList cityMarkers = Game.GetFormFromFile(0x0342C8, "ConquestOfSkyrimNet.esp") as FormList   ; CS_MapMarkers
	FormList fortMarkers = Game.GetFormFromFile(0x1E4541, "ConquestOfSkyrimNet.esp") as FormList   ; CS_AllFortMarkersPlayer
	Int best = -1
	Float bestDist = 0.0
	h = 0
	While h < 9
		ObjectReference[] marks = new ObjectReference[2]
		If cityMarkers && h < cityMarkers.GetSize()
			marks[0] = cityMarkers.GetAt(h) as ObjectReference
		EndIf
		If fortMarkers && h < fortMarkers.GetSize()
			marks[1] = fortMarkers.GetAt(h) as ObjectReference
		EndIf
		Int k = 0
		While k < 2
			ObjectReference r = marks[k]
			If r && r.GetWorldSpace() == p.GetWorldSpace()
				Float d = p.GetDistance(r)
				If best < 0 || d < bestDist
					best = h
					bestDist = d
				EndIf
			EndIf
			k += 1
		EndWhile
		h += 1
	EndWhile
	Return best
EndFunction

; why a settlement can't be founded where the player stands ("" when it can)
String Function FoundBlock() Global
	CSN_Core m = M()
	Actor p = Game.GetPlayer()
	If !Enabled()
		Return "Settlements are turned off in the MCM."
	ElseIf m.FactionStarted.GetValue() < 1
		Return "Found your faction first."
	ElseIf FreeSlot() < 0
		Return "The faction already has " + MaxSettlements() + " settlements."
	ElseIf p.IsInInterior()
		Return "Settlements are founded outdoors."
	EndIf
	Int h = PlayerHold()
	If h < 0
		Return "You are not inside any hold."
	EndIf
	If !m.OwnsHold(h) && CSN_Gov.RoadsSide(h) != 1
		Return "Your faction must hold " + m.HoldName(h) + "'s city or its roads to settle here."
	EndIf
	If CSN_World.TownOfLocation(p.GetCurrentLocation()) >= 0
		Return "This is already a town. Find open land."
	EndIf
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			ObjectReference hr = Heart(k)
			If hr && hr.GetWorldSpace() == p.GetWorldSpace() && p.GetDistance(hr) < Radius() * 2.0
				Return "Too close to " + Name(k) + "."
			EndIf
		EndIf
		k += 1
	EndWhile
	Return ""
EndFunction

Bool Function Found(Actor akVia = None) Global
	CSN_Core m = M()
	String err = FoundBlock()
	If err != ""
		CSN_Gov.Fail(err)
		Return False
	EndIf
	Int h = PlayerHold()
	If !CSNP.Confirm("Found a settlement", "Found a settlement here in " + m.HoldName(h) + "?\n\nCosts " + FoundGold() + " gold from the treasury (" + CSN_Gov.Treasury() + ") and " + FoundWood() + " wood (" + CSN_Gov.Stock(2) + "). A banner post marks its heart; you can build within about 70 paces of it.", "Found it", "Not here")
		Return False
	EndIf
	If CSN_Gov.Treasury() < FoundGold()
		CSN_Gov.Fail("The treasury holds " + CSN_Gov.Treasury() + " gold; " + FoundGold() + " needed.")
		Return False
	EndIf
	If !CSN_Gov.Spend(2, FoundWood())
		Return False
	EndIf
	String nm = CSNP.TextInput("Name the settlement", "")
	If nm == ""
		nm = "New " + m.HoldName(h)
	EndIf
	m.Econ().Treasury.Mod(-FoundGold())
	Int k = FreeSlot()
	Actor p = Game.GetPlayer()
	Form post = BannerBase()   ; the same banner as a claim's, scripted to open the settlement's menu
	ObjectReference heart = p.PlaceAtMe(post, 1, True, False)
	heart.SetAngle(0.0, 0.0, p.GetAngleZ())
	StorageUtil.SetIntValue(None, SK(k, "on"), 1)
	StorageUtil.SetStringValue(None, SK(k, "name"), nm)
	StorageUtil.SetFormValue(None, SK(k, "heart"), heart)
	StorageUtil.SetIntValue(None, SK(k, "hold"), h)
	CSN_Thanes.AddSlots(h, 1)   ; one more Thane for the hold
	StorageUtil.SetIntValue(None, SK(k, "pop"), 0)
	StorageUtil.SetIntValue(None, SK(k, "mood"), 0)
	StorageUtil.SetIntValue(None, SK(k, "since"), Today())
	StorageUtil.FormListClear(None, SK(k, "refs"))
	StorageUtil.IntListClear(None, SK(k, "types"))
	StorageUtil.FormListClear(None, SK(k, "people"))
	StorageUtil.SetIntValue(None, SK(k, "marker"), 0)
	StorageUtil.FormListClear(None, SK(k, "guards"))
	StorageUtil.SetIntValue(None, SK(k, "armyslot"), UnlockArmySlot())
	HomeArmy(k)
	ShowMarker(k)
	String txt = Game.GetPlayer().GetDisplayName() + " founded " + nm + ", a new settlement of the " + m.FactionName() + " in " + m.HoldName(h) + "."
	CSN_World.AddNews(-1, txt, "csn_settlement_founded", akVia)
	CSN_Gov.Say(nm + " is founded and on your map. Build homes so settlers can come.")
	If ArmySlot(k) >= 0
		CSN_Gov.Say("One more army can be raised, thanks to " + nm + ".")
	EndIf
	m.Refresh()
	Return True
EndFunction

Bool Function Rename(Int k) Global
	If !Exists(k)
		Return False
	EndIf
	String nm = CSNP.TextInput("Rename " + Name(k), Name(k))
	If nm == "" || nm == Name(k)
		Return False
	EndIf
	StorageUtil.SetStringValue(None, SK(k, "name"), nm)
	ShowMarker(k)
	M().Refresh()
	Return True
EndFunction

Bool Function Abandon(Int k) Global
	If !Exists(k)
		Return False
	EndIf
	If ArmyRaised(k)
		CSN_Gov.Fail(Name(k) + " can't be abandoned: " + CSN_Gov.ArmyLabel(ArmySlot(k)) + " was raised thanks to it. Dismiss that army first.")
		Return False
	EndIf
	If !CSNP.Confirm("Abandon " + Name(k), "Abandon " + Name(k) + "? Every building is taken down, the settlers and guards leave, and the extra army place it gave goes. Nothing is refunded.", "Abandon it", "Keep it")
		Return False
	EndIf
	Int i = StorageUtil.FormListCount(None, SK(k, "refs")) - 1
	While i >= 0
		ObjectReference r = StorageUtil.FormListGet(None, SK(k, "refs"), i) as ObjectReference
		If r
			Untrack(r)
			DeleteParts(r)
			r.Disable()
			r.Delete()
		EndIf
		i -= 1
	EndWhile
	i = StorageUtil.FormListCount(None, SK(k, "people")) - 1
	While i >= 0
		Actor a = StorageUtil.FormListGet(None, SK(k, "people"), i) as Actor
		If a
			a.Disable()
			a.Delete()
		EndIf
		i -= 1
	EndWhile
	ObjectReference h = Heart(k)
	If h
		h.Disable()
		h.Delete()
	EndIf
	String nm = Name(k)
	StorageUtil.FormListClear(None, SK(k, "refs"))
	StorageUtil.IntListClear(None, SK(k, "types"))
	StorageUtil.FormListClear(None, SK(k, "people"))
	HideMarker(k)
	CSN_Thanes.AddSlots(HoldOf(k), -1)
	DismissGuards(k)
	LockArmySlot(k)
	StorageUtil.SetIntValue(None, SK(k, "on"), 0)
	CSN_World.AddNews(-1, nm + " was abandoned.", "csn_settlement_abandoned")
	M().Refresh()
	Return True
EndFunction

; =============================================================================
; BUILD MODE
; =============================================================================
Bool Function Placing() Global
	Return StorageUtil.GetIntValue(None, "csn_st_placing", 0) == 1
EndFunction

; the build menu: pick a group, then a building (used by the screen and by conversation)
Function BuildMenu(Int k) Global
	If !Exists(k)
		k = Here()
	EndIf
	If k < 0
		CSN_Gov.Fail("Stand inside one of your settlements to build.")
		Return
	EndIf
	String[] groups = new String[8]
	groups[0] = "Homes"
	groups[1] = "Food"
	groups[2] = "Industry"
	groups[3] = "Trade"
	groups[4] = "Comfort"
	groups[5] = "Defense"
	groups[6] = "Storage"
	groups[7] = "Close"
	Int g = CSNP.Choose("Build in " + Name(k), "Treasury " + CSN_Gov.Treasury() + " gold · wood " + CSN_Gov.Stock(2) + " · metal " + CSN_Gov.Stock(1) + "\n" + SummaryText(k), groups)
	If g < 0 || g >= 7
		Return
	EndIf
	Int[] ids = PapyrusUtil.IntArray(0)
	String[] labels = PapyrusUtil.StringArray(0)
	Int t = 0
	While t < CatCount()
		If Group(t) == groups[g]
			ids = PapyrusUtil.PushInt(ids, t)
			String lab = TypeName(t) + " - " + CostText(t) + " - " + GivesText(t)
			If AffordBlock(t) != ""
				lab = "(can't afford) " + lab
			EndIf
			labels = PapyrusUtil.PushString(labels, lab)
		EndIf
		t += 1
	EndWhile
	labels = PapyrusUtil.PushString(labels, "Back")
	Int pick = CSNP.Choose(groups[g], "Choose what to build. You place it yourself; it is paid for when placed.", labels)
	If pick < 0 || pick >= ids.Length
		BuildMenu(k)
		Return
	EndIf
	Build(k, ids[pick])
EndFunction

String Function CostText(Int t) Global
	String s = Col(t, 3) + " gold"
	If Col(t, 4) > 0
		s += ", " + Col(t, 4) + " wood"
	EndIf
	If Col(t, 5) > 0
		s += ", " + Col(t, 5) + " metal"
	EndIf
	Return s
EndFunction

String Function GivesText(Int t) Global
	String s = ""
	If Col(t, 6) > 0
		s = CSN_Rebellion.AddTo(s, "beds " + Col(t, 6))
	EndIf
	If Col(t, 7) > 0
		s = CSN_Rebellion.AddTo(s, "food +" + Col(t, 7))
	EndIf
	If Col(t, 8) > 0
		s = CSN_Rebellion.AddTo(s, "wood +" + Col(t, 8))
	EndIf
	If Col(t, 9) > 0
		s = CSN_Rebellion.AddTo(s, "metal +" + Col(t, 9))
	EndIf
	If Col(t, 10) > 0
		s = CSN_Rebellion.AddTo(s, "gold +" + Col(t, 10))
	EndIf
	If Col(t, 11) > 0
		s = CSN_Rebellion.AddTo(s, "happiness +" + Col(t, 11))
	EndIf
	If Col(t, 12) > 0
		s = CSN_Rebellion.AddTo(s, "defence +" + Col(t, 12))
	EndIf
	If Col(t, 13) > 0
		s = CSN_Rebellion.AddTo(s, Col(t, 13) + " workers")
	EndIf
	If s == ""
		s = "a crafting station"
	EndIf
	Return s
EndFunction

String Function AffordBlock(Int t) Global
	If CSN_Gov.Treasury() < Col(t, 3)
		Return "The treasury holds " + CSN_Gov.Treasury() + " gold; " + Col(t, 3) + " needed."
	ElseIf CSN_Gov.Stock(2) < Col(t, 4)
		Return "The faction has " + CSN_Gov.Stock(2) + " wood; " + Col(t, 4) + " needed."
	ElseIf CSN_Gov.Stock(1) < Col(t, 5)
		Return "The faction has " + CSN_Gov.Stock(1) + " metal; " + Col(t, 5) + " needed."
	EndIf
	Return ""
EndFunction

Bool Function Build(Int k, Int t) Global
	If !CanPlaceIn(k)
		Return False
	EndIf
	If t < 0 || t >= CatCount()
		Return False
	EndIf
	String err = AffordBlock(t)
	If err != ""
		CSN_Gov.Fail(err)
		Return False
	EndIf
	Form b = Base(t)
	If !b
		CSN_Gov.Fail("That building's base object is missing from your game.")
		Return False
	EndIf
	CSN_Core m = M()
	m.CloseScreen()
	Utility.Wait(0.3)
	; the controls first (keys only start counting once this box is closed, so closing it doesn't place anything)
	String[] go = new String[2]
	go[0] = "Start placing"
	go[1] = "Cancel"
	If CSNP.Choose("Placing: " + TypeName(t), ControlsText() + "\n\nCost when placed: " + CostText(t) + ".\nGives: " + GivesText(t) + ".", go) != 0
		Return False
	EndIf
	ObjectReference ghost = Game.GetPlayer().PlaceAtMe(b, 1, True, False)
	BeginPlacing(k, t, ghost, 0, 0, Reach(t), 180.0, GroundOff(t))
	Return True
EndFunction

; how far a building's origin sits above the ground it stands on (the watchtower's floor is about 220 below it)
Float Function GroundOff(Int t) Global
	If t == 25
		Return 220.0
	EndIf
	Return 0.0
EndFunction

; in one of your settlements, with nothing else being placed
Bool Function CanPlaceIn(Int k) Global
	If !Exists(k)
		Return False
	EndIf
	If Placing()
		CSN_Gov.Fail("You are already placing something.")
		Return False
	EndIf
	ObjectReference h = Heart(k)
	Actor p = Game.GetPlayer()
	If !h || h.GetWorldSpace() != p.GetWorldSpace() || p.GetDistance(h) > Radius()
		CSN_Gov.Fail("Go to " + Name(k) + " to build there.")
		Return False
	EndIf
	Return True
EndFunction

; aiMode: 0 a new building, 1 moving building aiArg, 2 layout aiArg
Function BeginPlacing(Int k, Int t, ObjectReference akGhost, Int aiMode, Int aiArg, Float afDist, Float afRot, Float afZ) Global
	StorageUtil.SetFormValue(None, "csn_st_ghost", akGhost)
	StorageUtil.SetIntValue(None, "csn_st_placing", 1)
	StorageUtil.SetIntValue(None, "csn_st_pk", k)
	StorageUtil.SetIntValue(None, "csn_st_pt", t)
	StorageUtil.SetIntValue(None, "csn_st_mode", aiMode)
	StorageUtil.SetIntValue(None, "csn_st_marg", aiArg)
	StorageUtil.SetFloatValue(None, "csn_st_dist", afDist)
	StorageUtil.SetFloatValue(None, "csn_st_rot", afRot)
	StorageUtil.SetFloatValue(None, "csn_st_z", afZ)
	M().PlacementKeys(True)
	PlaceLoop()
EndFunction

String Function ControlsText() Global
	Return "The building floats in front of you, outlined so it is easy to see.\n\n- Move it: walk, and turn to aim it.\n- Rotate: Left / Right arrow.\n- Nearer / farther: Down / Up arrow.\n- Lower / raise: Page Down / Page Up.\n- Grid snapping: Home (off, 1, 2 or 4 paces). Now: " + GridText() + ".\n- Turn snapping: End (free, 15 or 45 degrees). Now: " + TurnText() + ".\n- Place it: Enter, or your Activate key.\n- Cancel: Backspace.\n\nIt has to stay within about 70 paces of the settlement's banner post."
EndFunction

String Function ControlsShort() Global
	Return "Placing: arrows turn/move, PgUp/PgDn height, Home grid, End turn snap, Enter place, Backspace cancel"
EndFunction

; ---- snapping (kept between placements; set on the Settlements tab or with Home / End while placing) ----
Int Function GridSize() Global
	Return StorageUtil.GetIntValue(None, "csn_st_grid", 0)
EndFunction

Int Function TurnStep() Global
	Return StorageUtil.GetIntValue(None, "csn_st_turn", 15)
EndFunction

Function SetGrid(Int aiUnits) Global
	If aiUnits != 0 && aiUnits != 70 && aiUnits != 140 && aiUnits != 280
		aiUnits = 0
	EndIf
	StorageUtil.SetIntValue(None, "csn_st_grid", aiUnits)
EndFunction

Function SetTurn(Int aiDegrees) Global
	If aiDegrees != 0 && aiDegrees != 15 && aiDegrees != 45
		aiDegrees = 15
	EndIf
	StorageUtil.SetIntValue(None, "csn_st_turn", aiDegrees)
EndFunction

String Function GridText() Global
	Int g = GridSize()
	If g <= 0
		Return "off"
	EndIf
	Return (g / 70) + " pace(s)"
EndFunction

String Function TurnText() Global
	Int t = TurnStep()
	If t <= 0
		Return "free"
	EndIf
	Return t + " degrees"
EndFunction

Float Function SnapTo(Float afV, Float afOrigin, Float afStep) Global
	Return afOrigin + Math.Floor((afV - afOrigin) / afStep + 0.5) * afStep
EndFunction

; Moves the building smoothly (TranslateTo) and only when where it should be has changed: setting its position
; every frame reloaded its 3D, which made it flash and fade.
Function PlaceLoop() Global
	Actor p = Game.GetPlayer()
	ObjectReference ghost = StorageUtil.GetFormValue(None, "csn_st_ghost") as ObjectReference
	Int k = StorageUtil.GetIntValue(None, "csn_st_pk", 0)
	Int mode = StorageUtil.GetIntValue(None, "csn_st_mode", 0)
	Int arg = StorageUtil.GetIntValue(None, "csn_st_marg", 0)
	ObjectReference h = Heart(k)
	EffectShader glow = Game.GetFormFromFile(0x000146, "Skyrim.esm") as EffectShader   ; LifeDetected: a bright edge, not see-through
	Bool warned = False
	Float lx = 0.0
	Float ly = 0.0
	Float lz = 0.0
	Float la = -999.0
	Float lastTip = Utility.GetCurrentRealTime()
	Bool first = True
	Bool first2 = True
	If ghost && glow
		glow.Play(ghost, -1.0)
	EndIf
	; a layout: the rest of its buildings float with the first, outlined too
	Int pv = 0
	While mode == 2 && glow && pv < StorageUtil.FormListCount(None, "csn_st_lay")
		ObjectReference pr = StorageUtil.FormListGet(None, "csn_st_lay", pv) as ObjectReference
		If pr
			glow.Play(pr, -1.0)
		EndIf
		pv += 1
	EndWhile
	Debug.Notification(ControlsShort())
	While Placing() && ghost
		Float az = p.GetAngleZ()
		Float d = StorageUtil.GetFloatValue(None, "csn_st_dist", 300.0)
		Float x = p.GetPositionX() + d * Math.Sin(az)
		Float y = p.GetPositionY() + d * Math.Cos(az)
		Float z = p.GetPositionZ() + StorageUtil.GetFloatValue(None, "csn_st_z", 0.0)
		Float ang = az + StorageUtil.GetFloatValue(None, "csn_st_rot", 180.0)
		Int g = GridSize()
		If g > 0 && h
			x = SnapTo(x, h.GetPositionX(), g as Float)
			y = SnapTo(y, h.GetPositionY(), g as Float)
		EndIf
		Int step = TurnStep()
		If step > 0
			ang = SnapTo(ang, 0.0, step as Float)
		EndIf
		If first
			ghost.SetPosition(x, y, z)
			ghost.SetAngle(0.0, 0.0, ang)
			first = False
		ElseIf Math.Abs(x - lx) > 6.0 || Math.Abs(y - ly) > 6.0 || Math.Abs(z - lz) > 4.0 || Math.Abs(ang - la) > 0.5
			ghost.TranslateTo(x, y, z, 0.0, 0.0, ang, 3000.0, 720.0)
		EndIf
		If mode == 2 && (first2 || Math.Abs(x - lx) > 6.0 || Math.Abs(y - ly) > 6.0 || Math.Abs(z - lz) > 4.0 || Math.Abs(ang - la) > 0.5)
			LayoutPreview(arg, x, y, z, ang, first2)
			first2 = False
		EndIf
		lx = x
		ly = y
		lz = z
		la = ang
		If h && ghost.GetDistance(h) > Radius()
			If !warned
				Debug.Notification("Outside " + Name(k) + ": move closer.")
				warned = True
			EndIf
		Else
			warned = False
		EndIf
		If Utility.GetCurrentRealTime() - lastTip > 12.0
			Debug.Notification(ControlsShort())
			lastTip = Utility.GetCurrentRealTime()
		EndIf
		Utility.Wait(0.1)
	EndWhile
	If ghost
		ghost.StopTranslation()
		If glow
			glow.Stop(ghost)
		EndIf
		; settle it exactly where it was aimed
		ghost.SetPosition(lx, ly, lz)
		ghost.SetAngle(0.0, 0.0, la)
	EndIf
	If mode == 2
		Int q = 0
		While q < StorageUtil.FormListCount(None, "csn_st_lay")
			ObjectReference pq = StorageUtil.FormListGet(None, "csn_st_lay", q) as ObjectReference
			If pq
				pq.StopTranslation()
				If glow
					glow.Stop(pq)
				EndIf
			EndIf
			q += 1
		EndWhile
		LayoutPreview(arg, lx, ly, lz, la, True)
	EndIf
	Int result = StorageUtil.GetIntValue(None, "csn_st_placing", 0)
	StorageUtil.SetIntValue(None, "csn_st_placing", 0)
	M().PlacementKeys(False)
	Bool inside = ghost && h && ghost.GetDistance(h) <= Radius()
	If mode == 1
		; moving a building: no cost; cancelled or too far puts it back where it stood
		If !(result == 2 && inside) && ghost
			ghost.SetPosition(StorageUtil.GetFloatValue(None, "csn_st_ox"), StorageUtil.GetFloatValue(None, "csn_st_oy"), StorageUtil.GetFloatValue(None, "csn_st_oz"))
			ghost.SetAngle(0.0, 0.0, StorageUtil.GetFloatValue(None, "csn_st_oa"))
			If result == 2
				Debug.Notification("Too far from " + Name(k) + ": put back.")
			Else
				Debug.Notification("Move cancelled.")
			EndIf
			SettleMoved(k, arg, ghost, False)
		ElseIf ghost
			SettleMoved(k, arg, ghost, True)
		EndIf
	ElseIf result == 2 && inside
		If mode == 2
			PlaceLayout(k, arg, ghost)
		Else
			Place(k, StorageUtil.GetIntValue(None, "csn_st_pt", 0), ghost)
		EndIf
	Else
		If result == 2
			Debug.Notification("Too far from " + Name(k) + ": not placed.")
		Else
			Debug.Notification("Building cancelled.")
		EndIf
		If ghost
			ghost.Disable()
			ghost.Delete()
		EndIf
		ClearLayoutPreview()
	EndIf
	StorageUtil.UnsetFormValue(None, "csn_st_ghost")
EndFunction

; keys while placing (forwarded by CSN_Core)
Function PlaceKey(Int aiCode) Global
	If !Placing()
		Return
	EndIf
	If aiCode == 28 || aiCode == 156 || aiCode == Input.GetMappedKey("Activate")
		StorageUtil.SetIntValue(None, "csn_st_placing", 2)
	ElseIf aiCode == 14
		StorageUtil.SetIntValue(None, "csn_st_placing", 3)
	ElseIf aiCode == 203 || aiCode == 205
		Float st = TurnStep() as Float
		If st <= 0.0
			st = 5.0
		EndIf
		If aiCode == 203
			st = -st
		EndIf
		StorageUtil.AdjustFloatValue(None, "csn_st_rot", st)
	ElseIf aiCode == 200
		StorageUtil.AdjustFloatValue(None, "csn_st_dist", 100.0)
	ElseIf aiCode == 208
		If StorageUtil.GetFloatValue(None, "csn_st_dist", 300.0) > 150.0
			StorageUtil.AdjustFloatValue(None, "csn_st_dist", -100.0)
		EndIf
	ElseIf aiCode == 201 || aiCode == 209
		; bigger steps for big buildings and layouts, so a press shows
		Float dz = 20.0
		If StorageUtil.GetIntValue(None, "csn_st_mode", 0) == 2 || Col(StorageUtil.GetIntValue(None, "csn_st_pt", 0), 3) >= 300
			dz = 50.0
		EndIf
		If aiCode == 209
			dz = -dz
		EndIf
		StorageUtil.AdjustFloatValue(None, "csn_st_z", dz)
	ElseIf aiCode == 199
		Int g = GridSize()
		If g == 0
			SetGrid(70)
		ElseIf g == 70
			SetGrid(140)
		ElseIf g == 140
			SetGrid(280)
		Else
			SetGrid(0)
		EndIf
		Debug.Notification("Grid snapping: " + GridText())
	ElseIf aiCode == 207
		Int t = TurnStep()
		If t == 0
			SetTurn(15)
		ElseIf t == 15
			SetTurn(45)
		Else
			StorageUtil.SetIntValue(None, "csn_st_turn", 0)
		EndIf
		Debug.Notification("Turn snapping: " + TurnText())
	EndIf
EndFunction

Function Place(Int k, Int t, ObjectReference akGhost, Bool abQuiet = False) Global
	CSN_Core m = M()
	String err = AffordBlock(t)
	If err != ""
		CSN_Gov.Fail(err)
		akGhost.Disable()
		akGhost.Delete()
		Return
	EndIf
	m.Econ().Treasury.Mod(-Col(t, 3))
	CSN_Gov.Spend(2, Col(t, 4))
	CSN_Gov.Spend(1, Col(t, 5))
	; refresh collision where it now stands
	akGhost.Disable()
	akGhost.Enable()
	StorageUtil.FormListAdd(None, SK(k, "refs"), akGhost)
	StorageUtil.IntListAdd(None, SK(k, "types"), t)
	Int at = StorageUtil.FormListCount(None, SK(k, "refs")) - 1
	; a field: eight more plants around the first, in a square
	Int pieces = Col(t, 14)
	If pieces > 1
		Form b = Base(t)
		Int n = 1
		While n < pieces
			ObjectReference pl = akGhost.PlaceAtMe(b, 1, True, False)
			StorageUtil.FormListAdd(None, SK(k, "refs"), pl)
			StorageUtil.IntListAdd(None, SK(k, "types"), -1)   ; part of the field above
			n += 1
		EndWhile
		LayField(k, at)
	EndIf
	; the lumber mill comes with its working log pile and saw (Skyrim's ResourceObjectSawmill), set exactly where the
	; mill stands as in Skyrim's own mills
	If t == 11
		Form pileBase = Game.GetFormFromFile(0x071C47, "Skyrim.esm")
		If pileBase
			AddPart(akGhost, pileBase, 0.0, 0.0, 0.0, 0.0)
		EndIf
	EndIf
	; a tent comes with its two bedrolls, laid as in Skyrim's own camps
	If t == 0
		Form roll = Game.GetFormFromFile(0x01899D, "Skyrim.esm")
		If roll
			AddPart(akGhost, roll, 145.0, -20.0, 0.0, 180.0)
			AddPart(akGhost, roll, -150.0, -20.0, 0.0, 180.0)
		EndIf
	EndIf
	Track(akGhost)
	If !abQuiet
		CSN_Gov.Say(TypeName(t) + " built in " + Name(k) + ".")
		CSN_SkyrimNet.LogEvent(Game.GetPlayer().GetDisplayName() + " built a " + TypeName(t) + " in the settlement of " + Name(k) + ".", None, Game.GetPlayer())
	EndIf
EndFunction

; the plants of a field (the refs after aiIndex) in a 3 x 3 square around its first plant
Function LayField(Int k, Int aiIndex) Global
	ObjectReference r = StorageUtil.FormListGet(None, SK(k, "refs"), aiIndex) as ObjectReference
	Int t = StorageUtil.IntListGet(None, SK(k, "types"), aiIndex)
	If !r || t < 0 || Col(t, 14) <= 1
		Return
	EndIf
	Float a = r.GetAngleZ()
	Int n = 1
	Int row = -1
	While row <= 1
		Int col = -1
		While col <= 1
			If row != 0 || col != 0
				ObjectReference pl = StorageUtil.FormListGet(None, SK(k, "refs"), aiIndex + n) as ObjectReference
				If pl
					Float ox = (col * 90.0) * Math.Cos(a) + (row * 90.0) * Math.Sin(a)
					Float oy = (row * 90.0) * Math.Cos(a) - (col * 90.0) * Math.Sin(a)
					pl.SetPosition(r.GetPositionX() + ox, r.GetPositionY() + oy, r.GetPositionZ())
					pl.SetAngle(0.0, 0.0, a)
					pl.Enable()
				EndIf
				n += 1
			EndIf
			col += 1
		EndWhile
		row += 1
	EndWhile
EndFunction

; ---- parts that come with a building (a tent's bedrolls, the mill's saw), kept at an offset from it ----
Function AddPart(ObjectReference akMain, Form akBase, Float afX, Float afY, Float afZ, Float afA) Global
	ObjectReference pr = akMain.PlaceAtMe(akBase, 1, True, False)
	If !pr
		Return
	EndIf
	StorageUtil.FormListAdd(akMain, "csn_st_parts", pr)
	StorageUtil.FloatListClear(pr, "csn_st_off")
	StorageUtil.FloatListAdd(pr, "csn_st_off", afX)
	StorageUtil.FloatListAdd(pr, "csn_st_off", afY)
	StorageUtil.FloatListAdd(pr, "csn_st_off", afZ)
	StorageUtil.FloatListAdd(pr, "csn_st_off", afA)
	PositionPart(akMain, pr)
EndFunction

Function PositionPart(ObjectReference akMain, ObjectReference akPart) Global
	Float a = akMain.GetAngleZ()
	Float px = StorageUtil.FloatListGet(akPart, "csn_st_off", 0)
	Float py = StorageUtil.FloatListGet(akPart, "csn_st_off", 1)
	Float ox = px * Math.Cos(a) + py * Math.Sin(a)
	Float oy = py * Math.Cos(a) - px * Math.Sin(a)
	akPart.SetPosition(akMain.GetPositionX() + ox, akMain.GetPositionY() + oy, akMain.GetPositionZ() + StorageUtil.FloatListGet(akPart, "csn_st_off", 2))
	akPart.SetAngle(0.0, 0.0, a + StorageUtil.FloatListGet(akPart, "csn_st_off", 3))
EndFunction

; abShow False hides them (while the building is being moved); True puts them back in place and shows them
Function ShowParts(ObjectReference akMain, Bool abShow) Global
	ObjectReference old = StorageUtil.GetFormValue(akMain, "csn_st_part") as ObjectReference   ; mills built before 2.0.10
	If old
		If abShow
			old.SetPosition(akMain.GetPositionX(), akMain.GetPositionY(), akMain.GetPositionZ())
			old.SetAngle(0.0, 0.0, akMain.GetAngleZ())
			old.Enable()
		Else
			old.Disable()
		EndIf
	EndIf
	Int i = 0
	While i < StorageUtil.FormListCount(akMain, "csn_st_parts")
		ObjectReference pr = StorageUtil.FormListGet(akMain, "csn_st_parts", i) as ObjectReference
		If pr
			If abShow
				PositionPart(akMain, pr)
				pr.Enable()
			Else
				pr.Disable()
			EndIf
		EndIf
		i += 1
	EndWhile
EndFunction

Function DeleteParts(ObjectReference akMain) Global
	ObjectReference old = StorageUtil.GetFormValue(akMain, "csn_st_part") as ObjectReference
	If old
		old.Disable()
		old.Delete()
	EndIf
	Int i = 0
	While i < StorageUtil.FormListCount(akMain, "csn_st_parts")
		ObjectReference pr = StorageUtil.FormListGet(akMain, "csn_st_parts", i) as ObjectReference
		If pr
			StorageUtil.FloatListClear(pr, "csn_st_off")
			pr.Disable()
			pr.Delete()
		EndIf
		i += 1
	EndWhile
	StorageUtil.FormListClear(akMain, "csn_st_parts")
	StorageUtil.UnsetFormValue(akMain, "csn_st_part")
EndFunction

; =============================================================================
; MOVE A BUILDING (no cost)
; =============================================================================
Bool Function MoveBuilding(Int k, Int aiIndex) Global
	If !CanPlaceIn(k)
		Return False
	EndIf
	Int t = StorageUtil.IntListGet(None, SK(k, "types"), aiIndex)
	ObjectReference r = StorageUtil.FormListGet(None, SK(k, "refs"), aiIndex) as ObjectReference
	If t < 0 || !r
		CSN_Gov.Fail("That building is gone.")
		Return False
	EndIf
	Actor p = Game.GetPlayer()
	If !r.Is3DLoaded()
		CSN_Gov.Fail("Go nearer the " + TypeName(t) + " to move it.")
		Return False
	EndIf
	M().CloseScreen()
	Utility.Wait(0.3)
	String[] go = new String[2]
	go[0] = "Pick it up"
	go[1] = "Cancel"
	If CSNP.Choose("Moving: " + TypeName(t), ControlsText() + "\n\nMoving it is free. Cancel (Backspace) puts it back where it stood.", go) != 0
		Return False
	EndIf
	StorageUtil.SetFloatValue(None, "csn_st_ox", r.GetPositionX())
	StorageUtil.SetFloatValue(None, "csn_st_oy", r.GetPositionY())
	StorageUtil.SetFloatValue(None, "csn_st_oz", r.GetPositionZ())
	StorageUtil.SetFloatValue(None, "csn_st_oa", r.GetAngleZ())
	; the field's other plants and the building's parts wait out of sight, then follow it
	Int n = 1
	While n < Col(t, 14)
		ObjectReference pl = StorageUtil.FormListGet(None, SK(k, "refs"), aiIndex + n) as ObjectReference
		If pl
			pl.Disable()
		EndIf
		n += 1
	EndWhile
	ShowParts(r, False)
	Float d = p.GetDistance(r)
	If d < 150.0
		d = Reach(t)
	EndIf
	Float rot = r.GetAngleZ() - p.GetAngleZ()
	BeginPlacing(k, t, r, 1, aiIndex, d, rot, r.GetPositionZ() - p.GetPositionZ())
	Return True
EndFunction

Function SettleMoved(Int k, Int aiIndex, ObjectReference r, Bool abMoved) Global
	r.Disable()
	r.Enable()
	LayField(k, aiIndex)
	ShowParts(r, True)
	If abMoved
		Untrack(r)   ; SkyBuild forgets where it stood, then learns where it stands now
		Track(r)
	EndIf
	If abMoved
		Int t = StorageUtil.IntListGet(None, SK(k, "types"), aiIndex)
		CSN_Gov.Say(TypeName(t) + " moved.")
	EndIf
EndFunction

; =============================================================================
; READY-MADE LAYOUTS: several buildings placed together around the first
; name|what it is for|type:x:y:turn;type:x:y:turn;...  (x/y in units around the first building)
; =============================================================================
Int Function LayoutCount() Global
	Return 6
EndFunction

String[] Function LayoutRow(Int L) Global
	String s = ""
	If L == 0
		s = "Starter camp|Beds, a fire, water and a first field: the first settlers move in.|0:0:0:0;23:0:-520:0;22:620:-480:0;5:-620:-520:0"
	ElseIf L == 1
		s = "Farmstead|A farmhouse with three fields, a beehive and a well: food for the faction.|2:0:0:0;7:-520:-820:0;6:0:-820:0;5:520:-820:0;8:960:0:0;22:-1020:0:0"
	ElseIf L == 2
		s = "Lumber camp|A lumber mill with its saw, a chopping block, a tent and a fire: wood every day.|11:0:0:0;12:720:-300:0;0:-1000:0:0;23:-1000:-560:0"
	ElseIf L == 3
		s = "Mining camp|A smelter, forge and anvil with a tent and a fire: metal and smiths.|13:0:0:0;15:520:0:0;16:860:0:0;0:0:-760:0;23:640:-700:0"
	ElseIf L == 4
		s = "Outpost|A watchtower behind three barricades, a dummy and a target: defence and sellswords.|25:0:0:0;27:-460:-520:0;27:0:-560:0;27:460:-520:0;28:560:260:0;29:-560:260:0"
	ElseIf L == 5
		s = "Market square|Two market stalls, a well and a banner: gold and happier settlers.|21:-320:0:0;21:320:0:0;22:0:-560:0;24:0:340:0"
	EndIf
	Return PapyrusUtil.StringSplit(s, "|")
EndFunction

String Function LayoutName(Int L) Global
	String[] r = LayoutRow(L)
	If r.Length > 0
		Return r[0]
	EndIf
	Return ""
EndFunction

String[] Function LayoutPieces(Int L) Global
	String[] r = LayoutRow(L)
	If r.Length > 2
		Return PapyrusUtil.StringSplit(r[2], ";")
	EndIf
	Return PapyrusUtil.StringArray(0)
EndFunction

Int Function PieceType(String asPiece) Global
	String[] f = PapyrusUtil.StringSplit(asPiece, ":")
	Return f[0] as Int
EndFunction

; total of one catalogue column over a layout
Int Function LayoutSum(Int L, Int c) Global
	String[] ps = LayoutPieces(L)
	Int n = 0
	Int i = 0
	While i < ps.Length
		n += Col(PieceType(ps[i]), c)
		i += 1
	EndWhile
	Return n
EndFunction

String Function LayoutAfford(Int L) Global
	Int g = LayoutSum(L, 3)
	Int w = LayoutSum(L, 4)
	Int mt = LayoutSum(L, 5)
	If CSN_Gov.Treasury() < g
		Return "The treasury holds " + CSN_Gov.Treasury() + " gold; " + g + " needed."
	ElseIf CSN_Gov.Stock(2) < w
		Return "The faction has " + CSN_Gov.Stock(2) + " wood; " + w + " needed."
	ElseIf CSN_Gov.Stock(1) < mt
		Return "The faction has " + CSN_Gov.Stock(1) + " metal; " + mt + " needed."
	EndIf
	Return ""
EndFunction

String Function LayoutList(Int L) Global
	String[] ps = LayoutPieces(L)
	String s = ""
	Int i = 0
	While i < ps.Length
		s = CSN_Rebellion.AddTo(s, TypeName(PieceType(ps[i])))
		i += 1
	EndWhile
	Return s
EndFunction

Bool Function BuildLayout(Int k, Int L) Global
	If L < 0 || L >= LayoutCount() || !CanPlaceIn(k)
		Return False
	EndIf
	String err = LayoutAfford(L)
	If err != ""
		CSN_Gov.Fail(err)
		Return False
	EndIf
	String[] ps = LayoutPieces(L)
	Int t0 = PieceType(ps[0])
	Form b = Base(t0)
	If !b
		CSN_Gov.Fail("A building of that layout is missing from your game.")
		Return False
	EndIf
	M().CloseScreen()
	Utility.Wait(0.3)
	String[] go = new String[2]
	go[0] = "Start placing"
	go[1] = "Cancel"
	String cost = LayoutSum(L, 3) + " gold, " + LayoutSum(L, 4) + " wood, " + LayoutSum(L, 5) + " metal"
	If CSNP.Choose("Placing: " + LayoutName(L), "You place the " + TypeName(t0) + "; the rest (" + LayoutList(L) + ") is set around it when you place it, so pick fairly flat, open ground. Any piece can be moved afterwards.\n\n" + ControlsText() + "\n\nCost when placed: " + cost + ".", go) != 0
		Return False
	EndIf
	ObjectReference ghost = Game.GetPlayer().PlaceAtMe(b, 1, True, False)
	; the rest of the layout, shown while placing
	ClearLayoutPreview()
	Int i = 1
	While i < ps.Length
		Form pb = Base(PieceType(ps[i]))
		ObjectReference pr = None
		If pb
			pr = Game.GetPlayer().PlaceAtMe(pb, 1, True, False)
		EndIf
		StorageUtil.FormListAdd(None, "csn_st_lay", pr, True)
		i += 1
	EndWhile
	BeginPlacing(k, t0, ghost, 2, L, 1200.0, 180.0, GroundOff(t0))
	Return True
EndFunction

; where piece i (1 on) of layout L stands when its first building is at x, y, z facing ang; the others stand on the
; same ground as the first (the watchtower's floor, not its origin)
Function LayoutPreview(Int L, Float x, Float y, Float z, Float ang, Bool abSnap) Global
	String[] ps = LayoutPieces(L)
	Float ground = z - GroundOff(PieceType(ps[0]))
	Int i = 1
	While i < ps.Length
		ObjectReference r = StorageUtil.FormListGet(None, "csn_st_lay", i - 1) as ObjectReference
		If r
			String[] f = PapyrusUtil.StringSplit(ps[i], ":")
			Int t = f[0] as Int
			Float px = f[1] as Float
			Float py = f[2] as Float
			Float ox = px * Math.Cos(ang) + py * Math.Sin(ang)
			Float oy = py * Math.Cos(ang) - px * Math.Sin(ang)
			Float pz = ground + GroundOff(t)
			Float pa = ang + (f[3] as Float)
			If abSnap
				r.SetPosition(x + ox, y + oy, pz)
				r.SetAngle(0.0, 0.0, pa)
			Else
				r.TranslateTo(x + ox, y + oy, pz, 0.0, 0.0, pa, 3000.0, 720.0)
			EndIf
		EndIf
		i += 1
	EndWhile
EndFunction

Function ClearLayoutPreview() Global
	Int i = 0
	While i < StorageUtil.FormListCount(None, "csn_st_lay")
		ObjectReference r = StorageUtil.FormListGet(None, "csn_st_lay", i) as ObjectReference
		If r
			r.Disable()
			r.Delete()
		EndIf
		i += 1
	EndWhile
	StorageUtil.FormListClear(None, "csn_st_lay")
EndFunction

Function PlaceLayout(Int k, Int L, ObjectReference akGhost) Global
	String err = LayoutAfford(L)
	If err != ""
		CSN_Gov.Fail(err)
		akGhost.Disable()
		akGhost.Delete()
		ClearLayoutPreview()
		Return
	EndIf
	String[] ps = LayoutPieces(L)
	Place(k, PieceType(ps[0]), akGhost, True)
	Int i = 1
	While i < ps.Length
		ObjectReference r = StorageUtil.FormListGet(None, "csn_st_lay", i - 1) as ObjectReference
		If r
			Place(k, PieceType(ps[i]), r, True)
		EndIf
		i += 1
	EndWhile
	StorageUtil.FormListClear(None, "csn_st_lay")   ; they are buildings now
	CSN_Gov.Say(LayoutName(L) + " built in " + Name(k) + ".")
	CSN_SkyrimNet.LogEvent(Game.GetPlayer().GetDisplayName() + " built a " + LayoutName(L) + " (" + LayoutList(L) + ") in the settlement of " + Name(k) + ".", None, Game.GetPlayer())
EndFunction

; =============================================================================
; BUILDINGS NEAREST FIRST (Take down / Move)
; =============================================================================
Float Function DistTo(ObjectReference r) Global
	If r && r.Is3DLoaded()
		Return Game.GetPlayer().GetDistance(r)
	EndIf
	Return 99999999.0
EndFunction

; indices of a settlement's buildings (fields once), nearest first; ones out of sight last
Int[] Function ByDistance(Int k) Global
	Int[] at = PapyrusUtil.IntArray(0)
	Float[] ds = PapyrusUtil.FloatArray(0)
	Int i = 0
	Int count = StorageUtil.IntListCount(None, SK(k, "types"))
	While i < count
		If StorageUtil.IntListGet(None, SK(k, "types"), i) >= 0
			Float d = DistTo(StorageUtil.FormListGet(None, SK(k, "refs"), i) as ObjectReference)
			; insert in order
			Int j = ds.Length
			at = PapyrusUtil.PushInt(at, i)
			ds = PapyrusUtil.PushFloat(ds, d)
			While j > 0 && ds[j - 1] > d
				ds[j] = ds[j - 1]
				at[j] = at[j - 1]
				j -= 1
			EndWhile
			ds[j] = d
			at[j] = i
		EndIf
		i += 1
	EndWhile
	Return at
EndFunction

; paces from the player, -1 when out of sight
Int Function Paces(Int k, Int aiIndex) Global
	Float d = DistTo(StorageUtil.FormListGet(None, SK(k, "refs"), aiIndex) as ObjectReference)
	If d >= 99999999.0
		Return -1
	EndIf
	Return (d / 70.0) as Int
EndFunction

String Function PacesText(Int k, Int aiIndex) Global
	Int n = Paces(k, aiIndex)
	If n < 0
		Return " (out of sight)"
	EndIf
	Return " (" + n + " paces away)"
EndFunction

; list of a settlement's buildings, nearest first; abMove: move instead of take down
Bool Function RemoveMenu(Int k, Bool abMove = False) Global
	If !Exists(k)
		Return False
	EndIf
	Int[] at = ByDistance(k)
	If at.Length == 0
		CSN_Gov.Fail(Name(k) + " has no buildings yet.")
		Return False
	EndIf
	String[] labels = PapyrusUtil.StringArray(0)
	Int i = 0
	While i < at.Length
		labels = PapyrusUtil.PushString(labels, TypeName(StorageUtil.IntListGet(None, SK(k, "types"), at[i])) + PacesText(k, at[i]))
		i += 1
	EndWhile
	labels = PapyrusUtil.PushString(labels, "Cancel")
	String title = "Take down a building"
	String body = "Nearest first. Half of its gold, wood and metal comes back."
	If abMove
		title = "Move a building"
		body = "Nearest first. Moving is free: pick it up, place it again."
	EndIf
	Int pick = CSNP.Choose(title, body, labels)
	If pick < 0 || pick >= at.Length
		Return False
	EndIf
	If abMove
		Return MoveBuilding(k, at[pick])
	EndIf
	RemoveAt(k, at[pick])
	M().Refresh()
	Return True
EndFunction

; Take down one building from the screen, after a yes
Bool Function TakeDown(Int k, Int aiIndex) Global
	If !Exists(k) || aiIndex < 0 || aiIndex >= StorageUtil.IntListCount(None, SK(k, "types"))
		Return False
	EndIf
	Int t = StorageUtil.IntListGet(None, SK(k, "types"), aiIndex)
	If t < 0
		Return False
	EndIf
	If !CSNP.Confirm("Take down", "Take down the " + TypeName(t) + PacesText(k, aiIndex) + "?\n\nBack: " + (Col(t, 3) / 2) + " gold, " + (Col(t, 4) / 2) + " wood, " + (Col(t, 5) / 2) + " metal.", "Take it down", "Keep it")
		Return False
	EndIf
	RemoveAt(k, aiIndex)
	Return True
EndFunction

Function RemoveAt(Int k, Int aiIndex) Global
	CSN_Core m = M()
	Int t = StorageUtil.IntListGet(None, SK(k, "types"), aiIndex)
	Int pieces = 1
	If t >= 0
		pieces = Col(t, 14)
		m.Econ().Treasury.Mod(Col(t, 3) / 2)
		m.Gov.EconUpdater.WoodTotalPlayer.Mod(Col(t, 4) / 2)
		m.Gov.EconUpdater.MetalTotalPlayer.Mod(Col(t, 5) / 2)
	EndIf
	Int n = 0
	While n < pieces
		ObjectReference r = StorageUtil.FormListGet(None, SK(k, "refs"), aiIndex) as ObjectReference
		If r
			Untrack(r)
			DeleteParts(r)
			r.Disable()
			r.Delete()
		EndIf
		StorageUtil.FormListRemoveAt(None, SK(k, "refs"), aiIndex)
		StorageUtil.IntListRemoveAt(None, SK(k, "types"), aiIndex)
		n += 1
	EndWhile
	If t >= 0
		CSN_Gov.Say(TypeName(t) + " taken down in " + Name(k) + ".")
	EndIf
EndFunction

; =============================================================================
; DAILY LIFE
; =============================================================================
Function Tick() Global
	If Count() <= 0
		Return
	EndIf
	Int d = Today()
	If StorageUtil.GetIntValue(None, "csn_st_day", -1) == d
		Return
	EndIf
	StorageUtil.SetIntValue(None, "csn_st_day", d)
	CSN_Core m = M()
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			Daily(k)
		EndIf
		k += 1
	EndWhile
	m.Gov.EconUpdater.CalculatePlayerPerDay()
EndFunction

Function Daily(Int k) Global
	CSN_Core m = M()
	; mood from events fades by a third each day
	Int mood = StorageUtil.GetIntValue(None, SK(k, "mood"), 0)
	StorageUtil.SetIntValue(None, SK(k, "mood"), mood * 2 / 3)
	Int happy = Happiness(k)
	Int pop = Pop(k)
	Int beds = Housing(k)
	; settlers come while there are beds and people are content; they leave when unhappy
	If pop < beds && happy >= 40
		Int n = 1
		If happy >= 70 && beds - pop >= 2
			n = 2
		EndIf
		Arrive(k, n)
	ElseIf happy < 25 && pop > 0
		Leave(k, 1)
		CSN_Gov.Say("A family left " + Name(k) + ": people there are unhappy.")
	EndIf
	; production to the faction's stocks
	Int food = FoodNet(k)
	Int wood = Output(k, 8)
	Int metal = Output(k, 9)
	Int gold = GoldDay(k)
	m.Holdings().FoodReserve.Mod(food)
	m.Gov.EconUpdater.WoodTotalPlayer.Mod(wood)
	m.Gov.EconUpdater.MetalTotalPlayer.Mod(metal)
	m.Econ().Treasury.Mod(gold)
	StorageUtil.SetStringValue(None, SK(k, "last"), "food " + Signed(food) + ", wood +" + wood + ", metal +" + metal + ", gold +" + gold)
	; raids
	Int chance = RaidChance(k)
	If chance > 0 && Utility.RandomInt(1, 100) <= chance
		Raid(k)
	EndIf
EndFunction

; daily chance (%) of a bandit raid: 10, minus the defence, plus 1 for every 10 happiness under 50; at least 2 once
; anything is built; none within 3 days of the last raid
Int Function RaidChance(Int k) Global
	If Pop(k) <= 0 && StorageUtil.IntListCount(None, SK(k, "types")) == 0
		Return 0
	EndIf
	If Today() - StorageUtil.GetIntValue(None, SK(k, "raid"), -10) < 3
		Return 0
	EndIf
	Int chance = 10 - Defense(k) + (50 - Happiness(k)) / 10
	If chance < 2
		chance = 2
	EndIf
	Return chance
EndFunction

String Function Signed(Int n) Global
	If n >= 0
		Return "+" + n
	EndIf
	Return "" + n
EndFunction

Function Arrive(Int k, Int n) Global
	StorageUtil.AdjustIntValue(None, SK(k, "pop"), n)
	; a few settlers are there to see (up to eight), the rest are counted
	Int shown = StorageUtil.FormListCount(None, SK(k, "people"))
	ObjectReference h = Heart(k)
	Int i = 0
	While i < n && shown < 8 && h
		ActorBase b = SettlerBase(k)
		If b
			Actor a = h.PlaceActorAtMe(b)
			StorageUtil.SetIntValue(a, "csn_settler", k + 1)
			StorageUtil.FormListAdd(None, SK(k, "people"), a)
			Sandbox(a)
			shown += 1
		EndIf
		i += 1
	EndWhile
	If n > 0
		CSN_Gov.Say(n + " settler(s) arrived in " + Name(k) + ".")
	EndIf
EndFunction

; Settlers live in their settlement: they wander it, sit, sleep in its beds and use its fires, chopping blocks,
; workbenches and stalls (Skyrim's own sandbox package, around where they are, over their own AI).
Function Sandbox(Actor a) Global
	If !a || StorageUtil.GetIntValue(a, "csn_sandbox", 0) == 1
		Return
	EndIf
	Package pk = Game.GetFormFromFile(0x0BFB6B, "Skyrim.esm") as Package   ; DefaultSandboxCurrentLocation1024 (near self)
	If pk
		ActorUtil.AddPackageOverride(a, pk, 100)
		a.EvaluatePackage()
		StorageUtil.SetIntValue(a, "csn_sandbox", 1)
	EndIf
EndFunction

; "Fix settlers": everyone is brought back to the banner post, given their settlement life again and told to get
; on with it; the missing are replaced (up to eight to see).
Function FixSettlers(Int k) Global
	If !Exists(k)
		Return
	EndIf
	ObjectReference h = Heart(k)
	Package pk = Game.GetFormFromFile(0x0BFB6B, "Skyrim.esm") as Package
	Int fixed = 0
	Int i = StorageUtil.FormListCount(None, SK(k, "people")) - 1
	While i >= 0
		Actor a = StorageUtil.FormListGet(None, SK(k, "people"), i) as Actor
		If !a || a.IsDead()
			StorageUtil.FormListRemoveAt(None, SK(k, "people"), i)
		Else
			If pk
				ActorUtil.RemovePackageOverride(a, pk)
			EndIf
			StorageUtil.UnsetIntValue(a, "csn_sandbox")
			If a.IsDisabled()
				a.Enable()
			EndIf
			a.StopCombat()
			If h && (a.GetDistance(h) > 1500.0 || a.GetWorldSpace() != h.GetWorldSpace())
				a.MoveTo(h, Utility.RandomFloat(-400.0, 400.0), Utility.RandomFloat(-400.0, 400.0), 0.0)
			EndIf
			Sandbox(a)
			a.EvaluatePackage()
			fixed += 1
		EndIf
		i -= 1
	EndWhile
	; the ones to see who went missing come back
	Int want = Pop(k)
	If want > 8
		want = 8
	EndIf
	Int shown = StorageUtil.FormListCount(None, SK(k, "people"))
	Int added = 0
	While shown < want && h
		ActorBase b = SettlerBase(k)
		If b
			Actor na = h.PlaceActorAtMe(b)
			StorageUtil.SetIntValue(na, "csn_settler", k + 1)
			StorageUtil.FormListAdd(None, SK(k, "people"), na)
			Sandbox(na)
			added += 1
		EndIf
		shown += 1
	EndWhile
	String msg = "Settlers of " + Name(k) + " sorted out: " + fixed + " back at work"
	If added > 0
		msg += ", " + added + " missing replaced"
	EndIf
	CSN_Gov.Say(msg + ".")
EndFunction

; ---- who moves in: the work the settlement offers draws its people ------------------------------
; 0 farmers (fields, beehives, windmills, sheds), 1 woodsmen (lumber mill, chopping block), 2 miners and smiths
; (smelter, smithy, forge, anvil), 3 traders (inn, market stalls), 4 an alchemist (alchemy lab), 5 sellswords
; (watchtower, walls, barricades, dummies, targets). Farmers always come in some number.
Int Function Weight(Int k, Int aiKind) Global
	If aiKind == 0
		Return 1 + Sum(k, 7)
	ElseIf aiKind == 1
		Return Sum(k, 8)
	ElseIf aiKind == 2
		Return Sum(k, 9) + Built(k, 15) + Built(k, 16)
	ElseIf aiKind == 3
		Return Sum(k, 10) / 10
	ElseIf aiKind == 4
		Return 2 * Built(k, 18)
	ElseIf aiKind == 5
		Return Sum(k, 12)
	EndIf
	Return 0
EndFunction

; how many of catalogue entry t stand in settlement k
Int Function Built(Int k, Int t) Global
	Int n = 0
	Int i = 0
	Int count = StorageUtil.IntListCount(None, SK(k, "types"))
	While i < count
		If StorageUtil.IntListGet(None, SK(k, "types"), i) == t
			n += 1
		EndIf
		i += 1
	EndWhile
	Return n
EndFunction

String Function KindName(Int aiKind) Global
	String[] nm = new String[6]
	nm[0] = "farmers"
	nm[1] = "woodsmen"
	nm[2] = "miners and smiths"
	nm[3] = "traders"
	nm[4] = "an alchemist"
	nm[5] = "sellswords"
	Return nm[aiKind]
EndFunction

ActorBase Function SettlerBase(Int k) Global
	Int total = 0
	Int kd = 0
	While kd < 6
		total += Weight(k, kd)
		kd += 1
	EndWhile
	Int roll = Utility.RandomInt(1, total)
	Int kind = 0
	kd = 0
	While kd < 6
		roll -= Weight(k, kd)
		If roll <= 0
			kind = kd
			kd = 6
		EndIf
		kd += 1
	EndWhile
	Int[] ids = new Int[3]
	If kind == 1
		ids[0] = 0x0BFB48   ; EncHunterNordF
		ids[1] = 0x0D9448   ; EncOrcHunter01M
		ids[2] = 0x0BFB45   ; EncHunterImperialF
	ElseIf kind == 2
		ids[0] = 0x103532   ; MG02Miner01
		ids[1] = 0x103533   ; MG02Miner02
		ids[2] = 0x103534   ; MG02Miner03
	ElseIf kind == 3
		ids[0] = 0x0BBCD2   ; WEMerchantMiscMaleCommoner
		ids[1] = 0x0B5D5A   ; WEMerchantMiscFemaleCommoner
		ids[2] = 0x0BBCD2
	ElseIf kind == 4
		ids[0] = 0x074937   ; WE30Alchemist
		ids[1] = 0x074937
		ids[2] = 0x074937
	ElseIf kind == 5
		ids[0] = 0x103503   ; WEAdventurerWarriorNordF
		ids[1] = 0x103504   ; WEAdventurerWarriorRedguardM
		ids[2] = 0x105555   ; WEAdventurerWarriorOrcF
	Else
		ids[0] = 0x1034E4   ; WEFarmerMale
		ids[1] = 0x1034E6   ; WEFarmerFemale
		ids[2] = 0x106A61   ; WEFarmerMale02
	EndIf
	ActorBase b = Game.GetFormFromFile(ids[Utility.RandomInt(0, 2)], "Skyrim.esm") as ActorBase
	If !b
		b = Game.GetFormFromFile(0x1034E4, "Skyrim.esm") as ActorBase
	EndIf
	Return b
EndFunction

; "farmers 50%, miners and smiths 25%, ..." for the faction screen
String Function MixText(Int k) Global
	Int total = 0
	Int kd = 0
	While kd < 6
		total += Weight(k, kd)
		kd += 1
	EndWhile
	String s = ""
	kd = 0
	While kd < 6
		Int w = Weight(k, kd)
		If w > 0
			If s != ""
				s += ", "
			EndIf
			s += KindName(kd) + " " + (w * 100 / total) + "%"
		EndIf
		kd += 1
	EndWhile
	Return s
EndFunction

; ---- navmesh (through SkyBuild) -----------------------------------------------------------------
; 0 SkyBuild isn't installed, 1 it is but can't be asked from here (an unpatched SkyBuild.dll), 2 ready
Int Function NavmeshSupport() Global
	If SKSE.GetPluginVersion("SkyBuild") < 0
		Return 0
	EndIf
	If SkyBuildNative.NavmeshApiVersion() >= 1
		Return 2   ; (with version 2 the settlement's buildings are added to SkyBuild's placed objects as well)
	EndIf
	Return 1
EndFunction

; ---- SkyBuild: our buildings join its placed objects, so its navmesh cuts around them like its own pieces ----
Bool Function CanTrack() Global
	Return SKSE.GetPluginVersion("SkyBuild") >= 0 && SkyBuildNative.NavmeshApiVersion() >= 2
EndFunction

Function Track(ObjectReference r) Global
	If !r || !CanTrack()
		Return
	EndIf
	SkyBuildNative.TrackObject(r)
	Int i = 0
	While i < StorageUtil.FormListCount(r, "csn_st_parts")
		ObjectReference pr = StorageUtil.FormListGet(r, "csn_st_parts", i) as ObjectReference
		If pr
			SkyBuildNative.TrackObject(pr)
		EndIf
		i += 1
	EndWhile
	ObjectReference old = StorageUtil.GetFormValue(r, "csn_st_part") as ObjectReference
	If old
		SkyBuildNative.TrackObject(old)
	EndIf
EndFunction

Function Untrack(ObjectReference r) Global
	If !r || !CanTrack()
		Return
	EndIf
	SkyBuildNative.UntrackObject(r)
	Int i = 0
	While i < StorageUtil.FormListCount(r, "csn_st_parts")
		ObjectReference pr = StorageUtil.FormListGet(r, "csn_st_parts", i) as ObjectReference
		If pr
			SkyBuildNative.UntrackObject(pr)
		EndIf
		i += 1
	EndWhile
	ObjectReference old = StorageUtil.GetFormValue(r, "csn_st_part") as ObjectReference
	If old
		SkyBuildNative.UntrackObject(old)
	EndIf
EndFunction

; every building of a settlement (built before SkyBuild knew about them, too); fields' plants are left out
Int Function TrackAll(Int k) Global
	If !CanTrack() || !Exists(k)
		Return 0
	EndIf
	Int n = 0
	Int i = 0
	Int count = StorageUtil.IntListCount(None, SK(k, "types"))
	While i < count
		If StorageUtil.IntListGet(None, SK(k, "types"), i) >= 0
			ObjectReference r = StorageUtil.FormListGet(None, SK(k, "refs"), i) as ObjectReference
			If r && !SkyBuildNative.IsTracked(r)
				Track(r)
				n += 1
			EndIf
		EndIf
		i += 1
	EndWhile
	Return n
EndFunction

; Rebuild the navmesh around the player (SkyBuild's runtime generation, as its tool wheel's "Navmesh" does) so
; settlers, soldiers and followers walk around what was built. Progress shows top left.
Function UpdateNavmesh() Global
	CSN_Core m = M()
	Int sup = NavmeshSupport()
	If sup == 0
		CSN_Gov.Fail("Updating the navmesh needs SkyBuild (an SKSE plugin) installed.")
		Return
	ElseIf sup == 1
		CSN_Gov.Fail("Your SkyBuild can't be asked from here. Reinstall Conquest of SkyrimNet with the SkyBuild option ticked and load it after SkyBuild, or use SkyBuild's hammer wheel > Navmesh.")
		Return
	EndIf
	If SkyBuildNative.NavmeshBusy()
		CSN_Gov.Say("The navmesh is already being updated.")
		Return
	EndIf
	m.CloseScreen()
	; the settlement's buildings, so the new navmesh goes around them
	Int here = Here()
	If here >= 0 && TrackAll(here) > 0
		Utility.WaitMenuMode(1.0)
	EndIf
	Debug.Notification("Updating the navmesh around you...")
	; SkyBuild sometimes trips over a door whose navmesh it changed earlier; a second try usually goes through
	Int r = NavmeshTry()
	If r == 1
		Debug.Notification("SkyBuild hit a snag; trying again...")
		Utility.WaitMenuMode(3.0)
		r = NavmeshTry()
	EndIf
	If r == 0
		Debug.Notification("Navmesh updated: settlers and soldiers can walk around your buildings.")
	ElseIf r == 1
		String why = SkyBuildNative.NavmeshMessage()
		CSN_Config.Log("navmesh: failed twice (" + why + ")")
		If StringUtil.Find(why, "door") >= 0
			CSN_Gov.Fail("SkyBuild couldn't rebuild the navmesh next to a door it changed earlier. Step away from doors (and the watchtower) and try again, or save, reload and try again.")
		Else
			CSN_Gov.Fail("The navmesh update failed: " + why)
		EndIf
	ElseIf r == 2
		CSN_Gov.Say("The navmesh update is taking long; SkyBuild carries on in the background.")
	EndIf
EndFunction

; one request: 0 done, 1 failed, 2 still running after 4 minutes, 3 not accepted
Int Function NavmeshTry() Global
	If !SkyBuildNative.RequestNavmesh()
		CSN_Gov.Fail("SkyBuild didn't accept the navmesh request.")
		Return 3
	EndIf
	CSN_Config.Log("navmesh: requested from SkyBuild")
	Float started = Utility.GetCurrentRealTime()
	Float lastNote = started
	Bool began = False
	Int st = 0
	While Utility.GetCurrentRealTime() - started < 240.0
		Utility.WaitMenuMode(1.0)
		st = SkyBuildNative.NavmeshStage()
		If st == 2 || st == 3 || SkyBuildNative.NavmeshBusy()
			began = True
			If Utility.GetCurrentRealTime() - lastNote >= 5.0
				lastNote = Utility.GetCurrentRealTime()
				Int pct = (SkyBuildNative.NavmeshProgress() * 100.0) as Int
				Debug.Notification("Updating the navmesh: " + pct + "%")
			EndIf
		ElseIf st == 4 && (began || Utility.GetCurrentRealTime() - started > 3.0)
			CSN_Config.Log("navmesh: done (" + SkyBuildNative.NavmeshMessage() + ")")
			Return 0
		ElseIf st == 5
			CSN_Config.Log("navmesh: failed (" + SkyBuildNative.NavmeshMessage() + ")")
			Return 1
		ElseIf st == 1 && began
			Return 0
		EndIf
	EndWhile
	Return 2
EndFunction

Function Leave(Int k, Int n) Global
	Int pop = Pop(k) - n
	If pop < 0
		pop = 0
	EndIf
	StorageUtil.SetIntValue(None, SK(k, "pop"), pop)
	While StorageUtil.FormListCount(None, SK(k, "people")) > pop
		Int last = StorageUtil.FormListCount(None, SK(k, "people")) - 1
		Actor a = StorageUtil.FormListGet(None, SK(k, "people"), last) as Actor
		If a && !a.Is3DLoaded()
			a.Disable()
			a.Delete()
		EndIf
		StorageUtil.FormListRemoveAt(None, SK(k, "people"), last)
	EndWhile
EndFunction

Function Raid(Int k) Global
	StorageUtil.SetIntValue(None, SK(k, "raid"), Today())
	String nm = Name(k)
	Int bandits = 3 + Utility.RandomInt(0, 4)
	If Here() == k
		; the player is there: a real fight
		ObjectReference h = Heart(k)
		ActorBase melee = Game.GetFormFromFile(0x01af77, "Skyrim.esm") as ActorBase   ; LvlBanditMeleeCommonerM
		ActorBase bow = Game.GetFormFromFile(0x01b0be, "Skyrim.esm") as ActorBase     ; LvlBanditMissileCommonerM
		Int i = 0
		While i < bandits
			ActorBase b = melee
			If i % 3 == 2
				b = bow
			EndIf
			Actor r = h.PlaceActorAtMe(b)
			r.MoveTo(h, 2500.0 * Math.Sin(i * 60.0), 2500.0 * Math.Cos(i * 60.0), 0.0)
			r.StartCombat(Game.GetPlayer())
			i += 1
		EndWhile
		CSNP.Notice("Bandits are raiding " + nm + "!")
		StorageUtil.AdjustIntValue(None, SK(k, "mood"), 5)
		Return
	EndIf
	Int def = Defense(k)
	If def * 3 + Utility.RandomInt(0, 10) >= bandits * 4
		StorageUtil.AdjustIntValue(None, SK(k, "mood"), 8)
		CSN_Gov.Say("Bandits attacked " + nm + " and were driven off.")
		CSN_World.AddNews(-1, "The settlers of " + nm + " drove off a bandit raid.", "csn_settlement_raid")
		Return
	EndIf
	; lost: a building burns and some settlers flee
	Int count = StorageUtil.IntListCount(None, SK(k, "types"))
	String lost = ""
	If count > 0
		Int tries = 0
		While tries < 6 && lost == ""
			Int at = Utility.RandomInt(0, count - 1)
			Int t = StorageUtil.IntListGet(None, SK(k, "types"), at)
			If t >= 0
				lost = TypeName(t)
				RemoveBurnt(k, at, t)
			EndIf
			tries += 1
		EndWhile
	EndIf
	Leave(k, 2)
	StorageUtil.AdjustIntValue(None, SK(k, "mood"), -15)
	If ArmyRaised(k)
		CSN_Rebellion.ModMorale(ArmySlot(k), -10, "bandits raided " + nm + ", the settlement it was raised from")
	EndIf
	String txt = "Bandits raided " + nm + "."
	If lost != ""
		txt += " The " + lost + " was burnt down."
	EndIf
	txt += " Build watchtowers and walls to keep them out."
	CSN_Gov.Say(txt)
	CSN_World.AddNews(-1, "Bandits raided the settlement of " + nm + ".", "csn_settlement_raid")
EndFunction

Function RemoveBurnt(Int k, Int aiIndex, Int t) Global
	Int pieces = Col(t, 14)
	Int n = 0
	While n < pieces
		ObjectReference r = StorageUtil.FormListGet(None, SK(k, "refs"), aiIndex) as ObjectReference
		If r
			Untrack(r)
			DeleteParts(r)
			r.Disable()
			r.Delete()
		EndIf
		StorageUtil.FormListRemoveAt(None, SK(k, "refs"), aiIndex)
		StorageUtil.IntListRemoveAt(None, SK(k, "types"), aiIndex)
		n += 1
	EndWhile
EndFunction

; every 5 seconds: settlers who wandered off are brought home while nobody is looking
Function Watch() Global
	If Count() <= 0
		Return
	EndIf
	Int k = Here()
	If k < 0
		Return
	EndIf
	UpgradeBanner(k)
	ObjectReference h = Heart(k)
	Int i = StorageUtil.FormListCount(None, SK(k, "people")) - 1
	While i >= 0
		Actor a = StorageUtil.FormListGet(None, SK(k, "people"), i) as Actor
		If a && !a.IsDead()
			Sandbox(a)   ; settlers from before 2.0.15
		EndIf
		If a && !a.IsDead() && a.GetDistance(h) > Radius() && !Game.GetPlayer().HasLOS(a)
			a.MoveTo(h, Utility.RandomFloat(-600.0, 600.0), Utility.RandomFloat(-600.0, 600.0), 0.0)
		ElseIf a && a.IsDead()
			StorageUtil.FormListRemoveAt(None, SK(k, "people"), i)
			StorageUtil.AdjustIntValue(None, SK(k, "pop"), -1)
		EndIf
		i -= 1
	EndWhile
EndFunction

; =============================================================================
; TEXT FOR THE SCREENS AND SKYRIMNET
; =============================================================================
String Function SummaryText(Int k) Global
	Return "Settlers " + Pop(k) + "/" + Housing(k) + " beds · happiness " + Happiness(k) + " · defence " + Defense(k) + " · jobs " + Jobs(k) + " (" + Staffed(k) + "% filled)"
EndFunction

String Function Json() Global
	CSN_Core m = M()
	Int here = Here()
	String s = "{\"on\":" + m.B(Enabled()) + ",\"nav\":" + NavmeshSupport() + ",\"here\":" + here
	s += ",\"grid\":" + GridSize() + ",\"turn\":" + TurnStep() + ",\"tg\":" + CSN_Gov.Treasury() + ",\"tw\":" + CSN_Gov.Stock(2) + ",\"tm\":" + CSN_Gov.Stock(1)
	s += ",\"cat\":" + CatJson() + ",\"lay\":" + LayJson() + ",\"block\":" + m.Q(FoundBlock()) + ",\"gold\":" + FoundGold() + ",\"wood\":" + FoundWood() + ",\"list\":["
	Bool first = True
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			If !first
				s += ","
			EndIf
			first = False
			s += "{\"k\":" + k + ",\"name\":" + m.Q(Name(k)) + ",\"hold\":" + m.Q(m.HoldName(HoldOf(k))) + ",\"pop\":" + Pop(k) + ",\"beds\":" + Housing(k)
			s += ",\"happy\":" + Happiness(k) + ",\"def\":" + Defense(k) + ",\"jobs\":" + Jobs(k) + ",\"staffed\":" + Staffed(k)
			s += ",\"food\":" + FoodNet(k) + ",\"woodDay\":" + Output(k, 8) + ",\"metalDay\":" + Output(k, 9) + ",\"goldDay\":" + GoldDay(k)
			s += ",\"buildings\":" + m.Q(BuildingsText(k)) + ",\"mix\":" + m.Q(MixText(k))
			s += ",\"guards\":" + Guards(k) + ",\"armyslot\":" + ArmySlot(k) + ",\"raised\":" + m.B(ArmyRaised(k))
			If k == here
				; the buildings here, nearest first (for Move / Take down)
				s += ",\"bl\":["
				Int[] at = ByDistance(k)
				Int bi = 0
				While bi < at.Length
					If bi > 0
						s += ","
					EndIf
					s += "{\"i\":" + at[bi] + ",\"n\":" + m.Q(TypeName(StorageUtil.IntListGet(None, SK(k, "types"), at[bi]))) + ",\"d\":" + Paces(k, at[bi]) + "}"
					bi += 1
				EndWhile
				s += "]"
			EndIf
			s += "}"
		EndIf
		k += 1
	EndWhile
	Return s + "]}"
EndFunction

; the catalogue for the screen (made once; it only changes with the catalogue)
String Function CatJson() Global
	String cacheKey = "csn_st_catjson3"
	String c = StorageUtil.GetStringValue(None, cacheKey, "")
	If c != ""
		Return c
	EndIf
	CSN_Core m = M()
	c = "["
	Int t = 0
	While t < CatCount()
		If t > 0
			c += ","
		EndIf
		c += "{\"t\":" + t + ",\"n\":" + m.Q(TypeName(t)) + ",\"grp\":" + m.Q(Group(t)) + ",\"g\":" + Col(t, 3) + ",\"w\":" + Col(t, 4) + ",\"m\":" + Col(t, 5) + ",\"gives\":" + m.Q(GivesText(t)) + "}"
		t += 1
	EndWhile
	c += "]"
	StorageUtil.SetStringValue(None, cacheKey, c)
	Return c
EndFunction

String Function LayJson() Global
	String cacheKey = "csn_st_layjson3"
	String c = StorageUtil.GetStringValue(None, cacheKey, "")
	If c != ""
		Return c
	EndIf
	CSN_Core m = M()
	c = "["
	Int L = 0
	While L < LayoutCount()
		String[] r = LayoutRow(L)
		If L > 0
			c += ","
		EndIf
		c += "{\"l\":" + L + ",\"n\":" + m.Q(r[0]) + ",\"why\":" + m.Q(r[1]) + ",\"has\":" + m.Q(LayoutList(L)) + ",\"g\":" + LayoutSum(L, 3) + ",\"w\":" + LayoutSum(L, 4) + ",\"m\":" + LayoutSum(L, 5) + ",\"gives\":" + m.Q(LayoutGives(L)) + "}"
		L += 1
	EndWhile
	c += "]"
	StorageUtil.SetStringValue(None, cacheKey, c)
	Return c
EndFunction

String Function LayoutGives(Int L) Global
	String s = ""
	If LayoutSum(L, 6) > 0
		s = CSN_Rebellion.AddTo(s, "beds " + LayoutSum(L, 6))
	EndIf
	If LayoutSum(L, 7) > 0
		s = CSN_Rebellion.AddTo(s, "food +" + LayoutSum(L, 7))
	EndIf
	If LayoutSum(L, 8) > 0
		s = CSN_Rebellion.AddTo(s, "wood +" + LayoutSum(L, 8))
	EndIf
	If LayoutSum(L, 9) > 0
		s = CSN_Rebellion.AddTo(s, "metal +" + LayoutSum(L, 9))
	EndIf
	If LayoutSum(L, 10) > 0
		s = CSN_Rebellion.AddTo(s, "gold +" + LayoutSum(L, 10))
	EndIf
	If LayoutSum(L, 11) > 0
		s = CSN_Rebellion.AddTo(s, "happiness +" + LayoutSum(L, 11))
	EndIf
	If LayoutSum(L, 12) > 0
		s = CSN_Rebellion.AddTo(s, "defence +" + LayoutSum(L, 12))
	EndIf
	If LayoutSum(L, 13) > 0
		s = CSN_Rebellion.AddTo(s, LayoutSum(L, 13) + " jobs")
	EndIf
	Return s
EndFunction

String Function BuildingsText(Int k) Global
	Int[] counts = Utility.CreateIntArray(CatCount())
	Int i = 0
	Int n = StorageUtil.IntListCount(None, SK(k, "types"))
	While i < n
		Int t = StorageUtil.IntListGet(None, SK(k, "types"), i)
		If t >= 0
			counts[t] = counts[t] + 1
		EndIf
		i += 1
	EndWhile
	String s = ""
	Int t2 = 0
	While t2 < counts.Length
		If counts[t2] > 0
			String part = TypeName(t2)
			If counts[t2] > 1
				part = counts[t2] + " x " + part
			EndIf
			s = CSN_Rebellion.AddTo(s, part)
		EndIf
		t2 += 1
	EndWhile
	If s == ""
		s = "nothing built yet"
	EndIf
	Return s
EndFunction

String Function ListText() Global
	String s = ""
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			s = CSN_Rebellion.AddTo(s, Name(k) + " in " + M().HoldName(HoldOf(k)) + " (" + Pop(k) + " settlers, " + BuildingsText(k) + ")")
		EndIf
		k += 1
	EndWhile
	Return s
EndFunction

; how settlements and raids work, for those who run the faction's lands
String Function RulesText() Global
	String s = " How the faction's settlements work: the leader founds one on open land in a hold whose city or roads the faction holds (" + FoundGold() + " gold and " + FoundWood() + " wood), and builds within about 70 paces of its banner post: homes give beds (room for more settlers), fields, beehives, windmills and sheds give food, the lumber mill and chopping block wood, the smelter, smithy and forge metal, the inn, market stalls, anvil, tanning rack, alchemy lab and enchanter gold, wells and campfires food and happiness, banners gold and happiness, storage chests food and wood, fine chests and strongboxes gold, and watchtowers (+5 defence, +3 gold in tolls), weapon racks (+2), stockade walls, barricades, training dummies and archery targets (+1 defence and +1 gold each) defence. Every four settlers add 1 defence too, and each guard 3: the leader hires up to five guards at a settlement by activating its banner (paid like troops: " + CSN_Config.GuardCost() + " gold, then " + CSN_Config.TroopUpkeep() + " gold and 1 food a day). Each settlement lets the faction raise one more army; once that army is raised the settlement can't be abandoned, and every raid the bandits win there lowers that army's morale. Ready-made layouts (a starter camp, farmstead, lumber camp, mining camp, outpost or market square) place several buildings at once."
	s += " Settlers come while there are free beds and happiness is 40 or more, and leave below 25; they fill the jobs, and buildings with jobs produce only as far as they are staffed. Each day the food left after the settlers eat, the wood, the metal and the gold (plus 2 gold tax per settler) go to the faction's stores."
	s += " Raids: bandits can strike a settlement once a day at most every three days; the chance is 10% minus its defence, higher when people are unhappy (never under 2% once anything is built). If the leader is there they fight the bandits; otherwise the settlers hold if their defence is strong enough, or a building is burnt and two settlers flee. Driving raiders off cheers people up; losing to them does the opposite."
	s += " Separately, a free company of deserters raids the faction's own supply lines every day (20 gold and half a food for each of its soldiers) and may storm one of the faction's cities, as rebels in a city that has risen may."
	Return s
EndFunction

String Function StatusText(Int k) Global
	String s = Name(k) + " in " + M().HoldName(HoldOf(k)) + ": " + SummaryText(k) + "; a day: " + StorageUtil.GetStringValue(None, SK(k, "last"), "nothing yet")
	Int c = RaidChance(k)
	s += "; raid risk " + c + "% a day"
	Int last = StorageUtil.GetIntValue(None, SK(k, "raid"), -1)
	If last >= 0
		s += " (last raid " + (Today() - last) + " day(s) ago)"
	EndIf
	Return s + "; buildings: " + BuildingsText(k)
EndFunction

; town leaders (jarls, village leaders and their stewards) of the faction's towns, and the faction's Steward and General
Bool Function RunsLand(Actor akActor) Global
	CSN_Core m = M()
	Int role = m.GetRole(akActor)
	If role == m.ROLE_STEWARD || role == m.ROLE_GENERAL
		Return True
	EndIf
	Int i = 0
	While i < 15
		If CSN_World.PlayerRules(i) && CSN_World.TownJarl(i) == akActor
			Return True
		EndIf
		i += 1
	EndWhile
	Int c = CSN_Gov.CityStewardOf(akActor)
	Return c >= 0 && CSN_World.PlayerRules(c)
EndFunction

String Function Knowledge(Actor akActor) Global
	CSN_Core m = M()
	If !m || m.FactionStarted.GetValue() < 1 || !akActor || !Enabled()
		Return ""
	EndIf
	Int mine = StorageUtil.GetIntValue(akActor, "csn_settler", 0) - 1
	If mine >= 0 && Exists(mine)
		Return " " + m.PlainName(akActor) + " is a settler of " + StatusText(mine) + "." + RulesText()
	EndIf
	If !RunsLand(akActor)
		Return ""
	EndIf
	String s = RulesText()
	If Count() <= 0
		Return s + " The faction has no settlements yet."
	EndIf
	s += " The faction's settlements now:"
	Int k = 0
	While k < MaxSettlements()
		If Exists(k)
			s += " " + StatusText(k) + "."
		EndIf
		k += 1
	EndWhile
	Return s
EndFunction
