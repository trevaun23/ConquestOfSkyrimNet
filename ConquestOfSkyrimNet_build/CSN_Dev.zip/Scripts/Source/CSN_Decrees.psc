Scriptname CSN_Decrees Hidden
{Conquest of SkyrimNet - the faction's decrees (CoS laws): conscription, crime punishments and religion.

 The work is done by CoS's CS_LawMenuScript (on the CS_FactionGovernment quest) through its CSN* functions, so a
 decree from the faction screen or from a SkyrimNet action is the same law as one made through the General's menus.
 Every decree passed (any way) is remembered for DecreeDays() days: StorageUtil string list "csn_decree_t",
 float list "csn_decree_d" (game day) and int list "csn_decree_h" (town, -1 the whole faction). People who'd know
 hear of it in their SkyrimNet context for that long.}

CSN_Core Function M() Global
	Return CSN_Gov.M()
EndFunction

CS_LawMenuScript Function Laws() Global
	CSN_Core m = M()
	If !m || !m.Gov
		Return None
	EndIf
	Return (m.Gov as Quest) as CS_LawMenuScript
EndFunction

Int Function DecreeDays() Global
	Return 30
EndFunction

String[] Function StatusNames() Global
	String[] a = new String[3]
	a[0] = "outlawed"
	a[1] = "allowed"
	a[2] = "mandatory"
	Return a
EndFunction

String Function StatusName(Int aiStatus) Global
	If aiStatus < 0 || aiStatus > 2
		Return "no law"
	EndIf
	Return StatusNames()[aiStatus]
EndFunction

; ---- memory of recent decrees ---------------------------------------------------------------------------------
Function Remember(Int aiHolding, String asText) Global
	StorageUtil.StringListAdd(None, "csn_decree_t", asText)
	StorageUtil.FloatListAdd(None, "csn_decree_d", Utility.GetCurrentGameTime())
	StorageUtil.IntListAdd(None, "csn_decree_h", aiHolding)
	Prune()
EndFunction

; forget decrees older than DecreeDays(), and keep at most 20
Function Prune() Global
	Float cut = Utility.GetCurrentGameTime() - DecreeDays()
	While StorageUtil.FloatListCount(None, "csn_decree_d") > 0 && (StorageUtil.FloatListGet(None, "csn_decree_d", 0) < cut || StorageUtil.FloatListCount(None, "csn_decree_d") > 20)
		StorageUtil.StringListRemoveAt(None, "csn_decree_t", 0)
		StorageUtil.FloatListRemoveAt(None, "csn_decree_d", 0)
		StorageUtil.IntListRemoveAt(None, "csn_decree_h", 0)
	EndWhile
EndFunction

; Recent decrees someone in aiTown would have heard of (-2: every one of them).
String Function RecentText(Int aiTown) Global
	Prune()
	String s = ""
	Float now = Utility.GetCurrentGameTime()
	Int i = StorageUtil.StringListCount(None, "csn_decree_t") - 1
	While i >= 0
		Int h = StorageUtil.IntListGet(None, "csn_decree_h", i)
		If aiTown == -2 || h == -1 || h == aiTown
			Int ago = (now - StorageUtil.FloatListGet(None, "csn_decree_d", i)) as Int
			String when = "today"
			If ago == 1
				when = "yesterday"
			ElseIf ago > 1
				when = ago + " days ago"
			EndIf
			If s != ""
				s += " "
			EndIf
			s += "(" + when + ") " + StorageUtil.StringListGet(None, "csn_decree_t", i)
		EndIf
		i -= 1
	EndWhile
	Return s
EndFunction

; ---- the standing laws ----------------------------------------------------------------------------------------
String Function StandingText() Global
	CS_LawMenuScript L = Laws()
	If !L
		Return ""
	EndIf
	String s = "Conscription: up to " + L.CSNConscription(-1) + "% of the able-bodied may be called up."
	String crimes = ""
	Int i = 0
	While i < L.CSNCrimeCount()
		Int p = L.CSNPunishment(-1, i)
		If p >= 0
			crimes = CSN_Rebellion.AddTo(crimes, L.CSNCrimeName(i) + ": " + L.CSNSentenceName(p))
		EndIf
		i += 1
	EndWhile
	If crimes != ""
		s += " Punishments: " + crimes + "."
	EndIf
	String outl = ""
	String req = ""
	i = 0
	While i < L.CSNDeityCount()
		Int st = L.CSNDeityStatus(i)
		If st == 0
			outl = CSN_Rebellion.AddTo(outl, L.CSNDeityName(i))
		ElseIf st == 2
			req = CSN_Rebellion.AddTo(req, L.CSNDeityName(i))
		EndIf
		i += 1
	EndWhile
	If outl != ""
		s += " Outlawed worship: " + outl + "."
	EndIf
	If req != ""
		s += " Mandatory worship: " + req + "."
	EndIf
	Return s
EndFunction

; What an NPC knows of the faction's decrees: its people (officers, soldiers, jarls and stewards, townsfolk of the
; towns it rules) know the decrees of the last DecreeDays() days; its officers, jarls and stewards know every
; standing law.
String Function Knowledge(Actor akActor) Global
	CSN_Core m = M()
	If !akActor || !m || m.FactionStarted.GetValue() < 1
		Return ""
	EndIf
	Bool official = m.GetRole(akActor) >= 0 || CSN_Gov.JarlCityOf(akActor) >= 0 || CSN_Gov.IsAnySteward(akActor)
	Bool member = official || m.GetArmy(akActor) >= 0
	Int town = CSN_World.TownOf(akActor)
	If !member && (town < 0 || !CSN_World.PlayerRules(town))
		Return ""
	EndIf
	String s = ""
	String recent = RecentText(town)
	If member
		recent = RecentText(-2)
	EndIf
	If recent != ""
		s += " Recent decrees of " + Game.GetPlayer().GetDisplayName() + " (the talk of the faction's lands): " + recent
	EndIf
	If official
		String st = StandingText()
		If st != ""
			s += " The " + m.FactionName() + "'s standing laws: " + st
		EndIf
	EndIf
	Return s
EndFunction

; ---- for the faction screen -----------------------------------------------------------------------------------
String Function Json() Global
	CSN_Core m = M()
	CS_LawMenuScript L = Laws()
	If !L
		Return "null"
	EndIf
	String s = "{\"consc\":" + L.CSNConscription(-1) + ",\"crimes\":["
	Int i = 0
	While i < L.CSNCrimeCount()
		If i > 0
			s += ","
		EndIf
		s += "{\"n\":" + m.Q(L.CSNCrimeName(i)) + ",\"s\":" + L.CSNPunishment(-1, i) + "}"
		i += 1
	EndWhile
	s += "],\"sentences\":["
	i = 0
	While i < L.CSNSentenceCount()
		If i > 0
			s += ","
		EndIf
		s += m.Q(L.CSNSentenceName(i))
		i += 1
	EndWhile
	s += "],\"deities\":["
	i = 0
	While i < L.CSNDeityCount()
		If i > 0
			s += ","
		EndIf
		s += "{\"n\":" + m.Q(L.CSNDeityName(i)) + ",\"st\":" + L.CSNDeityStatus(i) + "}"
		i += 1
	EndWhile
	s += "],\"recent\":["
	Prune()
	Float now = Utility.GetCurrentGameTime()
	Int n = StorageUtil.StringListCount(None, "csn_decree_t")
	i = n - 1
	While i >= 0
		If i < n - 1
			s += ","
		EndIf
		s += "{\"t\":" + m.Q(StorageUtil.StringListGet(None, "csn_decree_t", i)) + ",\"ago\":" + ((now - StorageUtil.FloatListGet(None, "csn_decree_d", i)) as Int) + "}"
		i -= 1
	EndWhile
	Return s + "],\"days\":" + DecreeDays() + "}"
EndFunction

; ---- passing a decree ------------------------------------------------------------------------------------------
; Each returns True when the law was changed. abAsk: confirm first (the faction screen).
Bool Function SetConscription(Int aiPercent, Int aiHolding = -1, Bool abAsk = True) Global
	CS_LawMenuScript L = Laws()
	If !L
		Return False
	EndIf
	If aiPercent < 0 || aiPercent > 100
		CSN_Gov.Fail("Conscription is set from 0% to 100%.")
		Return False
	EndIf
	Int now = L.CSNConscription(aiHolding)
	If now < 0
		now = L.CSNConscription(-1)
	EndIf
	If now == aiPercent
		CSN_Gov.Fail("Conscription is already " + aiPercent + "%.")
		Return False
	EndIf
	Int loy = (20.0 * ((now - aiPercent) as Float) / 100.0) as Int
	If abAsk
		String eff = "Loyalty doesn't change."
		If loy > 0
			eff = "Loyalty rises by " + loy + " in your towns."
		ElseIf loy < 0
			eff = "Loyalty falls by " + (-loy) + " in your towns."
		EndIf
		If !CSNP.Confirm("Decree: conscription", "Up to " + aiPercent + "% of the able-bodied may be called up (now " + now + "%).\n\nMore conscription means more troops to recruit. " + eff, "Decree it", "Not now")
			Return False
		EndIf
	EndIf
	L.CSNSetConscription(aiHolding, aiPercent)
	CSN_Gov.Say("Decreed: conscription " + aiPercent + "%.")
	Return True
EndFunction

Bool Function SetPunishment(Int aiCrime, Int aiSentence, Int aiHolding = -1, Bool abAsk = True) Global
	CS_LawMenuScript L = Laws()
	If !L || aiCrime < 0 || aiCrime >= L.CSNCrimeCount() || aiSentence >= L.CSNSentenceCount()
		Return False
	EndIf
	If L.CSNPunishment(aiHolding, aiCrime) == aiSentence
		CSN_Gov.Fail("That is already the law.")
		Return False
	EndIf
	String what = L.CSNCrimeName(aiCrime) + ": " + L.CSNSentenceName(aiSentence)
	If aiSentence < 0
		what = "repeal the law on " + L.CSNCrimeName(aiCrime)
	EndIf
	If abAsk && !CSNP.Confirm("Decree: crime and punishment", what + "?", "Decree it", "Not now")
		Return False
	EndIf
	L.CSNSetPunishment(aiHolding, aiCrime, aiSentence)
	CSN_Gov.Say("Decreed: " + what + ".")
	Return True
EndFunction

Bool Function SetDeity(Int aiDeity, Int aiStatus, Bool abAsk = True) Global
	CS_LawMenuScript L = Laws()
	If !L || aiDeity < 0 || aiDeity >= L.CSNDeityCount() || aiStatus < 0 || aiStatus > 2
		Return False
	EndIf
	If L.CSNDeityStatus(aiDeity) == aiStatus
		CSN_Gov.Fail("Worship of " + L.CSNDeityName(aiDeity) + " is already " + StatusName(aiStatus) + ".")
		Return False
	EndIf
	String what = "worship of " + L.CSNDeityName(aiDeity) + " " + StatusName(aiStatus)
	If abAsk
		String note = ""
		If aiStatus == 0
			note = "\n\nTheir shrines and statues in your lands are taken down."
		EndIf
		If !CSNP.Confirm("Decree: religion", "Make " + what + "?" + note, "Decree it", "Not now")
			Return False
		EndIf
	EndIf
	L.CSNSetDeity(aiDeity, aiStatus)
	CSN_Gov.Say("Decreed: " + what + ".")
	Return True
EndFunction

; ---- name lookups (SkyrimNet) ----------------------------------------------------------------------------------
Int Function FindCrime(String s) Global
	CS_LawMenuScript L = Laws()
	Int i = 0
	While L && s != "" && i < L.CSNCrimeCount()
		If CSN_SkyrimNet.Matches(L.CSNCrimeName(i), s)
			Return i
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

Int Function FindSentence(String s) Global
	CS_LawMenuScript L = Laws()
	Int i = 0
	While L && s != "" && i < L.CSNSentenceCount()
		If CSN_SkyrimNet.Matches(L.CSNSentenceName(i), s)
			Return i
		EndIf
		i += 1
	EndWhile
	Return -2
EndFunction

Int Function FindDeity(String s) Global
	CS_LawMenuScript L = Laws()
	Int i = 0
	While L && s != "" && i < L.CSNDeityCount()
		If CSN_SkyrimNet.Matches(L.CSNDeityName(i), s)
			Return i
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

String Function Names(Int aiWhat) Global
	CS_LawMenuScript L = Laws()
	If !L
		Return ""
	EndIf
	String s = ""
	Int i = 0
	Int n = L.CSNCrimeCount()
	If aiWhat == 1
		n = L.CSNSentenceCount()
	ElseIf aiWhat == 2
		n = L.CSNDeityCount()
	EndIf
	While i < n
		String one = L.CSNCrimeName(i)
		If aiWhat == 1
			one = L.CSNSentenceName(i)
		ElseIf aiWhat == 2
			one = L.CSNDeityName(i)
		EndIf
		If s != ""
			s += ", "
		EndIf
		s += one
		i += 1
	EndWhile
	Return s
EndFunction
