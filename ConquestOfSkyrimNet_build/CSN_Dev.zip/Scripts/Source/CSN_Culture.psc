Scriptname CSN_Culture Hidden
{Conquest of SkyrimNet: the faction's culture, military doctrine and leadership style.
 Written on the Culture tab of the faction screen (leadership style also in the MCM) and stored in the save
 (StorageUtil), so every playthrough has its own. SkyrimNet gets it through the csn_culture decorator:
   - everyone in Skyrim knows what the faction is (the culture text);
   - members (officers, captains, commanders, soldiers, the jarls and stewards of towns it rules) also follow the
     leadership style in how they talk to the leader and to each other;
   - military people (the General, captains, commanders, soldiers) also know the military doctrine.}

Int Function STYLE_LAISSEZ() Global
	Return 0
EndFunction
Int Function STYLE_DEMOCRATIC() Global
	Return 1
EndFunction
Int Function STYLE_DICTATORSHIP() Global
	Return 2
EndFunction
Int Function STYLE_OTHER() Global
	Return 3
EndFunction

; ---- stored values ------------------------------------------------------------
String Function CultureText() Global
	Return StorageUtil.GetStringValue(None, "csn_culture", "")
EndFunction

String Function DoctrineText() Global
	Return StorageUtil.GetStringValue(None, "csn_doctrine", "")
EndFunction

; 0 laissez-faire, 1 democratic (default), 2 dictatorship, 3 other
Int Function Style() Global
	Return StorageUtil.GetIntValue(None, "csn_lstyle", 1)
EndFunction

String Function OtherText() Global
	Return StorageUtil.GetStringValue(None, "csn_lstyle_other", "")
EndFunction

; ---- the leader's title (optional): 0 none, 1 Supreme Leader, 2 Jarl, 3 High Priest, 4 Master, 5 their own ----
Int Function TitleChoice() Global
	Return StorageUtil.GetIntValue(None, "csn_title", 0)
EndFunction

String Function TitleOther() Global
	Return StorageUtil.GetStringValue(None, "csn_title_other", "")
EndFunction

; "" when the leader wants no title
String Function Title() Global
	Int c = TitleChoice()
	If c == 1
		Return "Supreme Leader"
	ElseIf c == 2
		Return "Jarl"
	ElseIf c == 3
		Return "High Priest"
	ElseIf c == 4
		Return "Master"
	ElseIf c == 5
		Return TitleOther()
	EndIf
	Return ""
EndFunction

Function SetTitle(Int aiChoice) Global
	If aiChoice < 0 || aiChoice > 5
		aiChoice = 0
	EndIf
	StorageUtil.SetIntValue(None, "csn_title", aiChoice)
EndFunction

; The leader's name with their title in front ("Supreme Leader Trey"), or just the name.
String Function TitledName() Global
	String t = Title()
	String n = Game.GetPlayer().GetDisplayName()
	If t == ""
		Return n
	EndIf
	Return t + " " + n
EndFunction

; Only the faction's own people know the title: its members (officers, army, guards, jarls, stewards), Thanes and
; housecarls, and the people of the towns and villages it rules. Everyone else just knows the leader's name.
Bool Function KnowsTitle(Actor a) Global
	If !a || a == Game.GetPlayer()
		Return False
	EndIf
	If IsMember(a) || CSN_Thanes.IsThane(a) || CSN_Thanes.IsHousecarl(a)
		Return True
	EndIf
	Int t = CSN_World.TownOf(a)
	Return t >= 0 && CSN_World.PlayerRules(t)
EndFunction

; TitleText for akActor, or "" when they would not know the title.
String Function TitleTextFor(Actor akActor) Global
	If !KnowsTitle(akActor)
		Return ""
	EndIf
	Return TitleText()
EndFunction

; How the faction's troops, officers and subjects address the leader. "" with no title.
String Function TitleText() Global
	String t = Title()
	If t == ""
		Return ""
	EndIf
	String n = Game.GetPlayer().GetDisplayName()
	Return "The leader's title is " + t + " (known only to the faction's own people and the people of the towns and holds it rules; outsiders don't use it). The faction's soldiers, Captains, Commanders, officers, jarls, stewards and the people of its towns address " + n + " as \"" + t + "\" or \"" + t + " " + n + "\" (never by the bare name), and say \"" + t + " " + n + "\" when they speak of them."
EndFunction

Function SetText(String asField, String asText) Global
	asText = Clean(asText)
	If asField == "culture"
		StorageUtil.SetStringValue(None, "csn_culture", asText)
	ElseIf asField == "doctrine"
		StorageUtil.SetStringValue(None, "csn_doctrine", asText)
	ElseIf asField == "other"
		StorageUtil.SetStringValue(None, "csn_lstyle_other", asText)
	ElseIf asField == "titleother"
		If StringUtil.GetLength(asText) > 40
			asText = StringUtil.Substring(asText, 0, 40)
		EndIf
		StorageUtil.SetStringValue(None, "csn_title_other", asText)
	EndIf
EndFunction

Function SetStyle(Int aiStyle, Bool abSyncMCM = True) Global
	If aiStyle < -1 || aiStyle > 3
		aiStyle = -1
	EndIf
	Int old = Style()
	StorageUtil.SetIntValue(None, "csn_lstyle", aiStyle)
	If abSyncMCM && aiStyle >= 0
		CSN_Config.SetInt("iLeadership:Culture", aiStyle)
	EndIf
	If aiStyle != old && aiStyle >= 0
		CSN_Core m = CSN_Gov.M()
		CSN_SkyrimNet.AddFactionHistory(Game.GetPlayer().GetDisplayName() + " now rules the " + m.FactionName() + " in a " + StyleName(aiStyle) + " way.")
	EndIf
EndFunction

; The MCM dropdown is per profile, the style is per save: copy the save's value into the MCM on load.
Function SyncToMCM() Global
	If Style() >= 0
		CSN_Config.SetInt("iLeadership:Culture", Style())
	EndIf
EndFunction

Function ApplyFromMCM() Global
	SetStyle(CSN_Config.GetInt("iLeadership:Culture", Style()), False)
EndFunction

String Function StyleName(Int aiStyle) Global
	If aiStyle == 0
		Return "laissez-faire"
	ElseIf aiStyle == 1
		Return "democratic"
	ElseIf aiStyle == 2
		Return "dictatorial"
	ElseIf aiStyle == 3
		Return "its own"
	EndIf
	Return ""
EndFunction

; How members of the faction behave under each style.
String Function StyleGuide(Int aiStyle) Global
	String leader = Game.GetPlayer().GetDisplayName()
	If aiStyle == 0
		Return "Laissez-faire: " + leader + " rules with a light hand and leaves people to get on with it. Members of the faction are relaxed and casual with " + leader + " and with each other, speak their minds freely, share opinions, joke and argue openly, and use titles loosely if at all."
	ElseIf aiStyle == 1
		Return "Democratic: " + leader + " rules by consent and order. Members of the faction respect the chain of command and keep to formalities: they address anyone of higher rank by title or as sir or ma'am, raise their opinions respectfully and through proper channels, and expect to be heard before decisions are made."
	ElseIf aiStyle == 2
		Return "Dictatorship: " + leader + " rules with an iron fist. Discipline is strict and stern; orders are obeyed at once and without question, superiors are stern with those below them and dress them down when standards slip, and everyone is guarded and respectful in what they say to " + leader + ". Dissent is dangerous."
	ElseIf aiStyle == 3
		String t = OtherText()
		If t == ""
			Return ""
		EndIf
		Return "In " + leader + "'s own words: " + t
	EndIf
	Return ""
EndFunction

; ---- who gets what ------------------------------------------------------------
Bool Function IsMember(Actor a) Global
	CSN_Core m = CSN_Gov.M()
	If !a || !m
		Return False
	EndIf
	If m.GetRole(a) >= 0 || m.GetArmy(a) >= 0 || IsSoldier(a) || InCSFaction(a, False)
		Return True
	EndIf
	If CSN_Gov.CityStewardOf(a) >= 0
		Return True
	EndIf
	Int j = CSN_Gov.JarlCityOf(a)
	Return j >= 0 && CSN_World.PlayerRules(j)
EndFunction

; The player's own Conquest of Skyrim factions (ConquestOfSkyrimNet.esp): army, guards, commanders, government.
; abMilitaryOnly: only the fighting ones.
Bool Function InCSFaction(Actor a, Bool abMilitaryOnly) Global
	Int[] mil = new Int[6]
	mil[0] = 0x0028A5   ; CS_PlayerArmyFaction
	mil[1] = 0x0033AD   ; CS_PlayerArmyCommanders
	mil[2] = 0x566B45   ; CS_PlayerArmyFortCommanders
	mil[3] = 0x022D5D   ; CS_PlayerGuardFaction
	mil[4] = 0x004ED1   ; CS_PlayerArmyFollowerFaction
	mil[5] = 0x36B635   ; CS_ASICFaction (the General)
	Int i = 0
	While i < mil.Length
		Faction f = Game.GetFormFromFile(mil[i], "ConquestOfSkyrimNet.esp") as Faction
		If f && a.IsInFaction(f)
			Return True
		EndIf
		i += 1
	EndWhile
	If abMilitaryOnly
		Return False
	EndIf
	Faction gov = Game.GetFormFromFile(0x0227A1, "ConquestOfSkyrimNet.esp") as Faction   ; CS_PlayerFactionGovernment
	Faction mage = Game.GetFormFromFile(0x50B576, "ConquestOfSkyrimNet.esp") as Faction  ; CS_CourtMageFaction
	Return (gov && a.IsInFaction(gov)) || (mage && a.IsInFaction(mage))
EndFunction

Bool Function IsSoldier(Actor a) Global
	CSN_Core m = CSN_Gov.M()
	Faction f = m.Gov.LoyaltyScript.PlayerArmyFaction
	Return f && a.IsInFaction(f)
EndFunction

Bool Function IsMilitary(Actor a) Global
	CSN_Core m = CSN_Gov.M()
	Return m.GetRole(a) == m.ROLE_GENERAL || m.GetArmy(a) >= 0 || IsSoldier(a) || InCSFaction(a, True)
EndFunction

; Decorator csn_culture. "" when there is nothing to say.
String Function KnowledgeFor(Actor akActor) Global
	CSN_Core m = CSN_Gov.M()
	If !m || m.FactionStarted.GetValue() < 1 || !akActor || akActor == Game.GetPlayer()
		Return ""
	EndIf
	String fac = m.FactionName()
	String leader = Game.GetPlayer().GetDisplayName()
	String c = CultureText()
	If !IsMember(akActor)
		If c == ""
			Return ""
		EndIf
		Return "What people across Skyrim know of the " + fac + ", the faction led by " + leader + ": " + c
	EndIf
	String s = ""
	If c != ""
		s = m.BaseName(akActor) + " belongs to the " + fac + " and shares its ways and beliefs; they speak of them as their own and bring them up naturally. What the " + fac + " is and does: " + c
	EndIf
	String g = StyleGuide(Style())
	If g != ""
		If s != ""
			s += "\n"
		EndIf
		s += "How the " + fac + " is led (" + m.BaseName(akActor) + " behaves accordingly with " + leader + " and with other members of the faction): " + g
	EndIf
	If s != ""
		s += "\n"
	EndIf
	s += ConductText() + " " + RoleGuardrails(akActor)
	If TitleText() != ""
		s += "\n" + TitleText()
	EndIf
	If IsMilitary(akActor) && DoctrineText() != ""
		If s != ""
			s += "\n"
		EndIf
		s += "Military doctrine of the " + fac + " (" + m.BaseName(akActor) + " follows it in how they speak of war, train and fight): " + DoctrineText()
	EndIf
	Return s
EndFunction

; How the faction's people treat the leader whatever the style: loyal, constructive and not tiresome.
String Function ConductText() Global
	String leader = Game.GetPlayer().GetDisplayName()
	String s = "Working with " + leader + ": you are loyal and on their side. Speak positively and constructively; praise what goes well and offer encouragement and solutions. Do not criticise, second-guess or lecture " + leader + " unless something is truly at stake, and then say it once, briefly and respectfully, and move on."
	s += " Do not keep asking " + leader + " for decisions or end every remark with a question: use your own judgement within your duties and report what you did. Ask only when a choice is truly theirs to make."
	s += " " + leader + " may ask you many times to manage trade, troops, recruits, templates, uniforms or the treasury; carry out each request willingly and without complaint, as often as asked."
	Return s
EndFunction

; Things the faction's people get wrong about how this war works.
String Function RoleGuardrails(Actor a) Global
	CSN_Core m = CSN_Gov.M()
	String s = "How this war works: clearing a bandit camp, fort or other hostile place earns no gold and is not done for profit or loot; the faction takes such places to claim the land, a base and an army slot, and mines and mills it holds produce supplies. Reputation and honour are not measured and count for nothing here: never talk about the faction's reputation, honour, image or how things look. What counts is land, towns and their loyalty, the treasury, the supplies and the armies."
	Int role = m.GetRole(a)
	If role == m.ROLE_GENERAL || m.GetArmy(a) >= 0 || IsSoldier(a)
		s += " Gold is never your concern: the treasury belongs to the leader and the Steward. Don't worry, warn or complain about gold, costs or the treasury; speak of troops, orders, ground and battle."
	ElseIf role == m.ROLE_STEWARD || CSN_Gov.CityStewardOf(a) >= 0
		s += " Your concerns are the treasury, the supplies, trade, taxes and the towns. Defence, protection and military matters belong to the General and the army: don't dwell on them or steer the talk toward them."
	EndIf
	Return s
EndFunction

; ---- helpers -----------------------------------------------------------------
String Function Clean(String s) Global
	; the dashboard already strips | and line breaks; cap the length so prompts stay small
	If StringUtil.GetLength(s) > 1500
		s = StringUtil.Substring(s, 0, 1500)
	EndIf
	Return s
EndFunction
