Scriptname CSN_Letters Hidden
{Conquest of SkyrimNet and Physical Letters (optional, https://github.com/zevck/Physical-Letters).
 When Physical Letters is installed, requests from your government arrive as letters written by the
 steward or jarl who makes them (in their own words, through SkyrimNet), brought by courier.
 Reading one asks you for a decision; you can also write back, and the writer acts on your answer.
 Every call into Physical Letters is in this file and only runs after Available() is true.}

Bool Function Installed() Global
	Return Game.GetModByName("Physical Letters.esp") != 255
EndFunction

Bool Function Available() Global
	If !CSN_Config.UseLetters() || !Installed()
		Return False
	EndIf
	Return PhysicalLetters.GetApiVersion() >= 1
EndFunction

; Letters CoS SkyrimNet sends are tagged "csn_req_<request id>"; replies carry the same tag.
String Function TagFor(Int aiRequest) Global
	Return "csn_req_" + aiRequest
EndFunction

Int Function RequestOfTag(String asTag) Global
	If StringUtil.Find(asTag, "csn_req_") != 0
		Return -1
	EndIf
	Return StringUtil.Substring(asTag, 8) as Int
EndFunction

Bool Function SendRequest(Int aiRequest, Actor akFrom, String asNotes) Global
	String id = PhysicalLetters.SendLetter(akFrom, "", Game.GetPlayer(), asNotes, True, False, -1, TagFor(aiRequest))
	If id == ""
		Return False
	EndIf
	StorageUtil.SetStringValue(None, "csn_rq_" + aiRequest + "_letter", id)
	Return True
EndFunction

; Register on every game load (Physical Letters doesn't save registrations).
; Offered when the writer of a request reads the player's answer to it.
Function RegisterActions() Global
	If !Available()
		Return
	EndIf
	String[] names = new String[1]
	String[] what = new String[1]
	names[0] = "decision"
	what[0] = "accept, deny, or middle (meet in the middle), as the leader's letter decides"
	PhysicalLetters.RegisterAction("csn_request_answer", "Conquest of SkyrimNet requests", "Stewards and jarls act on your written answer to their request (taxes or trade).", \
		"The letter is the leader's answer to a request about taxes or trade that the reader sent, and it says whether the leader accepts, denies, or meets them in the middle.", names, what, 1)
EndFunction

; PhysicalLetters_Read: the player opened a request letter -> ask for a decision.
Function OnRead(String asLetterId, Form akReader) Global
	If akReader != Game.GetPlayer() || !Installed()
		Return
	EndIf
	Int rq = RequestOfTag(PhysicalLetters.GetTag(asLetterId))
	If rq > 0 && PhysicalLetters.GetRecipient(asLetterId) == Game.GetPlayer()
		CSN_Requests.MarkRead(rq)
		CSN_Requests.AskNow(rq)
	EndIf
EndFunction

; PhysicalLetters_Action_csn_request_answer: the writer read the player's reply and understood the decision.
Function OnAnswer(String asLetterId) Global
	If !Installed()
		Return
	EndIf
	Int rq = RequestOfTag(PhysicalLetters.GetTag(asLetterId))
	If rq <= 0
		Return
	EndIf
	String d = PhysicalLetters.GetActionValue(asLetterId, "decision")
	Int choice = 0
	If StringUtil.Find(d, "deny") >= 0 || StringUtil.Find(d, "refuse") >= 0 || StringUtil.Find(d, "reject") >= 0 || StringUtil.Find(d, "no") == 0
		choice = 1
	ElseIf StringUtil.Find(d, "middle") >= 0 || StringUtil.Find(d, "compromise") >= 0 || StringUtil.Find(d, "half") >= 0
		choice = 2
	EndIf
	CSN_Requests.Decide(rq, choice)
EndFunction
