Scriptname CS_DefendCityRebelScript extends CS_DefendCityScript
{Rebels attacking a city of the player's faction (quest CSN_DefendCityRebels).

 The unfinished Conquest of Skyrim build kept a CS_DefendCityRebelScript from an older layout (one war quest per
 city) that no quest uses. This one runs the same battle Conquest of Skyrim 0.3.9 uses when the Imperials or the
 Stormcloaks attack the player's city: CSN_DefendCityRebels is a copy of CS_DefendCityNewImp (aliases, packages,
 reinforcements, troop counts) with CoS's own rebel soldiers (CS_SiegeRebelSoldier / CS_SiegeRebelArcher) and
 enemyfactionnum 70. It starts from CoS's story event CS_StoryDefendCity with value 70, sent by CS_WarRebelsScript.

 What differs from an Imperial or Stormcloak attack:
   * the number of attackers comes from the rebels (an uprising's size or a free company's soldiers), not from an
     enemy side's armies;
   * no prisoners are taken: beaten rebels flee;
   * the outcome goes back to CS_WarRebelsScript (the uprising is broken, the company loses soldiers, or the town is
     lost) instead of an enemy side's war plans.}

CS_WarRebelsScript Function War()
	Return Quest.GetQuest("CSN_WarRebels") as CS_WarRebelsScript
EndFunction

Function SetUp()
	holdnum = AllLocations.Find(City.GetLocation())
	BattleTracker.Cities[holdnum] = true
	GarrisonCommanders = GarrisonCommandersAll.GetAt(holdnum) as FormList
	AttackMarker1.ForceRefTo(AttackMarkers1.GetAt(holdnum) as ObjectReference)
	AttackMarker2.ForceRefTo(AttackMarkers2.GetAt(holdnum) as ObjectReference)
	AttackSpawn.ForceRefTo(AttackerSpawnMarkers.GetAt(holdnum) as ObjectReference)
	((self as Quest) as CS_DefendCityTroopDeathAttacker).SetUpSpawns()
	((self as Quest) as CS_DefendCityTroopDeathDefender).SetUpSpawns()
	CS_ReinforcementControllerDCity ReinforcementController = (self as Quest) as CS_ReinforcementControllerDCity
	ReinforcementController.Attackers = Attackers
	ReinforcementController.Defenders = Defenders

	TroopsRemainingAttackersPercent.SetValue(100)
	TroopsRemainingDefendersPercent.SetValue(100)
	UpdateCurrentInstanceGlobal(TroopsRemainingDefendersPercent)
	UpdateCurrentInstanceGlobal(TroopsRemainingAttackersPercent)

	AssignDefenders()
	ReinforcementController.DefenseTroops = Garrison

	; the rebels bring their own numbers
	AttackersInitial = StorageUtil.GetIntValue(None, "csn_rw_troops", 20)
	If AttackersInitial < 5
		AttackersInitial = 5
	EndIf
	AttackerCount.SetValue(AttackersInitial)
	UpdateCurrentInstanceGlobal(AttackerCount)

	TroopsRemainingDefenders = DefendersInitial
	TroopsRemainingAttackers = AttackersInitial

	; make sure the rebels and the faction's soldiers fight each other
	Faction rebels = Game.GetFormFromFile(0x31A46B, "ConquestOfSkyrimNet.esp") as Faction
	Faction army = Game.GetFormFromFile(0x0028A5, "ConquestOfSkyrimNet.esp") as Faction
	If rebels
		rebels.SetPlayerEnemy(True)
		If army
			rebels.SetEnemy(army)
		EndIf
	EndIf

	CSNP.Show(DefendCityMessage, self)

	SetObjectiveDisplayed(0, true, true)
	SetObjectiveDisplayed(5, true, true)

	If AttackMarker1.GetRef().Is3DLoaded()
		SetStage(5)
	EndIf

	RegisterForUpdateGameTime(0.5)
EndFunction

; beaten rebels don't surrender to the faction's prison: they run
Function TroopsSurrender()
	Int fled = 0
	Int i = 0
	While i < Attackers.Length
		If Attackers[i].GetActorRef() != None
			Attackers[i].GetActorRef().AddToFaction(RetreatFaction)
			fled += 1
		EndIf
		Attackers[i].Clear()
		i += 1
	EndWhile
	i = 0
	While i < AttackerCommanders.Length
		If AttackerCommanders[i].GetActorRef() != None
			AttackerCommanders[i].GetActorRef().AddToFaction(RetreatFaction)
			fled += 1
		EndIf
		AttackerCommanders[i].Clear()
		i += 1
	EndWhile
	If fled > 0
		Debug.Notification(fled + " rebels are fleeing!")
	EndIf
	StopCombatDefenders()
EndFunction

; the city held
Function WinQuest()
	UnRegisterForUpdate()
	KillFlaggedTroops()
	TroopsSurrender()
	BattleTracker.Cities[holdnum] = false
	CS_WarRebelsScript w = War()
	If w
		w.RebelsBeaten(holdnum, TroopsRemainingAttackers)
	EndIf
	SetStage(20)
EndFunction

; the rebels took the city
Function FailQuest()
	KillFlaggedTroops()
	Int i = 0
	While i < GarrisonCommanders.GetSize()
		CommanderScript.ClearFactions(GarrisonCommanders.GetAt(i) as Actor)
		CommanderScript.ArmyScripts[CommanderScript.GetCommanderArmyNum(GarrisonCommanders.GetAt(i) as Actor)].Blockaded = false
		i += 1
	EndWhile
	(TriggerBoxes.GetAt(holdnum) as ObjectReference).enable()
	BattleTracker.Cities[holdnum] = false
	CS_WarRebelsScript w = War()
	If w
		w.RebelsWon(holdnum, TroopsRemainingAttackers)
	EndIf
	SetStage(21)
EndFunction
