Scriptname CSN_SkyrimNet Hidden
{Conquest of SkyrimNet - SkyrimNet integration. Every SkyrimNet call in the mod lives in this file.
 Decorators: csn_faction_context (officers/commanders), csn_town_context (town rule, mood, news),
 csn_hierarchy (ranks and chain of command). World events come from CSN_World.

 * Registers NPC actions (appointments, hiring, army orders, steward business).
 * Registers decorators that tell each NPC what they know about your faction (used by the bundle's
   prompts/submodules/character_bio/0650_conquestofskyrimnet.prompt), including csn_officer_knowledge:
   the exact treasury, supplies, armies, siege equipment, loadouts and town buildings an officer would know.
 * Logs faction milestones as persistent SkyrimNet events so NPCs remember them.

 VERIFY AGAINST YOUR SkyrimNetApi.psc / skynet_Library.psc BEFORE COMPILING (BUILD_GUIDE.md 10.3):
   - eligibility functions:  Bool Function X(Actor akActor, String contextJson, String paramsJson) Global
   - execution functions:    Function X(Actor akActor, String contextJson, String paramsJson) Global
   - SkyrimNetApi.GetJsonString(String json, String key, String default)}

; =============================================================================
; HELPERS
; =============================================================================
CSN_Core Function Main() Global
	Return Quest.GetQuest("CS_FactionGovernment") as CSN_Core
EndFunction

Bool Function Installed() Global
	Return Game.GetModByName("SkyrimNet.esp") != 255 && CSN_Config.SkyrimNetEnabled()
EndFunction

; Memory event: stored in the event history and in the memories of NPCs who are there, without
; making anyone start talking (SkyrimNet RegisterPersistentEvent).
Function WorldEvent(String asType, String asText, Actor akSource) Global
	If Installed()
		SkyrimNetApi.RegisterPersistentEvent(asText, akSource, None)
	EndIf
EndFunction

; A faction event remembered by the NPCs involved (appointments, orders, hiring).
Function LogEvent(String asText, Actor akSource = None, Actor akTarget = None) Global
	If Installed()
		SkyrimNetApi.RegisterPersistentEvent(asText, akSource, akTarget)
	EndIf
EndFunction

; A passing event (such as a new order) that does not need to stay in long-term memory.
Function ShortEvent(String asId, String asText, Actor akSource = None) Global
	If Installed()
		SkyrimNetApi.RegisterShortLivedEvent(asId, "csn_event", asText, asText, 60000, akSource, None)
	EndIf
EndFunction

; Something happening right now that people nearby react to out loud (SkyrimNet DirectNarration).
Function BattleAlert(String asText) Global
	If Installed()
		SkyrimNetApi.DirectNarration(asText, None, None)
	EndIf
EndFunction

; Lasting history (a town changing hands, a new jarl) as SkyrimNet world knowledge, known to the people of
; that town's hold and recalled when it comes up in conversation. History never goes out of date, so entries
; are dated and never need removing; what is true *now* comes from the csn_town_context decorator.
Function AddHistory(Int aiTown, String asText) Global
	If !Installed()
		Return
	EndIf
	String town = CSN_World.TownName(aiTown)
	String cond = HoldCondition(town)
	SkyrimNetApi.AddWorldKnowledge("On " + SkyrimDate() + ": " + asText, cond, False, 0.7, "Conquest of SkyrimNet: " + town)
EndFunction

; Faction-wide history: known to the faction's officers, soldiers and the people of every town it rules.
Function AddFactionHistory(String asText) Global
	If !Installed()
		Return
	EndIf
	SkyrimNetApi.AddWorldKnowledge("On " + SkyrimDate() + ": " + asText, "is_in_faction(actorUUID, \"CS_PlayerArmyFaction\") or is_in_faction(actorUUID, \"CS_PlayerFactionGovernment\") or is_in_faction(actorUUID, \"CS_PlayerArmyCommanders\")", False, 0.7, "Conquest of SkyrimNet: laws")
EndFunction

; Inja condition: people of the hold a town belongs to (by crime faction). "" = everyone.
String Function HoldCondition(String asTown) Global
	String f = ""
	If Matches(asTown, "Whiterun") || Matches(asTown, "Riverwood") || Matches(asTown, "Rorikstead")
		f = "CrimeFactionWhiterun"
	ElseIf Matches(asTown, "Solitude") || Matches(asTown, "Dragon Bridge")
		f = "CrimeFactionHaafingar"
	ElseIf Matches(asTown, "Windhelm") || Matches(asTown, "Kynesgrove")
		f = "CrimeFactionEastmarch"
	ElseIf Matches(asTown, "Riften") || Matches(asTown, "Ivarstead") || Matches(asTown, "Shor's Stone")
		f = "CrimeFactionRift"
	ElseIf Matches(asTown, "Markarth") || Matches(asTown, "Karthwasten") || Matches(asTown, "Old Hroldan")
		f = "CrimeFactionReach"
	ElseIf Matches(asTown, "Morthal")
		f = "CrimeFactionHjaalmarch"
	ElseIf Matches(asTown, "Dawnstar")
		f = "CrimeFactionPale"
	ElseIf Matches(asTown, "Falkreath") || Matches(asTown, "Helgen")
		f = "CrimeFactionFalkreath"
	ElseIf Matches(asTown, "Winterhold")
		f = "CrimeFactionWinterhold"
	EndIf
	If f == ""
		Return ""
	EndIf
	Return "is_in_faction(actorUUID, \"" + f + "\")"
EndFunction

String Function SkyrimDate() Global
	Int day = (Game.GetForm(0x00000037) as GlobalVariable).GetValueInt()
	Int month = (Game.GetForm(0x00000036) as GlobalVariable).GetValueInt()
	Int year = (Game.GetForm(0x00000035) as GlobalVariable).GetValueInt()
	String[] months = new String[12]
	months[0] = "Morning Star"
	months[1] = "Sun's Dawn"
	months[2] = "First Seed"
	months[3] = "Rain's Hand"
	months[4] = "Second Seed"
	months[5] = "Midyear"
	months[6] = "Sun's Height"
	months[7] = "Last Seed"
	months[8] = "Hearthfire"
	months[9] = "Frostfall"
	months[10] = "Sun's Dusk"
	months[11] = "Evening Star"
	String m = "a day"
	If month >= 0 && month < 12
		m = months[month]
	EndIf
	Return "the " + day + Ordinal(day) + " of " + m + ", 4E " + year
EndFunction

String Function Ordinal(Int n) Global
	Int t = n % 100
	If t >= 11 && t <= 13
		Return "th"
	EndIf
	Int u = n % 10
	If u == 1
		Return "st"
	ElseIf u == 2
		Return "nd"
	ElseIf u == 3
		Return "rd"
	EndIf
	Return "th"
EndFunction

Function RefreshBio(Actor akActor) Global
	If Installed() && akActor
		SkyrimNetApi.UpdateActorDynamicBio(akActor)
	EndIf
EndFunction

String Function Param(String asParamsJson, String asKey) Global
	Return SkyrimNetApi.GetJsonString(asParamsJson, asKey, "")
EndFunction

Bool Function Matches(String asA, String asB) Global
	If asA == "" || asB == ""
		Return False
	EndIf
	Return StringUtil.Find(asA, asB) >= 0 || StringUtil.Find(asB, asA) >= 0
EndFunction

; CoS numbering: 1 = Imperials, 2 = Stormcloaks
Int Function ParseSide(String s) Global
	If Matches(s, "Imperial") || Matches(s, "Empire") || Matches(s, "Legion")
		Return 1
	ElseIf Matches(s, "Stormcloak") || Matches(s, "Ulfric") || Matches(s, "Sons")
		Return 2
	EndIf
	Return -1
EndFunction

; CoS numbering: 0 = food, 1 = metal, 2 = wood
Int Function ParseMaterial(String s) Global
	If Matches(s, "food") || Matches(s, "grain") || Matches(s, "meat")
		Return 0
	ElseIf Matches(s, "metal") || Matches(s, "ore") || Matches(s, "iron")
		Return 1
	ElseIf Matches(s, "wood") || Matches(s, "lumber") || Matches(s, "timber")
		Return 2
	EndIf
	Return -1
EndFunction

Int Function ParseHold(String s) Global
	CSN_Core m = Main()
	Int i = 0
	While i < m.HoldCount()
		If Matches(s, m.HoldName(i))
			Return i
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

; Towns 0-14 (cities 0-8 share their number with their hold).
Int Function ParseTown(String s) Global
	Int i = 0
	While i < 15
		If Matches(s, CSN_World.TownName(i))
			Return i
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

; A hold given by its own name (The Reach) or its city's name (Markarth).
Int Function ParseHoldOrCity(String s) Global
	Int h = ParseHold(s)
	If h < 0
		h = ParseTown(s)
		If h > 8
			h = -1
		EndIf
	EndIf
	Return h
EndFunction

Int Function ParseCity(String s) Global
	Int c = ParseTown(s)
	If c < 0 || c > 8
		c = ParseHold(s)
	EndIf
	Return c
EndFunction

Int Function ParseFort(String s) Global
	CSN_Core m = Main()
	Int i = 0
	While i < m.FortCount()
		If Matches(s, m.FortName(i))
			Return i
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

Actor Function ParseCommander(String s) Global
	CS_PatrolHoldScript a = Main().Armies()
	Int i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c && (Matches(s, c.GetLeveledActorBase().GetName()) || Matches(s, c.GetDisplayName()))
			Return c
		EndIf
		i += 1
	EndWhile
	; or the army's own name ("the Iron Wolves")
	i = 0
	While i < a.Commanders.Length
		Actor c2 = a.Commanders[i].GetActorRef()
		If c2 && CSN_War.Name(i) != "" && Matches(s, CSN_War.Name(i))
			Return c2
		EndIf
		i += 1
	EndWhile
	Return None
EndFunction

; =============================================================================
; REGISTRATION (called on init and every game load)
; =============================================================================
Function Reg(String asName, String asDesc, String asElig, String asExec, String asSchema = "") Global
	SkyrimNetApi.RegisterAction(asName, asDesc, "CSN_SkyrimNet", asElig, "CSN_SkyrimNet", asExec, "", "PAPYRUS", 1, asSchema)
EndFunction

Function RegisterAll() Global
	If !Installed()
		Return
	EndIf
	SkyrimNetApi.RegisterDecorator("csn_faction_context", "CSN_SkyrimNet", "Decorator_FactionContext")
	SkyrimNetApi.RegisterDecorator("csn_town_context", "CSN_SkyrimNet", "Decorator_TownContext")
	SkyrimNetApi.RegisterDecorator("csn_hierarchy", "CSN_SkyrimNet", "Decorator_Hierarchy")
	SkyrimNetApi.RegisterDecorator("csn_officer_knowledge", "CSN_SkyrimNet", "Decorator_OfficerKnowledge")
	SkyrimNetApi.RegisterDecorator("csn_culture", "CSN_SkyrimNet", "Decorator_Culture")

	; ---- Appointments --------------------------------------------------------
	Reg("CSN_BecomeGeneral", "Accept the player's offer to become General of the player's faction. Use only when the player asks this NPC to be their General and the NPC agrees.", "Elig_General", "Exec_General")
	Reg("CSN_BecomeSteward", "Accept the player's offer to become Steward of the player's faction (treasury, trade, war declarations). Use only when the player asks and the NPC agrees.", "Elig_Steward", "Exec_Steward")
	Reg("CSN_BecomeBlacksmith", "Accept the player's offer to become Blacksmith of the player's faction. Use only when the player asks and the NPC agrees.", "Elig_Blacksmith", "Exec_Blacksmith")
	Reg("CSN_BecomeCourtWizard", "Accept the player's offer to become Court Wizard of the player's faction. Use only when the player asks and the NPC agrees.", "Elig_Wizard", "Exec_Wizard")
	Reg("CSN_BecomeHoldSteward", "Accept the player's offer to be the steward of one hold, city or village the player's faction rules (e.g. steward of the Rift, or of Riften): that town's own steward, who runs its taxes, buildings, guards and trade. NOT the faction's Steward (use CSN_BecomeSteward for that). Use when the player asks you to be steward of a particular place and you agree.", "Elig_TownOfficial", "Exec_HoldSteward", "{\"town\": \"the hold, city or village\"}")
	Reg("CSN_BecomeHousecarl", "Accept the player's offer to be the housecarl of one hold or city the player's faction rules (e.g. housecarl of Whiterun hold): you guard its jarl and hall. Use when the player asks you to be housecarl of a particular place and you agree.", "Elig_TownOfficial", "Exec_HoldHousecarl", "{\"town\": \"the hold or city\"}")
	Reg("CSN_BecomeThane", "Accept the player's offer to become a THANE of a hold the player's faction controls, whenever the player says Thane (e.g. 'I name you Thane of Whiterun', 'be my Thane of the Reach'). A Thane is not a jarl and does not rule the hold: a landed notable of that hold who wears its Thane outfit and may bring the leader private ventures to invest in. Use when the player asks you to be Thane and you agree. Costs the faction 1000 gold; officers, Captains, Commanders, jarls, stewards and housecarls can't be Thanes.", "Elig_Thane", "Exec_Thane", "{\"hold\": \"the hold (or its city)\"}")
	Reg("CSN_BecomeTownOfficial", "Accept the player's offer to be JARL of a city and its hold, or LEADER of a village, the player's faction rules: only when the player says jarl, leader or rule. NOT for Thane (a Thane is not a jarl: use CSN_BecomeThane), nor for a town's steward or housecarl (CSN_BecomeHoldSteward, CSN_BecomeHousecarl). Use only when the player asks this NPC to take that office and the NPC agrees.", "Elig_TownOfficial", "Exec_TownOfficial", "{\"town\": \"city or village name\", \"office\": \"jarl, leader, steward, housecarl or thane\"}")
	Reg("CSN_AnswerRequest", "You have a formal request waiting for the player's answer (see what you asked the leader). Use when the player gives their answer in conversation: they accept it, deny it, or offer to meet in the middle (a compromise, only where the request has one). The player confirms.", "Elig_AnswerRequest", "Exec_AnswerRequest", "{\"answer\": \"accept, deny or middle\", \"request\": \"a few words naming the request if you made more than one, e.g. taxes in Riverwood\"}")
	Reg("CSN_JoinAsCaptain", "Agree to lead one of the player's armies as a Captain (Captains become Commanders when they earn stars). Use only when the player asks this NPC to lead troops and the NPC agrees.", "Elig_JoinCommander", "Exec_JoinCommander")
	Reg("CSN_AcceptDismissal", "The player (the leader) has just removed you from your office in their faction (General, Steward, Blacksmith, Court Wizard, Captain or Commander, or jarl or steward of one of the faction's towns) and you accept it. Use only when the player clearly says you are dismissed, relieved, fired or replaced.", "Elig_InService", "Exec_Dismissed")
	Reg("CSN_ResignFromOffice", "Step down of your own accord from your office in the player's faction (General, Steward, Blacksmith, Court Wizard, Captain or Commander, or jarl or steward of one of the faction's towns). Use only when you truly no longer want to serve and say so; the leader may refuse.", "Elig_InService", "Exec_Resign")
	Reg("CSN_WearOutfitTemplate", "As a Captain or Commander, put on one of the faction's five army outfit templates (uniforms), numbered 1 to 5, when the player asks you to wear outfit template N. Opens that template so the player can fill or adjust it; you change into it when they close it. Not for the General, Steward, Blacksmith, Court Wizard, jarls or their courts (they use CSN_ChangeOutfit).", "Elig_Commander", "Exec_WearTemplate", "{\"template\": \"outfit template number, 1 to 5\"}")
	Reg("CSN_ChangeOutfit", "Change what YOU wear when the player plainly asks you to wear something different. The General, Steward, Blacksmith, Court Wizard, a jarl or a town's steward or housecarl gets the outfit of their position: the player edits it (default), or you wear the standard outfit that reflects your position, or whatever you wish. A Captain or Commander picks one of the army outfit templates (for a numbered template use CSN_WearOutfitTemplate). Never for talk about the faction's culture, customs, beliefs, doctrine or style of leadership, and never for the troops' equipment.", "Elig_Outfit", "Exec_Outfit", "{\"choice\": \"edit (the player chooses the clothes, the default), position (the standard outfit of your office) or whatever (you wear what you like)\"}")

	; ---- Unrest, deserters, plots and settlements (1.9.0) -----------------------
	Reg("CSN_RebelTerms", "The people of a town the player's faction rules are in unrest or have risen up (see what people here are talking about). As the rebels' leader, as that town's jarl, steward or leader, or as the faction's General or Steward, use this when the player offers or agrees to meet the people's demands (gold for the families, food, lower taxes). The player confirms the cost.", "Elig_RebelTerms", "Exec_RebelTerms", "{\"town\": \"the troubled town (leave empty for your own)\"}")
	Reg("CSN_FreeCompanyTerms", "You lead a free company of soldiers who broke away from the player's faction. Use when you and the player agree terms: either the player pays the arrears you are owed and you swear back into the faction (pay), or the player recognises your free realm and you make peace (peace). The player confirms.", "Elig_FreeCompany", "Exec_FreeCompany", "{\"terms\": \"pay (arrears paid, rejoin the faction) or peace (independence recognised)\"}")
	Reg("CSN_SendArmyAgainstRebels", "As the player's General, the faction's Steward, a jarl or steward of one of its towns, or a Captain or Commander, send an army of the faction to put down an uprising in one of the faction's towns (e.g. 'send Army 2 to crush the rising in Shor's Stone', or to a Captain: 'take your army and deal with the rebels in Riften'). The player confirms; the army marches there (hours, by distance) and the fight is decided when it arrives; the army loses troops either way.", "Elig_SendAgainstRebels", "Exec_SendAgainstRebels", "{\"army\": \"army number, name or leader (leave empty for your own as a Captain or Commander)\", \"town\": \"the town that has risen (leave empty if only one has)\"}")
	Reg("CSN_SendArmyAgainstDeserters", "As the player's General, the faction's Steward, a jarl or steward of one of its towns, or a Captain or Commander, send an army of the faction against a free company of deserters when the player orders it. The player confirms; the army marches there and the battle is decided when it arrives.", "Elig_SendAgainstDeserters", "Exec_SendAgainstDeserters", "{\"army\": \"army number, name or leader (leave empty for your own as a Captain or Commander)\", \"company\": \"the deserters' leader or company name (leave empty if there is only one)\"}")
	Reg("CSN_TakeBribe", "Take the player's gold as a bribe to turn against your jarl. You are a guard of this city. Use it whenever the player offers you gold, coin or a bribe and you take it, even warily or in secret; only words of refusal mean no. No gold changes hands without this action. The player then chooses how much.", "Elig_TakeBribe", "Exec_TakeBribe")
	Reg("CSN_TakeFunds", "Take the player's gold to back them against your jarl, for you and your friends. You live in this city (noble, merchant or citizen). Use it whenever the player offers you gold, coin or funds and you take it or show interest, even guardedly; only words of refusal mean no. No gold changes hands without this action. The player then chooses how much.", "Elig_TakeFunds", "Exec_TakeFunds")
	Reg("CSN_PersuadedAgainstJarl", "Be swayed against your jarl by the player's words. You live in or guard this city. Use it when the player argues, without offering gold, that your jarl is unworthy or that you should turn on them, and you listen or half-agree. Whether you are truly won over is decided by the player's Speech.", "Elig_Persuade", "Exec_Persuade")
	Reg("CSN_JoinCoup", "You are a guard or a noble of a city ruled by the Imperials or the Stormcloaks who has taken the player's side against the jarl. Use when the player says it is time to act and asks you to set the coup against the jarl in motion. The player confirms.", "Elig_Coup", "Exec_Coup")
	Reg("CSN_FoundSettlement", "As the player's Steward, General or one of the faction's jarls, found a new settlement of the faction where the player stands, when the player asks to settle or found a village here. The player confirms the cost and names it.", "Elig_Settler", "Exec_FoundSettlement")
	Reg("CSN_BuildInSettlement", "Open the build menu of the faction's settlement where the player stands, when the player wants to build something there (homes, fields, a mill, walls, towers and so on). As the player's Steward or General, a jarl, village leader or town steward of the faction, or a settler of that settlement.", "Elig_Build", "Exec_Build")

	; ---- Commander orders ----------------------------------------------------
	Reg("CSN_ArmyFollowPlayer", "As a Captain or Commander, lead your army to follow the player. Use when the player orders you to follow them or march with them.", "Elig_Commander", "Exec_ArmyFollow")
	Reg("CSN_ArmyFormUp", "As a Captain or Commander whose army is marching with the player, have your troops get in formation. Use when the player says to form up or get in formation.", "Elig_Commander", "Exec_FormUp")
	Reg("CSN_ArmyBreakFormation", "As a Captain or Commander whose army is marching with the player, have your troops break formation. Use when the player says to break formation or fall out.", "Elig_Commander", "Exec_BreakFormation")
	Reg("CSN_ArmyUniform", "Open the uniform of one army (only that army's troops wear it, over the troop-type outfits). As a Captain or Commander for your own army; as General or Blacksmith name the army. Use when the player wants a uniform or outfit just for that unit.", "Elig_ArmyUniform", "Exec_ArmyUniform", "{\"army\": \"army number, name or leader (leave empty for your own)\"}")
	Reg("CSN_ArmyHunt", "As a Captain or Commander, take your army hunting to gather food for the faction. Use when the player orders you to hunt or gather food.", "Elig_Commander", "Exec_ArmyHunt")
	Reg("CSN_ArmyReturnHome", "As a Captain or Commander, take your army back to its home holding. Use when the player orders you back home.", "Elig_Commander", "Exec_ArmyPatrolClaim")
	Reg("CSN_ArmyGarrisonCity", "As a Captain or Commander, move your army into the garrison of a city the faction rules. Use when the player orders you to garrison or defend one of their cities.", "Elig_CommanderCity", "Exec_ArmyGarrisonCity", "{\"city\": \"name of a city the faction rules\"}")
	Reg("CSN_ArmyGarrisonFort", "As a Captain or Commander, move your army into a fort the faction holds. Use when the player orders you to hold or garrison one of their forts.", "Elig_CommanderFort", "Exec_ArmyGarrison", "{\"fort\": \"name of a fort the faction holds\"}")
	Reg("CSN_ArmyMakeCamp", "As a Captain or Commander, march your army to a hold to patrol it or make camp there (an attack camp if the faction does not control that land yet). If the faction already has a war camp in that hold, your army joins that camp instead. Use when the player orders you to patrol, camp in, march on or join the camp in a hold.", "Elig_Commander", "Exec_ArmyCamp", "{\"hold\": \"hold or city name, e.g. Whiterun, The Reach\"}")
	Reg("CSN_NameArmy", "Give an army a name (at most 25 letters) and, if the player gives one, a purpose, goal or mantra. As a Captain or Commander you name your own army; as General any army. Use only when the player names or renames an army, or sets its purpose; an empty name gives it back its number.", "Elig_NameArmy", "Exec_NameArmy", "{\"army\": \"army number, its current name or its leader (leave empty for your own army)\", \"name\": \"the new name, at most 25 letters\", \"purpose\": \"its purpose, goal or mantra, if the player gave one\"}")
	Reg("CSN_WarCampPlans", "Open the war camp plans: a list of the targets in a hold (its city, fort and enemy war camps) for the player to choose one, then the army selection and confirmation, as at the war table. Use when the player wants to make war camp plans, plan an attack or discuss war plans with you. As a Captain or Commander at a war camp it is for that camp's hold; as General name the hold.", "Elig_WarPlans", "Exec_WarCampPlans", "{\"hold\": \"hold to plan in (leave empty for the camp you are at)\"}")
	Reg("CSN_OrderAttack", "Send one or more armies camped or garrisoned in a hold to attack a target there: a city, a fort or an enemy war camp, e.g. send Army 1 and Army 2 to attack Fort Greymoor. The player sees every detail and confirms. As a Captain or Commander at a war camp you may propose it for the armies at your camp; as General for any.", "Elig_WarPlans", "Exec_OrderAttack", "{\"armies\": \"armies to send, by number, name or leader, e.g. Army 1, Army 2 (leave empty for your own)\", \"target\": \"city, fort or enemy camp, e.g. Fort Greymoor, Whiterun, the Imperial camp in Whiterun\"}")
	Reg("CSN_BeginAttack", "Give the order to begin the attack that is waiting at the staging ground (a fort or city attack), blowing the horn. Use only when the player tells you it is time to begin the attack.", "Elig_BeginAttack", "Exec_BeginAttack")
	Reg("CSN_CallOffAttack", "Call off the faction's current attack on a city, fort or camp; the armies go back to their posts. Use only when the player orders the attack cancelled or called off.", "Elig_CallOffAttack", "Exec_CallOffAttack")

	; ---- General -------------------------------------------------------------
	Reg("CSN_OpenWarTable", "As General, open the war table (the faction screen's War Table tab) with every commander, their troops and orders. Use ONLY when the player asks to look over the war table or all the armies; for any particular order (camp, garrison, attack, war camp plans, recruit, stars, names, uniforms) use that order's own action instead.", "Elig_General_Is", "Exec_OpenWarTable")
	Reg("CSN_RelayOrder", "As General, as the faction's Steward, or as a jarl or steward of one of the faction's towns, pass the leader's order to one of the Captains or Commanders (e.g. 'have Army 2 garrison Riften' to put down an uprising there). Always name the army leader and, for garrison or camp orders, the exact city, fort or hold. Orders: follow, hunt, home, garrison city, garrison fort, camp.", "Elig_Council", "Exec_RelayOrder", "{\"commander\": \"commander's name\", \"order\": \"follow|hunt|home|garrison city|garrison fort|camp\", \"target\": \"city, fort or hold name when the order needs one\"}")
	Reg("CSN_ReceiveStar", "As a Captain or Commander of the player's army, accept a star (a medal and a rank) from the leader when the player says they are awarding you one. Costs the faction 10000 gold and 100 food; your troops grow stronger and their morale rises at once. The player confirms.", "Elig_Commander", "Exec_ReceiveStar")
	Reg("CSN_ArrangeIntrigue", "As the player's Steward, General or one of the faction's jarls, have your agents work in a city ruled by the Imperials or the Stormcloaks: bribe its guards, fund its nobles and citizens, or plan a coup against its jarl (e.g. 'tell your agents to plan the coup on Riften'), paid from the faction's treasury. Use whenever the player asks for any of these; the player confirms, and is told if the city isn't ready yet.", "Elig_SpyMaster", "Exec_ArrangeIntrigue", "{\"city\": \"the city\", \"what\": \"guards (bribe the guard), people (fund nobles and citizens) or coup (overthrow the jarl)\"}")
	Reg("CSN_GeneralAwardStar", "As General, award a star (medal) to one of the Captains or Commanders for distinguished service, when the leader asks you to give one or approves your proposal. A star costs 10000 gold and 100 food, makes a Captain a Commander, and gives that army's troops 10% more health and stamina; five stars is the most.", "Elig_General_Is", "Exec_AwardStar", "{\"commander\": \"name of the Captain or Commander to honour\"}")
	Reg("CSN_GeneralMakeCamp", "As General, have a commander set up an army camp or attack camp in a hold. Use when the player wants an army camped in a hold or ready to attack it.", "Elig_General_Is", "Exec_GeneralCamp", "{\"commander\": \"commander's name\", \"hold\": \"hold or city name\"}")

	Reg("CSN_GeneralDismissCaptain", "As General, remove one of the Captains or Commanders from command of their army, when the leader orders it. Name them.", "Elig_General_Is", "Exec_GeneralDismiss", "{\"commander\": \"name of the Captain or Commander to remove\"}")

	Reg("CSN_GeneralRecruitTroops", "As General, recruit new troops for one army when the leader asks, e.g. 5 archers and 10 soldiers for Army 5. The four troop types are soldiers, warriors, archers and crossbowmen; battlemages (fire, frost, shock, healers, conjurers, alteration) and Dwemer machines (spiders, spheres, ballistas) only once researched, and beasts (skeevers, wolves, sabre cats, frostbite spiders, bears, trolls, giants, mammoths). Never any other kind. Only so many troops can be recruited each day; the leader confirms the cost first.", "Elig_General_Is", "Exec_Recruit", "{\"army\": \"army number or the name of its Captain or Commander\", \"troops\": \"numbers and kinds, e.g. 5 archers, 10 soldiers\"}")
	Reg("CSN_SetTroopTemplate", "As General or Blacksmith, write a troop template (1 to 5) when the leader dictates it, e.g. 10 soldiers, 7 archers, 2 crossbowmen in template 1. It replaces what the template held; it costs nothing and only records the mix for later.", "Elig_GeneralOrSmith", "Exec_SetTemplate", "{\"template\": \"1 to 5\", \"troops\": \"numbers and kinds, e.g. 10 soldiers, 7 archers\"}")
	Reg("CSN_ApplyTroopTemplate", "As General or Blacksmith, apply a troop template (1 to 5) to an army when the leader asks, so the army refills to that mix.", "Elig_GeneralOrSmith", "Exec_ApplyTemplate", "{\"template\": \"1 to 5\", \"army\": \"army number or the name of its Captain or Commander\"}")

	; ---- Blacksmith ------------------------------------------------------------
	Reg("CSN_BlacksmithTroopEquipment", "As Blacksmith, manage the equipment of the faction's troops: their custom outfits by troop type (soldiers, warriors, archers, crossbowmen, city guards, battlemages), one outfit for all or separate outfits for men and women. Use when the player wants to change what the troops wear or carry.", "Elig_Blacksmith_Is", "Exec_TroopEquipment", "{\"troop\": \"soldiers, warriors, archers, crossbowmen, guards, or empty to choose\"}")
	Reg("CSN_BlacksmithUpgradeArmour", "As Blacksmith, offer the troops better standard armour (iron, steel, dwarven, ebony and so on) bought with the treasury and metal. Use when the player wants to upgrade the troops' armour.", "Elig_Blacksmith_Is", "Exec_UpgradeArmour")
	Reg("CSN_BlacksmithTroopRaces", "As Blacksmith, open the list of which races and genders may be recruited into the faction's army. Use when the player wants to change who can join the troops.", "Elig_Blacksmith_Is", "Exec_TroopRaces")

	; ---- Anyone of means -------------------------------------------------------
	Reg("CSN_SellSuppliesToFaction", "Sell food, metal or wood to the player's faction when the player asks to buy it from you, paid from their treasury (at least 20 gold each), at most 50 at a time. Anyone who works on, owns or lives on a farm sells food (farmhands, farm families such as the Battle-Borns, those who buy wheat); anyone from a mine sells metal (miners, mine owners and their households); anyone from a lumber camp or mill sells wood (lumberjacks, mill owners and workers, those who buy firewood). They sell what they produce to anyone; merchants sell any of the three; others only if they like the player. Use once you have agreed on what and how much (if no amount was agreed, the player chooses it).", "Elig_Seller", "Exec_SellToFaction", "{\"material\": \"food, metal or wood\", \"amount\": \"how many, 1 to 50\"}")
	Reg("CSN_BuySupplies", "Buy food, metal or wood from the player's faction, paid in gold to their treasury at the going rate, at most 50 at a time. Only if you are someone of means who would want it (a merchant, a jarl's court, a mill, mine or farm owner, a camp's chief) and you like the player enough to deal with them, and you have agreed on what and how much.", "Elig_Buyer", "Exec_BuySupplies", "{\"material\": \"food, metal or wood\", \"amount\": \"how many, 1 to 50\"}")

	; ---- Stewards ------------------------------------------------------------
	Reg("CSN_StewardDeposit", "As a steward or jarl of the faction, take gold from the player for the treasury. Use when the player hands you gold for the treasury.", "Elig_AnySteward", "Exec_Deposit", "{\"amount\": \"gold, a whole number\"}")
	Reg("CSN_StewardWithdraw", "As a steward or jarl of the faction, pay the player gold out of the treasury. Use when the player asks for gold from the treasury.", "Elig_AnySteward", "Exec_Withdraw", "{\"amount\": \"gold, a whole number\"}")
	Reg("CSN_StewardDeclareWar", "As the faction's Steward or one of its jarls, prepare a declaration of war for the player to sign. Use only when the player wants war.", "Elig_Steward_Is", "Exec_DeclareWar", "{\"side\": \"Imperials or Stormcloaks\"}")
	Reg("CSN_StewardProposeTrade", "As the faction's Steward or one of its jarls, draw up a trade with the Imperial Legion or the Stormcloaks (another faction, never one of the player's own towns or villages; for those use CSN_ProposeCityTrade) for the player to approve.", "Elig_Steward_Is", "Exec_ProposeTrade", "{\"side\": \"Imperials or Stormcloaks\", \"material\": \"food, metal or wood\", \"direction\": \"import or export\", \"amount\": \"units per day\"}")
	Reg("CSN_OpenStewardLedger", "As a steward, open the ledger (the faction screen's Steward tab): treasury, supplies, towns, trade and wars. Use ONLY when the player asks to look over the ledger or the books; for a particular deposit, withdrawal, trade, tax, upgrade, guards or declaration of war use that action instead.", "Elig_AnyStewardOrJarl", "Exec_OpenLedger")
	Reg("CSN_OpenEconomy", "As the faction's Steward or one of its jarls, open the full economy ledger (holdings, taxes, guards).", "Elig_Steward_Is", "Exec_OpenEconomy")

	Reg("CSN_Decree", "As the faction's General, its Steward or one of its jarls, pass a new decree (law) when the leader orders it: conscription (how many of the able-bodied may be called up, 0-100%), a punishment for a crime, or the faction's law on worshipping a god (outlawed, allowed or mandatory). Conscription and punishments can be for the whole faction or one town it rules; religion is for the whole faction. More conscription lowers loyalty, less raises it. The leader confirms. Crimes: " + CSN_Decrees.Names(0) + ". Punishments: " + CSN_Decrees.Names(1) + ". Gods: " + CSN_Decrees.Names(2) + ".", "Elig_Decree", "Exec_Decree", "{\"law\": \"conscription, punishment or religion\", \"percent\": \"conscription: 0, 25, 50, 75 or 100\", \"crime\": \"punishment: which crime\", \"sentence\": \"punishment: the punishment, or repeal\", \"god\": \"religion: which god\", \"status\": \"religion: outlawed, allowed or mandatory\", \"town\": \"a town the faction rules (leave empty for the whole faction)\"}")
	Reg("CSN_SetTaxes", "As the faction's Steward or one of its jarls (any town it rules) or as steward of one of its towns (your own town), change that town's taxes when the leader orders it. Taxes go from 0% to 50% in steps of 10%; lower taxes make people more loyal, higher taxes bring more gold.", "Elig_Taxes", "Exec_Taxes", "{\"town\": \"town name (leave empty for your own town)\", \"percent\": \"new tax rate: 0, 10, 20, 30, 40 or 50\", \"direction\": \"raise or lower, if no percent was given\"}")

	; ---- Jarls ---------------------------------------------------------------
	Reg("CSN_ProposeCityTrade", "Change the daily food, metal or wood trade between the player's faction and one of the cities or villages it rules: the faction exports supplies to the town, imports them from it, or stops. Use when the player says e.g. 'export 10 food to Riverwood' or 'import 5 wood from Whiterun'. The faction's Steward and its jarls can do it for any town the faction rules; a town's steward for their own town (and may propose it). The player confirms.", "Elig_Taxes", "Exec_CityTrade", "{\"town\": \"city or village name (leave empty for your own town)\", \"material\": \"food, metal or wood\", \"flow\": \"to_town (the faction exports to the town), from_town (the faction imports from the town) or stop\", \"amount\": \"units per day\"}")
	Reg("CSN_JarlCedeFort", "As a jarl whose side is at peace with the player's faction, agree to hand your hold's main fort over to the player's faction for your asking price. Use only when the player accepts your price. The deal is made at the asking price you named and remember. Or, at your sole discretion, hand it over for nothing (free: yes): under duress, to repay a truly great favour, or as part of a partnership.", "Elig_CedeFort", "Exec_CedeFort", "{\"gold\": \"gold agreed, 0 if none\", \"food\": \"food agreed, 0 if none\", \"metal\": \"metal agreed, 0 if none\", \"wood\": \"wood agreed, 0 if none\", \"free\": \"yes only if you give it for nothing, otherwise no\"}")
	Reg("CSN_StewardUpgradeBuilding", "As the faction's Steward or one of its jarls (any town it rules) or as steward of one of its towns (your own town), start an upgrade of a town's barracks, farms, lumber mills or mines when the leader orders it (villages have no barracks). The leader sees the level and cost in gold and wood first.", "Elig_Taxes", "Exec_Upgrade", "{\"town\": \"town name (leave empty for your own town)\", \"building\": \"barracks, farms, lumber mills or mines\"}")
	Reg("CSN_MoveTownGold", "As the faction's Steward or one of its jarls (any town it rules) or as steward of one of its towns (your own town), move gold between a town's own stores (where its taxes pile up) and the faction's treasury when the leader asks: bring it into the treasury, or send treasury gold to the town. The leader confirms.", "Elig_Taxes", "Exec_MoveTownGold", "{\"town\": \"town name (leave empty for your own town)\", \"amount\": \"gold, a whole number, or all\", \"direction\": \"to_treasury (from the town into the treasury) or to_town (from the treasury to the town)\"}")
	Reg("CSN_StewardHireGuards", "As the faction's Steward or one of its jarls (any town it rules) or as steward of one of its towns (your own town), hire guards for a town when the leader orders it. The leader sees the crime, the guards there and the cost first.", "Elig_Taxes", "Exec_HireGuards", "{\"town\": \"town name (leave empty for your own town)\", \"amount\": \"how many guards\"}")
	Reg("CSN_LeaderSellFort", "As General Tullius or Ulfric Stormcloak, agree to hand one of the forts your side holds over to the player's faction, while your side is at peace with it, for your asking price for that fort. Use only when the player accepts your price. The deal is made at the asking price you named and remember.", "Elig_LeaderFort", "Exec_LeaderFort", "{\"fort\": \"name of the fort\", \"gold\": \"gold agreed, 0 if none\", \"wood\": \"wood agreed, 0 if none\", \"metal\": \"metal agreed, 0 if none\", \"food\": \"food agreed, 0 if none\"}")
	Reg("CSN_JarlCedeCity", "As a jarl whose side is at peace with the player's faction, agree to bring your city over to the player's faction for your asking price. Use only when the player accepts your price. The deal is made at the asking price you named and remember. Or, at your sole discretion, hand it over for nothing (free: yes): under duress, to repay a truly great favour, or as part of a partnership.", "Elig_CedeCity", "Exec_CedeCity", "{\"price\": \"gold agreed\", \"food\": \"food agreed, 0 if none\", \"metal\": \"metal agreed, 0 if none\", \"wood\": \"wood agreed, 0 if none\", \"free\": \"yes only if you give it for nothing, otherwise no\"}")
	Reg("CSN_SetAskingPrice", "As a jarl, General Tullius or Ulfric Stormcloak at peace with the player's faction, name or change your asking price for your city and hold, or for a fort your side holds. Use whenever you state a price for the first time, or change the one you named before. Gold never under the least shown to you; food, metal and wood are up to you.", "Elig_SetAsk", "Exec_SetAsk", "{\"place\": \"the city or fort being priced\", \"gold\": \"gold asked\", \"food\": \"food asked, 0 if none\", \"metal\": \"metal asked, 0 if none\", \"wood\": \"wood asked, 0 if none\"}")
EndFunction

; =============================================================================
; DECORATOR: exact numbers an officer, commander, steward or jarl knows
; Prompt usage: {{ csn_officer_knowledge(actorUUID) }}
; =============================================================================
String Function Decorator_OfficerKnowledge(Actor akActor) Global
	Return CSN_Gov.Knowledge(akActor)
EndFunction

; Culture, leadership style and military doctrine (CSN_Culture). Prompt usage: {{ csn_culture(actorUUID) }}
String Function Decorator_Culture(Actor akActor) Global
	Return CSN_Culture.KnowledgeFor(akActor)
EndFunction

; =============================================================================
; DECORATOR: what this NPC knows about the player's faction
; Prompt usage: {{ csn_faction_context(npc.UUID) }}
; =============================================================================
String Function Decorator_FactionContext(Actor akActor) Global
	CSN_Core m = Main()
	If !m || m.FactionStarted.GetValue() < 1 || !akActor
		Return ""
	EndIf
	String fac = m.FactionName()
	String leader = Game.GetPlayer().GetDisplayName()
	Int role = m.GetRole(akActor)
	Int army = m.GetArmy(akActor)
	CS_ClaimAreaFunctions h = m.Holdings()
	String s = ""

	If role >= 0
		s = m.BaseName(akActor) + " is the " + m.RoleTitle(role) + " of the " + fac + ", a faction led by " + leader + ". "
		s += "Treasury: " + h.Treasury.GetValueInt() + " gold (" + h.TreasuryPerDay.GetValueInt() + " a day). Food: " + h.FoodReserve.GetValueInt() + " (" + h.FoodPerDay.GetValueInt() + " a day). "
		s += "Holdings: " + HoldingText(m) + ". Wars: " + WarText(m) + ". Officers: " + OfficerText(m) + ". Armies: " + ArmyText(m) + "."
		If role == m.ROLE_STEWARD
			s += " As Steward they run trade with the Imperials and Stormcloaks (" + CSN_Config.TradePrice() + " gold per unit per day; never import and export the same material with the same side) and prepare war declarations for the leader to sign."
		EndIf
		If role == m.ROLE_STEWARD || role == m.ROLE_GENERAL
			s += CSN_Requests.InvestmentsText()
		EndIf
		If role == m.ROLE_GENERAL
			s += " As General they oversee every army and pass on orders: follow, hunt, return home, garrison a city or fort the faction holds, make camp in a hold (or join the camp there), make war camp plans, send armies at a camp to attack a target, begin or call off an attack, and name armies. Armies at home or with no orders are on standby by the leader's choice, rested and ready: the General never complains that troops are idle, bored or need something to do. When it helps, the General makes a specific recommendation instead (which army, which order, which place, and why), and does not repeat it once the leader has heard it."
		EndIf
		Return s
	EndIf

	If army >= 0
		s = m.BaseName(akActor) + " is a " + CSN_Gov.RankText(akActor) + " of the " + fac + ", leading " + CSN_Gov.ArmyLabel(army) + " (" + m.ArmyTroops(army) + " troops, posted: " + CSN_Gov.PostText(army) + "). "
		If CSN_War.IdentityText(army) != ""
			s += CSN_War.IdentityText(army) + " "
		EndIf
		s += CSN_Rebellion.MoraleLine(army) + " "
		If m.Officer(m.ROLE_GENERAL)
			s += "Their General is " + m.BaseName(m.Officer(m.ROLE_GENERAL)) + ". "
		EndIf
		Return s + "Wars: " + WarText(m) + "."
	EndIf

	If m.IsFriend(akActor)
		Return leader + ", a friend of " + m.BaseName(akActor) + ", leads a faction called the " + fac + ". Wars: " + WarText(m) + "."
	EndIf
	Return ""
EndFunction

; =============================================================================
; DECORATOR: the town this NPC lives in - who rules it, how people feel, recent news
; Prompt usage: {{ csn_town_context(npc.UUID) }}
; =============================================================================
String Function Decorator_TownContext(Actor akActor) Global
	If !akActor || akActor == Game.GetPlayer()
		Return ""
	EndIf
	; unrest and uprisings, army morale and free companies, plots against jarls, settlements
	String extra = CSN_Rebellion.Knowledge(akActor) + CSN_Intrigue.Knowledge(akActor) + CSN_Settle.Knowledge(akActor) + CSN_Gov.StoresKnowledge(akActor) + CSN_Festival.Knowledge(akActor) + CSN_Decrees.Knowledge(akActor)
	String thane = CSN_Thanes.Knowledge(akActor)
	If thane != ""
		extra += " " + thane
	EndIf
	Return CSN_World.DescribeFor(akActor) + extra
EndFunction

; =============================================================================
; DECORATOR: ranks and chain of command of the player's faction, for anyone who would know them
; (its officers, commanders and soldiers, the player's friends, and townsfolk of towns it rules)
; Prompt usage: {{ csn_hierarchy(npc.UUID) }}
; =============================================================================
String Function Decorator_Hierarchy(Actor akActor) Global
	CSN_Core m = Main()
	If !m || m.FactionStarted.GetValue() < 1 || !akActor || akActor == Game.GetPlayer()
		Return ""
	EndIf
	Int role = m.GetRole(akActor)
	Int army = m.GetArmy(akActor)
	Bool soldier = m.Gov.LoyaltyScript.PlayerArmyFaction && akActor.IsInFaction(m.Gov.LoyaltyScript.PlayerArmyFaction)
	Int town = CSN_World.TownOf(akActor)
	Bool subject = town >= 0 && CSN_World.PlayerRules(town)
	If role < 0 && army < 0 && !soldier && !subject && !m.IsFriend(akActor)
		Return ""
	EndIf
	String fac = m.FactionName()
	String leader = Game.GetPlayer().GetDisplayName()
	String s = "Ranks of the " + fac + ": " + leader + " leads it and has the final word. Under the leader serve four officers: "
	s += "the General (commands every army; all Captains and Commanders answer to the General), the Steward (treasury, supplies, trade with the Imperials and Stormcloaks, and drafting declarations of war for the leader to sign), "
	s += "the Blacksmith (arms and armour for the troops) and the Court Wizard (magical counsel to the leader). "
	s += "Each army is led by a Captain chosen by the leader; a Captain who earns a star (up to five, awarded by the leader or the General) becomes a Commander, and stars make their troops stronger. Soldiers obey their Captain or Commander. Officers and army leaders are addressed by their title in front of their name (General, Steward, Captain, Commander)."
	s += " Every star is a rank of its own: a Commander with more stars outranks one with fewer, and every Commander outranks every Captain. An army leader never takes orders from one with fewer stars; Captains and lesser Commanders show those above them real respect (as a rule, though a bold one may voice doubts), and orders between army leaders only ever flow down the ranks. All of them answer to the General."
	s += " Current officers: " + OfficerText(m) + ". Army leaders: " + ArmyText(m) + "."
	If CSN_Culture.TitleTextFor(akActor) != ""
		s += " " + CSN_Culture.TitleTextFor(akActor)
	EndIf
	String thanes = ""
	Int ti = 0
	While ti < CSN_Thanes.Count()
		Actor tha = CSN_Thanes.At(ti)
		thanes = CSN_Rebellion.AddTo(thanes, m.PlainName(tha) + " (" + CSN_Thanes.HoldName(CSN_Thanes.HoldOf(tha)) + ")")
		ti += 1
	EndWhile
	If thanes != ""
		s += " Thanes of the faction (landed notables of its holds, not officers): " + thanes + "."
	EndIf
	If role >= 0
		s += " " + m.BaseName(akActor) + " is the " + m.RoleTitle(role) + " and answers directly to " + leader + "."
	ElseIf army >= 0
		s += StarOrderText(m, akActor)
		s += " " + m.BaseName(akActor) + " is the " + CSN_Gov.RankText(akActor) + " of " + CSN_Gov.ArmyLabel(army)
		If m.Officer(m.ROLE_GENERAL)
			s += " and answers to General " + m.BaseName(m.Officer(m.ROLE_GENERAL))
		Else
			s += " and answers directly to " + leader + " while no General is appointed"
		EndIf
		s += "."
	ElseIf soldier
		Int troopArmy = CSN_War.TroopArmy(akActor)
		Actor lead = None
		If troopArmy >= 0
			lead = m.Commander(troopArmy)
		EndIf
		If lead
			s += " " + m.BaseName(akActor) + " serves in " + CSN_Gov.ArmyLabel(troopArmy) + " under " + CSN_Gov.RankText(lead) + " " + m.BaseName(lead) + ", and obeys them."
			If CSN_War.IdentityText(troopArmy) != ""
				s += " " + CSN_War.IdentityText(troopArmy)
			EndIf
			s += CSN_War.BattleText()
		Else
			s += " " + m.BaseName(akActor) + " is a soldier in the faction's army and obeys their Captain or Commander."
		EndIf
	ElseIf subject
		s += " " + m.BaseName(akActor) + " lives in " + CSN_World.TownName(town) + ", which the " + fac + " rules."
	EndIf
	Return s
EndFunction

; Who outranks this army leader by stars, who ranks the same and who is below them.
String Function StarOrderText(CSN_Core m, Actor akActor) Global
	CS_PatrolHoldScript a = m.Armies()
	Int mine = CSN_Gov.Stars(akActor)
	String above = ""
	String same = ""
	String below = ""
	Int i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c && c != akActor && !c.IsDead()
			String who = CSN_Gov.RankText(c) + " " + m.BaseName(c)
			Int theirs = CSN_Gov.Stars(c)
			If theirs > mine
				If above != ""
					above += ", "
				EndIf
				above += who
			ElseIf theirs == mine
				If same != ""
					same += ", "
				EndIf
				same += who
			Else
				If below != ""
					below += ", "
				EndIf
				below += who
			EndIf
		EndIf
		i += 1
	EndWhile
	String s = " " + m.BaseName(akActor) + " (" + mine + " stars) ranks"
	If above != ""
		s += " below " + above + " (they defer to them and would take their orders)"
	Else
		s += " below no other army leader"
	EndIf
	If same != ""
		s += "; level with " + same + " (equals: neither orders the other)"
	EndIf
	If below != ""
		s += "; above " + below + " (who defer to them; they never take orders from them)"
	EndIf
	Return s + "."
EndFunction

String Function WarText(CSN_Core m) Global
	If m.AtWar(1) && m.AtWar(2)
		Return "at war with both the Imperial Legion and the Stormcloaks"
	ElseIf m.AtWar(1)
		Return "at war with the Imperial Legion"
	ElseIf m.AtWar(2)
		Return "at war with the Stormcloaks"
	EndIf
	Return "at peace"
EndFunction

String Function OfficerText(CSN_Core m) Global
	String s = ""
	Int i = 0
	While i < 4
		If m.Officer(i)
			If s != ""
				s += ", "
			EndIf
			s += m.RoleTitle(i) + " " + m.BaseName(m.Officer(i))
		EndIf
		i += 1
	EndWhile
	If s == ""
		Return "none appointed"
	EndIf
	Return s
EndFunction

String Function ArmyText(CSN_Core m) Global
	CS_PatrolHoldScript a = m.Armies()
	String s = ""
	Int i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c
			If s != ""
				s += "; "
			EndIf
			s += CSN_Gov.RankText(c) + " " + m.BaseName(c) + " (" + CSN_Gov.ArmyLabel(i) + ", " + m.ArmyTroops(i) + " troops, " + CSN_Gov.PostText(i) + ")"
		EndIf
		i += 1
	EndWhile
	If s == ""
		Return "none"
	EndIf
	Return s
EndFunction

String Function HoldingText(CSN_Core m) Global
	CS_ClaimAreaFunctions h = m.Holdings()
	String s = ""
	Int n = 0
	Int i = 0
	While i < h.Holdings.Length
		Location l = h.Holdings[i].GetLocation()
		If l
			n += 1
			If n <= 8
				If s != ""
					s += ", "
				EndIf
				s += l.GetName()
			EndIf
		EndIf
		i += 1
	EndWhile
	If n == 0
		Return "none yet"
	ElseIf n > 8
		s += " and " + (n - 8) + " more"
	EndIf
	Return s
EndFunction

; =============================================================================
; ELIGIBILITY
; =============================================================================
Bool Function CanTake(Actor a, Int aiRole) Global
	CSN_Core m = Main()
	Return m.CanServe(a) && m.GetRole(a) != aiRole && m.GetArmy(a) < 0   ; a Thane who takes office stops being one
EndFunction

Bool Function Elig_AnswerRequest(Actor akActor, String contextJson, String paramsJson) Global
	Return Main().FactionStarted.GetValue() >= 1 && CSN_Requests.PendingFrom(akActor) >= 0
EndFunction

Function Exec_AnswerRequest(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	String a = Param(paramsJson, "answer")
	Int choice = -1
	If Matches(a, "middle") || Matches(a, "compromise") || Matches(a, "half")
		choice = 2
	ElseIf Matches(a, "deny") || Matches(a, "decline") || Matches(a, "refuse") || Matches(a, "reject") || a == "no"
		choice = 1
	ElseIf Matches(a, "accept") || Matches(a, "approve") || Matches(a, "grant") || a == "yes" || Matches(a, "agree")
		choice = 0
	EndIf
	If choice < 0
		CSN_Gov.Fail("Accept, deny or meet in the middle?")
	Else
		CSN_Requests.AnswerInConversation(akActor, choice, Param(paramsJson, "request"))
	EndIf
	EndAction()
EndFunction

Bool Function Elig_TownOfficial(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Return m.FactionStarted.GetValue() >= 1 && m.CanServe(akActor) && m.GetRole(akActor) < 0 && m.GetArmy(akActor) < 0
EndFunction

; The town an office is for: a hold (its city), a city or a village by name; else the one the speaker or the player is
; in, if the faction rules it; else the player picks one.
Int Function OfficeTown(Actor akActor, String asTown, Bool abCityOnly) Global
	Int t = ParseHold(asTown)
	If t < 0
		t = ParseTown(asTown)
	EndIf
	If t < 0
		t = CSN_World.TownOf(akActor)
		If t < 0 || !CSN_World.PlayerRules(t)
			t = CSN_World.TownOf(Game.GetPlayer())
		EndIf
		If t >= 0 && !CSN_World.PlayerRules(t)
			t = -1
		EndIf
	EndIf
	If t >= 0 && abCityOnly && t > 8
		t = -1
	EndIf
	If t < 0
		Int[] ids = PapyrusUtil.IntArray(0)
		String[] names = PapyrusUtil.StringArray(0)
		Int i = 0
		While i < 15
			If CSN_World.PlayerRules(i) && (!abCityOnly || i <= 8)
				ids = PapyrusUtil.PushInt(ids, i)
				names = PapyrusUtil.PushString(names, CSN_World.TownName(i))
			EndIf
			i += 1
		EndWhile
		If ids.Length == 0
			Return -1
		EndIf
		names = PapyrusUtil.PushString(names, "Cancel")
		Int k = CSNP.Choose("Which town?", "Where should " + CSN_Gov.NameOf(akActor) + " serve?", names)
		If k < 0 || k >= ids.Length
			Return -1
		EndIf
		t = ids[k]
	EndIf
	Return t
EndFunction

; Offered to anyone who could at all be a Thane, so a "Thane" offer is never taken for a jarl's; the full check
; (a friend, not a guard, ...) runs when they accept, and the player is told what stands in the way.
Bool Function Elig_Thane(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Return m.FactionStarted.GetValue() >= 1 && akActor && !akActor.IsChild() && !CSN_Thanes.IsThane(akActor) && CSN_Gov.OfficeOf(akActor) == ""
EndFunction

Function Exec_Thane(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int h = OfficeTown(akActor, Param(paramsJson, "hold"), True)
	If h < 0
		CSN_Gov.Fail("Which hold? Name one your faction controls.")
	Else
		CSN_Thanes.Appoint(akActor, h, akActor)
	EndIf
	EndAction()
EndFunction

Function Exec_HoldSteward(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int t = OfficeTown(akActor, Param(paramsJson, "town"), False)
	If t < 0
		CSN_Gov.Fail("Which hold, city or village? Name one your faction rules.")
	Else
		CSN_Gov.AppointTownOffice(akActor, t, 1)
	EndIf
	EndAction()
EndFunction

Function Exec_HoldHousecarl(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int t = OfficeTown(akActor, Param(paramsJson, "town"), True)
	If t < 0
		CSN_Gov.Fail("Which hold or city? Only cities have housecarls.")
	Else
		CSN_Gov.AppointTownOffice(akActor, t, 2)
	EndIf
	EndAction()
EndFunction

Function Exec_TownOfficial(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int t = ParseHold(Param(paramsJson, "town"))
	If t < 0
		t = ParseTown(Param(paramsJson, "town"))
	EndIf
	String o = Param(paramsJson, "office")
	; a Thane is not a town office: name them Thane instead
	If StringUtil.Find(o, "thane") >= 0
		Int th = OfficeTown(akActor, Param(paramsJson, "town"), True)
		If th < 0
			CSN_Gov.Fail("Which hold? Name one your faction controls.")
		Else
			CSN_Thanes.Appoint(akActor, th, akActor)
		EndIf
		EndAction()
		Return
	EndIf
	Int office = 0
	If Matches(o, "steward")
		office = 1
	ElseIf Matches(o, "housecarl") || Matches(o, "guard")
		office = 2
	EndIf
	If t < 0
		CSN_Gov.Fail("Which city or village?")
	Else
		CSN_Gov.AppointTownOffice(akActor, t, office)
	EndIf
	EndAction()
EndFunction

Bool Function Elig_General(Actor akActor, String contextJson, String paramsJson) Global
	Return CanTake(akActor, 0)
EndFunction
Bool Function Elig_Steward(Actor akActor, String contextJson, String paramsJson) Global
	Return CanTake(akActor, 1)
EndFunction
Bool Function Elig_Blacksmith(Actor akActor, String contextJson, String paramsJson) Global
	Return CanTake(akActor, 2)
EndFunction
Bool Function Elig_Wizard(Actor akActor, String contextJson, String paramsJson) Global
	Return CanTake(akActor, 3)
EndFunction

Bool Function Elig_JoinCommander(Actor akActor, String contextJson, String paramsJson) Global
	Return Main().CanHireCommander(akActor)
EndFunction

Bool Function Elig_InService(Actor akActor, String contextJson, String paramsJson) Global
	Return CSN_Gov.OfficeOf(akActor) != ""
EndFunction

Bool Function Elig_Commander(Actor akActor, String contextJson, String paramsJson) Global
	Return Main().GetArmy(akActor) >= 0
EndFunction

Bool Function Elig_ArmyUniform(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Return m.GetArmy(akActor) >= 0 || m.GetRole(akActor) == m.ROLE_GENERAL || m.GetRole(akActor) == m.ROLE_BLACKSMITH
EndFunction

Function Exec_FormUp(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Gov.Formation(akActor, True)
	EndAction()
EndFunction

Function Exec_BreakFormation(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Gov.Formation(akActor, False)
	EndAction()
EndFunction

Function Exec_ArmyUniform(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Core m = Main()
	Int army = CSN_War.ParseArmy(Param(paramsJson, "army"))
	If army < 0 || (m.GetArmy(akActor) >= 0 && m.GetRole(akActor) < 0)
		army = m.GetArmy(akActor)
	EndIf
	CSN_Gov.ArmyUniform(army, akActor)
	EndAction()
EndFunction

Bool Function Elig_NameArmy(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Return m.GetArmy(akActor) >= 0 || m.GetRole(akActor) == m.ROLE_GENERAL
EndFunction

; a Captain or Commander at a war camp, or the General
Bool Function Elig_WarPlans(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	If m.GetRole(akActor) == m.ROLE_GENERAL
		Return True
	EndIf
	Return m.GetArmy(akActor) >= 0 && CSN_War.CampOf(akActor) >= 0
EndFunction

Bool Function Elig_BeginAttack(Actor akActor, String contextJson, String paramsJson) Global
	Return CSN_War.CanStart() && CSN_War.InAttack(akActor)
EndFunction

Bool Function Elig_CallOffAttack(Actor akActor, String contextJson, String paramsJson) Global
	Return CSN_War.CanCancel() && CSN_War.InAttack(akActor)
EndFunction

Bool Function Elig_CommanderCity(Actor akActor, String contextJson, String paramsJson) Global
	If Main().GetArmy(akActor) < 0
		Return False
	EndIf
	Int i = 0
	While i < 9
		If CSN_World.PlayerRules(i)
			Return True
		EndIf
		i += 1
	EndWhile
	Return False
EndFunction

Bool Function Elig_Outfit(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Return m.GetArmy(akActor) >= 0 || (m.FactionStarted.GetValue() >= 1 && CSN_Gov.GovOutfitKind(akActor) > 0)
EndFunction

Bool Function Elig_AnySteward(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Return m.FactionStarted.GetValue() >= 1 && (ActsAsSteward(akActor) || CSN_Gov.CityStewardOf(akActor) >= 0)
EndFunction

; The faction's Steward, or one of its jarls (or village leaders) of a town it rules: they can do all the Steward does.
Bool Function ActsAsSteward(Actor akActor) Global
	CSN_Core m = Main()
	If !akActor || m.FactionStarted.GetValue() < 1
		Return False
	EndIf
	If m.GetRole(akActor) == m.ROLE_STEWARD
		Return True
	EndIf
	Int j = CSN_Gov.JarlCityOf(akActor)
	Return j >= 0 && CSN_World.PlayerRules(j)
EndFunction

Bool Function Elig_Decree(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Return m.FactionStarted.GetValue() >= 1 && (m.GetRole(akActor) == m.ROLE_GENERAL || ActsAsSteward(akActor))
EndFunction

Function Exec_Decree(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_Decree(akActor, paramsJson)
	EndAction()
EndFunction

Function Do_Decree(Actor akActor, String paramsJson) Global
	String law = Param(paramsJson, "law")
	String tn = Param(paramsJson, "town")
	Int town = -1
	If tn != "" && !Matches(tn, "faction") && !Matches(tn, "all")
		town = ParseTown(tn)
		If town < 0 || !CSN_World.PlayerRules(town)
			CSN_Gov.Fail("Which town? Name one your faction rules, or none for the whole faction.")
			Return
		EndIf
	EndIf
	If Matches(law, "conscript") || Matches(law, "recruit") || Matches(law, "military") || Matches(law, "draft")
		String pc = Param(paramsJson, "percent")
		If pc == ""
			CSN_Gov.Fail("How much conscription? 0% to 100%.")
			Return
		EndIf
		CSN_Decrees.SetConscription(ParseNumber(pc), town)
	ElseIf Matches(law, "religion") || Matches(law, "worship") || Matches(law, "god") || Param(paramsJson, "god") != ""
		Int g = CSN_Decrees.FindDeity(Param(paramsJson, "god"))
		If g < 0
			CSN_Gov.Fail("Which god? " + CSN_Decrees.Names(2) + ".")
			Return
		EndIf
		String st = Param(paramsJson, "status")
		Int status = -1
		If Matches(st, "outlaw") || Matches(st, "ban") || Matches(st, "illegal") || Matches(st, "forbid")
			status = 0
		ElseIf Matches(st, "mandatory") || Matches(st, "require") || Matches(st, "official")
			status = 2
		ElseIf Matches(st, "allow") || Matches(st, "legal") || Matches(st, "permit")
			status = 1
		EndIf
		If status < 0
			CSN_Gov.Fail("Outlawed, allowed or mandatory?")
			Return
		EndIf
		CSN_Decrees.SetDeity(g, status)
	Else
		Int c = CSN_Decrees.FindCrime(Param(paramsJson, "crime"))
		If c < 0
			CSN_Gov.Fail("Which crime? " + CSN_Decrees.Names(0) + ".")
			Return
		EndIf
		String sn = Param(paramsJson, "sentence")
		Int sentence = -2
		If Matches(sn, "repeal") || Matches(sn, "none") || Matches(sn, "remove")
			sentence = -1
		Else
			sentence = CSN_Decrees.FindSentence(sn)
		EndIf
		If sentence < -1
			CSN_Gov.Fail("Which punishment? " + CSN_Decrees.Names(1) + ", or repeal.")
			Return
		EndIf
		CSN_Decrees.SetPunishment(c, sentence, town)
	EndIf
EndFunction

Bool Function Elig_AnyStewardOrJarl(Actor akActor, String contextJson, String paramsJson) Global
	Return Main().FactionStarted.GetValue() >= 1 && CSN_Gov.IsAnySteward(akActor)
EndFunction

Bool Function Elig_CityTrade(Actor akActor, String contextJson, String paramsJson) Global
	Return CityOfSpeaker(akActor) >= 0
EndFunction

; Town (0-14) whose jarl or steward this is, when the player's faction rules it.
Int Function CityOfSpeaker(Actor akActor) Global
	Int c = CSN_Gov.CityStewardOf(akActor)
	If c < 0
		c = CSN_Gov.JarlCityOf(akActor)
		If c >= 0 && !CSN_World.PlayerRules(c)
			c = -1
		EndIf
	EndIf
	Return c
EndFunction

Bool Function Elig_Taxes(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	If m.FactionStarted.GetValue() < 1
		Return False
	EndIf
	Return m.GetRole(akActor) == m.ROLE_STEWARD || CityOfSpeaker(akActor) >= 0
EndFunction

Function Do_Taxes(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Int own = CityOfSpeaker(akActor)
	Int t = ParseTown(Param(paramsJson, "town"))
	If t < 0
		t = own
	EndIf
	; town stewards and jarls only set their own town's taxes
	If !ActsAsSteward(akActor) && t != own
		t = own
	EndIf
	If t < 0 || !CSN_World.PlayerRules(t)
		CSN_Gov.Fail("Which town's taxes? Name one your faction rules.")
		Return
	EndIf
	Int now = CSN_Gov.TaxLevel(t)
	String pc = Param(paramsJson, "percent")
	Int level = now
	If pc != ""
		Int n = ParseNumber(pc)
		If n % 10 != 0 || n > 50
			CSN_Gov.Fail("Taxes can only be 0%, 10%, 20%, 30%, 40% or 50% (they are " + CSN_Gov.TaxText(now) + " in " + CSN_World.TownName(t) + ").")
			Return
		EndIf
		level = n / 10
	ElseIf Matches(Param(paramsJson, "direction"), "lower") || Matches(Param(paramsJson, "direction"), "cut")
		level = now - 1
	Else
		level = now + 1
	EndIf
	If level < 0
		CSN_Gov.Fail("Taxes in " + CSN_World.TownName(t) + " are already at the lowest rate, 0%.")
		Return
	ElseIf level > 5
		CSN_Gov.Fail("Taxes in " + CSN_World.TownName(t) + " are already at the highest rate, 50%.")
		Return
	ElseIf level == now
		CSN_Gov.Fail("Taxes in " + CSN_World.TownName(t) + " are already " + CSN_Gov.TaxText(now) + ".")
		Return
	EndIf
	CSN_Gov.SetTaxLevel(t, level, akActor)
EndFunction

Bool Function Elig_LeaderFort(Actor akActor, String contextJson, String paramsJson) Global
	Return CSN_Gov.LeaderSide(akActor) > 0 && CSN_Gov.LeaderFortsText(akActor) != ""
EndFunction

Bool Function Elig_CedeFort(Actor akActor, String contextJson, String paramsJson) Global
	Return CSN_Gov.CedableFort(akActor) >= 0
EndFunction

Bool Function Elig_CedeCity(Actor akActor, String contextJson, String paramsJson) Global
	Return CSN_Gov.CedableCity(akActor) >= 0
EndFunction

Bool Function Elig_CommanderFort(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	If m.GetArmy(akActor) < 0
		Return False
	EndIf
	Int i = 0
	While i < m.FortCount()
		If m.OwnsFort(i)
			Return True
		EndIf
		i += 1
	EndWhile
	Return False
EndFunction

Bool Function Elig_Blacksmith_Is(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Return m.GetRole(akActor) == m.ROLE_BLACKSMITH
EndFunction

Bool Function Elig_Seller(Actor akActor, String contextJson, String paramsJson) Global
	Return CSN_Gov.CanSellTo(akActor)
EndFunction

Bool Function Elig_GeneralOrSmith(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Int r = m.GetRole(akActor)
	Return r == m.ROLE_GENERAL || r == m.ROLE_BLACKSMITH
EndFunction

Bool Function Elig_Buyer(Actor akActor, String contextJson, String paramsJson) Global
	Return CSN_Gov.CanBuyFrom(akActor)
EndFunction

Bool Function Elig_General_Is(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Return m.GetRole(akActor) == m.ROLE_GENERAL
EndFunction

Bool Function Elig_Steward_Is(Actor akActor, String contextJson, String paramsJson) Global
	Return ActsAsSteward(akActor)
EndFunction

; =============================================================================
; EXECUTION
; =============================================================================
; Appointments made in conversation ask first (MCM: Confirmations > Appointments in conversation).
Bool Function ConfirmAppointment(Actor akActor, String asOffice) Global
	If !CSN_Config.ConfirmAppoint()
		Return True
	EndIf
	CSN_Core m = Main()
	String now = CSN_Gov.OfficeOf(akActor)
	String extra = ""
	If now != ""
		extra = "\n\nThey are " + now + " now and would give that up."
	EndIf
	Return CSNP.Confirm("Appointment", "Make " + m.PlainName(akActor) + " " + asOffice + " of the " + m.FactionName() + "?" + extra, "Appoint", "Not now")
EndFunction

Function AppointIn(Actor akActor, Int aiRole) Global
	CSN_Core m = Main()
	If ConfirmAppointment(akActor, m.RoleTitle(aiRole))
		m.Appoint(akActor, aiRole)
	EndIf
EndFunction

Function Do_General(Actor akActor, String contextJson, String paramsJson) Global
	AppointIn(akActor, 0)
EndFunction
Function Do_Steward(Actor akActor, String contextJson, String paramsJson) Global
	AppointIn(akActor, 1)
EndFunction
Function Do_Blacksmith(Actor akActor, String contextJson, String paramsJson) Global
	AppointIn(akActor, 2)
EndFunction
Function Do_Wizard(Actor akActor, String contextJson, String paramsJson) Global
	AppointIn(akActor, 3)
EndFunction

Function Do_JoinCommander(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	If ConfirmAppointment(akActor, "a Captain (leading " + CSN_Gov.ArmyLabel(m.FreeArmySlot()) + ")")
		m.HireCommander(akActor)
	EndIf
EndFunction

Function Do_Dismissed(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Gov.RemoveFromOffice(akActor, False, akActor)
EndFunction

Function Do_Resign(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Gov.RemoveFromOffice(akActor, True, akActor)
EndFunction

; =============================================================================
; PICKERS: when an action is missing a detail, a small PrismaUI list asks for it (never the faction screen)
; =============================================================================
Actor Function PickCommander(String asTitle, String asText) Global
	CSN_Core m = Main()
	CS_PatrolHoldScript a = m.Armies()
	Actor[] who = PapyrusUtil.ActorArray(0)
	String[] opts = Utility.CreateStringArray(0)
	Int i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c && !c.IsDead()
			who = PapyrusUtil.PushActor(who, c)
			opts = PapyrusUtil.PushString(opts, CSN_Gov.ArmyLabel(i) + ": " + CSN_Gov.RankText(c) + " " + m.PlainName(c))
		EndIf
		i += 1
	EndWhile
	If who.Length == 0
		CSN_Gov.Fail("The faction has no captains or commanders yet.")
		Return None
	EndIf
	opts = PapyrusUtil.PushString(opts, "Cancel")
	Int r = CSNP.Choose(asTitle, asText, opts)
	If r < 0 || r >= who.Length
		EndAction()
		Return None
	EndIf
	Return who[r]
EndFunction

; aiWhat: 0 holds an army can camp in, 1 cities the faction rules, 2 forts it holds
Int Function PickPlace(Int aiWhat, String asTitle, String asText) Global
	CSN_Core m = Main()
	Int[] ids = Utility.CreateIntArray(0)
	String[] opts = Utility.CreateStringArray(0)
	Int i = 0
	While i < 9
		Bool ok = False
		String name = ""
		If aiWhat == 0
			ok = CSN_Gov.CanCamp(i)
			name = m.HoldName(i)
			If ok && CSN_War.HasCamp(i)
				name += " (join the camp there)"
			ElseIf ok && CSN_Gov.IsAttackCamp(i)
				name += " (attack camp)"
			EndIf
		ElseIf aiWhat == 1
			ok = CSN_World.PlayerRules(i)
			name = CSN_World.TownName(i)
		Else
			ok = m.OwnsFort(i)
			name = m.FortName(i)
		EndIf
		If ok
			ids = PapyrusUtil.PushInt(ids, i)
			opts = PapyrusUtil.PushString(opts, name)
		EndIf
		i += 1
	EndWhile
	If ids.Length == 0
		If aiWhat == 1
			CSN_Gov.Fail("Your faction rules no city yet.")
		ElseIf aiWhat == 2
			CSN_Gov.Fail("Your faction holds no fort yet.")
		Else
			CSN_Gov.Fail("Your armies can't reach any hold yet.")
		EndIf
		Return -1
	EndIf
	opts = PapyrusUtil.PushString(opts, "Cancel")
	Int r = CSNP.Choose(asTitle, asText, opts)
	If r < 0 || r >= ids.Length
		EndAction()
		Return -1
	EndIf
	Return ids[r]
EndFunction

; 1 Imperial Legion, 2 Stormcloaks, -1 cancelled
Int Function PickSide(String asTitle, String asText) Global
	String[] opts = new String[3]
	opts[0] = "The Imperial Legion"
	opts[1] = "The Stormcloaks"
	opts[2] = "Cancel"
	Int r = CSNP.Choose(asTitle, asText, opts)
	If r == 0 || r == 1
		Return r + 1
	EndIf
	EndAction()
	Return -1
EndFunction

Function Do_GeneralDismiss(Actor akActor, String contextJson, String paramsJson) Global
	Actor c = ParseCommander(Param(paramsJson, "commander"))
	If !c
		c = PickCommander("Remove from command", "Which Captain or Commander should leave their army?")
	EndIf
	If !c
		Return
	EndIf
	CSN_Gov.RemoveFromOffice(c, False, akActor)
EndFunction

Function Do_TroopEquipment(Actor akActor, String contextJson, String paramsJson) Global
	String t = Param(paramsJson, "troop")
	Int k = -1
	If Matches(t, "soldier")
		k = 0
	ElseIf Matches(t, "warrior")
		k = 1
	ElseIf Matches(t, "crossbow")
		k = 3
	ElseIf Matches(t, "archer") || Matches(t, "bow")
		k = 2
	ElseIf Matches(t, "guard")
		k = 4
	EndIf
	If k >= 0
		CSN_Gov.TroopOutfit(k)
	Else
		CSN_Gov.TroopOutfitMenu()
	EndIf
EndFunction

Function Do_UpgradeArmour(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Gov.TroopUpgradeMenu()
EndFunction

Function Do_TroopRaces(Actor akActor, String contextJson, String paramsJson) Global
	; CoS's own races and genders menu (shown in PrismaUI), not the faction screen
	CS_ChooseTroopRacesScript r = CSN_Gov.Races()
	If !r
		CSN_Gov.Fail("The troop races menu isn't available.")
		Return
	EndIf
	r.StartMenu()
EndFunction

Function Do_BuySupplies(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Gov.SellSupplies(akActor, ParseMaterial(Param(paramsJson, "material")), ParseNumber(Param(paramsJson, "amount")))
EndFunction

Function Do_ArmyFollow(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	m.IssueOrder(akActor, m.ORDER_FOLLOW)
EndFunction

Function Do_ArmyHunt(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	m.IssueOrder(akActor, m.ORDER_HUNT)
EndFunction

Function Do_ArmyPatrolClaim(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	m.IssueOrder(akActor, m.ORDER_HOME)
EndFunction

Function Do_ArmyGarrisonCity(Actor akActor, String contextJson, String paramsJson) Global
	Int c = ParseCity(Param(paramsJson, "city"))
	If c < 0
		CSN_Gov.Fail("Which city? Name one your faction rules.")
		Return
	EndIf
	CSN_Gov.GarrisonCity(akActor, c, akActor)
EndFunction

Function Do_ArmyGarrison(Actor akActor, String contextJson, String paramsJson) Global
	Int f = ParseFort(Param(paramsJson, "fort"))
	If f < 0
		CSN_Gov.Fail("Which fort? Name one your faction holds.")
		Return
	EndIf
	CSN_Gov.GarrisonFort(akActor, f, akActor)
EndFunction

Function Do_ArmyCamp(Actor akActor, String contextJson, String paramsJson) Global
	Int h = ParseHoldOrCity(Param(paramsJson, "hold"))
	If h < 0
		CSN_Gov.Fail("Which hold should the army camp in?")
		Return
	EndIf
	CSN_Gov.MakeCamp(akActor, h, akActor)
EndFunction

Function Do_NameArmy(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Int army = CSN_War.ParseArmy(Param(paramsJson, "army"))
	If army < 0
		army = m.GetArmy(akActor)
	EndIf
	If army < 0
		CSN_Gov.Fail("Which army should get the name?")
		Return
	EndIf
	If m.GetRole(akActor) != m.ROLE_GENERAL && army != m.GetArmy(akActor)
		CSN_Gov.Fail("Only the General or the army's own leader can name " + CSN_Gov.ArmyLabel(army) + ".")
		Return
	EndIf
	String purpose = Param(paramsJson, "purpose")
	If purpose == ""
		purpose = CSN_War.Purpose(army)
	EndIf
	CSN_War.SetName(army, Param(paramsJson, "name"), purpose, akActor)
EndFunction

Function Do_WarCampPlans(Actor akActor, String contextJson, String paramsJson) Global
	CSN_War.WarCampPlans(akActor, CSN_War.PlanHoldFor(akActor, Param(paramsJson, "hold")))
EndFunction

Function Do_OrderAttack(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	String armies = Param(paramsJson, "armies")
	; a commander proposes it for the armies at their own camp
	If m.GetRole(akActor) != m.ROLE_GENERAL && armies == ""
		armies = "Army " + (m.GetArmy(akActor) + 1)
	EndIf
	CSN_War.OrderAttack(akActor, armies, Param(paramsJson, "target"))
EndFunction

Function Do_GeneralCamp(Actor akActor, String contextJson, String paramsJson) Global
	Actor c = ParseCommander(Param(paramsJson, "commander"))
	Int h = ParseHoldOrCity(Param(paramsJson, "hold"))
	If !c
		c = PickCommander("Make camp", "Which army should march and make camp?")
		If !c
			Return
		EndIf
	EndIf
	If h < 0
		h = PickPlace(0, "Make camp", "Where should " + Main().PlainName(c) + " make camp?")
		If h < 0
			Return
		EndIf
	EndIf
	CSN_Gov.MakeCamp(c, h, akActor)
EndFunction

Function Do_AwardStar(Actor akActor, String contextJson, String paramsJson) Global
	Actor c = ParseCommander(Param(paramsJson, "commander"))
	If !c
		c = PickCommander("Award a star", "Which Captain or Commander should be honoured?")
	EndIf
	If !c
		Return
	EndIf
	CSN_Gov.AwardStar(c, akActor)
EndFunction

Function Do_Outfit(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	; the General, Steward, Blacksmith, Court Wizard, jarls and court: their position's outfit, as in dialogue
	If CSN_Gov.GovOutfitKind(akActor) > 0
		String c = Param(paramsJson, "choice")
		Int choice = 0
		If Matches(c, "position") || Matches(c, "office") || Matches(c, "uniform") || Matches(c, "reflect") || Matches(c, "default")
			choice = 1
		ElseIf Matches(c, "whatever") || Matches(c, "own") || Matches(c, "free") || Matches(c, "anything")
			choice = 2
		EndIf
		String what = "Edit what " + m.PlainName(akActor) + " wears for their position?"
		String yes = "Open the outfit"
		If choice == 1
			what = "Have " + m.PlainName(akActor) + " wear the outfit that reflects their position?"
			yes = "Agree"
		ElseIf choice == 2
			what = "Let " + m.PlainName(akActor) + " wear whatever they wish?"
			yes = "Agree"
		EndIf
		If CSN_Config.ConfirmOutfit() && !CSNP.Confirm("Outfit", what, yes, "No")
			Return
		EndIf
		CSN_Gov.GovOutfit(akActor, choice)
		Return
	EndIf
	If CSN_Config.ConfirmOutfit() && !CSNP.Confirm("Outfit", "Choose what " + m.PlainName(akActor) + " wears?", "Open the outfit menu", "No")
		Return
	EndIf
	CSN_Gov.EditOutfit(akActor)
EndFunction

Function Do_Deposit(Actor akActor, String contextJson, String paramsJson) Global
	Int amount = ParseNumber(Param(paramsJson, "amount"))
	If amount <= 0
		Int purse = Game.GetPlayer().GetGoldAmount()
		If purse <= 0
			CSN_Gov.Fail("You carry no gold.")
			Return
		EndIf
		amount = CSNP.AskAmount("Deposit gold", "How much gold do you hand to the treasury? You carry " + purse + ".", 100, 1, purse)
		If amount <= 0
			Return
		EndIf
	EndIf
	CSN_Gov.Deposit(amount, akActor)
EndFunction

Function Do_Withdraw(Actor akActor, String contextJson, String paramsJson) Global
	Int amount = ParseNumber(Param(paramsJson, "amount"))
	If amount <= 0
		Int t = CSN_Gov.Treasury()
		If t <= 0
			CSN_Gov.Fail("The treasury is empty.")
			Return
		EndIf
		amount = CSNP.AskAmount("Withdraw gold", "How much gold do you take from the treasury? It holds " + t + ".", 100, 1, t)
		If amount <= 0
			Return
		EndIf
	EndIf
	CSN_Gov.Withdraw(amount, akActor)
EndFunction

Function Do_CityTrade(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Int c = StewardTown(akActor, Param(paramsJson, "town"))
	If c < 0
		If Param(paramsJson, "town") != ""
			CSN_Gov.Fail("Your faction doesn't rule " + Param(paramsJson, "town") + ".")
		Else
			CSN_Gov.Fail("Which city or village? Name a town your faction rules.")
		EndIf
		Return
	EndIf
	Int mat = ParseMaterial(Param(paramsJson, "material"))
	If mat < 0
		CSN_Gov.Fail("Which supplies: food, metal or wood?")
		Return
	EndIf
	Int amount = ParseNumber(Param(paramsJson, "amount"))
	String f = Param(paramsJson, "flow")
	If f == ""
		f = Param(paramsJson, "direction")
	EndIf
	; +: the faction sends to the town (CoS "import" for the town), -: the town sends to the faction
	Int sign = 0
	If Matches(f, "stop") || Matches(f, "end") || Matches(f, "none") || Matches(f, "halt") || Matches(f, "cancel")
		sign = 0
	ElseIf Matches(f, "to_town") || Matches(f, "to town") || Matches(f, "to the town")
		sign = 1
	ElseIf Matches(f, "from_town") || Matches(f, "from town") || Matches(f, "from the town")
		sign = -1
	ElseIf ActsAsSteward(akActor)
		; the faction's point of view: export to the town, import from it
		If Matches(f, "export") || Matches(f, "send")
			sign = 1
		ElseIf Matches(f, "import") || Matches(f, "take") || Matches(f, "receive")
			sign = -1
		EndIf
	Else
		; the town's point of view: we import from the faction, we export to it
		If Matches(f, "import") || Matches(f, "receive")
			sign = 1
		ElseIf Matches(f, "export") || Matches(f, "send")
			sign = -1
		EndIf
	EndIf
	If sign != 0 && amount <= 0
		CSN_Gov.Fail("How much " + m.MaterialName(mat) + " a day?")
		Return
	EndIf
	If sign == 0 && !(Matches(f, "stop") || Matches(f, "end") || Matches(f, "none") || Matches(f, "halt") || Matches(f, "cancel"))
		CSN_Gov.Fail("Export to " + CSN_World.TownName(c) + ", import from it, or stop?")
		Return
	EndIf
	CSN_Gov.SetCityTrade(c, mat, sign * amount, akActor)
EndFunction

Function Do_CedeCity(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Gov.CedeCity(akActor, ParseNumber(Param(paramsJson, "price")), ParseNumber(Param(paramsJson, "food")), ParseNumber(Param(paramsJson, "metal")), ParseNumber(Param(paramsJson, "wood")), IsYes(Param(paramsJson, "free")))
EndFunction

; ---- asking prices for cities and forts (remembered by whoever named them) ----
Bool Function Elig_SetAsk(Actor akActor, String contextJson, String paramsJson) Global
	Return CSN_Gov.CedableCity(akActor) >= 0 || CSN_Gov.CedableFort(akActor) >= 0 || (CSN_Gov.LeaderSide(akActor) > 0 && CSN_Gov.LeaderFortsText(akActor) != "")
EndFunction

Function Exec_SetAsk(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	String place = Param(paramsJson, "place")
	Int kind = -1
	Int idx = -1
	Int f = ParseFort(place)
	Int side = CSN_Gov.LeaderSide(akActor)
	If f >= 0 && (CSN_Gov.CedableFort(akActor) == f || (side > 0 && CSN_Gov.FortOwner(f) == side))
		kind = 1
		idx = f
	ElseIf CSN_Gov.CedableCity(akActor) >= 0 && (place == "" || f < 0)
		kind = 0
		idx = CSN_Gov.CedableCity(akActor)
	ElseIf CSN_Gov.CedableFort(akActor) >= 0
		kind = 1
		idx = CSN_Gov.CedableFort(akActor)
	EndIf
	If idx < 0
		CSN_Gov.Fail("Which fort? Name one " + CSN_Gov.NameOf(akActor) + "'s side holds.")
	Else
		CSN_Gov.SetAsk(akActor, kind, idx, ParseNumber(Param(paramsJson, "gold")), ParseNumber(Param(paramsJson, "food")), ParseNumber(Param(paramsJson, "metal")), ParseNumber(Param(paramsJson, "wood")))
	EndIf
	EndAction()
EndFunction

Function Do_OpenWarTable(Actor akActor, String contextJson, String paramsJson) Global
	Main().OpenDashboard("general")
EndFunction

Function Do_RelayOrder(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Actor c = ParseCommander(Param(paramsJson, "commander"))
	String o = Param(paramsJson, "order")
	String t = Param(paramsJson, "target")
	If !c
		c = PickCommander("Pass on an order", "Which Captain or Commander is the order for?")
		If !c
			Return
		EndIf
	EndIf
	If o == ""
		String[] orders = new String[7]
		orders[0] = "Follow me"
		orders[1] = "Hunt for food"
		orders[2] = "Return home"
		orders[3] = "Garrison a city"
		orders[4] = "Garrison a fort"
		orders[5] = "Make camp in a hold"
		orders[6] = "Cancel"
		Int pick = CSNP.Choose("Order for " + m.PlainName(c), "What should " + m.PlainName(c) + " do?", orders)
		If pick < 0 || pick > 5
			EndAction()
			Return
		EndIf
		String[] words = new String[6]
		words[0] = "follow"
		words[1] = "hunt"
		words[2] = "home"
		words[3] = "garrison city"
		words[4] = "fort"
		words[5] = "camp"
		o = words[pick]
	EndIf
	m.SetOrderVia(akActor)
	RelayOrderTo(m, c, o, t, akActor)
	m.SetOrderVia(None)
EndFunction

Function RelayOrderTo(CSN_Core m, Actor c, String o, String t, Actor akActor) Global
	If Matches(o, "follow")
		m.IssueOrder(c, m.ORDER_FOLLOW)
	ElseIf Matches(o, "hunt")
		m.IssueOrder(c, m.ORDER_HUNT)
	ElseIf Matches(o, "fort")
		Int f = ParseFort(t)
		If f < 0
			f = PickPlace(2, "Garrison a fort", "Which fort should " + m.PlainName(c) + " hold?")
		EndIf
		If f >= 0
			CSN_Gov.GarrisonFort(c, f, akActor)
		EndIf
	ElseIf Matches(o, "camp") || Matches(o, "march") || Matches(o, "attack")
		Int h = ParseHoldOrCity(t)
		If h < 0
			h = PickPlace(0, "Make camp", "Where should " + m.PlainName(c) + " make camp?")
		EndIf
		If h >= 0
			CSN_Gov.MakeCamp(c, h, akActor)
		EndIf
	ElseIf Matches(o, "garrison") || Matches(o, "city") || Matches(o, "defend")
		Int cc = ParseCity(t)
		Int ff = ParseFort(t)
		If ff >= 0 && cc < 0
			CSN_Gov.GarrisonFort(c, ff, akActor)
		Else
			If cc < 0
				cc = PickPlace(1, "Garrison a city", "Which city should " + m.PlainName(c) + " garrison?")
			EndIf
			If cc >= 0
				CSN_Gov.GarrisonCity(c, cc, akActor)
			EndIf
		EndIf
	Else
		m.IssueOrder(c, m.ORDER_HOME)
	EndIf
EndFunction

; War is never declared straight from conversation: the player signs it in PrismaUI.
Function Do_DeclareWar(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Int side = ParseSide(Param(paramsJson, "side"))
	If side < 0
		side = PickSide("Declaration of war", "On whom should war be declared?")
		If side < 0
			Return
		EndIf
	EndIf
	m.AskWar(side)
EndFunction

; Trades go straight to the amount dialog, filled in, for the player to seal.
Function Do_ProposeTrade(Actor akActor, String contextJson, String paramsJson) Global
	Int side = ParseSide(Param(paramsJson, "side"))
	Int mat = ParseMaterial(Param(paramsJson, "material"))
	String d = Param(paramsJson, "direction")
	Int dir = 1
	If Matches(d, "export") || Matches(d, "sell")
		dir = -1
	EndIf
	Int amount = ParseNumber(Param(paramsJson, "amount"))
	If amount <= 0
		amount = 1
	EndIf
	If side < 0
		side = 1
	EndIf
	If mat < 0
		mat = 0
	EndIf
	CSN_Config.Log("trade proposed by " + akActor.GetDisplayName() + ": side " + side + " mat " + mat + " dir " + dir + " amount " + amount)
	Main().AskTrade(side, mat, dir, amount, akActor)
EndFunction

; First whole number in a string ("3", "3 units", "about 10") - the model writes numbers in many ways.
Bool Function IsYes(String s) Global
	; Papyrus compares strings without regard to case
	Return s == "yes" || s == "true" || s == "1" || s == "free" || s == "gift" || s == "yes, free"
EndFunction

Int Function ParseNumber(String s) Global
	Int n = StringUtil.GetLength(s)
	Int i = 0
	String digits = ""
	While i < n
		String ch = StringUtil.GetNthChar(s, i)
		If StringUtil.IsDigit(ch)
			digits += ch
		ElseIf digits != "" && (ch == "," || ch == "_" || ch == "'") && i + 1 < n && StringUtil.IsDigit(StringUtil.GetNthChar(s, i + 1))
			; a thousands separator: 500,000
		ElseIf digits != ""
			Return Scaled(digits as Int, s, i)
		EndIf
		i += 1
	EndWhile
	If digits != ""
		Return digits as Int
	EndIf
	Return 0
EndFunction

; "80k", "1.5 million"-style words right after a number
Int Function Scaled(Int aiN, String s, Int aiAt) Global
	String rest = StringUtil.Substring(s, aiAt, 12)
	If StringUtil.Find(rest, "k") == 0 || StringUtil.Find(rest, " thousand") == 0 || StringUtil.Find(rest, "thousand") == 0
		Return aiN * 1000
	ElseIf StringUtil.Find(rest, " million") == 0 || StringUtil.Find(rest, "m ") == 0 || rest == "m"
		Return aiN * 1000000
	EndIf
	Return aiN
EndFunction

Function Do_OpenLedger(Actor akActor, String contextJson, String paramsJson) Global
	Main().OpenStewardFor(akActor)
EndFunction

Function Do_OpenEconomy(Actor akActor, String contextJson, String paramsJson) Global
	Main().Econ().StartMenu()
EndFunction

; =============================================================================
; ACTION WRAPPERS: every action runs inside Begin/EndAction, so a failure (CSN_Gov.Fail) or a "No" in a
; confirmation tells the NPC that it did not happen.
; =============================================================================
Function BeginAction(Actor akActor) Global
	StorageUtil.SetFormValue(None, "csn_act", akActor)
	StorageUtil.SetFloatValue(None, "csn_act_t", Utility.GetCurrentRealTime())
EndFunction

Function EndAction() Global
	StorageUtil.UnsetFormValue(None, "csn_act")
EndFunction

Actor Function ActingNPC() Global
	Float t = StorageUtil.GetFloatValue(None, "csn_act_t", 0.0)
	Float now = Utility.GetCurrentRealTime()
	If now < t || now - t > 180.0
		Return None
	EndIf
	Return StorageUtil.GetFormValue(None, "csn_act") as Actor
EndFunction

Function ActionFailed(String asReason) Global
	Actor a = ActingNPC()
	If a && Installed()
		EndAction()
		SkyrimNetApi.DirectNarration("It did not happen: " + asReason + " " + a.GetDisplayName() + " realises it and says so plainly to " + Game.GetPlayer().GetDisplayName() + ", without pretending it was done.", a, Game.GetPlayer())
	EndIf
EndFunction

Function ActionDeclined() Global
	Actor a = ActingNPC()
	If a && Installed()
		EndAction()
		SkyrimNetApi.DirectNarration(Game.GetPlayer().GetDisplayName() + " has called that off for now, so it was not done. " + a.GetDisplayName() + " simply acknowledges it in a word or two and moves on, without questioning the decision or asking why.", a, Game.GetPlayer())
	EndIf
EndFunction

Function Exec_Taxes(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_Taxes(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_General(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_General(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_Steward(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_Steward(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_Blacksmith(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_Blacksmith(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_Wizard(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_Wizard(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_JoinCommander(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_JoinCommander(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_Dismissed(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_Dismissed(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_Resign(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_Resign(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_GeneralDismiss(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_GeneralDismiss(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_TroopEquipment(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_TroopEquipment(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_UpgradeArmour(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_UpgradeArmour(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_TroopRaces(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_TroopRaces(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_BuySupplies(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_BuySupplies(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_ArmyFollow(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_ArmyFollow(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_ArmyHunt(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_ArmyHunt(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_ArmyPatrolClaim(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_ArmyPatrolClaim(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_ArmyGarrisonCity(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_ArmyGarrisonCity(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_ArmyGarrison(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_ArmyGarrison(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_ArmyCamp(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_ArmyCamp(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_NameArmy(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_NameArmy(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_WarCampPlans(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_WarCampPlans(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_OrderAttack(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_OrderAttack(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_BeginAttack(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_War.StartAttack(akActor)
	EndAction()
EndFunction

Function Exec_CallOffAttack(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_War.CancelAttack(akActor)
	EndAction()
EndFunction

Function Exec_GeneralCamp(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_GeneralCamp(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_AwardStar(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_AwardStar(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_Outfit(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_Outfit(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_Deposit(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_Deposit(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_Withdraw(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_Withdraw(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_CityTrade(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_CityTrade(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_CedeCity(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_CedeCity(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_OpenWarTable(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_OpenWarTable(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_RelayOrder(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_RelayOrder(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_DeclareWar(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_DeclareWar(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_ProposeTrade(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_ProposeTrade(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_OpenLedger(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_OpenLedger(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

Function Exec_OpenEconomy(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Do_OpenEconomy(akActor, contextJson, paramsJson)
	EndAction()
EndFunction

; ---- recruiting and templates (CSN_Troops) ----------------------------------------
Function Exec_Recruit(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int army = CSN_Troops.ParseArmy(Param(paramsJson, "army"))
	If army < 0
		CSN_Gov.Fail("Which army should the recruits join? Name it by number or by its Captain or Commander.")
	Else
		CSN_Troops.Recruit(army, Param(paramsJson, "troops"), akActor)
	EndIf
	EndAction()
EndFunction

Function Exec_SetTemplate(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Troops.SetTemplate(ParseNumber(Param(paramsJson, "template")), Param(paramsJson, "troops"), akActor)
	EndAction()
EndFunction

Function Exec_ApplyTemplate(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Troops.ApplyTemplate(ParseNumber(Param(paramsJson, "template")), CSN_Troops.ParseArmy(Param(paramsJson, "army")), akActor)
	EndAction()
EndFunction

Function Exec_SellToFaction(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int mat = ParseMaterial(Param(paramsJson, "material"))
	If mat < 0
		; a farmer sells food, a miner metal, a lumberjack wood
		mat = CSN_Gov.ProducerOf(akActor)
	EndIf
	CSN_Gov.BuySupplies(akActor, mat, ParseNumber(Param(paramsJson, "amount")))
	EndAction()
EndFunction

Function Exec_WearTemplate(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Gov.WearOutfitTemplate(akActor, ParseNumber(Param(paramsJson, "template")))
	EndAction()
EndFunction

Function Exec_CedeFort(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Gov.CedeFort(akActor, ParseNumber(Param(paramsJson, "gold")), ParseNumber(Param(paramsJson, "food")), ParseNumber(Param(paramsJson, "metal")), ParseNumber(Param(paramsJson, "wood")), IsYes(Param(paramsJson, "free")))
	EndAction()
EndFunction

; Town for a steward action: their own town, or any the faction rules for the faction's Steward.
Int Function StewardTown(Actor akActor, String asTown) Global
	CSN_Core m = Main()
	Int own = CityOfSpeaker(akActor)
	Int t = ParseTown(asTown)
	If t < 0
		t = own
	EndIf
	If !ActsAsSteward(akActor) && t != own
		t = own
	EndIf
	If t < 0 || !CSN_World.PlayerRules(t)
		Return -1
	EndIf
	Return t
EndFunction

Function Exec_Upgrade(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int t = StewardTown(akActor, Param(paramsJson, "town"))
	String b = Param(paramsJson, "building")
	Int k = -1
	If Matches(b, "barrack")
		k = 0
	ElseIf Matches(b, "farm")
		k = 1
	ElseIf Matches(b, "lumber") || Matches(b, "mill") || Matches(b, "wood")
		k = 2
	ElseIf Matches(b, "mine")
		k = 3
	EndIf
	If t < 0
		CSN_Gov.Fail("Which town? Name one your faction rules.")
	ElseIf k < 0
		CSN_Gov.Fail("Which building: barracks, farms, lumber mills or mines?")
	Else
		CSN_Gov.UpgradeBuilding(t, k, akActor)
	EndIf
	EndAction()
EndFunction

Function Exec_HireGuards(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int t = StewardTown(akActor, Param(paramsJson, "town"))
	If t < 0
		CSN_Gov.Fail("Which town? Name one your faction rules.")
	Else
		CSN_Gov.HireGuards(t, ParseNumber(Param(paramsJson, "amount")), akActor)
	EndIf
	EndAction()
EndFunction

Function Exec_MoveTownGold(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int t = StewardTown(akActor, Param(paramsJson, "town"))
	String amt = Param(paramsJson, "amount")
	String dir = Param(paramsJson, "direction")
	Bool toTown = Matches(dir, "to_town") || Matches(dir, "to town") || Matches(dir, "send") || Matches(dir, "export")
	If t < 0
		CSN_Gov.Fail("Which town? Name one your faction rules.")
	ElseIf !toTown && (Matches(amt, "all") || Matches(amt, "every") || Matches(amt, "everything"))
		CSN_Gov.MoveTownGold(t, 0, akActor, True, True)
	Else
		Int n = ParseNumber(amt)
		If toTown
			n = -n
		EndIf
		CSN_Gov.MoveTownGold(t, n, akActor)
	EndIf
	EndAction()
EndFunction

Function Exec_LeaderFort(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Gov.LeaderSellFort(akActor, ParseFort(Param(paramsJson, "fort")), ParseNumber(Param(paramsJson, "gold")), ParseNumber(Param(paramsJson, "food")), ParseNumber(Param(paramsJson, "metal")), ParseNumber(Param(paramsJson, "wood")))
	EndAction()
EndFunction

; =============================================================================
; UNREST, DESERTERS, PLOTS AND SETTLEMENTS (1.9.0)
; =============================================================================
; the town in unrest this person can speak for: the rebels' leader, or the town's jarl / steward / leader
Int Function UnrestTownOf(Actor akActor) Global
	Int i = 0
	While i < 15
		If CSN_Rebellion.Stage(i) > 0
			If StorageUtil.GetFormValue(None, "csn_reb_" + i + "_leader") == akActor
				Return i
			EndIf
			If CSN_World.TownJarl(i) == akActor || CSN_Gov.CityStewardOf(akActor) == i
				Return i
			EndIf
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

Bool Function Elig_RebelTerms(Actor akActor, String contextJson, String paramsJson) Global
	Return UnrestTownOf(akActor) >= 0 || (IsCouncil(akActor) && CSN_Rebellion.TroubledTown("") >= 0)
EndFunction

Function Exec_RebelTerms(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int t = -1
	String named = Param(paramsJson, "town")
	If named != ""
		t = CSN_Rebellion.TroubledTown(named)
	EndIf
	If t < 0
		t = UnrestTownOf(akActor)
	EndIf
	If t < 0
		t = CSN_Rebellion.TroubledTown("")
	EndIf
	If t < 0
		CSN_Gov.Fail("Which town? None of your towns is in unrest.")
	Else
		CSN_Rebellion.Appease(t, akActor)
	EndIf
	EndAction()
EndFunction

; The General, the faction's Steward, and the jarls and stewards of the faction's towns: the faction's council.
Bool Function IsCouncil(Actor a) Global
	CSN_Core m = Main()
	If !a || m.FactionStarted.GetValue() < 1
		Return False
	EndIf
	Return m.GetRole(a) == m.ROLE_GENERAL || CSN_Gov.IsAnySteward(a)
EndFunction

Bool Function Elig_Council(Actor akActor, String contextJson, String paramsJson) Global
	Return IsCouncil(akActor)
EndFunction

Bool Function Elig_FreeCompany(Actor akActor, String contextJson, String paramsJson) Global
	Int w = CSN_Rebellion.BandOf(akActor)
	Return w >= 0 && !CSN_Rebellion.Recognised(w)
EndFunction

Function Exec_FreeCompany(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int w = CSN_Rebellion.BandOf(akActor)
	String t = Param(paramsJson, "terms")
	If Matches(t, "peace") || Matches(t, "recogn") || Matches(t, "independ")
		CSN_Rebellion.Recognise(w)
	Else
		CSN_Rebellion.PayArrears(w)
	EndIf
	EndAction()
EndFunction

Bool Function Elig_SendAgainstRebels(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	If CSN_Rebellion.RisenTown("") < 0
		Return False
	EndIf
	Return IsCouncil(akActor) || m.GetArmy(akActor) >= 0
EndFunction

Function Exec_SendAgainstRebels(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Core m = Main()
	Int a = m.GetArmy(akActor)
	String armyArg = Param(paramsJson, "army")
	If armyArg != ""
		Int parsed = CSN_War.ParseArmy(armyArg)
		If parsed >= 0
			a = parsed
		EndIf
	EndIf
	If a < 0
		Actor c = PickCommander("Send which army?", "Choose the army to put down the uprising.")
		a = m.GetArmy(c)
	EndIf
	Int t = CSN_Rebellion.RisenTown(Param(paramsJson, "town"))
	If a < 0
		CSN_Gov.Fail("Which army?")
	ElseIf t < 0
		CSN_Gov.Fail("Which town? None of your towns has risen up there.")
	Else
		CSN_Rebellion.QuellUprising(t, a, akActor)
	EndIf
	EndAction()
EndFunction

Bool Function Elig_SendAgainstDeserters(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	If CSN_Rebellion.BandCount() <= 0
		Return False
	EndIf
	Return IsCouncil(akActor) || m.GetArmy(akActor) >= 0
EndFunction

Function Exec_SendAgainstDeserters(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Core m = Main()
	Int a = m.GetArmy(akActor)
	String armyArg = Param(paramsJson, "army")
	If armyArg != ""
		Int parsed = CSN_War.ParseArmy(armyArg)
		If parsed >= 0
			a = parsed
		EndIf
	EndIf
	If a < 0
		Actor c = PickCommander("Send which army?", "Choose the army to send against the deserters.")
		a = m.GetArmy(c)
	EndIf
	Int w = -1
	String cs = Param(paramsJson, "company")
	Int k = 0
	While k < 10 && w < 0
		If CSN_Rebellion.BandAlive(k) && !CSN_Rebellion.Recognised(k)
			If cs == "" || Matches(cs, CSN_Rebellion.BandName(k)) || Matches(cs, m.PlainName(CSN_Rebellion.BandLeader(k)))
				w = k
			EndIf
		EndIf
		k += 1
	EndWhile
	If a < 0
		CSN_Gov.Fail("Which army?")
	ElseIf w < 0
		CSN_Gov.Fail("Which company of deserters?")
	Else
		CSN_Rebellion.SendArmy(w, a, akActor)
	EndIf
	EndAction()
EndFunction

Bool Function Elig_TakeBribe(Actor akActor, String contextJson, String paramsJson) Global
	Return CSN_Intrigue.Enabled() && akActor.IsGuard() && CSN_Intrigue.Target(CSN_World.TownOf(akActor))
EndFunction

Function Exec_TakeBribe(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Intrigue.Pay(CSN_World.TownOf(akActor), 0, akActor)
	EndAction()
EndFunction

Bool Function Elig_TakeFunds(Actor akActor, String contextJson, String paramsJson) Global
	Int i = CSN_World.TownOf(akActor)
	Return CSN_Intrigue.Enabled() && !akActor.IsGuard() && CSN_Intrigue.Target(i) && CSN_World.TownJarl(i) != akActor
EndFunction

Function Exec_TakeFunds(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Intrigue.Pay(CSN_World.TownOf(akActor), 1, akActor)
	EndAction()
EndFunction

Bool Function Elig_Persuade(Actor akActor, String contextJson, String paramsJson) Global
	Int i = CSN_World.TownOf(akActor)
	Return CSN_Intrigue.Enabled() && CSN_Intrigue.Target(i) && CSN_World.TownJarl(i) != akActor
EndFunction

Function Exec_Persuade(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Intrigue.Persuade(akActor)
	EndAction()
EndFunction

Bool Function Elig_Coup(Actor akActor, String contextJson, String paramsJson) Global
	Int i = CSN_World.TownOf(akActor)
	If !CSN_Intrigue.Enabled() || !CSN_Intrigue.Target(i) || CSN_World.TownJarl(i) == akActor
		Return False
	EndIf
	Return CSN_Intrigue.CanCoup(i) && (StorageUtil.GetIntValue(akActor, "csn_bribed", 0) == 1 || akActor.IsGuard() || CSN_Intrigue.IsNoble(akActor))
EndFunction

Function Exec_Coup(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Intrigue.PlanCoup(CSN_World.TownOf(akActor), akActor)
	EndAction()
EndFunction

Bool Function Elig_Settler(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	If !CSN_Settle.Enabled() || m.FactionStarted.GetValue() < 1
		Return False
	EndIf
	Return ActsAsSteward(akActor) || m.GetRole(akActor) == m.ROLE_GENERAL
EndFunction

Function Exec_FoundSettlement(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Settle.Found(akActor)
	EndAction()
EndFunction

Bool Function Elig_Build(Actor akActor, String contextJson, String paramsJson) Global
	If !CSN_Settle.Enabled() || CSN_Settle.Here() < 0
		Return False
	EndIf
	Return CSN_Settle.RunsLand(akActor) || StorageUtil.GetIntValue(akActor, "csn_settler", 0) - 1 == CSN_Settle.Here()
EndFunction

Function Exec_Build(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	EndAction()
	CSN_Settle.BuildMenu(CSN_Settle.Here())
EndFunction

; a Captain or Commander receiving a star from the leader in person
Function Exec_ReceiveStar(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	CSN_Gov.AwardStar(akActor, None)
	EndAction()
EndFunction

; the Steward arranges bribes, funding or a coup in an enemy city, from the treasury
Bool Function Elig_SpyMaster(Actor akActor, String contextJson, String paramsJson) Global
	CSN_Core m = Main()
	Int r = m.GetRole(akActor)
	Return CSN_Intrigue.Enabled() && (ActsAsSteward(akActor) || r == m.ROLE_GENERAL)
EndFunction

Function Exec_ArrangeIntrigue(Actor akActor, String contextJson, String paramsJson) Global
	BeginAction(akActor)
	Int i = ParseCity(Param(paramsJson, "city"))
	String w = Param(paramsJson, "what")
	If i < 0
		i = PickIntrigueCity()
	EndIf
	If i < 0
		CSN_Gov.Fail("Which city?")
	ElseIf Matches(w, "coup") || Matches(w, "overthrow") || Matches(w, "jarl")
		CSN_Intrigue.PlanCoup(i, akActor)
	ElseIf Matches(w, "people") || Matches(w, "noble") || Matches(w, "citizen") || Matches(w, "fund")
		CSN_Intrigue.Pay(i, 1, akActor, True)
	Else
		CSN_Intrigue.Pay(i, 0, akActor, True)
	EndIf
	EndAction()
EndFunction

Int Function PickIntrigueCity() Global
	Int[] ids = PapyrusUtil.IntArray(0)
	String[] names = PapyrusUtil.StringArray(0)
	Int i = 0
	While i < 9
		If CSN_Intrigue.Target(i)
			ids = PapyrusUtil.PushInt(ids, i)
			names = PapyrusUtil.PushString(names, CSN_World.TownName(i) + " (guards " + CSN_Intrigue.Guards(i) + ", people " + CSN_Intrigue.People(i) + ")")
		EndIf
		i += 1
	EndWhile
	If ids.Length == 0
		Return -1
	EndIf
	names = PapyrusUtil.PushString(names, "Cancel")
	Int k = CSNP.Choose("Which city?", "Where should our agents work?", names)
	If k < 0 || k >= ids.Length
		Return -1
	EndIf
	Return ids[k]
EndFunction
