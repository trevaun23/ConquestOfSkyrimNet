Scriptname CSN_Thanes Hidden
{Conquest of SkyrimNet - Thanes of the holds the faction controls.

 A Thane is a landed notable of one hold (0-8, the hold of that city), appointed by the leader for ThaneCost() gold.
 They carry "Thane" before their name, know their hold, wear their hold's Thane outfit ("Whiterun Thane Outfit")
 and pitch private investments to the leader (CSN_Requests kind 6), which pay back a little more over 15-30 days.
 Officers, Captains and Commanders, jarls, town stewards and housecarls can't be Thanes.

 StorageUtil: actor "csn_thane" = hold + 1; global form list "csn_thanes"; per hold "csn_thane_chest_<h>" (the
 outfit chest) and form list "csn_thane_outfit_<h>" (what they wear).}

CSN_Core Function M() Global
	Return CSN_Gov.M()
EndFunction

Int Function ThaneCost() Global
	Return 1000
EndFunction

Int Function MaxPerHold() Global
	Return 3
EndFunction

; Thanes a hold may have: 3, plus one for every settlement founded in it (added when one is founded, taken away when
; one is abandoned)
Int Function MaxIn(Int h) Global
	Return MaxPerHold() + StorageUtil.GetIntValue(None, "csn_thane_extra_" + h, 0)
EndFunction

Function AddSlots(Int h, Int aiBy) Global
	If h < 0
		Return
	EndIf
	Int n = StorageUtil.GetIntValue(None, "csn_thane_extra_" + h, 0) + aiBy
	If n < 0
		n = 0
	EndIf
	StorageUtil.SetIntValue(None, "csn_thane_extra_" + h, n)
EndFunction

Int Function HoldOf(Actor a) Global
	If !a
		Return -1
	EndIf
	Return StorageUtil.GetIntValue(a, "csn_thane", 0) - 1
EndFunction

Bool Function IsThane(Actor a) Global
	Return HoldOf(a) >= 0
EndFunction

String Function HoldName(Int h) Global
	Return M().HoldName(h)
EndFunction

Int Function Count() Global
	Prune()
	Return StorageUtil.FormListCount(None, "csn_thanes")
EndFunction

Actor Function At(Int i) Global
	Return StorageUtil.FormListGet(None, "csn_thanes", i) as Actor
EndFunction

Int Function CountIn(Int h) Global
	Int n = 0
	Int i = 0
	While i < Count()
		If HoldOf(At(i)) == h
			n += 1
		EndIf
		i += 1
	EndWhile
	Return n
EndFunction

; the dead and the missing leave the list
Function Prune() Global
	Int i = StorageUtil.FormListCount(None, "csn_thanes") - 1
	While i >= 0
		Actor a = StorageUtil.FormListGet(None, "csn_thanes", i) as Actor
		If !a || a.IsDead() || HoldOf(a) < 0
			StorageUtil.FormListRemoveAt(None, "csn_thanes", i)
			If a
				StorageUtil.UnsetIntValue(a, "csn_thane")
			EndIf
		EndIf
		i -= 1
	EndWhile
EndFunction

; holds the faction controls: it rules the hold's city
Bool Function Controls(Int h) Global
	Return h >= 0 && h <= 8 && CSN_World.PlayerRules(h)
EndFunction

; why this person can't be made a Thane ("" if they can)
String Function Block(Actor a) Global
	CSN_Core m = M()
	If !a || a == Game.GetPlayer()
		Return "No one to appoint."
	ElseIf m.FactionStarted.GetValue() < 1
		Return "Found your faction first."
	ElseIf a.IsDead() || a.IsChild()
		Return M().PlainName(a) + " can't be a Thane."
	ElseIf IsThane(a)
		Return M().PlainName(a) + " is already Thane of " + HoldName(HoldOf(a)) + "."
	ElseIf CSN_Gov.OfficeOf(a) != "" || IsHousecarl(a)
		Return M().PlainName(a) + " already holds an office (General, Steward, Blacksmith, Court Wizard, Captain or Commander, jarl, steward or housecarl); they can't also be a Thane."
	ElseIf !CanJoinGovernment(a)
		Return M().PlainName(a) + " can't be named Thane: they must be a friend of yours, and not a guard, a prisoner or already in your faction's service."
	EndIf
	Return ""
EndFunction

; Conquest of Skyrim's "I would like to recruit you to my faction's government" test, without its race and
; Empire/Stormcloak restrictions (any race may be a Thane, and so may those who serve either side).
Bool Function CanJoinGovernment(Actor a) Global
	CSN_Core m = M()
	Actor p = Game.GetPlayer()
	If !a || a == p || a.IsDead() || a.IsChild()
		Return False
	EndIf
	If m.FactionStarted.GetValue() < 1 || m.Gov.GetStage() < 1
		Return False
	EndIf
	; no guards (an orc stronghold's warriors are fine)
	Faction orcs = Game.GetFormFromFile(0x028713, "Skyrim.esm") as Faction
	If a.IsGuard() && !(orcs && a.IsInFaction(orcs))
		Return False
	EndIf
	; not already in the faction's service, a prisoner, or kept from recruiting
	Int[] ids = new Int[6]
	ids[0] = 0x0227A1   ; CS_PlayerFactionGovernment
	ids[1] = 0x033275   ; CS_PrisonerFaction
	ids[2] = 0x0033AD   ; CS_PlayerArmyCommanders
	ids[3] = 0x0028A5   ; CS_PlayerArmyFaction
	ids[4] = 0x42C6F6   ; CS_NoRecruitFaction
	ids[5] = 0
	Int i = 0
	While i < 5
		Faction f = Game.GetFormFromFile(ids[i], "ConquestOfSkyrimNet.esp") as Faction
		If f && a.IsInFaction(f)
			Return False
		EndIf
		i += 1
	EndWhile
	; a friend of the leader
	Return a.GetRelationshipRank(p) >= 1
EndFunction

Bool Function IsHousecarl(Actor a) Global
	CS_GovScriptFunctions g = M().Gov
	Return CSN_Gov.InAliases(g.RecruitJarl.HousecarlAliases, a) || (g.ASIC && g.ASIC.GetActorRef() == a)
EndFunction

Bool Function Appoint(Actor a, Int h, Actor akVia = None) Global
	CSN_Core m = M()
	String err = Block(a)
	If err != ""
		CSN_Gov.Fail(err)
		Return False
	EndIf
	If !Controls(h)
		CSN_Gov.Fail("Thanes are named only in holds your faction controls; it doesn't rule " + HoldName(h) + "'s city.")
		Return False
	EndIf
	If CountIn(h) >= MaxIn(h)
		CSN_Gov.Fail(HoldName(h) + " already has " + MaxIn(h) + " Thanes (3, plus one for each settlement founded there).")
		Return False
	EndIf
	If CSN_Gov.Treasury() < ThaneCost()
		CSN_Gov.Fail("Naming a Thane costs " + ThaneCost() + " gold; the treasury holds " + CSN_Gov.Treasury() + ".")
		Return False
	EndIf
	If !CSNP.Confirm("Name a Thane", "Name " + m.PlainName(a) + " Thane of " + HoldName(h) + "?\n\nCosts " + ThaneCost() + " gold from the treasury (" + CSN_Gov.Treasury() + "). Thanes wear the " + OutfitName(h) + ", know their hold and bring you private ventures to invest in.", "Name them Thane", "Not now")
		Return False
	EndIf
	m.Econ().Treasury.Mod(-ThaneCost())
	StorageUtil.SetIntValue(a, "csn_thane", h + 1)
	StorageUtil.FormListAdd(None, "csn_thanes", a, False)
	m.SetTitle(a, "Thane", False)
	Dress(a)
	String txt = Game.GetPlayer().GetDisplayName() + " named " + m.PlainName(a) + " Thane of " + HoldName(h) + " for the " + m.FactionName() + "."
	CSN_Gov.Say(m.PlainName(a) + " is now Thane of " + HoldName(h) + ".")
	CSN_World.AddNews(h, txt, "csn_thane", a)
	CSN_SkyrimNet.LogEvent(txt, a, Game.GetPlayer())
	CSN_SkyrimNet.RefreshBio(a)
	m.Refresh()
	Return True
EndFunction

; no longer a Thane (removed, resigned)
Function Remove(Actor a) Global
	Int h = HoldOf(a)
	If h < 0
		Return
	EndIf
	StorageUtil.UnsetIntValue(a, "csn_thane")
	StorageUtil.FormListRemove(None, "csn_thanes", a, True)
	M().ClearTitle(a)
	Undress(a)
EndFunction

; A hold whose capital city the faction no longer holds loses all its Thanes: the title, the outfit, the
; ventures, and their name goes back to plain ("Thane Ysolda" -> "Ysolda").
Function LoseHold(Int h, String asWhy = "") Global
	CSN_Core m = M()
	If h < 0 || h > 8
		Return
	EndIf
	String lost = ""
	Int i = StorageUtil.FormListCount(None, "csn_thanes") - 1
	While i >= 0
		Actor a = StorageUtil.FormListGet(None, "csn_thanes", i) as Actor
		If a && HoldOf(a) == h
			lost = CSN_Rebellion.AddTo(lost, m.PlainName(a))
			Remove(a)
			m.ClearTitle(a)   ; sure the plain name is back
		EndIf
		i -= 1
	EndWhile
	If lost == ""
		Return
	EndIf
	CSN_Requests.StopInvestments(h, "the faction no longer holds " + CSN_World.TownName(h) + ".")
	String why = asWhy
	If why == ""
		why = "the faction no longer holds " + CSN_World.TownName(h)
	EndIf
	CSN_Gov.Say(HoldName(h) + " lost its Thanes: " + why + ".")
	CSN_World.AddNews(h, lost + " are no longer Thanes of " + HoldName(h) + " for the " + m.FactionName() + ": " + why + ".", "csn_thanes_lost")
	CSN_Config.Log("thanes: " + HoldName(h) + " lost " + lost)
EndFunction

; A Thane who takes an office (Steward, General, Blacksmith, Court Wizard, Captain or Commander, a town's jarl,
; steward or housecarl) stops being a Thane: the office's title replaces "Thane".
Function CheckOffices() Global
	CSN_Core m = M()
	Int i = StorageUtil.FormListCount(None, "csn_thanes") - 1
	While i >= 0
		Actor a = StorageUtil.FormListGet(None, "csn_thanes", i) as Actor
		If a && (m.GetRole(a) >= 0 || m.GetArmy(a) >= 0 || CSN_Gov.JarlCityOf(a) >= 0 || CSN_Gov.CityStewardOf(a) >= 0 || IsHousecarl(a))
			String hold = HoldName(HoldOf(a))
			Remove(a)
			m.SyncTitles()   ; the new office's title right away
			CSN_Gov.Say(m.PlainName(a) + " is no longer Thane of " + hold + ": they took an office in your service.")
		EndIf
		i -= 1
	EndWhile
EndFunction

; Every hold whose capital the faction doesn't hold loses its Thanes (checked every few seconds; cheap when none).
Function CheckHolds() Global
	If StorageUtil.FormListCount(None, "csn_thanes") <= 0
		Return
	EndIf
	CheckOffices()
	Int h = 0
	While h < 9
		If !Controls(h) && CountIn(h) > 0
			LoseHold(h)
		EndIf
		h += 1
	EndWhile
EndFunction

; ---- the Thane outfit of each hold ----------------------------------------------------------
String Function OutfitName(Int h) Global
	Return HoldName(h) + " Thane Outfit"
EndFunction

; Open the hold's Thane outfit chest; when it closes, every Thane of the hold changes into it.
Function EditOutfit(Int h) Global
	CSN_Core m = M()
	If h < 0 || h > 8
		Return
	EndIf
	ObjectReference chest = StorageUtil.GetFormValue(None, "csn_thane_chest_" + h) as ObjectReference
	Actor p = Game.GetPlayer()
	If !chest
		Container base = Game.GetFormFromFile(0x0F3923, "Skyrim.esm") as Container   ; PlayerHouseChest (never respawns)
		chest = p.PlaceAtMe(base, 1, True, True)
		StorageUtil.SetFormValue(None, "csn_thane_chest_" + h, chest)
		chest.SetDisplayName(OutfitName(h), True)
	EndIf
	chest.MoveTo(p, 0.0, 0.0, -2000.0)
	chest.Enable()
	m.CloseScreen()
	m.WatchThaneOutfit(h)
	CSN_Gov.Say(OutfitName(h) + ": put in what the Thanes of " + HoldName(h) + " should wear, then close it.")
	Utility.Wait(0.3)
	chest.Activate(p, True)
EndFunction

; the chest closed: remember what is in it, put the chest away, dress the hold's Thanes
Function OutfitClosed(Int h) Global
	ObjectReference chest = StorageUtil.GetFormValue(None, "csn_thane_chest_" + h) as ObjectReference
	If !chest
		Return
	EndIf
	String lk = "csn_thane_outfit_" + h
	StorageUtil.FormListClear(None, lk)
	Int n = chest.GetNumItems()
	Int i = 0
	While i < n
		Form f = chest.GetNthForm(i)
		If (f as Armor) || (f as Weapon)
			StorageUtil.FormListAdd(None, lk, f, False)
		EndIf
		i += 1
	EndWhile
	chest.Disable()
	Int k = 0
	Int dressed = 0
	While k < Count()
		Actor a = At(k)
		If HoldOf(a) == h
			Dress(a)
			dressed += 1
		EndIf
		k += 1
	EndWhile
	If StorageUtil.FormListCount(None, lk) == 0
		CSN_Gov.Say(OutfitName(h) + " is empty: the Thanes wear what they like.")
	Else
		CSN_Gov.Say(OutfitName(h) + " saved (" + StorageUtil.FormListCount(None, lk) + " pieces); " + dressed + " Thane(s) changed into it.")
	EndIf
EndFunction

Function Dress(Actor a) Global
	Int h = HoldOf(a)
	If !a || h < 0 || a.IsDead()
		Return
	EndIf
	String lk = "csn_thane_outfit_" + h
	Int n = StorageUtil.FormListCount(None, lk)
	If n == 0
		Return
	EndIf
	; no strip-everything first: each piece replaces what's in its slot, one at a time, and only what isn't worn
	; already (a full strip and redress of a loaded NPC can crash the game)
	Int i = 0
	While i < n
		CSN_Gov.WearItem(a, StorageUtil.FormListGet(None, lk, i))
		i += 1
	EndWhile
EndFunction

Function Undress(Actor a) Global
	If a
		Int i = 0
		While i < 9
			String lk = "csn_thane_outfit_" + i
			Int k = 0
			While k < StorageUtil.FormListCount(None, lk)
				Form f = StorageUtil.FormListGet(None, lk, k)
				If f && a.IsEquipped(f)
					a.UnequipItem(f, False, True)
				EndIf
				k += 1
			EndWhile
			i += 1
		EndWhile
	EndIf
EndFunction

; every load: Thanes back in their hold's colours
Function OnLoad() Global
	Int i = 0
	While i < Count()
		Dress(At(i))
		i += 1
	EndWhile
EndFunction

; ---- what a Thane knows ---------------------------------------------------------------------
String Function Knowledge(Actor akActor) Global
	Int h = HoldOf(akActor)
	If h < 0
		Return ""
	EndIf
	CSN_Core m = M()
	String hold = HoldName(h)
	String s = m.PlainName(akActor) + " is a Thane of " + hold + " for the " + m.FactionName() + ", named by " + CSN_Culture.TitledName() + ": a landed notable of the hold, not an officer of the government. Their hold: " + hold + " (its city " + CSN_World.TownName(h) + ", loyalty " + CSN_World.TownLoyalty(h) + ")."
	s += " As Thane they look after their own private ventures in " + hold + " (trade, workshops, farms and the like). One of a Thane's privileges: they can bring the leader investment opportunities, a business proposal of their own for the faction to invest in (an upfront sum of gold and supplies, paid back with a 10-35% profit over 15-30 days into the hold's city treasury). They can raise one in conversation whenever it suits them or when the leader asks; it then waits in the leader's Requests."
	String can = CSN_Requests.CanPitch(akActor)
	If can == ""
		s += " They could bring a new venture right now."
	Else
		s += " " + can
	EndIf
	s += " They wear the " + OutfitName(h) + " when the leader has set one."
	String inv = CSN_Requests.ThaneInvestText(akActor)
	If inv != ""
		s += inv
	EndIf
	Return s
EndFunction

; for the faction screen
String Function Json() Global
	CSN_Core m = M()
	String s = "["
	Int i = 0
	While i < Count()
		Actor a = At(i)
		If i > 0
			s += ","
		EndIf
		s += "{\"i\":" + i + ",\"name\":" + m.Q(m.PlainName(a)) + ",\"hold\":" + HoldOf(a) + ",\"holdname\":" + m.Q(HoldName(HoldOf(a))) + "}"
		i += 1
	EndWhile
	s += "],\"thaneholds\":["
	Int h = 0
	Bool first = True
	While h < 9
		If Controls(h)
			If !first
				s += ","
			EndIf
			first = False
			s += "{\"h\":" + h + ",\"name\":" + m.Q(HoldName(h)) + ",\"outfit\":" + StorageUtil.FormListCount(None, "csn_thane_outfit_" + h) + ",\"n\":" + CountIn(h) + ",\"max\":" + MaxIn(h) + "}"
		EndIf
		h += 1
	EndWhile
	Return s + "]"
EndFunction
