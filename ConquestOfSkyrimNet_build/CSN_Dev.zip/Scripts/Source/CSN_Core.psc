Scriptname CSN_Core extends Quest
{Conquest of SkyrimNet layer on top of the Conquest of Skyrim code base.
 Attached to the CoS quest CS_FactionGovernment (Tools/esp_patch.py adds it and fills the properties).
 Hotkey from ConquestOfSkyrimNetUI.dll (set it in the MCM; unbound by default) opens the faction screen.
 Officers are appointed in conversation or from the Officers tab (a list of people nearby).

 Adds: officer titles (General / Steward / Blacksmith / Court Wizard), Commander titles,
 officer appointment and commander hiring outside dialogue, the PrismaUI dashboard
 (overview, claims, war table, steward ledger), and the hooks SkyrimNet uses.
 Everything calls the existing CS_ functions, so CoS keeps doing the real work.}

; =============================================================================
; PROPERTIES
; =============================================================================
Actor Property PlayerRef Auto
CS_GovScriptFunctions Property Gov Auto          ; quest CS_FactionGovernment
ReferenceAlias Property CourtSteward Auto        ; alias "Steward" on quest CS_Court (same as the Steward dialogue)
GlobalVariable Property FactionStarted Auto      ; CS_FactionStarted
GlobalVariable Property RecruitASIC Auto         ; CS_FactionStartRecruitASIC
GlobalVariable Property RecruitSteward Auto      ; CS_FactionStartRecruitSteward
GlobalVariable Property RecruitCommanderTut Auto ; CS_FactionStartRecruitCommander
Keyword Property PlayerDefended Auto             ; same keyword CS_ClaimAreaFunctions uses for guard counts
Keyword Property MineLocType Auto                ; same keyword CS_ClaimAreaFunctions uses for miner counts

; =============================================================================
; CONSTANTS / STATE
; =============================================================================
Int Property ROLE_GENERAL = 0 AutoReadOnly
Int Property ROLE_STEWARD = 1 AutoReadOnly
Int Property ROLE_BLACKSMITH = 2 AutoReadOnly
Int Property ROLE_WIZARD = 3 AutoReadOnly

Int Property ORDER_HOME = 0 AutoReadOnly
Int Property ORDER_HUNT = 1 AutoReadOnly
Int Property ORDER_FOLLOW = 2 AutoReadOnly
Int Property ORDER_HOLD = 3 AutoReadOnly
Int Property ORDER_FORT = 4 AutoReadOnly
Int Property ORDER_CAMP = 5 AutoReadOnly

Actor[] TitledOfficers      ; who currently carries an officer title (to remove it when replaced)
Actor[] TitledCommanders
String CurrentScreen = ""
String CurrentCtx = "{}"
Actor[] Candidates          ; people nearby offered on the Officers tab
Actor NearSteward           ; steward or jarl next to the player when the screen opened
Actor NearGeneral
Actor NearBlacksmith
String PayloadTab = "overview"   ; which tab the next payload is for ("lite" = only the header and basics)
Actor PendingOutfit         ; changes into their outfit template when the template's inventory closes
Bool PendingGovOutfit       ; ... or, for the government and courts, into their position's outfit (CoS)
Int PendingThaneHold = -1   ; the hold whose Thane outfit chest is open
Actor OrderVia              ; the General passing an order on (for the notification), or None
Int HotkeyCode = -1         ; faction menu key (DirectX scan code from the MCM), registered with RegisterForKey
Float LastClose = 0.0
Bool HotkeyOpen = False      ; the dashboard is being opened with the faction-menu key

; =============================================================================
; LIFECYCLE
; =============================================================================
Event OnInit()
	TitledOfficers = new Actor[4]
	TitledCommanders = new Actor[40]
	OnGameLoad()
EndEvent

Function OnGameLoad()
	; a save made with the screen open would otherwise block the hotkey forever
	CurrentScreen = ""
	LastClose = 0.0
	UnregisterForAllModEvents()
	RegisterForModEvent("CSN_UICommand", "OnFFUICommand")
	RegisterForModEvent("PhysicalLetters_Read", "OnLetterRead")
	RegisterForModEvent("PhysicalLetters_Action_csn_request_answer", "OnLetterAnswer")
	CSN_SkyrimNet.RegisterAll()
	CSN_Letters.RegisterActions()
	RegisterHotkey()
	CSN_Gov.SyncDifficultyToMCM()
	CSN_Culture.SyncToMCM()
	; 1.6.6 handed holds over without the story event and left CoS's transfer quest running, which blocks every
	; later conquest; it only ever runs for a moment, so a running one at load is that leftover
	CSN_Gov.ResetTransferQuest()
	; settlement map markers: their names aren't kept in the save
	CSN_Settle.OnLoad()
	CSN_Thanes.OnLoad()
	; journal quests for trouble that started before they existed
	If FactionStarted.GetValue() >= 1
		CSN_Journal.Sync()
	EndIf
	If FactionStarted.GetValue() >= 1
		CSN_Troops.FixAutoRecruit()
	EndIf
	CSN_Config.Log("game loaded; hotkey " + HotkeyCode)
	RegisterForSingleUpdate(5.0)
EndFunction

; Keep titles in sync with CoS's own aliases, whichever way people were appointed (dialogue, menu, SkyrimNet).
Int WorldTick = 0

Event OnUpdate()
	If FactionStarted.GetValue() >= 1
		SyncTitles()
		; every attack the faction launches becomes known across Skyrim, however it was started
		CSN_War.WatchBattles()
		; rebels in the streets, deserters at their fort, settlers who wandered off
		CSN_Rebellion.Watch()
		CSN_Settle.Watch()
		CSN_Thanes.CheckHolds()
		CSN_Festival.Watch()   ; an approved festival's festivities follow you into its town
	EndIf
	; townsfolk news and opinion: about once a minute
	WorldTick += 1
	If WorldTick >= 12
		WorldTick = 0
		CSN_World.Poll()
		CSN_Requests.Tick()
		CSN_Gov.ApplyStarBuffs()
		If FactionStarted.GetValue() >= 1
			CSN_Gov.WarFronts()   ; cities that reached an enemy outside CoS's war flow
		EndIf
		If FactionStarted.GetValue() >= 1
			; once a day: unrest, army morale, free companies, settlements; a coup that has ended
			CSN_Rebellion.Tick()
			CSN_Settle.Tick()
			CSN_Intrigue.Tick()
			CSN_Festival.Tick()   ; holidays (with the Holidays mod)
		EndIf
	EndIf
	RegisterForSingleUpdate(5.0)
EndEvent

; ---- faction menu hotkey (Papyrus opens; the UI plugin closes it while it has focus) ----
Function RegisterHotkey()
	If HotkeyCode > 0
		UnregisterForKey(HotkeyCode)
	EndIf
	HotkeyCode = CSN_Config.GetInt("iLedgerKey:Hotkeys", -1)
	If HotkeyCode > 0
		RegisterForKey(HotkeyCode)
	EndIf
EndFunction

; build mode (CSN_Settle): arrows, Page Up/Down, Enter / Activate, Backspace
Function PlacementKeys(Bool abOn)
	Int[] keys = new Int[11]
	keys[9] = 199    ; Home: grid snapping
	keys[10] = 207   ; End: turn snapping
	keys[0] = 28
	keys[1] = 156
	keys[2] = 14
	keys[3] = 203
	keys[4] = 205
	keys[5] = 200
	keys[6] = 208
	keys[7] = 201
	keys[8] = 209
	Int i = 0
	While i < keys.Length
		If keys[i] != HotkeyCode
			If abOn
				RegisterForKey(keys[i])
			Else
				UnregisterForKey(keys[i])
			EndIf
		EndIf
		i += 1
	EndWhile
	Int act = Input.GetMappedKey("Activate")
	If act > 0 && act != HotkeyCode
		If abOn
			RegisterForKey(act)
		Else
			UnregisterForKey(act)
		EndIf
	EndIf
EndFunction

Event OnKeyDown(Int aiKeyCode)
	If CSN_Settle.Placing() && !Utility.IsInMenuMode()
		CSN_Settle.PlaceKey(aiKeyCode)
		Return
	EndIf
	If aiKeyCode == HotkeyCode && CurrentScreen != "" && !CSN_Native.IsScreenOpen()
		; the screen was closed without telling us (or this same key press just closed it): count it as closed,
		; and don't open it again on this press
		CurrentScreen = ""
		LastClose = Utility.GetCurrentRealTime()
		Return
	EndIf
	If aiKeyCode != HotkeyCode || CurrentScreen != "" || Utility.IsInMenuMode()
		Return
	EndIf
	If Utility.GetCurrentRealTime() - LastClose < 0.6
		Return
	EndIf
	CSN_Config.Log("hotkey pressed")
	If FactionStarted.GetValue() >= 1
		; back to the tab that was open last time (kept in the save)
		String last = StorageUtil.GetStringValue(None, "csn_lasttab", "overview")
		CSN_Config.Log("dashboard: hotkey opens the last tab, " + last)
		HotkeyOpen = True
		OpenDashboard(last)
		HotkeyOpen = False
	Else
		Debug.Notification("Found your faction first: read Start my Faction.")
	EndIf
EndEvent

; SkyrimNet answered the request study (CSN_Requests.Study).
Function OnRequestLLM(String asResponse, Int aiSuccess)
	CSN_Requests.FromLLM(asResponse, aiSuccess)
EndFunction

; Physical Letters (optional): a request letter was read / its writer read the player's answer.
Event OnLetterRead(String asEventName, String asLetterId, Float afNumArg, Form akSender)
	CSN_Letters.OnRead(asLetterId, akSender)
EndEvent

Event OnLetterAnswer(String asEventName, String asLetterId, Float afNumArg, Form akSender)
	CSN_Letters.OnAnswer(asLetterId)
EndEvent

; Called by CSN_MCM when a setting changes.
Function OnSettingsChanged(String asId)
	If StringUtil.Find(asId, ":Hotkeys") >= 0
		RegisterHotkey()
	EndIf
	If StringUtil.Find(asId, ":SkyrimNet") >= 0
		CSN_SkyrimNet.RegisterAll()
	ElseIf StringUtil.Find(asId, ":Difficulty") >= 0
		CSN_Gov.ApplyDifficultyFromMCM()
	ElseIf StringUtil.Find(asId, ":Culture") >= 0
		CSN_Culture.ApplyFromMCM()
	EndIf
	If CurrentScreen != ""
		Refresh()
	EndIf
EndFunction

; "Open the ledger now" button on the MCM About page.
Function OpenLedgerFromMenu()
	If FactionStarted.GetValue() >= 1
		OpenDashboard("overview")
	Else
		CSNP.Notice("Read \"Start my Faction\" first to found your faction.")
	EndIf
EndFunction

; =============================================================================
; COS ACCESSORS
; =============================================================================
CS_ClaimAreaFunctions Function Holdings()
	Return Gov.HoldingsQuest
EndFunction

; guards standing at the faction's claims (forts, mines, farms, camps); each is paid like a troop
Int Function ClaimGuards()
	CS_ClaimAreaFunctions h = Holdings()
	Int n = 0
	Int i = 0
	While h && i < h.Holdings.Length
		Location loc = h.Holdings[i].GetLocation()
		If loc
			n += loc.GetKeywordData(PlayerDefended) as Int
		EndIf
		i += 1
	EndWhile
	Return n + CSN_Settle.GuardTotal()   ; settlement guards are paid the same way
EndFunction

CS_PatrolHoldScript Function Armies()
	Return Gov.HoldingsQuest.CommanderQuest
EndFunction

CS_EconomyMenuFunctions Function Econ()
	Return Gov.EconUpdater.EconReport as CS_EconomyMenuFunctions
EndFunction

ReferenceAlias Function OfficerAlias(Int aiRole)
	If aiRole == ROLE_GENERAL
		Return Gov.ASIC
	ElseIf aiRole == ROLE_STEWARD
		Return Gov.Steward
	ElseIf aiRole == ROLE_BLACKSMITH
		Return Gov.Blacksmith
	ElseIf aiRole == ROLE_WIZARD
		Return Gov.CourtMage
	EndIf
	Return None
EndFunction

Actor Function Officer(Int aiRole)
	ReferenceAlias a = OfficerAlias(aiRole)
	If a
		Return a.GetActorRef()
	EndIf
	Return None
EndFunction

String Function RoleTitle(Int aiRole)
	If aiRole == ROLE_GENERAL
		Return "General"
	ElseIf aiRole == ROLE_STEWARD
		Return "Steward"
	ElseIf aiRole == ROLE_BLACKSMITH
		Return "Blacksmith"
	ElseIf aiRole == ROLE_WIZARD
		Return "Court Wizard"
	EndIf
	Return ""
EndFunction

Int Function GetRole(Actor akActor)
	If !akActor
		Return -1
	EndIf
	Int i = 0
	While i < 4
		If Officer(i) == akActor
			Return i
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

Int Function GetArmy(Actor akActor)
	If !akActor
		Return -1
	EndIf
	Return Armies().GetCommanderArmyNum(akActor)
EndFunction

String Function FactionName()
	; CoS keeps the faction name as the base name of the object in the "FactionName" alias.
	Return CSNP.AliasText(Gov, "FactionName")
EndFunction

; =============================================================================
; TITLES
; =============================================================================
; The person's own name, without a title this mod added. Taken from their display name the first time
; they get a title, so names from NPC Name Distributor (and similar mods) are kept.
String Function PlainName(Actor akActor)
	If !akActor
		Return ""
	EndIf
	String saved = StorageUtil.GetStringValue(akActor, "csn_plainname", "")
	If saved != ""
		Return saved
	EndIf
	Return StripTitle(akActor.GetDisplayName())
EndFunction

String Function StripTitle(String asName)
	String[] titles = new String[8]
	titles[0] = "General "
	titles[1] = "Steward "
	titles[2] = "Blacksmith "
	titles[3] = "Court Wizard "
	titles[4] = "Commander "
	titles[5] = "Captain "
	titles[6] = "Thane "
	titles[7] = "Jarl "
	Int i = 0
	While i < titles.Length
		Int n = StringUtil.GetLength(titles[i])
		If StringUtil.Find(asName, titles[i]) == 0 && StringUtil.GetLength(asName) > n
			Return StringUtil.Substring(asName, n)
		EndIf
		i += 1
	EndWhile
	Return asName
EndFunction

String Function BaseName(Actor akActor)
	Return PlainName(akActor)
EndFunction

Function SetTitle(Actor akActor, String asTitle)
	If !akActor
		Return
	EndIf
	String plain = PlainName(akActor)
	StorageUtil.SetStringValue(akActor, "csn_plainname", plain)
	String want = asTitle + " " + plain
	If akActor.GetDisplayName() != want
		akActor.SetDisplayName(want, True)
	EndIf
EndFunction

Function ClearTitle(Actor akActor)
	If !akActor
		Return
	EndIf
	String plain = PlainName(akActor)
	If akActor.GetDisplayName() != plain
		akActor.SetDisplayName(plain, True)
	EndIf
	StorageUtil.UnsetStringValue(akActor, "csn_plainname")
EndFunction

Function SyncTitles()
	Int i = 0
	While i < 4
		Actor now = Officer(i)
		If TitledOfficers[i] != now
			If TitledOfficers[i] && GetRole(TitledOfficers[i]) < 0 && GetArmy(TitledOfficers[i]) < 0
				ClearTitle(TitledOfficers[i])
			EndIf
			TitledOfficers[i] = now
		EndIf
		If now
			SetTitle(now, RoleTitle(i))
		EndIf
		i += 1
	EndWhile

	; jarls of the faction's cities carry "Jarl" before their name (however they were appointed)
	Int j = 0
	While j < 9
		Actor jarl = None
		If CSN_World.PlayerRules(j)
			jarl = CSN_World.TownJarl(j)
		EndIf
		Actor was = StorageUtil.GetFormValue(None, "csn_titled_jarl_" + j) as Actor
		If was && was != jarl
			If GetRole(was) < 0 && GetArmy(was) < 0 && !CSN_Thanes.IsThane(was)
				ClearTitle(was)
			EndIf
			StorageUtil.UnsetFormValue(None, "csn_titled_jarl_" + j)
		EndIf
		If jarl && jarl != PlayerRef && !jarl.IsDead() && GetRole(jarl) < 0 && GetArmy(jarl) < 0
			SetTitle(jarl, "Jarl")
			StorageUtil.SetFormValue(None, "csn_titled_jarl_" + j, jarl)
		EndIf
		j += 1
	EndWhile

	; the stewards of the faction's towns carry "Steward" before their name
	CS_RecruitJarl rj = Gov.RecruitJarl
	Int sw = 0
	While rj && sw < rj.StewardAliases.Length && sw < 15
		Actor stw = None
		If CSN_World.PlayerRules(sw)
			stw = rj.StewardAliases[sw].GetActorRef()
		EndIf
		Actor sWas = StorageUtil.GetFormValue(None, "csn_titled_steward_" + sw) as Actor
		If sWas && sWas != stw
			If GetRole(sWas) < 0 && GetArmy(sWas) < 0 && !CSN_Thanes.IsThane(sWas) && CSN_Gov.JarlCityOf(sWas) < 0
				ClearTitle(sWas)
			EndIf
			StorageUtil.UnsetFormValue(None, "csn_titled_steward_" + sw)
		EndIf
		If stw && stw != PlayerRef && !stw.IsDead() && GetRole(stw) < 0 && GetArmy(stw) < 0
			SetTitle(stw, "Steward")
			StorageUtil.SetFormValue(None, "csn_titled_steward_" + sw, stw)
		EndIf
		sw += 1
	EndWhile

	CS_PatrolHoldScript a = Armies()
	Int n = a.Commanders.Length
	If n > 40
		n = 40
	EndIf
	i = 0
	While i < n
		Actor c = a.Commanders[i].GetActorRef()
		If TitledCommanders[i] != c
			If TitledCommanders[i] && GetArmy(TitledCommanders[i]) < 0 && GetRole(TitledCommanders[i]) < 0
				ClearTitle(TitledCommanders[i])
			EndIf
			TitledCommanders[i] = c
		EndIf
		If c && !c.IsDead()
			SetTitle(c, CSN_Gov.RankTitle(c))
		EndIf
		i += 1
	EndWhile
EndFunction

; =============================================================================
; OFFICERS (same steps as the CoS appointment dialogue)
; =============================================================================
Bool Function CanServe(Actor akActor)
	Return FactionStarted.GetValue() >= 1 && akActor && akActor != PlayerRef && !akActor.IsDead() && !akActor.IsChild() && !akActor.IsHostileToActor(PlayerRef)
EndFunction

Bool Function Appoint(Actor akActor, Int aiRole)
	If !CanServe(akActor) || aiRole < 0 || aiRole > 3
		Return False
	EndIf
	If GetArmy(akActor) >= 0
		CSN_Gov.Fail(akActor.GetDisplayName() + " already commands an army.")
		Return False
	EndIf
	Int old = GetRole(akActor)
	If old == aiRole
		Return True
	EndIf
	If old >= 0
		OfficerAlias(old).Clear()
	EndIf

	OfficerAlias(aiRole).ForceRefTo(akActor)
	akActor.IgnoreFriendlyHits(True)
	akActor.SetCrimeFaction(None)
	Gov.RemoveFromAllCrimeFactions(akActor)
	Gov.DisplayTravelMessage(akActor)
	Int capital = Gov.CapitalGlobal.GetValueInt()
	If aiRole == ROLE_GENERAL
		If capital >= 0
			Gov.Housecarls[capital].ForceRefTo(akActor)
		EndIf
		If RecruitASIC.GetValue() == 0
			RecruitASIC.SetValue(1)
			Gov.SetStage(5)
		EndIf
	ElseIf aiRole == ROLE_STEWARD
		CourtSteward.ForceRefTo(akActor)
		If capital >= 0
			Gov.Stewards[capital].ForceRefTo(akActor)
		EndIf
		If RecruitSteward.GetValue() == 0
			RecruitSteward.SetValue(1)
			Gov.SetStage(2)
		EndIf
	ElseIf aiRole == ROLE_BLACKSMITH
		If Gov.GetStage() == 10
			Gov.SetStage(11)
		EndIf
	EndIf
	SetTitle(akActor, RoleTitle(aiRole))
	CSN_Gov.Say(BaseName(akActor) + " is now " + RoleTitle(aiRole) + " of the " + FactionName() + ".")
	CSN_SkyrimNet.LogEvent(BaseName(akActor) + " was appointed " + RoleTitle(aiRole) + " of the " + FactionName() + ".", akActor, PlayerRef)
	CSN_SkyrimNet.RefreshBio(akActor)
	Return True
EndFunction

Function Dismiss(Int aiRole)
	Actor a = Officer(aiRole)
	If !a
		Return
	EndIf
	OfficerAlias(aiRole).Clear()
	If aiRole == ROLE_STEWARD && CourtSteward.GetActorRef() == a
		CourtSteward.Clear()
	EndIf
	ClearTitle(a)
	CSN_SkyrimNet.LogEvent(BaseName(a) + " is no longer " + RoleTitle(aiRole) + " of the " + FactionName() + ".", a, PlayerRef)
	CSN_SkyrimNet.RefreshBio(a)
EndFunction

; =============================================================================
; COMMANDERS AND ORDERS (CS_PatrolHoldScript does the work)
; =============================================================================
Bool Function IsFriend(Actor akActor)
	Return akActor && akActor.GetRelationshipRank(PlayerRef) >= 1
EndFunction

; First open army slot (CoS opens one per claimed holding), or -1.
Int Function FreeArmySlot()
	FormList slots = Armies().RecruitCommanders
	Int i = 0
	Int n = slots.GetSize()
	While i < n
		If (slots.GetAt(i) as GlobalVariable).GetValue() == 1
			Return i
		EndIf
		i += 1
	EndWhile
	Return -1
EndFunction

Bool Function CanHireCommander(Actor akActor)
	Return CanServe(akActor) && GetRole(akActor) < 0 && GetArmy(akActor) < 0 && FreeArmySlot() >= 0
EndFunction

Bool Function HireCommander(Actor akActor)
	If !CanServe(akActor)
		Return False
	EndIf
	If GetRole(akActor) >= 0 || GetArmy(akActor) >= 0
		CSN_Gov.Fail(akActor.GetDisplayName() + " already serves you.")
		Return False
	EndIf
	Int slot = FreeArmySlot()
	If slot < 0
		CSN_Gov.Fail("Claim another holding to open a commander slot.")
		Return False
	EndIf
	Armies().RecruitCommander(akActor, slot + 1)
	If RecruitCommanderTut.GetValue() == 0
		RecruitCommanderTut.SetValue(1)
		Gov.SetStage(6)
	EndIf
	SetTitle(akActor, "Captain")
	CSN_Gov.Say(BaseName(akActor) + " is now Captain of " + CSN_Gov.ArmyLabel(slot) + ".")
	CSN_SkyrimNet.LogEvent(BaseName(akActor) + " became a Captain of the " + FactionName() + ", leading " + CSN_Gov.ArmyLabel(slot) + ". Captains who earn stars become Commanders.", akActor, PlayerRef)
	CSN_SkyrimNet.RefreshBio(akActor)
	Return True
EndFunction

Function FireCommander(Actor akActor)
	If GetArmy(akActor) < 0
		Return
	EndIf
	Armies().FireCommander(akActor)
	CSN_Gov.ClearStars(akActor)
	ClearTitle(akActor)
	CSN_SkyrimNet.LogEvent(BaseName(akActor) + " no longer leads an army of the " + FactionName() + "; any stars they earned are gone.", akActor, PlayerRef)
	CSN_SkyrimNet.RefreshBio(akActor)
EndFunction

Int Function HoldCount()
	Return Gov.AllHolds.GetSize()
EndFunction

String Function HoldName(Int aiHold)
	Location l = Gov.AllHolds.GetAt(aiHold) as Location
	If l
		Return l.GetName()
	EndIf
	Return "Hold " + aiHold
EndFunction

; VERIFY in game: CoS stores the owner of each hold city in AllHoldings (11 Imperial, 12 Stormcloak, player = TMPlayer.FactionNum).
Bool Function OwnsHold(Int aiHold)
	GlobalVariable g = Gov.AllHoldings.GetAt(aiHold) as GlobalVariable
	Return g && g.GetValueInt() == Gov.TMPlayer.FactionNum
EndFunction

Int Function FortCount()
	Return Gov.AllLocationsFort.GetSize()
EndFunction

String Function FortName(Int aiFort)
	Location l = Gov.AllLocationsFort.GetAt(aiFort) as Location
	If l
		Return l.GetName()
	EndIf
	Return "Fort " + aiFort
EndFunction

; VERIFY in game: CoS marks fort owners with CWOwner keyword data (1 Imperial, 2 Stormcloak, player = FactionNum - 10).
Bool Function OwnsFort(Int aiFort)
	Location l = Gov.AllLocationsFort.GetAt(aiFort) as Location
	; CoS marks a fort's owner with CWOwner: 1 Imperials, 2 Stormcloaks, 69 the player's faction
	Return l && l.GetKeywordData(Gov.CWOwner) as Int == 69
EndFunction

String Function CheckOrder(Actor akCommander, Int aiOrder, Int aiArg)
	If GetArmy(akCommander) < 0
		Return "That isn't one of your commanders."
	EndIf
	If aiOrder == ORDER_HOLD
		Return CSN_Gov.CheckGarrisonCity(akCommander, aiArg)
	EndIf
	If aiOrder == ORDER_CAMP && !CSN_Gov.CanCamp(aiArg)
		Return "Your armies can't reach that hold yet."
	EndIf
	If aiOrder == ORDER_FORT && (aiArg < 0 || aiArg >= FortCount() || !OwnsFort(aiArg))
		Return "That fort isn't yours."
	EndIf
	If aiOrder < 0 || aiOrder > 5
		Return "Unknown order."
	EndIf
	Return ""
EndFunction

Bool Function IssueOrder(Actor akCommander, Int aiOrder, Int aiArg = -1)
	String err = CheckOrder(akCommander, aiOrder, aiArg)
	If err != ""
		CSN_Gov.Fail(err)
		Return False
	EndIf
	CS_PatrolHoldScript a = Armies()
	If aiOrder == ORDER_HOME
		a.ReturnToBase(akCommander)
	ElseIf aiOrder == ORDER_HUNT
		a.StartHunt(akCommander)
	ElseIf aiOrder == ORDER_FOLLOW
		a.FollowPlayer(akCommander)
	ElseIf aiOrder == ORDER_HOLD
		a.StartPatrol(akCommander, aiArg)
	ElseIf aiOrder == ORDER_FORT
		a.GiveFortToCommander(akCommander, aiArg)
	ElseIf aiOrder == ORDER_CAMP
		a.StartPatrolHold(akCommander, aiArg)
	EndIf
	NoteOrder(akCommander, OrderName(aiOrder, aiArg))
	Return True
EndFunction

Function NoteOrder(Actor akCommander, String asOrder)
	String who = CSN_Gov.RankTitle(akCommander) + " " + PlainName(akCommander)
	If OrderVia && OrderVia != akCommander
		CSN_Gov.Say(PlainName(OrderVia) + " passed your order to " + who + ": " + asOrder + ".")
	Else
		CSN_Gov.Say(who + " (" + CSN_Gov.ArmyLabel(GetArmy(akCommander)) + "): " + asOrder + ".")
	EndIf
	CSN_SkyrimNet.ShortEvent("csn_order_" + GetArmy(akCommander), "Commander " + PlainName(akCommander) + " received new orders: " + asOrder + ".", akCommander)
	CSN_SkyrimNet.LogEvent("Commander " + PlainName(akCommander) + " was ordered to " + asOrder + ".", akCommander, PlayerRef)
EndFunction

; Orders with the player's confirmation (MCM page Confirmations) where it applies.
Bool Function OrderWithConfirm(Actor akCommander, Int aiOrder, Int aiArg, Actor akVia = None)
	If aiOrder == ORDER_HOLD
		Return CSN_Gov.GarrisonCity(akCommander, aiArg, akVia)
	ElseIf aiOrder == ORDER_FORT
		Return CSN_Gov.GarrisonFort(akCommander, aiArg, akVia)
	ElseIf aiOrder == ORDER_CAMP
		Return CSN_Gov.MakeCamp(akCommander, aiArg, akVia)
	EndIf
	Return IssueOrder(akCommander, aiOrder, aiArg)
EndFunction

String Function OrderName(Int aiOrder, Int aiArg)
	If aiOrder == ORDER_HOME
		Return "return to the home holding"
	ElseIf aiOrder == ORDER_HUNT
		Return "hunt for food"
	ElseIf aiOrder == ORDER_FOLLOW
		Return "follow " + PlayerRef.GetDisplayName()
	ElseIf aiOrder == ORDER_HOLD
		Return "garrison " + CSN_World.TownName(aiArg)
	ElseIf aiOrder == ORDER_FORT
		Return "garrison " + FortName(aiArg)
	ElseIf aiOrder == ORDER_CAMP
		Return "make camp in " + HoldName(aiArg)
	EndIf
	Return "?"
EndFunction

String Function ArmyTask(Int i)
	ObjectReference t = Armies().ArmyScripts[i].CurrentTask
	If t
		Return t.GetDisplayName()
	EndIf
	Return "No orders"
EndFunction

Int Function ArmyTroops(Int i)
	Return Armies().ArmyScripts[i].TroopCount
EndFunction

; =============================================================================
; STEWARD: WAR AND TRADE (CS_TMScript / CS_EconomyMenuFunctions do the work)
; side: 1 = Imperials, 2 = Stormcloaks (CoS numbering). material: 0 food, 1 metal, 2 wood.
; =============================================================================
CS_TMScript Function SideQuest(Int aiSide)
	If aiSide == 1
		Return Gov.TMImp
	EndIf
	Return Gov.TMSons
EndFunction

String Function SideName(Int aiSide)
	If aiSide == 1
		Return "the Imperial Legion"
	EndIf
	Return "the Stormcloaks"
EndFunction

Bool Function AtWar(Int aiSide)
	Return SideQuest(aiSide).AtWarPlayer
EndFunction

; Same as the CoS war dialogue: stage 10 on CS_TMImperials / CS_TMSons starts the war.
Function DeclareWar(Int aiSide)
	If !Officer(ROLE_STEWARD)
		CSN_Gov.Fail("Appoint a Steward first.")
		Return
	EndIf
	CS_TMScript tm = SideQuest(aiSide)
	If tm.AtWarPlayer
		Return
	EndIf
	If tm.TrucePlayer
		CSNP.Notice("You are in a truce with " + SideName(aiSide) + ". Break it through the peace talks first.")
		Return
	EndIf
	(tm as Quest).SetStage(10)
	CSN_Gov.Say("The " + FactionName() + " is now at war with " + SideName(aiSide) + ".")
	CSN_SkyrimNet.LogEvent("The " + FactionName() + " declared war on " + SideName(aiSide) + ". All trade with them has ended.", Officer(ROLE_STEWARD), PlayerRef)
EndFunction

GlobalVariable Function TradeGlobal(Int aiSide, Int aiMat, Bool abImport)
	CS_EconomyMenuFunctions e = Econ()
	If aiMat == 0
		If abImport
			If aiSide == 1
				Return e.FoodImportedImp
			EndIf
			Return e.FoodImportedSons
		EndIf
		If aiSide == 1
			Return e.FoodExportedImp
		EndIf
		Return e.FoodExportedSons
	ElseIf aiMat == 1
		If abImport
			If aiSide == 1
				Return e.MetalImportedImp
			EndIf
			Return e.MetalImportedSons
		EndIf
		If aiSide == 1
			Return e.MetalExportedImp
		EndIf
		Return e.MetalExportedSons
	EndIf
	If abImport
		If aiSide == 1
			Return e.WoodImportedImp
		EndIf
		Return e.WoodImportedSons
	EndIf
	If aiSide == 1
		Return e.WoodExportedImp
	EndIf
	Return e.WoodExportedSons
EndFunction

String Function MaterialName(Int aiMat)
	If aiMat == 0
		Return "food"
	ElseIf aiMat == 1
		Return "metal"
	ElseIf aiMat == 3
		Return "gold"
	EndIf
	Return "wood"
EndFunction

; aiDir 1 = import, -1 = export. Amount is units per day, like the CoS trade menus.
String Function CheckTrade(Int aiSide, Int aiMat, Int aiDir, Int aiAmount)
	If !Officer(ROLE_STEWARD)
		Return "Appoint a Steward first."
	EndIf
	If (aiSide != 1 && aiSide != 2) || aiMat < 0 || aiMat > 2 || (aiDir != 1 && aiDir != -1) || aiAmount <= 0
		Return "That trade makes no sense."
	EndIf
	If AtWar(aiSide)
		Return "You are at war with " + SideName(aiSide) + "."
	EndIf
	If aiDir == 1 && TradeGlobal(aiSide, aiMat, False).GetValue() > 0
		Return "You export " + MaterialName(aiMat) + " to " + SideName(aiSide) + ", so you can't import it from them."
	EndIf
	If aiDir == -1 && TradeGlobal(aiSide, aiMat, True).GetValue() > 0
		Return "You import " + MaterialName(aiMat) + " from " + SideName(aiSide) + ", so you can't export it to them."
	EndIf
	Return ""
EndFunction

Bool Function Trade(Int aiSide, Int aiMat, Int aiDir, Int aiAmount)
	String err = CheckTrade(aiSide, aiMat, aiDir, aiAmount)
	If err != ""
		CSN_Gov.Fail(err)
		Return False
	EndIf
	CS_EconomyMenuFunctions e = Econ()
	If aiMat == 0
		If aiDir == 1
			e.ImportFood(aiSide, aiAmount)
		Else
			e.ExportFood(aiSide, aiAmount)
		EndIf
	ElseIf aiMat == 1
		If aiDir == 1
			e.ImportMetal(aiSide, aiAmount)
		Else
			e.ExportMetal(aiSide, aiAmount)
		EndIf
	Else
		If aiDir == 1
			e.ImportWood(aiSide, aiAmount)
		Else
			e.ExportWood(aiSide, aiAmount)
		EndIf
	EndIf
	Gov.EconUpdater.CalculatePlayerPerDay()  ; refresh the daily figures only: the economy itself updates once a day (CoS)
	If aiDir == 1
		CSN_Gov.Say("Agreed: importing " + aiAmount + " " + MaterialName(aiMat) + " a day from " + SideName(aiSide) + ".")
	Else
		CSN_Gov.Say("Agreed: exporting " + aiAmount + " " + MaterialName(aiMat) + " a day to " + SideName(aiSide) + ".")
	EndIf
	CSN_SkyrimNet.LogEvent("The " + FactionName() + " agreed to " + TradeWords(aiSide, aiMat, aiDir, aiAmount) + ".", Officer(ROLE_STEWARD), PlayerRef)
	Return True
EndFunction

; Trade with the Imperials / Stormcloaks after the player picks the amount (stepper dialog). Used by the
; Steward tab and by the Steward in conversation ("import 3 food from the Imperials").
Bool Function AskTrade(Int aiSide, Int aiMat, Int aiDir, Int aiAmount, Actor akVia = None)
	If aiSide < 1 || aiSide > 2 || aiMat < 0 || aiMat > 2
		Return False
	EndIf
	If AtWar(aiSide)
		CSN_Gov.Fail("You are at war with " + SideName(aiSide) + ": no trade.")
		Return False
	EndIf
	Int cur = TradeGlobal(aiSide, aiMat, True).GetValueInt() - TradeGlobal(aiSide, aiMat, False).GetValueInt()
	If (cur > 0 && aiDir < 0) || (cur < 0 && aiDir > 0)
		CSN_Gov.Fail("End the current " + MaterialName(aiMat) + " agreement with " + SideName(aiSide) + " first.")
		Return False
	EndIf
	If aiAmount < 1
		aiAmount = 1
	EndIf
	String verb = "Import"
	String label = "{n} " + MaterialName(aiMat) + " a day costs {g} gold a day"
	If aiDir < 0
		verb = "Export"
		label = "{n} " + MaterialName(aiMat) + " a day earns {g} gold a day"
	EndIf
	String now = "No agreement yet."
	If cur > 0
		now = "Now importing " + cur + " a day."
	ElseIf cur < 0
		now = "Now exporting " + (-cur) + " a day."
	EndIf
	String who = ""
	If akVia
		who = PlainName(akVia) + " has drawn up the terms. "
	EndIf
	Int n = CSNP.AskAmount(verb + " " + MaterialName(aiMat) + " " + SideTo(aiSide, aiDir), who + verb + " how much " + MaterialName(aiMat) + " each day, at " + CSN_Config.TradePrice() + " gold per unit? " + now, aiAmount, 1, 1000, CSN_Config.TradePrice(), label, "Seal the agreement", "Cancel")
	If n <= 0
		Return False
	EndIf
	Return Trade(aiSide, aiMat, aiDir, n)
EndFunction

String Function TradeWords(Int aiSide, Int aiMat, Int aiDir, Int aiAmount)
	If aiDir == 1
		Return "import " + aiAmount + " " + MaterialName(aiMat) + " a day from " + SideName(aiSide)
	EndIf
	Return "export " + aiAmount + " " + MaterialName(aiMat) + " a day to " + SideName(aiSide)
EndFunction

String Function SideTo(Int aiSide, Int aiDir)
	If aiDir < 0
		Return "to " + SideName(aiSide)
	EndIf
	Return "from " + SideName(aiSide)
EndFunction

Function CancelTrade(Int aiSide, Int aiMat, Int aiDir)
	CS_EconomyMenuFunctions e = Econ()
	CSN_Gov.Say("Ended the " + MaterialName(aiMat) + " agreement with " + SideName(aiSide) + ".")
	If aiMat == 0
		If aiDir == 1
			e.CancelFoodImports(aiSide)
		Else
			e.CancelFoodExports(aiSide)
		EndIf
	ElseIf aiMat == 1
		If aiDir == 1
			e.CancelMetalImports(aiSide)
		Else
			e.CancelMetalExports(aiSide)
		EndIf
	Else
		If aiDir == 1
			e.CancelWoodImports(aiSide)
		Else
			e.CancelWoodExports(aiSide)
		EndIf
	EndIf
	Gov.EconUpdater.CalculatePlayerPerDay()  ; refresh the daily figures only: the economy itself updates once a day (CoS)
EndFunction

; =============================================================================
; PRISMAUI SCREENS
; =============================================================================
Function Open(String asScreen, String asCtx)
	If !CSN_Native.IsAvailable()
		CSNP.Notice("Conquest of SkyrimNet: PrismaUI or ConquestOfSkyrimNetUI.dll is missing.")
		Return
	EndIf
	CurrentScreen = asScreen
	CurrentCtx = asCtx
	; show the screen at once with the header, then fill in the tab
	CSN_Native.OpenView(asScreen, BuildPayload("lite"))
	CSN_Native.PushData(asScreen, BuildPayload())
EndFunction

Function Refresh()
	If CurrentScreen != ""
		CSN_Native.PushData(CurrentScreen, BuildPayload())
	EndIf
EndFunction

; for other scripts (script variables can't be read from outside)
String Function ScreenTab()
	If PayloadTab == "lite" || PayloadTab == ""
		Return "overview"
	EndIf
	Return PayloadTab
EndFunction

Actor Function StewardNear()
	Return NearSteward
EndFunction

Function CloseScreen()
	If CurrentScreen != ""
		CurrentScreen = ""
		CSN_Native.CloseView()
	EndIf
EndFunction

Function RememberTab(String asTab)
	If asTab != "" && asTab != "lite"
		If asTab != StorageUtil.GetStringValue(None, "csn_lasttab", "")
			CSN_Config.Log("dashboard: tab " + asTab)
		EndIf
		StorageUtil.SetStringValue(None, "csn_lasttab", asTab)
	EndIf
EndFunction

; Opens the faction screen. Steward and War Table tabs only appear next to a steward / jarl or the General.
Function OpenDashboard(String asTab)
	NearSteward = CSN_Gov.NearbySteward()
	NearGeneral = CSN_Gov.NearbyGeneral()
	NearBlacksmith = CSN_Gov.NearbyBlacksmith()
	Candidates = PapyrusUtil.ActorArray(0)
	If asTab == "blacksmith" && !NearBlacksmith
		NearBlacksmith = Officer(ROLE_BLACKSMITH)
	EndIf
	; the War Table is part of the Armies tab and the Steward's books part of Lands: asked for by name (from
	; conversation), the officer runs them even from afar
	If asTab == "steward"
		If !NearSteward
			NearSteward = Officer(ROLE_STEWARD)
		EndIf
		asTab = "holdings"
	ElseIf asTab == "general"
		If !NearGeneral
			NearGeneral = Officer(ROLE_GENERAL)
		EndIf
		asTab = "armies"
	EndIf
	; a remembered Blacksmith tab whose Blacksmith is gone: the overview instead
	If asTab == "blacksmith" && !NearBlacksmith
		asTab = "overview"
	EndIf
	PayloadTab = asTab
	RememberTab(asTab)
	; from the hotkey the page may go back to the tab it last showed (it remembers it too)
	String hk = ""
	If HotkeyOpen
		hk = ",\"hotkey\":1"
	EndIf
	Open("dashboard", "{\"tab\":\"" + asTab + "\"" + hk + "}")
EndFunction

; Opened by a steward or jarl in conversation: that person runs the Steward tab.
Function OpenStewardFor(Actor akSteward)
	OpenDashboard("steward")
	If akSteward
		NearSteward = akSteward
		Refresh()
	EndIf
EndFunction

Function AskWar(Int aiSide)
	If AtWar(aiSide)
		Return
	EndIf
	If CSNP.Confirm("Declaration of war", "Declare war on " + SideName(aiSide) + "?\n\nTheir armies will attack your holdings and all trade with them ends.", "Sign and seal", "Not yet")
		DeclareWar(aiSide)
	EndIf
EndFunction

Function OpenTradeProposalOld(Int aiSide, Int aiMat, Int aiDir, Int aiAmount)
	OpenDashboard("steward")
	If !NearSteward
		NearSteward = Officer(ROLE_STEWARD)
	EndIf
	CurrentCtx = "{\"tab\":\"steward\",\"proposal\":{\"side\":" + aiSide + ",\"mat\":" + aiMat + ",\"dir\":" + aiDir + ",\"amount\":" + aiAmount + "}}"
	Refresh()
EndFunction

Function ScanCandidates()
	Candidates = CSN_Gov.NearbyCandidates()
EndFunction

Actor Function Candidate(Int i)
	If Candidates && i >= 0 && i < Candidates.Length
		Return Candidates[i]
	EndIf
	Return None
EndFunction

Actor Function Commander(Int aiArmy)
	CS_PatrolHoldScript a = Armies()
	If aiArmy >= 0 && aiArmy < a.Commanders.Length
		Return a.Commanders[aiArmy].GetActorRef()
	EndIf
	Return None
EndFunction

Event OnFFUICommand(String asEventName, String asStrArg, Float afNumArg, Form akSender)
	String[] p = PapyrusUtil.StringSplit(asStrArg, "|")
	If p.Length == 0
		Return
	EndIf
	String cmd = p[0]
	Int a1 = ArgInt(p, 1)
	Int a2 = ArgInt(p, 2)
	Int a3 = ArgInt(p, 3)
	Int a4 = ArgInt(p, 4)
	If cmd == "close"
		CurrentScreen = ""
		LastClose = Utility.GetCurrentRealTime()
		Return
	ElseIf cmd == "gameLoaded"
		OnGameLoad()
		Return
	ElseIf cmd == "hotkeyLedger"
		If FactionStarted.GetValue() >= 1
			OpenDashboard("overview")
		Else
			Debug.Notification("Found your faction first: read Start my Faction.")
		EndIf
		Return
	ElseIf cmd == "prefetch"
		; the page asks, while idle, for another tab's data so that tab opens at once
		String pt = ArgStr(p, 1)
		If CurrentScreen == "dashboard" && pt != "" && pt != PayloadTab
			CSN_Native.PushData(CurrentScreen, BuildPayload(pt, True))
		EndIf
		Return
	ElseIf cmd == "openTab"
		CurrentScreen = "dashboard"
		PayloadTab = ArgStr(p, 1)
		CurrentCtx = "{\"tab\":\"" + Esc(PayloadTab) + "\"}"
		RememberTab(PayloadTab)
	ElseIf cmd == "scan"
		ScanCandidates()
	ElseIf cmd == "manageHolding"
		CS_ClaimAreaFunctions h = Holdings()
		Location loc = h.Holdings[a1].GetLocation()
		ObjectReference banner = h.CommanderMarkers[a1].GetRef()
		If loc
			h.ManageHoldingMenu(Holding = loc, SelectedBanner = banner)
		EndIf
	ElseIf cmd == "appoint"
		; appoint|role|candidate
		Appoint(Candidate(a2), a1)
	ElseIf cmd == "dismissOfficer"
		Actor off = Officer(a1)
		If off && CSNP.Confirm("Relieve of duty", "Relieve " + PlainName(off) + " of the office of " + RoleTitle(a1) + "?", "Relieve", "Keep")
			Dismiss(a1)
			CSN_Gov.Say(PlainName(off) + " is no longer " + RoleTitle(a1) + ".")
		EndIf
	ElseIf cmd == "thane"
		; thane|appoint|candidate|hold  ·  thane|remove|index  ·  thane|outfit|hold
		String thWhat = ArgStr(p, 1)
		If thWhat == "appoint"
			CSN_Thanes.Appoint(Candidate(a2), a3)
		ElseIf thWhat == "remove"
			Actor th = CSN_Thanes.At(a2)
			If th
				CSN_Gov.RemoveFromOffice(th, False)
			EndIf
		ElseIf thWhat == "outfit"
			CSN_Thanes.EditOutfit(a2)
			Return
		EndIf
	ElseIf cmd == "hire"
		; hire|candidate
		HireCommander(Candidate(a1))
	ElseIf cmd == "fire"
		Actor c = Commander(a1)
		If c && CSNP.Confirm("Dismiss " + CSN_Gov.RankTitle(c), "Dismiss " + CSN_Gov.RankText(c) + " " + PlainName(c) + " from command of " + CSN_Gov.ArmyLabel(a1) + "?\n\nThey leave your service and any stars they earned are lost.", "Dismiss", "Keep them")
			FireCommander(c)
			CSN_Gov.Say(PlainName(c) + " no longer leads " + CSN_Gov.ArmyLabel(a1) + ".")
		EndIf
	ElseIf cmd == "order"
		OrderVia = NearGeneral
		OrderWithConfirm(Commander(a1), a2, a3, NearGeneral)
		OrderVia = None
	ElseIf cmd == "armyName"
		; armyName|army|name|purpose   (the screen strips | and line breaks; names are cut to 25 letters)
		; "~" stands for an empty field
		String nm = ArgStr(p, 2)
		String pu = ArgStr(p, 3)
		If nm == "~"
			nm = ""
		EndIf
		If pu == "~"
			pu = ""
		EndIf
		CSN_War.SetName(a1, nm, pu)
	ElseIf cmd == "troops"
		Armies().TroopManage.ArmyMenu(a1)
	ElseIf cmd == "outfit"
		; outfit|role  (role -1 = commander of army a2)
		Actor who = Officer(a1)
		If a1 < 0
			who = Commander(a2)
			CSN_Gov.EditOutfit(who)
		ElseIf CSN_Gov.GovOutfitKind(who) > 0
			; officers: their position's outfit, as in the dialogue ("Let me edit what you need to wear")
			CSN_Gov.GovOutfit(who, 0)
		Else
			CSN_Gov.EditOutfit(who)
		EndIf
	ElseIf cmd == "war"
		AskWar(a1)
	ElseIf cmd == "trade"
		; from the dashboard the player already chose the amount: no second dialog
		Trade(a1, a2, a3, a4)
	ElseIf cmd == "culture"
		; culture|field|text   (the screen strips | and line breaks from the text)
		If ArgStr(p, 1) == "style"
			CSN_Culture.SetStyle(a2)
		ElseIf ArgStr(p, 1) == "title"
			CSN_Culture.SetTitle(a2)
		Else
			CSN_Culture.SetText(ArgStr(p, 1), ArgStr(p, 2))
		EndIf
	ElseIf cmd == "cultureSaved"
		CSN_Gov.Say("Saved: the " + FactionName() + "'s culture, leadership style and doctrine.")
	ElseIf cmd == "removeOffice"
		; removeOffice|role (officer) or removeOffice|-1|army
		Actor gone = Officer(a1)
		If a1 < 0
			gone = Commander(a2)
		EndIf
		CSN_Gov.RemoveFromOffice(gone, False)
	ElseIf cmd == "bsOutfit"
		CSN_Gov.TroopOutfit(a1)
	ElseIf cmd == "bsOutfitMenu"
		CSN_Gov.TroopOutfitMenu()
	ElseIf cmd == "bsUpgrade"
		CSN_Gov.TroopUpgradeMenu()
	ElseIf cmd == "bsRace"
		CSN_Gov.SetRaceAllowed(a1, a2 == 1)
	ElseIf cmd == "bsGender"
		CSN_Gov.SetGenderAllowed(a1, a2 == 1)
	ElseIf cmd == "bsApply"
		CSN_Gov.ApplyRaceChanges()
	ElseIf cmd == "star"
		CSN_Gov.AwardStar(Commander(a1), NearGeneral)
	ElseIf cmd == "tradeCancel"
		CancelTrade(a1, a2, a3)
	ElseIf cmd == "deposit"
		CSN_Gov.Deposit(a1, NearSteward)
	ElseIf cmd == "withdraw"
		CSN_Gov.Withdraw(a1, NearSteward)
	ElseIf cmd == "law"
		; law|consc|percent  ·  law|crime|crime|sentence (-1 repeal)  ·  law|deity|god|status (0 outlawed, 1 allowed, 2 mandatory)
		String what = ArgStr(p, 1)
		If what == "consc"
			CSN_Decrees.SetConscription(ArgStr(p, 2) as Int)
		ElseIf what == "crime"
			CSN_Decrees.SetPunishment(ArgStr(p, 2) as Int, ArgStr(p, 3) as Int)
		ElseIf what == "deity"
			CSN_Decrees.SetDeity(ArgStr(p, 2) as Int, ArgStr(p, 3) as Int)
		EndIf
	ElseIf cmd == "townGold"
		; townGold|city|amount (+ from the town into the treasury, - to the town)  ·  townGold|city|all
		If ArgStr(p, 2) == "all"
			CSN_Gov.MoveTownGold(a1, 0, NearSteward, True, True)
		Else
			CSN_Gov.MoveTownGold(a1, ArgStr(p, 2) as Int, NearSteward)
		EndIf
	ElseIf cmd == "cityTrade"
		; cityTrade|city|material|value   (value: + faction sends to the city, - city sends to the faction)
		Int v = ArgStr(p, 3) as Int
		CSN_Gov.SetCityTrade(a1, a2, v, NearSteward)
	ElseIf cmd == "upgrades"
		; our own list (CoS's menu needs the game running, so it only showed once every screen was closed)
		CSN_Gov.UpgradeMenu(a1)
		Return
	ElseIf cmd == "tax"
		; tax|town|level (0-5)
		CSN_Gov.SetTaxLevel(a1, a2, NearSteward)
	ElseIf cmd == "decide"
		; decide|request|choice (0 accept, 1 deny, 2 middle)
		CSN_Requests.Decide(a1, a2)
	ElseIf cmd == "economyMenu"
		Econ().StartMenu()
	ElseIf cmd == "setting"
		ApplySetting(ArgStr(p, 1), a2)
	ElseIf cmd == "winBattle"
		If CSNP.Confirm("Debug", "Win the battle being fought right now?", "Win it", "Cancel")
			CSN_Gov.WinBattle()
		EndIf
	ElseIf cmd == "debugHold"
		; debugHold|hold|owner (1 your faction, 11 Imperials, 12 Stormcloaks)
		CSN_Gov.DebugSetHoldOwner(a1, a2)
		Return
	ElseIf cmd == "debugFort"
		; debugFort|fort|owner (1 your faction, 11 Imperials, 12 Stormcloaks)
		CSN_Gov.DebugSetFortOwner(a1, a2)
		Return
	ElseIf cmd == "reb"
		; reb|appease|town  ·  reb|send|company|army  ·  reb|pay|company  ·  reb|grant|company
		String rbWhat = ArgStr(p, 1)
		If rbWhat == "appease"
			CSN_Rebellion.Appease(a2)
		ElseIf rbWhat == "send"
			CSN_Rebellion.SendArmy(a2, a3)
		ElseIf rbWhat == "quell"
			; reb|quell|town|army
			CSN_Rebellion.QuellUprising(a2, a3)
		ElseIf rbWhat == "pay"
			CSN_Rebellion.PayArrears(a2)
		ElseIf rbWhat == "grant"
			CSN_Rebellion.Recognise(a2)
		EndIf
	ElseIf cmd == "intr"
		; intr|guards|city  ·  intr|people|city  ·  intr|coup|city
		String inWhat = ArgStr(p, 1)
		If inWhat == "guards"
			CSN_Intrigue.Pay(a2, 0)
		ElseIf inWhat == "people"
			CSN_Intrigue.Pay(a2, 1)
		ElseIf inWhat == "coup"
			CloseScreen()
			CSN_Intrigue.PlanCoup(a2)
			Return
		EndIf
	ElseIf cmd == "st"
		; st|found  ·  st|build|k  ·  st|remove|k  ·  st|rename|k  ·  st|abandon|k
		String stWhat = ArgStr(p, 1)
		If stWhat == "found"
			CloseScreen()
			If CSN_Settle.Found()
				OpenDashboard("settle")
			EndIf
			Return
		ElseIf stWhat == "build"
			CloseScreen()
			CSN_Settle.BuildMenu(a2)
			Return
		ElseIf stWhat == "remove"
			CSN_Settle.RemoveMenu(a2)
		ElseIf stWhat == "place"
			; st|place|k|type: one building from the screen's catalogue
			CloseScreen()
			CSN_Settle.Build(a2, a3)
			Return
		ElseIf stWhat == "layout"
			CloseScreen()
			CSN_Settle.BuildLayout(a2, a3)
			Return
		ElseIf stWhat == "move"
			; st|move|k|index, or st|move|k for the list
			CloseScreen()
			If ArgStr(p, 3) == ""
				CSN_Settle.RemoveMenu(a2, True)
			Else
				CSN_Settle.MoveBuilding(a2, a3)
			EndIf
			Return
		ElseIf stWhat == "fix"
			CSN_Settle.FixSettlers(a2)
		ElseIf stWhat == "take"
			CSN_Settle.TakeDown(a2, a3)
		ElseIf stWhat == "grid"
			CSN_Settle.SetGrid(a2)
		ElseIf stWhat == "turn"
			CSN_Settle.SetTurn(a2)
		ElseIf stWhat == "rename"
			CSN_Settle.Rename(a2)
		ElseIf stWhat == "abandon"
			CSN_Settle.Abandon(a2)
		ElseIf stWhat == "navmesh"
			CSN_Settle.UpdateNavmesh()
			Return
		EndIf
	ElseIf cmd == "loseBattle"
		If CSNP.Confirm("Debug", "Lose the battle being fought right now?", "Lose it", "Cancel")
			CSN_Gov.LoseBattle()
		EndIf
	ElseIf cmd == "skipTutorial"
		If CSNP.Confirm("Skip tutorial", "Skip the founding tutorial and go straight to declaring war on the Imperials or Stormcloaks?", "Skip it", "Cancel")
			CSN_Gov.SkipTutorial()
		EndIf
	EndIf
	Refresh()
EndEvent

CS_UpgradeMenuFunctions Function Upgrades()
	Return CSN_Gov.Upg()
EndFunction

; Settings tab: theme and difficulty. Mirrored into the MCM.
Function ApplySetting(String asKey, Int aiValue)
	If asKey == "theme"
		CSN_Config.SetInt("iTheme:Interface", aiValue)
		CSN_Native.ReloadSettings()
	ElseIf asKey == "battleSize"
		; 0 = 8 v 8, 1 = 16 v 16, 2 = 32 v 32
		CSN_Gov.SetBattleSize(CSN_Gov.BattleSizeFromChoice(aiValue))
		CSN_Config.SetInt("iBattleSize:Difficulty", CSN_Gov.BattleSizeChoice())
	ElseIf asKey == "pause"
		CSN_Config.SetBool("bPauseGame:Interface", aiValue == 1)
		CSN_Native.ReloadSettings()
	ElseIf asKey == "battleSpeed"
		CSN_Gov.SetBattleSpeed(aiValue)
		CSN_Config.SetInt("iBattleSpeed:Difficulty", aiValue)
	ElseIf asKey == "enemyRespawn"
		CSN_Gov.SetEnemyRespawn(aiValue)
		CSN_Config.SetInt("iEnemyRespawn:Difficulty", aiValue)
	ElseIf asKey == "enemyRecovery"
		CSN_Gov.SetEnemyRecovery(aiValue)
		CSN_Config.SetInt("iEnemyRecovery:Difficulty", aiValue)
	EndIf
EndFunction

Int Function ArgInt(String[] p, Int i)
	If i < p.Length
		Return p[i] as Int
	EndIf
	Return -1
EndFunction

String Function ArgStr(String[] p, Int i)
	If i < p.Length
		Return p[i]
	EndIf
	Return ""
EndFunction

; ---- JSON -------------------------------------------------------------------
String Function Esc(String s)
	If StringUtil.Find(s, "\"") < 0 && StringUtil.Find(s, "\\") < 0
		Return s
	EndIf
	String out = ""
	Int n = StringUtil.GetLength(s)
	Int i = 0
	While i < n
		String ch = StringUtil.GetNthChar(s, i)
		If ch == "\""
			out += "\\\""
		ElseIf ch == "\\"
			out += "\\\\"
		Else
			out += ch
		EndIf
		i += 1
	EndWhile
	Return out
EndFunction

String Function Q(String s)
	Return "\"" + Esc(s) + "\""
EndFunction

; JSON 1 or 0. Not true/false: Papyrus keeps one spelling per string regardless of case, so once "False" exists
; anywhere in the game a literal "false" comes out as "False", which is not JSON (SkyrimNet rejected the context).
String Function B(Bool b)
	If b
		Return "1"
	EndIf
	Return "0"
EndFunction

String Function NameOf(Actor a)
	If a
		Return PlainName(a)
	EndIf
	Return ""
EndFunction

; asTab: build for that tab instead of the screen's own (prefetching another tab, or the quick "lite" header).
; A prefetch leaves out the screen's context so the page doesn't act on it twice.
String Function BuildPayload(String asTab = "", Bool abPrefetch = False)
	String bt = asTab
	If bt == ""
		bt = PayloadTab
	EndIf
	CS_ClaimAreaFunctions h = Holdings()
	CS_EconomyVariableFunctions ev = Gov.EconUpdater
	CS_PatrolHoldScript a = Armies()
	String s = "{\"founded\":" + B(FactionStarted.GetValue() >= 1) + ",\"version\":" + Q(CSN_Config.Version())
	s += ",\"name\":" + Q(FactionName()) + ",\"leader\":" + Q(PlayerRef.GetDisplayName())
	s += ",\"theme\":" + CSN_Config.Theme()
	s += ",\"gold\":" + CSN_Gov.Treasury() + ",\"goldDay\":" + h.TreasuryPerDay.GetValueInt()
	s += ",\"purse\":" + PlayerRef.GetItemCount(Econ().Gold001)
	s += ",\"food\":" + h.FoodReserve.GetValueInt() + ",\"foodDay\":" + h.FoodPerDay.GetValueInt()
	s += ",\"metal\":" + ev.MetalTotalPlayer.GetValueInt() + ",\"metalDay\":" + ev.MetalTotalPlayerPerDay.GetValueInt()
	s += ",\"wood\":" + ev.WoodTotalPlayer.GetValueInt() + ",\"woodDay\":" + ev.WoodTotalPlayerPerDay.GetValueInt()
	s += ",\"tradePrice\":" + CSN_Config.TradePrice()
	s += ",\"war\":[" + B(AtWar(1)) + "," + B(AtWar(2)) + "]"
	s += ",\"nearSteward\":" + Q(NameOf(NearSteward)) + ",\"nearGeneral\":" + Q(NameOf(NearGeneral)) + ",\"nearBlacksmith\":" + Q(NameOf(NearBlacksmith))
	s += ",\"culture\":{\"text\":" + Q(CSN_Culture.CultureText()) + ",\"doctrine\":" + Q(CSN_Culture.DoctrineText()) + ",\"style\":" + CSN_Culture.Style() + ",\"other\":" + Q(CSN_Culture.OtherText()) + ",\"title\":" + CSN_Culture.TitleChoice() + ",\"titleother\":" + Q(CSN_Culture.TitleOther()) + "}"
	If NearBlacksmith && Want("smith", bt)
		s += ",\"smith\":{\"races\":[" + BlacksmithRaces() + "],\"genders\":[" + B(CSN_Gov.GenderAllowed(0)) + "," + B(CSN_Gov.GenderAllowed(1)) + "]"
		s += ",\"pending\":" + B(CSN_Gov.RaceChangesPending()) + ",\"mages\":" + B(CSN_Gov.MagesResearched())
		s += ",\"gendered\":[" + B(CSN_Gov.OutfitGendered(0)) + "," + B(CSN_Gov.OutfitGendered(1)) + "," + B(CSN_Gov.OutfitGendered(2)) + "," + B(CSN_Gov.OutfitGendered(3)) + "," + B(CSN_Gov.OutfitGendered(4)) + "]}"
	EndIf

	; trade[side-1][mat] = units per day (+ import, - export)
	s += ",\"trade\":["
	Int side = 1
	While side <= 2
		If side > 1
			s += ","
		EndIf
		s += "["
		Int m = 0
		While m < 3
			If m > 0
				s += ","
			EndIf
			s += (TradeGlobal(side, m, True).GetValueInt() - TradeGlobal(side, m, False).GetValueInt())
			m += 1
		EndWhile
		s += "]"
		side += 1
	EndWhile
	s += "]"

	s += ",\"officers\":["
	Int i = 0
	While i < 4
		If i > 0
			s += ","
		EndIf
		s += "{\"role\":" + Q(RoleTitle(i)) + ",\"name\":" + Q(NameOf(Officer(i))) + "}"
		i += 1
	EndWhile
	s += "]"

	; the Tamrielic date now, so the screen can date requests (GameYear, GameMonth, GameDay)
	s += ",\"now\":" + Utility.GetCurrentGameTime() + ",\"date\":[" + (Game.GetFormFromFile(0x35, "Skyrim.esm") as GlobalVariable).GetValueInt() + "," + (Game.GetFormFromFile(0x36, "Skyrim.esm") as GlobalVariable).GetValueInt() + "," + (Game.GetFormFromFile(0x37, "Skyrim.esm") as GlobalVariable).GetValueInt() + "]"
	s += ",\"pending\":" + CSN_Requests.PendingCount() + ",\"tab\":" + Q(bt)
	s += ",\"upkeep\":" + CSN_Config.TroopUpkeep() + ",\"claimguards\":" + ClaimGuards()
	If bt != "lite" && Want("laws", bt)
		s += ",\"laws\":" + CSN_Decrees.Json()
	EndIf
	If bt == "lite"
		Return s + ",\"ctx\":" + CurrentCtx + ",\"loading\":true}"
	EndIf
	s += ",\"candidates\":["
	i = 0
	While Candidates && i < Candidates.Length
		If i > 0
			s += ","
		EndIf
		Actor c = Candidates[i]
		s += "{\"i\":" + i + ",\"name\":" + Q(NameOf(c)) + ",\"role\":" + GetRole(c) + ",\"army\":" + GetArmy(c) + "}"
		i += 1
	EndWhile
	s += "],\"freeSlot\":" + FreeArmySlot()

	Bool first = True
	If Want("claims", bt)
	Location baseLoc = h.CapitalBase.GetLocation()
	s += ",\"claims\":["
	i = 0
	While i < h.Holdings.Length
		Location loc = h.Holdings[i].GetLocation()
		If loc
			If !first
				s += ","
			EndIf
			first = False
			s += "{\"i\":" + i + ",\"name\":" + Q(loc.GetName())
			s += ",\"guards\":" + (loc.GetKeywordData(PlayerDefended) as Int)
			s += ",\"mine\":" + B(loc.HasKeyword(MineLocType)) + ",\"miners\":" + (loc.GetKeywordData(MineLocType) as Int)
			Keyword farmKw = Game.GetFormFromFile(0xD3D894, "ConquestOfSkyrimNet.esp") as Keyword
			If farmKw && loc.HasKeyword(farmKw)
				s += ",\"farm\":1,\"farmhands\":" + (loc.GetKeywordData(farmKw) as Int)
			EndIf
			s += ",\"base\":" + B(baseLoc && h.ConvertCSToLoc(loc) == baseLoc) + "}"
		EndIf
		i += 1
	EndWhile
	s += "]"
	EndIf

	s += ",\"armies\":["
	first = True
	i = 0
	While i < a.Commanders.Length
		Actor c = a.Commanders[i].GetActorRef()
		If c
			If !first
				s += ","
			EndIf
			first = False
			CS_ArmyTroopDeath t = a.ArmyScripts[i]
			s += "{\"i\":" + i + ",\"name\":" + Q(NameOf(c)) + ",\"troops\":" + ArmyTroops(i)
			s += ",\"task\":" + Q(ArmyTask(i)) + ",\"dead\":" + B(c.IsDead())
			s += ",\"aname\":" + Q(CSN_War.Name(i)) + ",\"motto\":" + Q(CSN_War.Purpose(i))
			s += ",\"stars\":" + CSN_Gov.Stars(c) + ",\"rank\":" + Q(CSN_Gov.RankTitle(c)) + ",\"post\":" + Q(CSN_Gov.PostText(i))
			If t
				s += ",\"mix\":[" + t.CountSoldier + "," + t.CountWarrior + "," + t.CountArcher + "," + t.CountCrossbow + "]"
			EndIf
			s += "}"
		EndIf
		i += 1
	EndWhile
	s += "]"

	CS_AttackPlanningNewScript plan = CSN_Gov.Planning()
	If plan && Want("war", bt)
		s += ",\"siege\":[" + plan.BatteringRamsPurchased.GetValueInt() + "," + plan.LaddersPurchased.GetValueInt() + "," + plan.CatapultsPurchased.GetValueInt() + "]"
	EndIf

	If Want("war", bt) || Want("smith", bt)
		s += ",\"recruitToday\":" + CSN_Troops.RecruitableToday() + ",\"recruitLimit\":" + CSN_Troops.DailyLimit() + ",\"templates\":["
		i = 1
		While i <= 5
			If i > 1
				s += ","
			EndIf
			s += Q(CSN_Troops.TemplateText(i))
			i += 1
		EndWhile
		s += "]"
	EndIf
	If Want("war", bt)
	s += ",\"holds\":["
	i = 0
	While i < HoldCount()
		If i > 0
			s += ","
		EndIf
		s += "{\"i\":" + i + ",\"name\":" + Q(HoldName(i)) + ",\"camp\":" + B(CSN_Gov.CanCamp(i)) + ",\"attack\":" + B(CSN_Gov.IsAttackCamp(i)) + "}"
		i += 1
	EndWhile
	s += "],\"forts\":["
	i = 0
	While i < FortCount()
		If i > 0
			s += ","
		EndIf
		s += "{\"i\":" + i + ",\"name\":" + Q(FortName(i)) + ",\"owned\":" + B(OwnsFort(i)) + "}"
		i += 1
	EndWhile
	s += "]"
	EndIf
	If Want("cities", bt)
	s += ",\"cities\":["
	i = 0
	While i < 15
		If i > 0
			s += ","
		EndIf
		s += "{\"i\":" + i + ",\"name\":" + Q(CSN_World.TownName(i)) + ",\"ours\":" + B(CSN_World.PlayerRules(i)) + ",\"city\":" + B(i < 9)
		s += ",\"owner\":" + Q(OwnerShort(CSN_World.TownOwner(i))) + ",\"loyalty\":" + CSN_World.TownLoyalty(i)
		s += ",\"lv\":[" + CSN_Gov.BuildingLevel(i, 0) + "," + CSN_Gov.BuildingLevel(i, 1) + "," + CSN_Gov.BuildingLevel(i, 2) + "," + CSN_Gov.BuildingLevel(i, 3) + "]"
		s += ",\"tax\":" + CSN_Gov.TaxLevel(i)
		s += ",\"tr\":[" + CSN_Gov.CityTrade(i, 0) + "," + CSN_Gov.CityTrade(i, 1) + "," + CSN_Gov.CityTrade(i, 2) + "]"
		s += ",\"eco\":" + CSN_Gov.TownEconomyJson(i) + "}"
		i += 1
	EndWhile
	s += "]"
	EndIf

	If Want("settings", bt)
	s += ",\"settings\":{\"battleSize\":" + CSN_Gov.BattleSizeChoice() + ",\"pause\":" + B(CSN_Config.PauseGame()) + ",\"battleSpeed\":" + CSN_Gov.BattleSpeed()
	s += ",\"enemyRespawn\":" + CSN_Gov.EnemyRespawn() + ",\"enemyRecovery\":" + CSN_Gov.EnemyRecovery()
	s += ",\"tutorialDone\":" + B(CSN_Gov.TutorialDone()) + ",\"battle\":" + B(CSN_Gov.BattleRunning())
	s += ",\"logPath\":" + Q(CSN_Config.LogPath()) + ",\"debugLog\":" + B(CSN_Config.DebugLog()) + ",\"starCost\":" + CSN_Gov.StarCost()
	s += ",\"forts\":["
	Int f = 0
	While f < FortCount()
		If f > 0
			s += ","
		EndIf
		s += "{\"name\":" + Q(FortName(f)) + ",\"owner\":" + CSN_Gov.FortOwner(f) + "}"
		f += 1
	EndWhile
	s += "],\"holdowners\":["
	f = 0
	While f < 9
		If f > 0
			s += ","
		EndIf
		s += "{\"name\":" + Q(HoldName(f)) + ",\"city\":" + Q(CSN_World.TownName(f)) + ",\"owner\":" + CSN_World.TownOwner(f) + ",\"roads\":" + CSN_Gov.RoadsSide(f) + "}"
		f += 1
	EndWhile
	s += "]}"
	EndIf
	If Want("requests", bt)
		s += ",\"requests\":" + CSN_Requests.Json(Self)
	EndIf
	If Want("realm", bt)
		s += ",\"realm\":" + CSN_Rebellion.Json() + ",\"intrigue\":" + CSN_Intrigue.Json()
	EndIf
	If Want("settle", bt)
		s += ",\"settle\":" + CSN_Settle.Json()
	EndIf
	s += ",\"letters\":" + B(CSN_Letters.Installed())
	s += ",\"thanes\":" + CSN_Thanes.Json()
	If abPrefetch
		Return s + ",\"prefetch\":" + Q(bt) + "}"
	EndIf
	s += ",\"ctx\":" + CurrentCtx + "}"
	Return s
EndFunction

; Which parts of the payload the current tab needs (building all of it takes Papyrus a few seconds).
Bool Function Want(String asPart, String asTab = "")
	String t = asTab
	If t == ""
		t = PayloadTab
	EndIf
	If asPart == "cities"
		Return t == "overview" || t == "holdings" || t == "steward" || t == "general" || t == "armies"
	ElseIf asPart == "claims"
		Return t == "overview" || t == "holdings"
	ElseIf asPart == "war"
		Return t == "general" || t == "armies"
	ElseIf asPart == "settings"
		Return t == "settings"
	ElseIf asPart == "requests"
		Return t == "requests" || t == "overview"
	ElseIf asPart == "smith"
		Return t == "blacksmith"
	ElseIf asPart == "realm"
		Return t == "realm" || t == "overview"
	ElseIf asPart == "laws"
		Return t == "armies" || t == "general"
	ElseIf asPart == "settle"
		Return t == "settle" || t == "overview"
	EndIf
	Return True
EndFunction

String Function BlacksmithRaces()
	String s = ""
	Int i = 0
	While i < 10
		If i > 0
			s += ","
		EndIf
		s += B(CSN_Gov.RaceAllowed(i))
		i += 1
	EndWhile
	Return s
EndFunction

; Result line on the faction screen (no-op when it isn't open).
Function UIToast(String asText, Bool abError)
	If CurrentScreen != "" && CSN_Native.IsAvailable()
		CSN_Native.UIMessage(asText, abError)
	EndIf
EndFunction

Function WatchOutfit(Actor akActor, Bool abGovernment = False)
	PendingOutfit = akActor
	PendingGovOutfit = abGovernment
	RegisterForMenu("ContainerMenu")
EndFunction

Function WatchThaneOutfit(Int aiHold)
	PendingThaneHold = aiHold
	RegisterForMenu("ContainerMenu")
EndFunction

Event OnMenuClose(String asMenuName)
	If asMenuName == "ContainerMenu" && PendingThaneHold >= 0
		Int th = PendingThaneHold
		PendingThaneHold = -1
		If !PendingOutfit
			UnregisterForMenu("ContainerMenu")
		EndIf
		Utility.Wait(0.2)
		CSN_Thanes.OutfitClosed(th)
		Return
	EndIf
	If asMenuName == "ContainerMenu" && PendingOutfit
		Actor a = PendingOutfit
		PendingOutfit = None
		UnregisterForMenu("ContainerMenu")
		Utility.Wait(0.2)
		If PendingGovOutfit
			PendingGovOutfit = False
			; what the dialogue's end fragment does after "Let me edit what you need to wear"
			Gov.UpdateGovOutfit(a)
		Else
			CSN_Gov.ApplyOutfitTemplate(a)
		EndIf
	EndIf
EndEvent

Function SetOrderVia(Actor akGeneral)
	OrderVia = akGeneral
EndFunction

String Function OwnerShort(Int aiOwner)
	If aiOwner == 11
		Return "Imperial Legion"
	ElseIf aiOwner == 12
		Return "Stormcloaks"
	ElseIf FactionStarted.GetValue() >= 1 && aiOwner == Gov.TMPlayer.FactionNum
		Return FactionName()
	EndIf
	Return "None"
EndFunction
