Scriptname CSN_Intrigue Hidden
{Conquest of SkyrimNet - turning a city against its jarl.

 For each of the nine hold cities ruled by the Imperials or the Stormcloaks CSN keeps two measures (0-100):
   * GUARDS - how ready the city guard is to betray its jarl. Raised by bribing guards (gold) and by persuading
     them in conversation (Speech).
   * PEOPLE - how much the nobles and citizens back the player. Raised by funding them (gold; court members and
     merchants count double) and by persuading them.
 Every bribe carries a risk of being exposed (higher where the city is loyal to its rulers, lower with good Speech).

 When the player PLANS A COUP, CSN writes the measures into the values CoS's own coup quest (CS_Coup, already
 complete in 0.3.9 but only reachable through its unused spy network menu) reads, and starts it with CoS's story
 event (CS_StoryCoup). CoS then runs the coup in the jarl's hall: crowds with torches gather (more with PEOPLE),
 the player confronts the jarl, and the guards decide:
   * GUARDS 80+ and PEOPLE 40+  -> the guards arrest the jarl (a clean coup)
   * GUARDS 40+ and PEOPLE 60+  -> the guards argue, then side with the player
   * otherwise                  -> the guards side with the jarl: a fight with the citizens at the player's side
                                   (a hostile takeover), or the player is arrested if it is lost.
 Winning gives the city to the player's faction (CoS's own transfer).}

CSN_Core Function M() Global
	Return CSN_Gov.M()
EndFunction

Form Function F(Int aiId) Global
	Return Game.GetFormFromFile(aiId, "ConquestOfSkyrimNet.esp")
EndFunction

Quest Function CoupQuest() Global
	Return F(0xa4fdf2) as Quest
EndFunction

Keyword Function KW(Int aiId) Global
	Return F(aiId) as Keyword
EndFunction

Int Function Today() Global
	Return Utility.GetCurrentGameTime() as Int
EndFunction

Bool Function Enabled() Global
	Return CSN_Config.GetBool("bIntrigue:Rebellion", True)
EndFunction

; a city that can be turned: one of the nine hold cities, ruled by the Imperials or Stormcloaks, with a jarl
Bool Function Target(Int i) Global
	If i < 0 || i > 8
		Return False
	EndIf
	Int o = CSN_World.TownOwner(i)
	Return (o == 11 || o == 12) && CSN_World.TownJarl(i) != None
EndFunction

String Function K(Int i, String asKey) Global
	Return "csn_intr_" + i + "_" + asKey
EndFunction

Int Function Clamp(Int v) Global
	If v < 0
		Return 0
	ElseIf v > 100
		Return 100
	EndIf
	Return v
EndFunction

; starting points: a city that loves its rulers has loyal guards; goodwill toward the faction is the people's start
Int Function Guards(Int i) Global
	Return StorageUtil.GetIntValue(None, K(i, "guards"), Clamp(40 - CSN_World.TownLoyalty(i) / 2))
EndFunction

Int Function People(Int i) Global
	Int like = CSN_World.PlayerFactionLiking(i)
	If like < 0
		like = 50
	EndIf
	Return StorageUtil.GetIntValue(None, K(i, "people"), Clamp(like / 2))
EndFunction

Function AddGuards(Int i, Int n) Global
	StorageUtil.SetIntValue(None, K(i, "guards"), Clamp(Guards(i) + n))
EndFunction

Function AddPeople(Int i, Int n) Global
	StorageUtil.SetIntValue(None, K(i, "people"), Clamp(People(i) + n))
EndFunction

; what the guards will do if the coup were tonight: 0 arrest the jarl, 1 side with you after arguing, 2 side with the jarl
Int Function Outlook(Int i) Global
	If Guards(i) >= 80 && People(i) >= 40
		Return 0
	ElseIf Guards(i) >= 40 && People(i) >= 60
		Return 1
	EndIf
	Return 2
EndFunction

String Function OutlookText(Int i) Global
	Int o = Outlook(i)
	If o == 0
		Return "the guards would arrest the jarl"
	ElseIf o == 1
		Return "the guards would argue, then side with you"
	EndIf
	Return "the guards would stand by the jarl; you would have to fight them with the citizens at your side"
EndFunction

; how many citizens with torches would gather (CoS counts them from the same values)
Int Function Crowd(Int i) Global
	Int p = People(i)
	Int g = Guards(i)
	Int n = 0
	If p >= 40
		n += 1
	EndIf
	If p >= 60
		n += 1
	EndIf
	If p >= 80
		n += 1
	EndIf
	If g >= 40
		n += 1
	EndIf
	If g >= 60
		n += 1
	EndIf
	If g >= 80
		n += 1
	EndIf
	If p >= 10
		n += 1
	EndIf
	If p >= 50
		n += 1
	EndIf
	If p >= 100
		n += 1
	EndIf
	Return n
EndFunction

; gold per point
Int Function GuardPrice(Int i) Global
	Int base = 300
	If i < 5
		base = 500
	EndIf
	Int price = base + base * CSN_World.TownLoyalty(i) / 100
	If Guards(i) >= 60
		price = price * 3 / 2
	EndIf
	Return price
EndFunction

Int Function PeoplePrice(Int i, Bool abNoble) Global
	Int base = 200
	If i < 5
		base = 350
	EndIf
	Int price = base + base * CSN_World.TownLoyalty(i) / 100
	If People(i) >= 60
		price = price * 3 / 2
	EndIf
	If abNoble
		price = price / 2
	EndIf
	Return price
EndFunction

Int Function ExposeChance(Int i) Global
	Int speech = Game.GetPlayer().GetActorValue("Speechcraft") as Int
	Int c = 5 + CSN_World.TownLoyalty(i) / 5 - speech / 10
	If c < 2
		c = 2
	EndIf
	Return c
EndFunction

Bool Function IsNoble(Actor a) Global
	If !a
		Return False
	EndIf
	If CSN_Gov.IsMerchant(a)
		Return True
	EndIf
	; the jarl's court (steward, court wizard, housecarl) counts as nobility
	Int[] ids = new Int[3]
	ids[0] = 0x00050922
	ids[1] = 0x0005091E
	ids[2] = 0x0005091F
	Int k = 0
	While k < ids.Length
		Faction f = Game.GetFormFromFile(ids[k], "Skyrim.esm") as Faction
		If f && a.IsInFaction(f)
			Return True
		EndIf
		k += 1
	EndWhile
	Return False
EndFunction

; ---- bribing and funding ---------------------------------------------------------------
; aiWho: 0 guards, 1 nobles and citizens. akVia: the person in conversation (None from the screen).
; abTreasury: the Steward's agents pay from the faction's treasury instead of the player's purse
Bool Function Pay(Int i, Int aiWho, Actor akVia = None, Bool abTreasury = False) Global
	CSN_Core m = M()
	If !Enabled()
		CSN_Gov.Fail("Intrigue is turned off in the MCM.")
		Return False
	EndIf
	If !Target(i)
		CSN_Gov.Fail("Only a hold city ruled by the Imperials or the Stormcloaks, with a jarl, can be turned.")
		Return False
	EndIf
	If CoupPending() >= 0
		CSN_Gov.Fail("A coup is already under way.")
		Return False
	EndIf
	String town = CSN_World.TownName(i)
	Bool noble = aiWho == 1 && IsNoble(akVia)
	Int price = GuardPrice(i)
	String whom = "the guards of " + town
	Int now = Guards(i)
	If aiWho == 1
		price = PeoplePrice(i, noble)
		whom = "the nobles and citizens of " + town
		now = People(i)
		If noble
			whom = m.PlainName(akVia) + " and their friends among the nobles of " + town
		EndIf
	ElseIf akVia && !abTreasury
		whom = m.PlainName(akVia) + " and the guards they trust"
	EndIf
	If abTreasury
		noble = False
		If aiWho == 1
			price = PeoplePrice(i, False)
			whom = "the nobles and citizens of " + town
		EndIf
	EndIf
	Int purse = Game.GetPlayer().GetItemCount(m.Econ().Gold001)
	String from = "your own purse"
	If abTreasury
		purse = CSN_Gov.Treasury()
		from = "the treasury, through " + m.PlainName(akVia) + "'s agents"
	EndIf
	Int most = (100 - now) * price
	If most > purse
		most = purse
	EndIf
	If most < price
		CSN_Gov.Fail("One point of support in " + town + " costs " + price + " gold; " + from + " holds " + purse + ".")
		Return False
	EndIf
	String what = "Guards ready to betray the jarl"
	If aiWho == 1
		what = "Nobles and citizens behind you"
	EndIf
	Int start = price * 5
	If start > most
		start = most
	EndIf
	Int g = CSNP.AskAmount("Gold for " + whom, what + ": " + now + "/100. Every " + price + " gold you hand over adds a point. Each payment has a " + ExposeChance(i) + "% risk of being reported to the jarl. You pay from " + from + " (" + purse + " gold).", start, price, most, 1, "{n} gold", "Hand it over", "Keep it")
	If g < price
		Return False
	EndIf
	If abTreasury
		m.Econ().Treasury.Mod(-g)
	Else
		Game.GetPlayer().RemoveItem(m.Econ().Gold001, g, True)
	EndIf
	Int pts = g / price
	StorageUtil.AdjustIntValue(None, K(i, "spent"), g)
	If Utility.RandomInt(1, 100) <= ExposeChance(i)
		pts = pts / 2
		AddGuards(i, -10)
		AddPeople(i, -5)
		StorageUtil.AdjustIntValue(None, "csn_goodwill_" + i, -5)
		String txt = "Word reached the jarl of " + town + " that agents of the " + m.FactionName() + " were handing out gold."
		CSN_World.AddNews(i, txt, "csn_bribe_exposed", akVia)
		CSN_Gov.Say("Your bribe was reported. Half of it bought nothing, and the jarl is on guard.")
	EndIf
	If aiWho == 0
		AddGuards(i, pts)
	Else
		AddPeople(i, pts)
	EndIf
	String note = Game.GetPlayer().GetDisplayName() + " secretly paid " + g + " gold to " + whom + " to turn them against their jarl."
	If akVia
		CSN_SkyrimNet.LogEvent(note, akVia, Game.GetPlayer())
		If !abTreasury
			StorageUtil.SetIntValue(akVia, "csn_bribed", 1)
		EndIf
	EndIf
	CSN_Gov.Say(town + ": guards " + Guards(i) + "/100, people " + People(i) + "/100. If the coup were tonight, " + OutlookText(i) + ".")
	m.Refresh()
	Return True
EndFunction

; ---- persuasion: free, once a day per person, Speech against the city's loyalty -----------
Bool Function Persuade(Actor akWho) Global
	CSN_Core m = M()
	Int i = CSN_World.TownOf(akWho)
	If !Target(i)
		CSN_Gov.Fail("This person's city can't be turned.")
		Return False
	EndIf
	If StorageUtil.GetIntValue(akWho, "csn_persuaded_day", -1) == Today()
		CSN_Gov.Fail(m.PlainName(akWho) + " has heard enough for today.")
		Return False
	EndIf
	StorageUtil.SetIntValue(akWho, "csn_persuaded_day", Today())
	Int speech = Game.GetPlayer().GetActorValue("Speechcraft") as Int
	Int chance = speech * 6 / 10 + akWho.GetRelationshipRank(Game.GetPlayer()) * 10 + 10 - CSN_World.TownLoyalty(i) / 4
	If chance < 5
		chance = 5
	ElseIf chance > 90
		chance = 90
	EndIf
	Bool guard = akWho.IsGuard()
	String town = CSN_World.TownName(i)
	If Utility.RandomInt(1, 100) <= chance
		If guard
			AddGuards(i, 4)
		Else
			Int n = 3
			If IsNoble(akWho)
				n = 6
			EndIf
			AddPeople(i, n)
		EndIf
		CSN_Gov.Say(m.PlainName(akWho) + " is won over. " + town + ": guards " + Guards(i) + "/100, people " + People(i) + "/100.")
		CSN_SkyrimNet.LogEvent(Game.GetPlayer().GetDisplayName() + " persuaded " + m.PlainName(akWho) + " to turn against the jarl of " + town + ".", akWho, Game.GetPlayer())
		Return True
	EndIf
	If guard && Utility.RandomInt(1, 100) <= 30
		AddGuards(i, -3)
		CSN_World.AddNews(i, "A guard of " + town + " reported talk of betraying the jarl.", "csn_bribe_exposed", akWho)
	EndIf
	CSN_Gov.Fail(m.PlainName(akWho) + " is not convinced (" + chance + "% chance).")
	Return False
EndFunction

; ---- the coup ----------------------------------------------------------------------------
Int Function CoupPending() Global
	Return StorageUtil.GetIntValue(None, "csn_intr_coup", 0) - 1
EndFunction

Bool Function CanCoup(Int i) Global
	Return Target(i) && (Guards(i) >= 40 || People(i) >= 40) && CoupPending() < 0 && Today() >= StorageUtil.GetIntValue(None, K(i, "next"), 0)
EndFunction

String Function CoupBlock(Int i) Global
	If !Target(i)
		Return "This city can't be turned."
	ElseIf CoupPending() >= 0
		Return "A coup is already under way in " + CSN_World.TownName(CoupPending()) + "."
	ElseIf Today() < StorageUtil.GetIntValue(None, K(i, "next"), 0)
		Return "After the last attempt the jarl is watchful; wait " + (StorageUtil.GetIntValue(None, K(i, "next"), 0) - Today()) + " more day(s)."
	ElseIf Guards(i) < 40 && People(i) < 40
		Return "Nobody in " + CSN_World.TownName(i) + " would stand with you yet: you need the guards or the people at 40 or more."
	EndIf
	Return ""
EndFunction

Bool Function PlanCoup(Int i, Actor akVia = None) Global
	CSN_Core m = M()
	String err = CoupBlock(i)
	If err != ""
		CSN_Gov.Fail(err)
		Return False
	EndIf
	Quest q = CoupQuest()
	If !q || q.IsRunning()
		CSN_Gov.Fail("Conquest of Skyrim's coup is busy elsewhere.")
		Return False
	EndIf
	String town = CSN_World.TownName(i)
	Actor jarl = CSN_World.TownJarl(i)
	Int owner = CSN_World.TownOwner(i)
	String side = "the Imperials"
	Int s = 1
	If owner == 12
		side = "the Stormcloaks"
		s = 2
	EndIf
	String warn = ""
	If !m.AtWar(s)
		warn = "\n\nYou are at peace with " + side + "; taking one of their cities this way will not go unnoticed."
	EndIf
	If !CSNP.Confirm("Plan a coup in " + town, "Overthrow Jarl " + m.PlainName(jarl) + " of " + town + "?\n\nGuards ready to betray: " + Guards(i) + "/100. Nobles and citizens behind you: " + People(i) + "/100 (about " + Crowd(i) + " citizens with torches).\nIf it happens now, " + OutlookText(i) + ".\n\nGo to the jarl's hall: the crowd gathers and you confront the jarl. Win, and " + town + " is yours. Lose, and you are arrested." + warn, "Plan the coup", "Not yet")
		Return False
	EndIf
	Location cs = CSN_World.TownLocation(i)
	Keyword kPlayer = KW(0x2aabd7)    ; CS_Loyalty (CoS reads it as the people's loyalty to the player here)
	Keyword kJarl = KW(0xa2c69a)      ; CS_LoyaltyJarl
	Keyword kSpy = KW(0xa2c6a4)       ; CS_SpyNetworkProgress
	StorageUtil.SetFloatValue(None, "csn_intr_old_loy", cs.GetKeywordData(kPlayer))
	StorageUtil.SetFloatValue(None, "csn_intr_old_jarl", cs.GetKeywordData(kJarl))
	StorageUtil.SetFloatValue(None, "csn_intr_old_spy", cs.GetKeywordData(kSpy))
	cs.SetKeywordData(kPlayer, People(i))
	cs.SetKeywordData(kJarl, 100 - Guards(i))
	cs.SetKeywordData(kSpy, People(i))
	StorageUtil.SetIntValue(None, "csn_intr_coup", i + 1)
	StorageUtil.SetIntValue(None, "csn_intr_owner", owner)
	KW(0xab5395).SendStoryEvent(CSN_World.TownVanillaLocation(i))   ; CS_StoryCoup -> CS_Coup
	; the story manager can take a moment
	Int tries = 0
	While !q.IsRunning() && tries < 12
		Utility.Wait(0.25)
		tries += 1
	EndWhile
	If !q.IsRunning()
		CSN_Config.Log("coup: CS_Coup did not start for " + town + " (jarl " + m.PlainName(jarl) + ")")
		RestoreValues(i)
		StorageUtil.SetIntValue(None, "csn_intr_coup", 0)
		CSN_Gov.Fail("The coup could not be set in motion (Conquest of Skyrim's coup quest did not start).")
		Return False
	EndIf
	CSN_Config.Log("coup: CS_Coup started for " + town + ", stage " + q.GetStage())
	CSNP.Notice("The coup in " + town + " is set in motion. Go to Jarl " + m.PlainName(jarl) + ": the crowd is gathering. If it happens now, " + OutlookText(i) + ".")
	If akVia
		CSN_SkyrimNet.LogEvent(Game.GetPlayer().GetDisplayName() + " and " + m.PlainName(akVia) + " set a coup against Jarl " + m.PlainName(jarl) + " of " + town + " in motion.", akVia, Game.GetPlayer())
	EndIf
	m.Refresh()
	Return True
EndFunction

Function RestoreValues(Int i) Global
	Location cs = CSN_World.TownLocation(i)
	cs.SetKeywordData(KW(0x2aabd7), StorageUtil.GetFloatValue(None, "csn_intr_old_loy", 50.0))
	cs.SetKeywordData(KW(0xa2c69a), StorageUtil.GetFloatValue(None, "csn_intr_old_jarl", 50.0))
	cs.SetKeywordData(KW(0xa2c6a4), StorageUtil.GetFloatValue(None, "csn_intr_old_spy", 0.0))
EndFunction

; once a minute (CSN_Core): has the coup ended?
Function Tick() Global
	Int i = CoupPending()
	If i < 0
		Return
	EndIf
	Quest q = CoupQuest()
	If q && q.IsRunning() && q.GetStage() < 100
		; a coup stuck while the guards choose (saves from before the fix): wake its watch now and then
		Int st = q.GetStage()
		If st >= 31 && st <= 34 && Utility.GetCurrentRealTime() - StorageUtil.GetFloatValue(None, "csn_coup_kick", -999.0) > 70.0
			StorageUtil.SetFloatValue(None, "csn_coup_kick", Utility.GetCurrentRealTime())
			q.RegisterForSingleUpdate(2)
		EndIf
		Return
	EndIf
	If q && q.IsRunning()
		Return   ; CoS is finishing up (stages 100-110)
	EndIf
	CSN_Core m = M()
	String town = CSN_World.TownName(i)
	StorageUtil.SetIntValue(None, "csn_intr_coup", 0)
	If CSN_World.PlayerRules(i)
		String txt = "A coup in " + town + " overthrew the jarl. The city now belongs to the " + m.FactionName() + "."
		CSN_World.AddNews(i, txt, "csn_coup_won")
		CSN_World.AddNews(-1, txt, "csn_coup_won")
		StorageUtil.UnsetIntValue(None, K(i, "guards"))
		StorageUtil.UnsetIntValue(None, K(i, "people"))
		; the people who backed it start out fond of their new rulers
		Location cs = CSN_World.TownLocation(i)
		Int want = 40 + People(i) / 2
		If cs.GetKeywordData(KW(0x2aabd7)) < want
			cs.SetKeywordData(KW(0x2aabd7), want)
		EndIf
	Else
		RestoreValues(i)
		StorageUtil.SetIntValue(None, K(i, "guards"), Guards(i) / 2)
		StorageUtil.SetIntValue(None, K(i, "people"), People(i) / 2)
		StorageUtil.SetIntValue(None, K(i, "next"), Today() + 7)
		CSN_World.AddNews(i, "A coup against the jarl of " + town + " failed. The plotters are in hiding.", "csn_coup_failed")
		CSN_Gov.Say("The coup in " + town + " failed. You can try again in 7 days.")
	EndIf
	m.Refresh()
EndFunction

; ---- screens and SkyrimNet ---------------------------------------------------------------
String Function Json() Global
	CSN_Core m = M()
	String s = "{\"on\":" + m.B(Enabled()) + ",\"coup\":" + CoupPending() + ",\"cities\":["
	Bool first = True
	Int i = 0
	While i < 9
		If Target(i)
			If !first
				s += ","
			EndIf
			first = False
			s += "{\"i\":" + i + ",\"name\":" + m.Q(CSN_World.TownName(i)) + ",\"owner\":" + CSN_World.TownOwner(i) + ",\"jarl\":" + m.Q(m.PlainName(CSN_World.TownJarl(i)))
			s += ",\"guards\":" + Guards(i) + ",\"people\":" + People(i) + ",\"gp\":" + GuardPrice(i) + ",\"pp\":" + PeoplePrice(i, False)
			s += ",\"risk\":" + ExposeChance(i) + ",\"outlook\":" + Outlook(i) + ",\"crowd\":" + Crowd(i) + ",\"block\":" + m.Q(CoupBlock(i)) + ",\"spent\":" + StorageUtil.GetIntValue(None, K(i, "spent"), 0) + "}"
		EndIf
		i += 1
	EndWhile
	Return s + "]}"
EndFunction

; the faction's Steward runs the secret dealings from the treasury
String Function StewardKnowledge() Global
	String s = " As Steward or General they can, when the leader asks, send agents with treasury gold to bribe the guards or fund the nobles and citizens of a city ruled by the Imperials or the Stormcloaks, and set a coup against its jarl in motion once the guards or the people stand at 40 or more (guards 80+ with people 40+ means the guards arrest the jarl; guards 40+ with people 60+ means they side with the leader after arguing; otherwise the guards fight for the jarl). Bribes can be reported to the jarl. In person, the leader can also bribe a guard or win over a noble or citizen of that city directly."
	String list = ""
	Int i = 0
	While i < 9
		If Target(i)
			list = CSN_Rebellion.AddTo(list, CSN_World.TownName(i) + " (guards " + Guards(i) + ", people " + People(i) + "; " + OutlookText(i) + ")")
		EndIf
		i += 1
	EndWhile
	If list != ""
		s += " Where things stand: " + list + "."
	EndIf
	If CoupPending() >= 0
		s += " A coup is under way in " + CSN_World.TownName(CoupPending()) + "."
	EndIf
	Return s
EndFunction

String Function Knowledge(Actor akActor) Global
	CSN_Core m = M()
	If !m || m.FactionStarted.GetValue() < 1 || !akActor || !Enabled()
		Return ""
	EndIf
	If m.GetRole(akActor) == m.ROLE_STEWARD || m.GetRole(akActor) == m.ROLE_GENERAL
		Return StewardKnowledge()
	EndIf
	Int i = CSN_World.TownOf(akActor)
	If !Target(i)
		Return ""
	EndIf
	String town = CSN_World.TownName(i)
	String s = ""
	If akActor.IsGuard()
		s = " " + m.PlainName(akActor) + " serves in the guard of " + town + ". "
		Int g = Guards(i)
		If g >= 80
			s += "Most of the guard is ready to turn on the jarl for " + Game.GetPlayer().GetDisplayName() + "."
		ElseIf g >= 40
			s += "Many guards grumble about the jarl; some have taken gold from " + Game.GetPlayer().GetDisplayName() + "'s agents."
		Else
			s += "The guard is loyal to the jarl, though gold or a good argument can change a guard's mind."
		EndIf
		If StorageUtil.GetIntValue(akActor, "csn_bribed", 0) == 1
			s += " " + m.PlainName(akActor) + " has personally taken the player's gold."
		EndIf
	ElseIf People(i) >= 60
		s = " Many in " + town + ", nobles and commoners alike, would back " + Game.GetPlayer().GetDisplayName() + " against the jarl."
	EndIf
	If CoupPending() == i
		s += " A coup against the jarl is under way in " + town + "."
	EndIf
	Return s
EndFunction
