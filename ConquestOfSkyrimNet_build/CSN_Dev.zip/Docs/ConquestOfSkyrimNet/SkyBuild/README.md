# SkyBuild navmesh option

The installer's "SkyBuild: Update navmesh button" option installs a SkyBuild.dll built from SkyBuild's source
(https://github.com/Sokco/SkyBuild, commit in BASE_COMMIT.txt) with one small addition,
`skybuild-navmesh-papyrus.patch`: Papyrus functions (SkyBuildNative.RequestNavmesh, NavmeshStage, NavmeshBusy,
NavmeshProgress, NavmeshMessage, NavmeshApiVersion) so the Settlements tab's Update navmesh button can start
SkyBuild's navmesh rebuild and show its progress. Nothing else in SkyBuild is changed.

It needs SkyBuild itself (its plugin, scripts and models) installed. Conquest of SkyrimNet must load after SkyBuild
so this SkyBuild.dll and Conquest of SkyrimNet's SkyBuildNative.pex win the file conflicts.

SkyBuild is (c) sokco816, licensed under the GNU GPL 3.0; this modified build is under the same licence, and its
full source is SkyBuild's source at that commit plus the patch in this folder.
