# Conquest of SkyrimNet - Changelog

## 2.1.5 (2026-11-23)
- Today's date (weekday, hour, day and month, 4E year) shows at the top right of the faction screen.
- Automatic recruitment for armies from settlements: each settlement now adds 3 to the troops that can be recruited
  each day (as a claimed holding does), and the daily refill starts with a different army each day, so the armies
  settlements gave are no longer always last in line when the day's recruits or the gold run out. Applying a troop
  template turns automatic recruitment on for that army, and once per save every army that follows a template has
  it switched on.

## 2.1.4 (2026-11-23)
- An army sent against an uprising (or a free company of deserters) really marches there: its commander and troops
  leave their post and walk or run to the town (or the company's seat) through CoS's own moving system, the same way
  they go to garrison a city or attack a camp, and the army menus show it as moving. The fight happens when they
  arrive (in sight of the place, or when the march time is up); afterwards the army waits there for orders.

## 2.1.3 (2026-11-23)
- Decrees on the faction screen: the Armies tab has a Decrees sub-tab with conscription (0-100%), crime and
  punishment (each crime's sentence, or no law) and religion (each god outlawed, allowed or mandatory). Anyone sees
  the laws; beside your General you change them (each confirms first, with its loyalty effect). The same CoS law
  functions do the work, so shrines come down for outlawed gods as before.
- SkyrimNet action CSN_Decree: ask your General, Steward or a jarl to pass a decree (conscription, a punishment, a
  god's status; conscription and punishments for the whole faction or one town).
- Decrees are remembered for 30 days, however they were passed (also through CoS's own law menu): officers,
  soldiers, jarls, stewards and the people of your towns know the recent ones in their SkyrimNet context, and
  officers, jarls and stewards always know the standing laws. The Decrees sub-tab lists the recent ones.

## 2.1.2 (2026-11-23)
- Thane ventures pay their gold into the hold's city treasury, like its taxes, instead of the faction treasury, and
  it counts in that town's gold a day. Hover a town's Gold tile (Lands) for taxes and every venture running there:
  +gold a day and days left. Food, metal and wood from a venture still go to the faction's stores.
- Losing a hold's city (to another faction or an uprising) deletes its ventures outright, running or proposed.
- Requests has an Ongoing tab: investments while they pay out, with a progress bar.

## 2.1.1 (2026-11-23)
- The original Conquest of Skyrim army menus now show the armies you raised and ordered through Conquest of
  SkyrimNet: each army's commander, troops and current task, instead of "Unavailable" and "No Task". The menu copies
  the commanders across every time it opens.
- A city that reaches a side you're at war with outside a war (rebels handing it to the Imperials or Stormcloaks)
  becomes a front-line city as if the war had just started: its map markers disappear and it can be attacked. A
  city handed to a side you're at peace with keeps its markers. Cities in this state in a running game are put
  right within a minute.

## 2.1.0 (2026-11-23)
- Armies and the War Table are one tab: Armies shows every army; beside your General (or anyone who may open the War
  Table) the same tab adds siege equipment, recruiting, orders, dismissal, troop upkeep and templates.
- Lands and the Steward's books are one tab, made simpler: each town you rule is a card with four tiles (gold, food,
  metal, wood) showing what's in store, the daily surplus or deficit, and what you trade with it. Beside your
  Steward or a jarl: Take / Send on a tile sets the daily trade (Set seals it), gold moves with Take / Take all /
  Send, taxes and upgrades are on the card, and Treasury, War and Trade abroad are sub-tabs. Other towns and claims
  are their own sub-tabs.
- Versions go on from 2.1.0.

## 2.0.22 (2026-11-23)
- Town stewards carry "Steward" before their name again (kept up like officers' and jarls' titles); a replaced
  steward goes back to their own name.
- Appointing a town's steward or housecarl when the office is taken asks first ("This replaces X, the steward of
  Y now."), then replaces them, instead of refusing.
- Jarls: what they know now matches what they can do. They're told they act with the Steward's full authority for
  any of your towns (treasury, town gold, taxes, town trade, upgrades, guards, trade with the Imperials and
  Stormcloaks, declarations of war, the ledger, settlements, agents, army orders), and they know the treasury,
  supplies and every town as the Steward does, so they take those requests themselves.

## 2.0.21 (2026-11-23)
- Thanes can be recruited as Steward, General, Blacksmith, Court Wizard, Captain, jarl, town steward or housecarl:
  they stop being Thanes (and lose the Thane outfit), and their new title replaces "Thane".
- Jarls of your cities always carry "Jarl" before their name, however they were appointed; a replaced jarl goes
  back to their own name.
- Settlements tab: Who moves in and Update navmesh sit above the sub-tabs, so they show on every one. The button
  works with any SkyBuild.dll built from this mod's patch (the newest one also lets the navmesh go around your
  buildings).
- Steward tab: gold is in the same dropdown as food, metal and wood on each town card (Export sends treasury gold
  to the town, Import brings the town's gold into the treasury, once).
- Overview: Officers comes before Wars. War Table: Armies comes first.
- Fold-out arrows are twice the size.
- Typing a number or letter in a number box no longer closes and reopens the faction screen when it matches its key.

## 2.0.20 (2026-11-23)
- Approved festivals stay in their town: Holidays' festivities are switched on when you walk into the festival town
  and off when you leave it, so other towns you visit that day aren't decorated or celebrating.
- Installer: a Holidays option in Optional requirements, saying what it does and that Holidays turns celebrations
  off while the civil war is under way.

## 2.0.19 (2026-11-23)
- Festivals you approve: when you accept (or meet halfway) a town's request for a grant for a festival, the festival
  is held the next day. That day the town gets the "Attend the Festival in <Town>" quest (loyalty when you come).
  With Holidays installed, its own festivities are switched on for that day through its Override setting:
  decorations go up and the townsfolk of the town you're in gather as that holiday does: a warriors' festival at
  the smiths and the town centre, a merchants' festival at the shops, a festival of prayer at the temple, a harvest
  festival at the inns, and so on, picked from what the festival is for. The next day Holidays goes back to its
  own calendar.

## 2.0.18 (2026-11-23)
- Faction screen: sub-tabs. Every section with its own header is now a sub-tab of its tab (e.g. Unrest & Intrigue:
  Your towns, Army morale, Free companies, Intrigue; Settlements: Found a settlement and one per settlement, the one
  you're in first). Each tab remembers its sub-tab.
- Festivals, with the Holidays mod (isoku, Holidays.esp): on a holiday Holidays celebrates, the nearest town your
  faction rules that celebrates it gets an optional journal quest, "Attend the Festival in <Town>", with a map
  marker. Be in the town that day and its loyalty rises by 5. Its people know what they're celebrating.
  Without Holidays nothing changes.

## 2.0.17 (2026-11-23)
- Settlements use the claim banner: the banner post at a settlement's heart and the Banner you can build are the
  same banner a claim gets. Settlements from before switch over when you visit them.
- Activate a settlement's banner to hire up to five guards there (the claims' guards: 250 gold, then 10 gold and
  1 food a day, +3 defence each) or dismiss them. Their pay counts with the claim guards on the War Table.
- One more army for each settlement: founding one opens another army place (existing settlements add theirs when
  you load). Once that army is raised the settlement can't be abandoned, and every raid bandits win there lowers
  the army's morale. Abandoning a settlement whose army place is still empty closes it again.

## 2.0.16 (2026-11-23)
- Thanes: a hold whose capital city your faction no longer holds loses all its Thanes at once: the title, the outfit
  and their ventures, and their name goes back to normal ("Thane Ysolda" -> "Ysolda"). You're told, and the news
  spreads.
- Update navmesh now goes around the settlement's buildings: they join SkyBuild's own placed objects when built,
  moved or taken down, and buildings from before this version are added when you press the button. Needs the
  SkyBuild.dll from this version (rebuild it with Build_SkyBuild_Patched before packaging).
- Settlements tab: Fix settlers. Brings a settlement's settlers back to the banner post, gives them their
  settlement life again, gets them moving, and replaces any that went missing.

## 2.0.15 (2026-11-23)
- Settlers live in their settlement: they wander it, sit, sleep in its beds and use its fires, chopping blocks,
  workbenches and stalls (Skyrim's sandbox), instead of standing still. Settlers already there pick it up too.
- Ready-made layouts: every building of the layout floats in front of you, outlined, while you place it, and is set
  exactly where you saw it. Page Up/Down raise and lower the whole layout (bigger steps for layouts and big buildings).
- Outpost: the barricades, dummy and target stand on the ground at the watchtower's door, not up in the air. A single
  watchtower starts at the right height too.
- Update navmesh: when SkyBuild trips over a door it changed earlier ("runtime door binding requires an authored-face
  anchor"), it tries once more by itself, and if it still can't, says what to do.
- Settlements tab: the page keeps your place when it updates (no more jumping to the top or bottom), and Build here,
  Ready-made layouts and Buildings here fold open and shut (the building list starts folded).

## 2.0.14 (2026-11-23)
- SkyBuild navmesh in the one package: the installer has a SkyBuild step. With SkyBuild installed, tick "SkyBuild:
  Update navmesh button" to get the SkyBuild.dll that lets the Settlements tab rebuild the navmesh. It is only
  offered when SkyBuild is installed; load Conquest of SkyrimNet after SkyBuild. No separate download.

## 2.0.13 (2026-11-23)
- Town gold: each town's taxes and trade pile up in its own stores. The Steward tab's town cards now move it: bring an
  amount (or all of it) into the treasury, or send treasury gold to the town. In conversation, ask your Steward, a jarl
  (any of your towns) or a town's steward (their own town), e.g. "bring Whiterun's gold into the treasury".
- Top-left messages are no longer cut off after a name with something in brackets ("Ylva's army (Army 2) will
  arrive..."). When a message is long, the bracketed parts are dropped instead, and the limit is a little longer.

## 2.0.12 (2026-11-23)
- Your jarls (and village leaders) of towns your faction rules can do everything your Steward does, for any of your
  towns: take or pay out treasury gold, trade with the Imperials or Stormcloaks, draw up declarations of war, open
  the economy ledger, set taxes, trade supplies with your towns, upgrade buildings, hire guards, found settlements and
  send agents into enemy cities. They know the treasury and what they can do. Town stewards still act for their own
  town.

## 2.0.11 (2026-11-23)
- Thanes: each hold allows 3, plus 1 for every settlement founded in it. Founding a settlement adds a place there;
  abandoning one takes it away (Thanes already named keep their title). The Officers tab shows each hold's limit.
- Your jarls, village leaders and town stewards know exactly what sits in their own town's stores: gold, food, wood
  and metal, and how much each changes by a day.

## 2.0.10 (2026-11-23)
- Unrest: taxes stopping when a town rises (and coming back after) no longer raise or lower loyalty. Meeting the
  people's demands still lowers taxes and calms the town, without a second loyalty bonus on top.
- Settlements tab, at the settlement you're in:
  - Build catalogue with each building's cost and what it gives; what you can't afford is greyed out.
  - Ready-made layouts: starter camp, farmstead, lumber camp, mining camp, outpost, market square, placed in one go.
  - Grid snapping (off / 1 / 2 / 4 paces) and turn snapping (free / 15 / 45 degrees); Home and End change them while
    placing.
  - Buildings here, nearest first, each with Move (free; picks it back up into build mode, Backspace puts it back)
    and Take down. The Take down menu is nearest first too.
- New Storage group: storage chest, fine chest, strongbox and a weapon rack, all usable containers.
- Every building now gives beds, food, wood, metal or gold: crafting stations, wells, campfires, banners and defences
  gained a resource.
- Tents come with two bedrolls inside.

## 2.0.9 (2026-11-22)
- Claim guards are paid like troops (10 gold a day each, MCM > Economy). The hire button says so ("250 Gold, then 10
  Gold + 1 Food a day"), and hiring shows what the guard and all claim guards cost a day. The Lands tab shows each
  claim's guard cost.
- War table: a Troop upkeep table with each army's troops and gold a day, claim guards, and the total. Each army's
  card shows its own daily cost.
- Your title (Culture tab) is known only to your own people: the faction, its Thanes and housecarls, and the people
  of towns and villages you rule. Outsiders, including friends outside the faction, use your name.

## 2.0.8 (2026-11-22)
- Settlers vary with what you build: farmers, woodsmen, miners and smiths, traders, an alchemist and sellswords
  (vanilla Skyrim people). The Settlements tab shows who each settlement draws, with hints on what brings whom.
- The lumber mill now comes with its log pile and the working saw, placed as Skyrim's own mills are.
- Settlements tab: Update navmesh button. With SkyBuild and its patched SkyBuild.dll it rebuilds the navmesh around
  you, with progress and the result top left (SkyBuildNative.pex with the new functions ships with the mod).

## 2.0.7 (2026-11-22)
- Armies sent against an uprising or deserters march first: "Ylva's army (Army 2) will arrive at Shor's Stone in 7
  hours" (about an hour per 15,000 units of distance, plus two, at most 24). The fight is decided when they arrive;
  if the rising is already over, they're told so. Marching armies show on the Unrest tab and can't be sent twice;
  their leaders know where they are going.
- Awarding a star: the confirmation says "Food", not "supplies".
- Lands and Steward tabs: hover a town for what sits in its own stores (gold, food, metal, wood) and what it makes,
  needs and trades each day. The Steward tab also shows the stores on each town's card.
- Requests: sorted newest first with their Tamrielic date ("Morndas, 9 AM, 31st of Last Seed, 4E 201"), and split
  into Waiting and Finished sub-tabs.
- A new request enters SkyrimNet's memory at the next economy update; its Physical Letters letter still goes out at
  once.

## 2.0.6 (2026-11-22)
- Thanes: any race may be named, and so may people who serve the Empire or the Stormcloaks. A Thane must still be a
  friend of yours, not a guard, a prisoner or already in your faction's service.

## 2.0.5 (2026-11-22)
- Naming someone Thane in conversation no longer turns into a jarl appointment: the Thane action is offered to
  anyone who could be a Thane (the full check runs when they accept, and you're told what stands in the way), the
  jarl action says plainly it is not for Thanes, and a Thane offer that still lands on it is redirected.

## 2.0.4 (2026-11-22)
- Your jarls and town stewards can do what the General and the faction's Steward do about trouble: pass orders to
  army leaders (e.g. "have Army 2 garrison Riften"), send an army against rebels or deserters, and agree the
  people's demands. The General and the Steward can agree any troubled town's demands too.
- The General, Captains and Commanders (and the council) know every troubled town and how to put an uprising down:
  the rebels, the garrison it has and needs (twice the rebels; cities only), the days left, and each option.
- Your jarls stay loyal through unrest: they never side with the rebels; they just want it over.

## 2.0.3 (2026-11-22)
- A town's jarl (or village leader) and steward know its unrest or uprising in full, wherever they are: the
  grievances, the people's exact demands (the gold, any food, and the tax step down), how many rebels, the days left,
  and how it can end. They state the demands with the exact figures when it comes up, and can agree them with you on
  the spot.

## 2.0.2 (2026-11-22)
- Who can be a Thane: the same people Conquest of Skyrim's "I would like to recruit you to my faction's government"
  allows (a friend of yours, of a playable race, not a guard, prisoner, soldier or servant of either side).
- A Thane's ventures stop paying if the faction loses that hold's capital (to another faction, or when its uprising
  hands it over); waiting proposals there are withdrawn. Your Steward, General, jarls and town stewards know every
  running and proposed venture.

## 2.0.1 (2026-11-22)
- Thanes: name Thanes in holds you control (1,000 gold; up to 3 per hold) in conversation ("I name you Thane of
  Whiterun") or on the Officers tab. They carry "Thane" before their name, know their hold, wear their hold's Thane
  outfit (Officers tab > "<Hold> outfit" opens a chest for it) and can be relieved like any office. Officers,
  Captains, Commanders, jarls, stewards and housecarls can't be Thanes.
- Thane investments (new request kind): a Thane pitches a private venture; you put up gold and often food, metal
  and wood, and it pays back 110-135% of that (valued in gold) a little each day for 15-30 days. All or nothing.
- Send an army against an uprising: on the Unrest tab, or tell your General, a Captain or a Commander ("send Army 2
  to crush the rising in Shor's Stone"). Decided at once; the army loses troops either way (more if beaten).
- Troop upkeep: every troop costs 10 gold a day (MCM > Economy > Troop upkeep).
- A star now costs 10,000 gold and 100 food.
- Army morale no longer drops for days spent in the field.
- Uprising journal: the town is marked on the map; leaving the town fails "defeat their leader" (it comes back when
  you return) and the marker no longer points at a rebel who was removed.

## 2.0.0 (2026-11-22)
- Requests sent as letters reach the Requests tab a day after they were written (or as soon as the letter is read),
  with a notice when they arrive. The cap of 6 waiting requests still counts the ones on their way.
- Hotkey: the faction screen now reliably reopens on the tab you last had open, however it was closed.
- New README.md: what to say to whom in conversation, for new players, how claims work, every claim, and links.
- Seven new claims: Fort Frostmoth (Solstheim), Northwatch Keep, Northwind Mine, Sarethi Farm, Honeystrand Cave,
  Alchemist's Shack and Lost Prospect Mine. Sarethi Farm is the first farm claim: farmhands (up to 5) add 2 food a day.
- Claiming now also requires clearing Thalmor and bears.
- Your title (Culture tab, optional): Supreme Leader, Jarl, High Priest, Master, or your own. Troops, captains,
  commanders, officers, jarls, stewards and your subjects address you by it or put it before your name.
- Journal: "Unrest in [...]" / "Deserters at [...]" now name the town or place. The journal quests start through
  the story manager with the place already filled; entries from earlier versions are rebuilt once on load.
- Faction screen: details on hover. The Unrest tab was redesigned: short buttons ("Meet demands…", "Pay arrears…",
  "Plan a coup…") show their full cost and effect when hovered, long grievances and complaints are cut to one line
  with the full text on hover, section help sits behind an (i) icon, intrigue cities sit side by side, and officer
  and settlement details moved into hover panels too.
- Clicking a tab starts its page at the top; the tab strip has no scrollbar any more (it wraps to a second row
  when the tabs don't fit).
- New conversation actions to appoint a hold's own steward (CSN_BecomeHoldSteward; not the faction's Steward) and a
  hold's housecarl (CSN_BecomeHousecarl). Name the hold ("steward of the Rift") or its city; with no name, the town
  you're in is used, or you pick one.
- Coups: tell your Steward or your General "tell your agents to plan the coup on Riften"; the confirmation follows
  once the city is ready (or you're told what's missing). The General now knows where every city's plot stands.
- Coup fix: the quest no longer sticks at "Wait for the guards to choose a side". If the guards' scene doesn't play
  (common outside Whiterun), within a minute the guards carry out their choice: arrest the jarl, or stand by the jarl
  and fight. The waiting objective now marks the jarl, a notice says the guards are choosing, and the fight is won as
  soon as the jarl falls.
- Jarls may hand over their city and hold, or their fort, for nothing, at their own discretion (under duress, to
  repay a great favour, or as part of a partnership).
- Asking prices for cities and forts are the seller's own: each jarl, General Tullius and Ulfric names a price
  (at least 500,000 gold for any hold, 80,000 gold for a fort, plus food, metal and wood as they see fit), remembers
  it, and changes it only for a reason (new action CSN_SetAskingPrice). Deals always go through at that price.
  Numbers like "500,000" or "80k" in conversation are now read correctly.
- The General no longer complains about idle troops; armies without orders are on standby, and the General makes
  specific recommendations instead.
- Faction screen opens instantly: it shows the last known figures, marked "Updating content…", while fresh ones
  load (remembered between openings and sessions). While you read a tab, the other tabs are fetched one by one in
  the background, so switching tabs shows their data at once.
- Top-left notices are now short: only the first sentence, about 70 letters at most. The faction screen and the NPC
  still get the full text.
- Bribing guards, funding citizens and persuading them now trigger reliably in conversation: the actions tell the NPC
  that taking the gold at all (even warily) is the action, and that no gold changes hands without it.

## 1.9.8 (2026-11-21)

### Added
- Journal quests. "Unrest in <town>" (CSN_JournalUnrest1-3): unrest, uprising, the rebel leader as a map target,
  defending the city from the rebels' assault; completed when it ends, failed if the town is lost. "Deserters at
  <place>" (CSN_JournalCompany1-2): a free company, its leader as a map target, its attacks; completed when it is
  beaten, paid off or recognised. Trouble that started earlier gets its entry on the next load.
- The coup's journal goes past "Lead the coup": waiting for the guards, the guards turning on the jarl or siding
  with you, and the fight when they stand by the jarl.

## 1.9.7 (2026-11-21)

### Fixed
- Planning a coup did nothing outside Whiterun. CoS only placed the coup's markers (the jarl's spot, the guards' and
  the crowd's) in Whiterun, and they were required, so CS_Coup couldn't start anywhere else. They are optional now,
  and the coup script (now shipped by this mod) places any missing ones around the jarl. The city is handed over
  with the mod's own transfer, and the start is logged (ConquestOfSkyrimNet.log, "coup:").
- Reviewed the rebel city defence (CSN_DefendCityRebels): it uses only CoS's city-defence markers, which every hold
  city has, so it starts in all nine.

## 1.9.6 (2026-11-21)

### Added
- Requests about an army change its morale: an army leader's own request +6 accepted, +3 met halfway, -8 denied; a
  town asking for a famous army +4 sent, -3 refused. Request cards and the confirmation in conversation show the
  change and the army's morale now; a message gives before and after.
- An upgrade request that can't be carried out says why on the faction screen once it reopens, and keeps the reason
  on the request's card.
- Build mode starts with a box listing the controls, and a short reminder shows every few seconds while placing.

### Fixed
- The building being placed flashed and looked faded: it was moved by resetting its position every frame, which
  reloads it. It now glides to where you aim (only when that changes) and carries a bright outline (Detect Life)
  until it is placed.

## 1.9.5 (2026-11-21)

### Added
- Settlements get a map marker named after them, for fast travel. It follows a rename and goes away when the
  settlement is abandoned. Settlements founded before this version get theirs on the next load. The plugin holds
  eight spare markers (CSN_SettlementMarker1-8); the UI DLL gains CSN_Native.SetMapMarkerName, since Skyrim has no
  way to rename a marker from a script and the name isn't kept in the save (CSN sets it again on every load).

## 1.9.4 (2026-11-21)

### Changed
- The faction-screen hotkey opens the tab that was open when you last closed it (kept in the save). A Steward,
  War Table or Blacksmith tab whose officer you no longer have falls back to the Overview.

## 1.9.3 (2026-11-21)

### Fixed
- Buying supplies in conversation only worked with people in the three job factions, so most farmers, miners and
  mill workers couldn't sell. 54 factions now count, all checked against Skyrim, Dragonborn and Hearthfire: every farm
  and farm household (Chillfurrow, Pelagia, Brandy-Mug, Hollyfrost, Hlaalu, Katla's, Corpselight, Frost River,
  Fellstar, Cowflop, Lemkil's, Snow-Shod, Sarethi, Merryfair, Barleydark, Loreius, Salvius, Ienth), House
  Battle-Born, FavorJobsGatherWheatFaction and WEFarmerFaction sell food; every mine faction (Whistling, Quicksilver,
  Iron-Breaker, Left Hand, Karthwasten, Kolskeggr, Raven Rock, Kolbjorn, FavorJobsMineOreFaction) sells metal; every
  lumber camp and mill (Dragon Bridge, Mixwater, Anga's, Solitude Sawmill, Half-Moon, Heartwood, Irontree, Riverwood's
  mill owners, the Solstheim woodcutter, Hearthfire's lumber sellers, FavorJobsChopWoodFaction) sells wood.

## 1.9.2 (2026-11-21)

### Added
- Stars in conversation: tell a Captain or Commander you are awarding them a star (CSN_ReceiveStar), or ask your
  General (CSN_GeneralAwardStar). A star now lifts the army's morale by 15 at once; the confirmation and the message
  show the change.
- Captains and Commanders know their own army's morale, its complaints and what last changed it.
- Your Steward can run intrigue from the treasury (CSN_ArrangeIntrigue): bribe a city's guards, fund its nobles and
  citizens, or set a coup in motion. The Steward knows where each city stands.
- Every tab of the faction screen shows a spinner until its data has arrived.
- The Steward tab shows each town's loyalty as a bar under the number.

### Fixed
- "You are not inside any hold" when founding a settlement in a hold you control. Skyrim's location check was used
  the wrong way round (also in finding which town an NPC belongs to, and where rebels and deserters are), and open
  wilderness with no location now counts as the hold whose city or fort is nearest.
- The user guide no longer mentions Faction Forge.

## 1.9.1 (2026-11-21)

### Added
- Rebels attack like the Imperials and Stormcloaks do. Two quests use the rebel scripts: CSN_WarRebels
  (CS_WarRebelsScript, the rebels' side) and CSN_DefendCityRebels (CS_DefendCityRebelScript, a copy of CoS's own
  city-defence battle with its rebel soldiers, started by CoS's CS_StoryDefendCity story event). Once a day, when
  the economy updates, a risen hold city or a free company may storm one of your cities; the chance grows with the
  days of the uprising, the company's size, an empty garrison and a proclaimed realm. One battle at a time, as in
  CoS. MCM > Rebellion: on/off and base chance.
- The day's unrest, morale and free company checks now run at the economy update too.
- Your Steward, General and the jarls, village leaders and stewards of your towns know how settlements and raids
  work (buildings, settlers, production, defence, raid chance and outcome) and how each settlement is doing. Town
  leaders can open the build menu.

### Fixed
- 1.9.0 didn't compile: a variable was named after Papyrus's Key type. build_all.bat now stays open at the end so
  errors can be read.

## 1.9.0 (2026-11-21)

Brings in the unfinished systems from the Conquest of Skyrim development build ("Current"). That build removes the
armies, economy updaters, loyalty check and transfers this mod is built on, so it isn't used as a base; its systems
are rebuilt here on 0.3.9's own records and quests.

### Added
- Civilian uprisings. Towns you rule with low loyalty and a grievance (hunger, heavy taxes, no garrison, court cases,
  anger) have a day of unrest, then rise: CoS's rebel soldiers and rebellion leaders hold the town, taxes stop and
  loyalty falls. End it by meeting their demands, killing the leader, or a garrison twice their size; left alone, the
  town goes over to your enemies. (CoS 0.3.9 starts this in its loyalty check but its quest is missing.)
- Army morale and desertion. Unpaid wages, hunger, long postings and refused requests lower an army's morale; stars
  and granted requests raise it. A broken army leaves as a free company that holds its post, raids you, draws in
  other unhappy armies and proclaims its own realm. Fight it, send an army, pay its arrears or recognise it.
- Bribery, persuasion and coups. Bribe guards and fund nobles and citizens in cities ruled by the Imperials or
  Stormcloaks, or win them over with Speech, then plan a coup that runs Conquest of Skyrim's own coup quest (the guards
  arrest the jarl, side with you, or fight you with the citizens at your side).
- Settlements. Found up to 8 on open land in holds you control and build them from base-game and Hearthfire
  buildings with a build mode (homes, crop fields, mills, smelter, smithy, inn, market, walls, towers). Settlers move
  in and work, production goes to the faction every day, and bandits raid poorly defended ones.
- New tabs: Unrest & Intrigue (towns, army morale, free companies, intrigue per city) and Settlements. The Overview
  warns of trouble in the realm.
- New conversation actions: CSN_RebelTerms, CSN_FreeCompanyTerms, CSN_SendArmyAgainstDeserters, CSN_TakeBribe,
  CSN_TakeFunds, CSN_PersuadedAgainstJarl, CSN_JoinCoup, CSN_FoundSettlement, CSN_BuildInSettlement. NPCs know about
  unrest, morale, deserters, plots and settlements that concern them.
- MCM pages Rebellion and Settlements.

## 1.8.5 (2026-11-21)

### Changed
- A jarl at peace with you asks at least 500,000 gold for a major city (minor cities half) and at least 80,000 for
  their hold's main fort (ten times more than before). The MCM sliders start there.

## 1.8.4 (2026-11-21)

### Added
- Answering a request in conversation (CSN_AnswerRequest): tell the person who asked that you accept it, deny it,
  or (where it has one) meet in the middle. A confirmation shows the request and what the answer means (the
  compromise, or the loyalty a denial costs). Go ahead: the answer is carried out and remembered, exactly as on
  the Requests tab. "Not now": they are told it was put off and remember that. "Decline (silent)": nothing happens
  and nothing is remembered. With several requests from one person, name it ("the Riverwood taxes").

## 1.8.3 (2026-11-19)

### Fixed
- Farmers (JobFarmerFaction) wouldn't sell food to the faction unless they already liked you, so the action never
  triggered. Farmers now sell food, miners (JobMinerFaction) metal and lumberjacks (JobLumberjackFaction) wood to
  anyone, like merchants do; asked for something else, they say what they do have. Others still sell only to friends.

## 1.8.2 (2026-11-19)

### Changed
- Conversation actions no longer fall back to the faction screen. When a detail is missing, a small PrismaUI list or
  amount box asks for it instead: which commander (General's orders, dismissals, stars, camps), which order, hold,
  city or fort, how much gold (deposits, withdrawals), which side (declaration of war). "Troop races" opens CoS's own
  races and genders menu. Only "show the war table" and "show the ledger" open the faction screen, each on its own tab.

## 1.8.1 (2026-11-19)

### Fixed
- The General, the Blacksmith and army leaders invented troop types. Their knowledge now says the army has exactly
  four (soldiers, warriors, archers, crossbowmen), with battlemages and Dwemer machines only once researched. The
  same goes for the recruiting action and the knowledge pack.

## 1.8.0 (2026-11-19)

### Changed
- Requests: one study can bring several at once. SkyrimNet may write up to three (one JSON object per line);
  the rules make up to two. Village Leaders ask for their villages and sign as "Leader of <village>".
- Duplicates are dropped: never a second waiting request of the same kind for the same town (same material for
  trade, same building for upgrades, same army for security), and not the same thing again within a day of a
  decision. Six waiting requests are still the most.
- MCM > Requests says which SkyrimNet model writes them: the Dialogue LLM.

## 1.7.9 (2026-11-19)

### Fixed
- With "Keep the game paused" off, keys typed into the faction screen (culture, army names...) also reached other
  mods' hotkeys (SKSE Menu Framework and the like). While a text box has focus the game is now held paused, which
  those hotkeys respect, and it runs again as soon as you leave the box. Needs the rebuilt UI plugin.
- Appointing a jarl or village leader in CoS's dialogue ("I want you to be the leader of Riverwood") now asks for
  confirmation like the faction's own appointments (MCM > Confirmations > Appointments).

### Added
- CSN_BecomeTownOfficial: appoint someone Jarl, village Leader, Steward or Housecarl of a town you rule in
  conversation, with the confirmation. Offices already held must be freed first.

## 1.7.8 (2026-11-18)

### Fixed
- Debug "Hold owner" and "Fort owner" buttons did nothing: they read the dropdowns with a helper that only exists
  inside the screen's script ("Can't find variable: $" in the UI log), so the click never reached the game.

## 1.7.7 (2026-11-18)

### Added
- Debug (Settings tab) "Hold owner": hand a hold's city and its roads (land superiority) to your faction, the
  Imperials or the Stormcloaks. The city goes through CoS's city transfer; Imperial and Stormcloak cities are
  swapped by way of your faction. The roads change the way CoS changes them after a camp battle: the old side
  loses them and its war camp there, and the new side establishes them. The list shows each hold's current city
  owner and roads.

## 1.7.6 (2026-11-18)

### Fixed
- Debug "Fort owner" did nothing. Forts and cities now change hands by calling CoS's own transfer directly, the
  way its story event handler does (transfer, then stop the quest), instead of going through the Story Manager. This
  also covers forts sold by jarls, Tullius or Ulfric, and cities handed over by jarls.
- A compile error from 1.7.0 in the Imperial/Stormcloak trade code stopped the build.

## 1.7.5 (2026-11-18)

### Added
- The faction screen shows the mod's version under its title.
- The build names the mod zip after the version (ConquestOfSkyrimNet_v1.7.5.zip).

## 1.7.4 (2026-11-18)

### Added
- "Get in formation" / "Break formation" in conversation (CSN_ArmyFormUp, CSN_ArmyBreakFormation), for the army
  marching with you. They do what the dialogue's "Form up!" and "Break formation!" do.
- An army's own uniform in conversation (CSN_ArmyUniform): CoS's per-army equipment, worn by that army's troops over
  the troop-type outfits. You choose whether to edit it, or whether the leader wears it too. It says plainly that
  it is one uniform for men and women. CoS keeps a gender split only for the Blacksmith's troop-type outfits.

## 1.7.3 (2026-11-18)

### Added
- Star ranks: every star is a rank. Army leaders know who outranks them, who is level with them and who is below,
  never take orders from a leader with fewer stars, and respect those above them.
- Debug (Settings tab): hand any fort to your faction, the Imperials or the Stormcloaks through CoS's own fort
  transfer. Imperial and Stormcloak forts are swapped by way of your faction, so the fort counts and markers stay right.

## 1.7.2 (2026-11-18)

### Added
- Upgrade requests: a town's steward or jarl asks for better barracks (cities), farms, lumber mills or mines, only
  when no upgrade is under way there. Accepting shows the usual cost confirmation and starts it; denying costs
  2 loyalty. From SkyrimNet (kind "upgrade") or the built-in rules (farms where food runs short, barracks where
  unrest grows, otherwise the weaker of mills and mines).

### Fixed
- "Upgrade buildings…" on the Steward tab only said "Working" and opened CoS's menu once every screen was closed.
  CoS works out upgrade costs on a timer that stands still while a menu pauses the game. The button now
  shows a list of that town's buildings with level, gold, wood and hours, then the confirmation, then brings the
  faction screen back.

### Changed
- Lands: the towns you rule are listed first.
- Officers: the Captains section only shows when an army slot is waiting for a captain.

## 1.7.1 (2026-11-18)

### Added
- Security requests: once one of your army leaders has a star, cities ask for a famous commander to be stationed
  with them, e.g. "Station 3-star Commander Aerina and the Iron Wolves (Army 2) at Solitude's garrison" or "... at
  Fort Neugrad". Accepting sends that army there and raises the town's loyalty (more stars, more loyalty).
  Denying lowers it. They come from SkyrimNet (prompt conquestofskyrimnet/requests, kind "security") or from the
  built-in rules. MCM > Requests > Security requests.

### Fixed
- Answering a request didn't update the Requests tab. Accepting a tax or trade request ran a full economy update
  (fixed in 1.7.0), which waits on game time and so stalled while the screen was open. The tab now also changes as
  soon as you click, and the game's answer follows.
- The requests context is now normalised by the plugin even when no screen is open.

## 1.7.0 (2026-11-18)

### Fixed
- Asking the General, Steward, Blacksmith or Court Wizard (or a jarl, town steward or housecarl) to change outfits
  opened the commanders' outfit templates. It now does what CS_FactionGovernment's dialogue does: their position's
  outfit chest opens to edit, and they change into it when it closes. They can also wear the standard outfit of
  their position, or whatever they wish. The Officers tab's outfit button does the same. Outfit templates are for
  army leaders only.
- The economy update ("Economy Updated") ran after every trade, tax change, guard hire and faction trade made through
  this mod, and each run also paid out a day's income. Those now only refresh the daily figures. The economy updates
  once a day, as in Conquest of Skyrim.
- Government requests failed with "Failed to render template". The request prompt's JSON examples started lines
  with "{", which SkyrimNet's template engine rejects, and the context sent "False" instead of false. Papyrus
  changes a string's case to match one already in the game. Booleans now go out as 1 or 0.

## 1.6.9 (2026-11-18)

### Fixed
- "Export 10 food to Riverwood" to the faction's Steward did nothing: town trade was only offered to a town's own
  jarl or steward. The faction's Steward can now set it for any city or village the faction rules (CSN_ProposeCityTrade
  takes the town and the direction: export to the town, import from it, or stop). Trade with the Imperials and
  Stormcloaks stays a separate action.

### Changed
- The town trade confirmation says "This will halt all current <material> exports to <town>" (or imports from it)
  when the new order goes the other way. It doesn't show that line otherwise. Wording on the Cities tab and in
  confirmations is now from the faction's side: export to a town, import from it.

## 1.6.8 (2026-11-18)

### Added
- Army names (25 letters at most) and an optional purpose, goal or mantra, from the Armies and War Table tabs or in
  conversation (CSN_NameArmy). Army leaders, their soldiers and the General know them, and orders accept them.
- War camp plans in conversation (CSN_WarCampPlans): commanders at a war camp, or the General, show the targets in
  the hold (city, fort, enemy war camps). A reason such as "control the roads of Whiterun first" is shown before
  anything closes. Conquest of Skyrim's own army selection and confirmation follow.
- Direct attack orders (CSN_OrderAttack): "send Army 1 and Army 2 to attack Fort Greymoor", with a confirmation of
  every detail. The General can give them; commanders at the camp can propose them.
- Begin the attack (CSN_BeginAttack) and call it off (CSN_CallOffAttack) in conversation, as the commanders' dialogue
  does. New confirmation on MCM > Confirmations.
- Every attack the faction launches becomes Skyrim-wide news and part of the town's history.

### Changed
- Patrolling or making camp in a hold that already has a war camp of yours joins that camp, the way the war map
  does, instead of setting up a new one.

## 1.6.7 (2026-11-18)

### Fixed
- A jarl's hold hand-over now goes through Conquest of Skyrim's own story event (CS_StoryTransferHoldingCity), as a
  surrender does. The old jarl and court join CS_JarlCitizens and leave the palace for the city's inn. The city's
  invasion objective is marked done. Forts use CS_StoryTransferHoldingFort.
- 1.6.6 called the transfer directly, which left CoS's transfer quest running and blocked later conquests. It is now
  stopped on load and before each hand-over.

## 1.6.6 (2026-11-18)

### Fixed
- The 1.6.5 scripts didn't compile (a function was defined twice), so the build stopped at step 2.
- The UI plugin build could skip recompiling the plugin's source (only relinking it), so plugin changes since 1.6
  never reached the game. build_dll.bat now always copies and rebuilds it.

### Changed
- A jarl handing over their hold is handled as Conquest of Skyrim handles any change of hands (they don't stay on).

## 1.6.5 (2026-11-18)

### Fixed
- **The hotkey stopped opening the faction screen** after loading a save made while the screen was open. The screen's
  state is reset on every load, and the hotkey checks with the UI plugin whether the screen is really open.

### Added
- **Steward actions** (your Steward for any town you rule; a town's steward or jarl for their own town):
  - **Upgrade buildings**: "upgrade the lumber mills in Riverwood" (barracks, farms, lumber mills, mines; villages have
    no barracks). The confirmation shows the current level, the cost in gold and wood, the time, and your gold, wood and food.
  - **Hire guards**: "hire 3 guards for Whiterun". The confirmation shows crime, guards now / most, cost and food.
  - **Taxes** only accept Conquest of Skyrim's rates (0, 10, 20, 30, 40, 50%); anything else, or a rate already at the
    top or bottom, is refused with the reason.
- Stewards know each town's crime, guards (and how many more can be hired), taxes and building levels: town stewards
  for their own town, your Steward for every town you rule.
- **General Tullius and Ulfric Stormcloak** can hand over forts their side holds while at peace with you, for gold,
  wood, metal and food (same minimum as a jarl's fort). They never learn what your faction holds.

### Changed
- Guards cost what MCM > Economy > "Guard cost" says (Conquest of Skyrim had 250 gold built in).

## 1.6.4 (2026-11-18)

### Fixed
- **A jarl agreeing to hand over their hold did nothing.** The hand-over used the wrong faction number for your faction;
  the city and hold now change hands.
- **Forts you hold were never recognised as yours** (wrong owner check), which also blocked "garrison a fort" orders.

### Added
- **A jarl can hand over their hold's main fort** in conversation, for any agreed mix of gold, food, metal and wood
  (at least MCM > Economy > "Price of a hold's fort", 8,000 by default, with supplies counted at the trade price).
- Jarls and the courts of holds you don't rule know who holds their roads and countryside and who holds their main fort.

### Changed
- Jarls never learn how much gold or supplies your faction has. If a deal falls through they're only told the faction
  couldn't raise enough gold (or metal, wood, food); you see the exact shortfall.

## 1.6.3 (2026-11-18)

### Changed
- **Confirmations for things asked in conversation have three answers**: the action itself, **Not now** and
  **Decline (silent)**. "Not now" lets the person know it was called off (they acknowledge it briefly and move on, no
  questioning); "Decline (silent)" just cancels, and they are told nothing. This covers garrisons, camps, recruiting,
  setting and applying troop templates through the General, imports and exports through the Steward, deposits and
  withdrawals, and every other confirmation that comes from conversation. Esc is the silent option. Confirmations you
  turned off in the MCM simply go ahead, so nothing is said either way. Dashboard confirmations keep two buttons.

## 1.6.2 (2026-11-18)

### Fixed
- **Choosing an outfit template didn't change what a Captain, Commander or officer wore** (Conquest of Skyrim only
  dressed them on the next cell load). They now change into it as soon as you close the template's inventory.

### Added
- **"Wear outfit template 1"** in conversation (Captains, Commanders and officers): opens that template's inventory to
  fill or adjust it, and they change into it when you close it. "Wear something different" still opens the template
  picker.

## 1.6.1 (2026-11-18)

### Fixed
- **Culture reached too few people.** Everyone in your faction's Conquest of Skyrim factions (army, guards, fort
  commanders, the General's and government factions, court mage) now counts as a member: they get the culture,
  leadership style and conduct, and the fighting ones the military doctrine. The culture is framed as their own beliefs,
  under its own heading in the character prompt.
- **Asking a commander about "culture" opened their outfit menu.** The outfit action is now only for plain requests
  to change clothes or armour, and opening an outfit menu from conversation asks first
  (MCM > Confirmations > Opening an outfit menu in conversation).

### Changed
- Guardrails for your people: the General, captains, commanders and soldiers never fret about gold (that's the
  leader's and the Steward's business); the Steward sticks to the treasury, supplies, trade, taxes and towns and leaves
  defence to the General; clearing bandit camps is never described as profitable; reputation and honour aren't
  talked about (nothing measures them). Also in the request prompt and the knowledge pack.

## 1.6.0 (2026-11-18)

### Fixed
- **The faction screen took about 4 seconds to appear** (it looked as if it only opened after the pause menu). It now
  opens at once with the header and fills in the tab a moment later; each tab only gathers what it shows.
- **Clicking "Done" in a menu opened from the dashboard closed the dashboard too.** Troop outfits, armour upgrades,
  town upgrades and commander outfits now open over the dashboard and return to it. When Conquest of Skyrim opens an
  inventory (to dress a troop type, say), the screen steps aside and comes back afterwards.
- **Slow or missing feedback on the dashboard**: every action says "Working…" at once and then shows the result in green,
  or the reason it failed in red (declaring war, trades, deposits, orders, taxes, stars...). The race and gender ticks
  on the Blacksmith tab, tax buttons and settings change on screen immediately.
- "Saved" messages are green, not red.
- **Actions that could not be done**: the reason shows top left and on the screen, and the NPC is told it did not happen
  (or that you said no in the confirmation), so they don't carry on as if it had.

### Added
- **Recruit through the General**: "Recruit 5 archers and 10 soldiers for Army 5" (or name the army's Captain or
  Commander). Any troop or creature kind your faction can raise; several kinds at once. The confirmation lists each kind
  with its cost, the total gold, the extra food a day and how many can still be recruited today. The General and every
  Captain and Commander know today's recruiting limit (it changes daily).
- **Troop templates**: "Put 10 soldiers, 7 archers and 2 crossbowmen in template 1" (General or Blacksmith). Replaces
  what the template held, costs nothing, asks first. "Apply template 1 to Army 3" shows the full mix before applying.
  The General and the Blacksmith know all five templates; the War Table and Blacksmith tabs list them.
- **Buying supplies in conversation**: people who like you, or have good reason to trade (merchants), sell up to 50
  food, metal or wood at 20 gold each (at least), paid from the treasury. Remembered like sales; buying from outlaws gets
  talked about and makes the next few town grants worth less loyalty. MCM > Economy.
- MCM > Confirmations: "Recruiting troops in conversation".

### Changed
- **Your people are on your side**: officers, captains, commanders, jarls and stewards speak positively and
  constructively, criticise you only when something is truly at stake (once, briefly), stop asking you for decisions
  they can make themselves, and carry out repeated requests about trade, troops, templates and uniforms without complaint.
  Under a Dictatorship, sternness is directed down the ranks, not at you.

### Note
- The crash at Halted Stream Camp happened in the game's physics while loading a bandit from Bandit War.esp, with
  SkyBuild.dll on the stack; Conquest of SkyrimNet was not involved.

## 1.5.0 (2026-11-18)

### Fixed
- **No ConquestOfSkyrimNet.log.** The UI plugin now writes its logs next to `skse64.log` (it looks for that file
  instead of trusting the folder SKSE reports) and starts the log as soon as the game loads. The exact path is shown on
  the faction screen's Settings tab. Script messages still need MCM > Debug > Debug logging.
- **Wrong troop counts per army** (3 troops showed as 2 soldiers, 2 warriors, 2 archers): troops waiting to spawn were
  counted twice. The dashboard and what officers know now match Conquest of Skyrim's own count.
- **Asking the Blacksmith to manage troop equipment opened the commander outfit menu.** The Blacksmith now opens the
  troop equipment menu: troop type (soldiers, warriors, archers, crossbowmen, city guards, battlemages), then one outfit for
  all or separate outfits for men and women, as in Conquest of Skyrim.
- **Captains and Commanders following you never made requests.** An army marching with you now counts as something
  notable, the LLM is told which armies are with you, and without SkyrimNet (or when it doesn't answer) army leaders
  can still ask for weapon repairs, drills, rations or iron.
- Trading from the dashboard's Steward tab no longer opens a second confirmation; only trades proposed in conversation do.
- The AI calls the faction's food, metal and wood its **supplies**, not "stores".
- Fixed two Conquest of Skyrim bugs: removing a race from the second page of the race list removed the wrong race, and
  "Disable gendered outfits" for battlemages turned them on.

### Added
- **Culture tab**: what your faction is and does (general knowledge across Skyrim), a **leadership style**
  (Laissez-faire, Democratic, Dictatorship or your own words) that your officers, captains, soldiers, jarls and stewards
  follow in how they speak to you and to each other, and a **military doctrine** for the General, captains, commanders and
  soldiers. Kept in your save. Leadership style is also in the MCM (Culture page). SkyrimNet decorator: `csn_culture`.
- **Blacksmith tab** (next to your Blacksmith): outfits by troop type, better standard armour, and which races and
  genders may join your army, with a button to apply the change to current troops.
- **Leaving office** in conversation: the leader can remove a General, Steward, Blacksmith, Court Wizard, Captain or
  Commander, or the jarl or steward of one of your towns, and they can ask to step down of their own accord (you can
  refuse). The General can remove a Captain or Commander on your orders. Confirmation switches for both.
- **Appointments made in conversation ask first** (General, Steward, Blacksmith, Court Wizard, Captain). Switch:
  MCM > Confirmations > Appointments in conversation.
- **Selling supplies in conversation**: people of means who like you (merchants, a jarl's court, mill and mine owners, a
  camp's chief) buy up to 50 food, metal or wood at 10 gold each, straight into the treasury. The deal is remembered;
  selling to bandits, the Forsworn or thieves gets talked about and makes the next few town requests worth less loyalty,
  honest trade makes them worth a little more. Price, limit and how much they must like you: MCM > Economy.
- **Top-left messages** for everything done in conversation: appointments, orders (including orders the General passes
  on), trades, war, removals, sales.
- **Header quick view** on every tab: treasury, food, metal, wood and the gold you carry.
- **Pause the game while menus are open** (MCM > General, or the Settings tab). Off by default.
- Converted Conquest of Skyrim menus put Back / Previous / Next / Done in their own row at the bottom, styled apart from
  the choices.

### Changed
- **Battle size** is now 8 v 8, 16 v 16 or 32 v 32 (MCM and Settings tab) instead of a slider.
- "Dismiss" and "Relieve" on the dashboard say they ask first ("Dismiss…"); the Armies tab explains that an army's
  "Set outfit" overrides the troop-type outfits from the Blacksmith tab.

## 1.4.0 (2026-11-18)

### Fixed
- **Faction menu hotkey did nothing.** MCM Helper saves its settings file with a byte-order mark, so the UI plugin
  never found the `[Hotkeys]` section. Fixed, and the key is now also registered in Papyrus (`RegisterForKey`), so it
  opens the faction screen however the settings file is written. Esc or the key closes it.
- **MCM Difficulty page was empty.** The MCM script refreshed the menu while it was opening; that is gone, and the
  difficulty values are synced from the game on every load instead.
- **"Import 3 food from the Imperials" only opened the Steward tab.** The Steward now opens the trade confirmation
  straight away, filled in with side, material, direction and amount. Numbers like "3 units" are understood.
- **Towns no longer complain about taxes at 0%.** Requests never ask to lower taxes below 0% or raise them above 50%
  (rules and LLM alike), and townsfolk are told when their taxes are at the lowest level.
- SkyrimNet knowledge conditions written with `||` (not understood by SkyrimNet's templates) now use `or`.
- The UI plugin's own log (`ConquestOfSkyrimNetUI.log`) is written again; its folder is found even when SKSE can't report it.

### Changed
- **Captains**: an army leader with no stars is a **Captain** ("Captain Faendal"), and a **Commander** once awarded a
  star. Screens, knowledge and the recruit dialogue ("I want you to lead my troops as a Captain!") and the
  tutorial objective ("Recruit your first captain") say so. Army leaders know whether they are a Captain or, say, a
  3-star Commander, and who their rivals are.
- **Trade confirmation** (conversation and Steward tab): an amount picker with -100, -10, -1, +1, +10, +100 and typing,
  showing the daily cost or income.
- The "Manage" button next to claims is gone.

### Added
- **Stars (medals)**: the leader (War Table or Armies tab) or the General (in conversation) awards a Captain or Commander
  a star for 10,000 gold from the treasury, up to five each. Each star gives that army's troops +10% health and stamina.
  Dismissing an army leader removes their stars. Confirmation switch: MCM > Confirmations.
- **The General knows each army's post** (task and where its leader is now), rank, stars and troops.
- **Knowledge for every Conquest of Skyrim faction** (`CS_PlayerArmyFaction`, `CS_PlayerGuardFaction`,
  `CS_PlayerArmyCommanders`, `CS_ASICFaction`, `CS_StewardFaction`, `CS_JarlFaction`, `CS_CourtMageFaction`,
  `CS_HousecarlFaction`, `CS_PlayerFactionGovernment`, army duty factions, enemy commanders, prisoners...): who they are,
  whom they obey, whom they command, and which orders they can give or carry out and what they need to know for it
  (for example the General names the army leader and the fort to garrison).
- **Requests decided by SkyrimNet**: "How often should it study events to create requests?" (every N hours or days),
  with "Skip if nothing notable happened". The dialogue model reads the faction's state and recent events and picks
  the most fitting request, or none (prompt `conquestofskyrimnet/requests` in a small always-installed SkyrimNet bundle).
  Without SkyrimNet, or with the option off, the fixed rules still make tax and trade requests.
- **Town grants**: a city, minor city or village asks for a one-time sum of gold, food or metal for a festival, parade,
  memorial or cause (never something built), stating the loyalty it would earn. Meet in the middle pays half for half.
- **Army requests**: captains, commanders and the General ask for gold, food or metal for drills, sharpening weapons,
  a veteran instructor and the like. Roleplay only, a way to spend late-game riches; the asker remembers your answer.
- **Debug log file**: `Documents\My Games\Skyrim Special Edition\SKSE\ConquestOfSkyrimNet.log` (MCM > Debug >
  Debug logging), shown in the MCM and on the Settings tab. Nothing is written to the Papyrus log any more.

## 1.3.0 (2026-11-17)

### Added
- **Taxes per town**: raise or lower taxes (0-50%, steps of 10%) in any village, minor city or major city you rule.
  Steward tab buttons, or ask in conversation (SkyrimNet action `CSN_SetTaxes`: your Steward for any town, a town's
  steward or jarl for their own). Confirmation switch on MCM > Confirmations. Taxes are shown on the Lands tab and
  are part of what stewards and jarls know.
- **Requests from your government**: town stewards, jarls and your Steward ask to lower or raise taxes, send or take
  food, or take spare metal and wood, based on the town's real loyalty, food balance and production.
  - **Requests tab** (history log): every request with who asked, why, and its status; Accept, Deny, or Meet in the
    middle where a number in between exists. Denying costs 2 loyalty in that town; unanswered requests are withdrawn
    after 10 days. Decisions become town news and SkyrimNet memories, and the person who asked remembers.
  - **Physical Letters** (optional, https://github.com/zevck/Physical-Letters): requests arrive as letters written by
    the person asking, by courier. Reading one opens the decision; writing back works too (the writer acts on your
    answer through the letter action `csn_request_answer`).
  - Without Physical Letters: the notification "A new request has come in from (your faction)".
  - MCM page **Requests**: on/off, days between requests, send as letters.
- **FOMOD**: the package is now a FOMOD installer (core, optional SkyrimNet knowledge, and an "Optional requirements"
  page that lists Physical Letters and marks it Recommended when installed).
- Three-button choice dialog in the UI plugin (`OpenChoice`).
- Knowledge pack: what stewards and jarls may ask for.

## 1.2.0 (2026-11-17)

### Fixed
- **Faction name, player name and dates missing from menus.** Titles like "The Economy of <Alias=FactionName>"
  and law texts ("<Alias=Player>, Leader of ... on <Global.WeekDay=GameDaysPassed>...") now show the real
  names and date. The UI plugin fills `<Alias=...>`, `<Alias.Pronoun/Cap/...=...>` and `<Global.Day/MonthWord/
  Year/WeekDay=...>` in titles, text and buttons, the same as the game does.
- **War Table and Steward tabs didn't highlight or open.** Papyrus could hand the tab name back capitalised
  ("General"), which matched nothing. Tab names are now compared case-insensitively.
- SkyrimNet actions were registered without their parameter list, so orders like "garrison Fort Greymoor" lost
  their target. Every action now declares its parameters.

### Removed
- **Command Seal** (hotkey, screen and MCM entry).
- **Friends-only commanders.** Anyone who isn't hostile can lead an army or hold an office (the dialogue condition
  and the script check are gone; the tutorial objective now reads "Recruit your first commander").

### Changed
- **Redesigned faction screen**: dark and light themes (MCM or Settings tab), clearer cards, tables and buttons,
  Yes/No confirmation dialogs, line breaks in CoS messages.
- **Tabs**: Overview, Officers, Armies, Lands and Settings are always there. **Steward** only appears when the
  screen is opened next to your Steward, a town steward or one of your jarls; **War Table** only next to your General.
- **Officers** are appointed in conversation or from a list of people nearby (Officers tab).
- **NPC Name Distributor**: names it gives are kept; titles are added in front and removed cleanly.
- Order "Patrol a hold" is now what it always did: **Garrison a city** (cities you rule).

### Added
- **Treasury**: deposit any amount from your purse (refused if you don't carry it) or withdraw any amount, through
  any steward of the faction (screen or SkyrimNet).
- **Make camp**: the General (or a commander) sets up an army camp, or an attack camp in land you don't hold yet,
  in any hold your armies can reach.
- **Garrison a city / a fort** you control, from the War Table or by asking the General or the commander.
- **Outfits** for the General, Steward, Blacksmith, Court Wizard and commanders (same menu as "I want you to wear a
  different outfit" > "Let me edit what you need to wear").
- **Town trade offers**: jarls and stewards of your towns propose sending more or less food, metal or wood
  to or from their town; also set by hand on the Steward tab, with building upgrades per town.
- **Buying a city**: a jarl whose side is at peace with you can bring their city over to your faction for gold
  from the treasury (least price on MCM > Economy; minor cities ask half).
- **Confirmations** for all of the above, each switchable on MCM > Confirmations.
- **Difficulty** (MCM and Settings tab): battle size per side (4-40, e.g. 8 v 8, 16 v 16, 32 v 32), reinforcement
  speed, hours before enemy armies return and refill. Kept in sync with CoS's own settings.
- **Debug**: win or lose the current battle (MCM and Settings tab).
- **Skip tutorial** (MCM and Settings tab): jumps the faction questline to declaring war.
- **What officers know** (SkyrimNet decorator `csn_officer_knowledge`, exact figures, never guessed):
  - Steward, General, Blacksmith, Court Wizard: treasury, food, metal, wood, daily changes, trade agreements, towns ruled.
  - Your Steward: buildings (barracks, farms, lumber mills, mines) and trade of every town you rule;
    town stewards and jarls: their own town.
  - General: every commander, troop mix (soldiers, warriors, archers, crossbowmen, mages...), task, and the battering
    rams, ladders and catapults ready.
  - Blacksmith: each army's equipment.
  - Commanders: their own troops, plus the cities and forts they can be sent to.
- **New laws are memory events**: conscription, crime punishments and religion decrees become town news,
  SkyrimNet memories and lasting knowledge for the people they affect.
- Knowledge pack: General's duties, town trade, jarls changing sides; stewards' treasury duties.

## 1.1.0 (2026-11-17)

### Renamed
- **Faction Forge is now Conquest of SkyrimNet.** Plugin `ConquestOfSkyrimNet.esp`, UI plugin
  `SKSE/Plugins/ConquestOfSkyrimNetUI.dll`, menus in `PrismaUI/views/ConquestOfSkyrimNet/`, scripts `CSN_*`
  (CSN_Core, CSN_World, CSN_SkyrimNet, CSN_Config, CSN_MCM, CSN_Native, CSNP), SkyrimNet actions `CSN_*`.
- Because the plugin file name changed, saves made with `FactionForge.esp` do not carry over. Uninstall
  Faction Forge and start a new game (or a clean save made without it).

### Fixed
- **Ledger hotkey opened an empty PrismaUI screen with the cursor stuck on it.** Papyrus stores strings
  case-insensitively, so the menu data it built could come out as `True`/`Name` instead of `true`/`name`,
  which broke the data the screen received. The UI plugin now cleans the data (lower-case keys, JSON
  true/false/null) before it reaches the screen, and the screen shows a message instead of going blank
  if anything still fails.
- **You can always get out of a screen.** Esc, or the ledger hotkey again, now closes the faction screens
  from the UI plugin itself, even if the page has an error.
- Screen errors are written to `Documents/My Games/Skyrim Special Edition/SKSE/ConquestOfSkyrimNetUI.log`
  (the plugin did not write a log before).

### Changed
- **Hotkeys are unbound by default.** Set "Faction ledger" and "Command Seal" in the MCM.
- Economy values (trade price, hunting food, guard and miner cost) moved from
  `StorageUtilData/FactionForge/config.json` to the MCM.

### Added
- **MCM menu** (needs MCM Helper and SkyUI), four pages:
  - General: ledger and Command Seal hotkeys, use PrismaUI menus on/off, big-news notifications, "Open the ledger now".
  - Economy: trade price, food per hunting soldier, guard cost, miner cost.
  - SkyrimNet: SkyrimNet features on/off, town news, townsfolk opinion, how long news lasts,
    how big a loyalty change people notice.
  - About: version and debug logging.
- **Townsfolk know who rules them.** Every NPC who lives in (or is standing in) a Conquest of Skyrim town
  knows which faction controls it and who sits as Jarl.
- **Townsfolk mood and liking.** Each town's CoS loyalty (0-100) becomes a mood the locals share
  (devoted, content, uneasy, resentful, close to revolt). In towns you don't rule, locals also have an
  opinion of your faction: it rises when you fund their town and falls if you're at war with a ruler they're loyal to.
- **SkyrimNet knowledge pack** (`SKSE/Plugins/SkyrimNet/external/conquestofskyrimnet.skyrimnet/`, a SkyrimNet bundle
  that shows on SkyrimNet's package page). `knowledge/conquest_of_skyrimnet.sknpack` covers how the war of conquest
  works, how town loyalty works, your faction's ranks and chain of command, and what Commanders, the Steward and a
  conquered town's Jarl do. Each entry is always known to the people it concerns (your soldiers, commanders,
  officers, guards and jarls, by their Conquest of Skyrim factions); anyone else recalls it when the conversation
  turns to it.
- **Dynamic knowledge at runtime.** When a town changes hands or a Jarl is named, a dated entry is added to
  SkyrimNet's world knowledge (`AddWorldKnowledge`), known to the people of that hold (by crime faction), e.g.
  "On the 12th of Frostfall, 4E 201: Whiterun has fallen under the control of ...".
- **Town news and memory events.** These become news that townsfolk talk about for 14 in-game days
  (adjustable), and are recorded as SkyrimNet memory events (`RegisterPersistentEvent`: remembered, without
  making anyone start talking):
  - a town changing hands (also a corner notification);
  - a new Jarl being named or removed;
  - loyalty rising or falling noticeably;
  - farms, lumber mills, mines or barracks being funded, with the Jarl's court named when a Jarl helps
    (for example "The farms of Whiterun are being expanded, paid for by ... with the help of Jarl ...'s court");
  - battles, sieges, raids, ambushes, coups and protests starting and ending. A battle starting is also
    narrated to the people nearby (`DirectNarration`), so they react out loud.
- **Faction ranks and hierarchy in SkyrimNet.** New `csn_hierarchy` knowledge tells the people who would
  know (your officers, commanders, soldiers, friends, and the townsfolk of towns you rule) how your faction
  is organised:
  - the leader;
  - the four officers and what each does;
  - who answers to whom;
  - the current office holders and commanders;
  - the NPC's own place in it.
- New SkyrimNet decorators `csn_town_context` and `csn_hierarchy`, used with `csn_faction_context` by the bundle's
  character bio module `prompts/submodules/character_bio/0650_conquestofskyrimnet.prompt` (now in the bundle
  instead of SkyrimNet's prompts override folder).
- User guide: `Docs/ConquestOfSkyrimNet/UserGuide.md`.

### Requirements
- Unchanged: SKSE, PapyrusUtil, PrismaUI, SkyUI.
- New: **MCM Helper** (for the menu; without it the defaults apply and hotkeys stay unbound).
- Optional: SkyrimNet 0.25 or newer.

## 1.0.0 (2026-11-17) - as Faction Forge
- Standalone fork of Conquest of Skyrim 0.3.9: every menu drawn in PrismaUI.
- Added:
  - officer titles (General, Steward, Blacksmith, Court Wizard) and Commander titles;
  - friends-only commander hiring;
  - the faction dashboard (overview, claims, war table, steward ledger);
  - steward trade at 10 gold per unit;
  - SkyrimNet actions for appointments, hiring, army orders and steward business.
