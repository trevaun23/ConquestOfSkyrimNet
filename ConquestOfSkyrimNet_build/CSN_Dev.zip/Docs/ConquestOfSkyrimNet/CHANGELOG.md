# Conquest of SkyrimNet - Changelog

## 1.9.9 (2026-11-21)
- Requests sent as letters reach the Requests tab a day after they were written (or as soon as the letter is read),
  with a notice when they arrive. The cap of 6 waiting requests still counts the ones on their way.
- Hotkey: the faction screen now reliably reopens on the tab you last had open, however it was closed.
- New README.md: what to say to whom in conversation, for new players, how claims work, every claim, and links.
- Seven new claims: Fort Frostmoth (Solstheim), Northwatch Keep, Northwind Mine, Sarethi Farm, Honeystrand Cave,
  Alchemist's Shack and Lost Prospect Mine. Sarethi Farm is the first farm claim: farmhands (up to 5) add 2 food a day.
- Claiming now also requires clearing Thalmor and bears.

## 1.9.8 (2026-11-21)

### Added
- Journal quests. "Unrest in <town>" (CSN_JournalUnrest1-3): unrest, uprising, the rebel leader as a map target,
  defending the city from the rebels' assault; completed when it ends, failed if the town is lost. "Deserters at
  <place>" (CSN_JournalCompany1-2): a free company, its leader as a map target, its attacks; completed when it is
  beaten, paid off or recognised. Trouble that started earlier gets its entry on the next load.
- The coup's journal goes past "Lead the coup": waiting for the guards, the guards turning on the jarl or siding
  with you, and the fight when they stand by the jarl.

## 1.9.7 (2026-11-21)

### Fixed
- Planning a coup did nothing outside Whiterun. CoS only placed the coup's markers (the jarl's spot, the guards' and
  the crowd's) in Whiterun, and they were required, so CS_Coup couldn't start anywhere else. They are optional now,
  and the coup script (now shipped by this mod) places any missing ones around the jarl. The city is handed over
  with the mod's own transfer, and the start is logged (ConquestOfSkyrimNet.log, "coup:").
- Reviewed the rebel city defence (CSN_DefendCityRebels): it uses only CoS's city-defence markers, which every hold
  city has, so it starts in all nine.

## 1.9.6 (2026-11-21)

### Added
- Requests about an army change its morale: an army leader's own request +6 accepted, +3 met halfway, -8 denied; a
  town asking for a famous army +4 sent, -3 refused. Request cards and the confirmation in conversation show the
  change and the army's morale now; a message gives before and after.
- An upgrade request that can't be carried out says why on the faction screen once it reopens, and keeps the reason
  on the request's card.
- Build mode starts with a box listing the controls, and a short reminder shows every few seconds while placing.

### Fixed
- The building being placed flashed and looked faded: it was moved by resetting its position every frame, which
  reloads it. It now glides to where you aim (only when that changes) and carries a bright outline (Detect Life)
  until it is placed.

## 1.9.5 (2026-11-21)

### Added
- Settlements get a map marker named after them, for fast travel. It follows a rename and goes away when the
  settlement is abandoned. Settlements founded before this version get theirs on the next load. The plugin holds
  eight spare markers (CSN_SettlementMarker1-8); the UI DLL gains CSN_Native.SetMapMarkerName, since Skyrim has no
  way to rename a marker from a script and the name isn't kept in the save (CSN sets it again on every load).

## 1.9.4 (2026-11-21)

### Changed
- The faction-screen hotkey opens the tab that was open when you last closed it (kept in the save). A Steward,
  War Table or Blacksmith tab whose officer you no longer have falls back to the Overview.

## 1.9.3 (2026-11-21)

### Fixed
- Buying supplies in conversation only worked with people in the three job factions, so most farmers, miners and
  mill workers couldn't sell. 54 factions now count, all checked against Skyrim, Dragonborn and Hearthfire: every farm
  and farm household (Chillfurrow, Pelagia, Brandy-Mug, Hollyfrost, Hlaalu, Katla's, Corpselight, Frost River,
  Fellstar, Cowflop, Lemkil's, Snow-Shod, Sarethi, Merryfair, Barleydark, Loreius, Salvius, Ienth), House
  Battle-Born, FavorJobsGatherWheatFaction and WEFarmerFaction sell food; every mine faction (Whistling, Quicksilver,
  Iron-Breaker, Left Hand, Karthwasten, Kolskeggr, Raven Rock, Kolbjorn, FavorJobsMineOreFaction) sells metal; every
  lumber camp and mill (Dragon Bridge, Mixwater, Anga's, Solitude Sawmill, Half-Moon, Heartwood, Irontree, Riverwood's
  mill owners, the Solstheim woodcutter, Hearthfire's lumber sellers, FavorJobsChopWoodFaction) sells wood.

## 1.9.2 (2026-11-21)

### Added
- Stars in conversation: tell a Captain or Commander you are awarding them a star (CSN_ReceiveStar), or ask your
  General (CSN_GeneralAwardStar). A star now lifts the army's morale by 15 at once; the confirmation and the message
  show the change.
- Captains and Commanders know their own army's morale, its complaints and what last changed it.
- Your Steward can run intrigue from the treasury (CSN_ArrangeIntrigue): bribe a city's guards, fund its nobles and
  citizens, or set a coup in motion. The Steward knows where each city stands.
- Every tab of the faction screen shows a spinner until its data has arrived.
- The Steward tab shows each town's loyalty as a bar under the number.

### Fixed
- "You are not inside any hold" when founding a settlement in a hold you control. Skyrim's location check was used
  the wrong way round (also in finding which town an NPC belongs to, and where rebels and deserters are), and open
  wilderness with no location now counts as the hold whose city or fort is nearest.
- The user guide no longer mentions Faction Forge.

## 1.9.1 (2026-11-21)

### Added
- Rebels attack like the Imperials and Stormcloaks do. Two quests use the rebel scripts: CSN_WarRebels
  (CS_WarRebelsScript, the rebels' side) and CSN_DefendCityRebels (CS_DefendCityRebelScript, a copy of CoS's own
  city-defence battle with its rebel soldiers, started by CoS's CS_StoryDefendCity story event). Once a day, when
  the economy updates, a risen hold city or a free company may storm one of your cities; the chance grows with the
  days of the uprising, the company's size, an empty garrison and a proclaimed realm. One battle at a time, as in
  CoS. MCM > Rebellion: on/off and base chance.
- The day's unrest, morale and free company checks now run at the economy update too.
- Your Steward, General and the jarls, village leaders and stewards of your towns know how settlements and raids
  work (buildings, settlers, production, defence, raid chance and outcome) and how each settlement is doing. Town
  leaders can open the build menu.

### Fixed
- 1.9.0 didn't compile: a variable was named after Papyrus's Key type. build_all.bat now stays open at the end so
  errors can be read.

## 1.9.0 (2026-11-21)

Brings in the unfinished systems from the Conquest of Skyrim development build ("Current"). That build removes the
armies, economy updaters, loyalty check and transfers this mod is built on, so it isn't used as a base; its systems
are rebuilt here on 0.3.9's own records and quests.

### Added
- Civilian uprisings. Towns you rule with low loyalty and a grievance (hunger, heavy taxes, no garrison, court cases,
  anger) have a day of unrest, then rise: CoS's rebel soldiers and rebellion leaders hold the town, taxes stop and
  loyalty falls. End it by meeting their demands, killing the leader, or a garrison twice their size; left alone, the
  town goes over to your enemies. (CoS 0.3.9 starts this in its loyalty check but its quest is missing.)
- Army morale and desertion. Unpaid wages, hunger, long postings and refused requests lower an army's morale; stars
  and granted requests raise it. A broken army leaves as a free company that holds its post, raids you, draws in
  other unhappy armies and proclaims its own realm. Fight it, send an army, pay its arrears or recognise it.
- Bribery, persuasion and coups. Bribe guards and fund nobles and citizens in cities ruled by the Imperials or
  Stormcloaks, or win them over with Speech, then plan a coup that runs Conquest of Skyrim's own coup quest (the guards
  arrest the jarl, side with you, or fight you with the citizens at your side).
- Settlements. Found up to 8 on open land in holds you control and build them from base-game and Hearthfire
  buildings with a build mode (homes, crop fields, mills, smelter, smithy, inn, market, walls, towers). Settlers move
  in and work, production goes to the faction every day, and bandits raid poorly defended ones.
- New tabs: Unrest & Intrigue (towns, army morale, free companies, intrigue per city) and Settlements. The Overview
  warns of trouble in the realm.
- New conversation actions: CSN_RebelTerms, CSN_FreeCompanyTerms, CSN_SendArmyAgainstDeserters, CSN_TakeBribe,
  CSN_TakeFunds, CSN_PersuadedAgainstJarl, CSN_JoinCoup, CSN_FoundSettlement, CSN_BuildInSettlement. NPCs know about
  unrest, morale, deserters, plots and settlements that concern them.
- MCM pages Rebellion and Settlements.

## 1.8.5 (2026-11-21)

### Changed
- A jarl at peace with you asks at least 500,000 gold for a major city (minor cities half) and at least 80,000 for
  their hold's main fort (ten times more than before). The MCM sliders start there.

## 1.8.4 (2026-11-21)

### Added
- Answering a request in conversation (CSN_AnswerRequest): tell the person who asked that you accept it, deny it,
  or (where it has one) meet in the middle. A confirmation shows the request and what the answer means (the
  compromise, or the loyalty a denial costs). Go ahead: the answer is carried out and remembered, exactly as on
  the Requests tab. "Not now": they are told it was put off and remember that. "Decline (silent)": nothing happens
  and nothing is remembered. With several requests from one person, name it ("the Riverwood taxes").

## 1.8.3 (2026-11-19)

### Fixed
- Farmers (JobFarmerFaction) wouldn't sell food to the faction unless they already liked you, so the action never
  triggered. Farmers now sell food, miners (JobMinerFaction) metal and lumberjacks (JobLumberjackFaction) wood to
  anyone, like merchants do; asked for something else, they say what they do have. Others still sell only to friends.

## 1.8.2 (2026-11-19)

### Changed
- Conversation actions no longer fall back to the faction screen. When a detail is missing, a small PrismaUI list or
  amount box asks for it instead: which commander (General's orders, dismissals, stars, camps), which order, hold,
  city or fort, how much gold (deposits, withdrawals), which side (declaration of war). "Troop races" opens CoS's own
  races and genders menu. Only "show the war table" and "show the ledger" open the faction screen, each on its own tab.

## 1.8.1 (2026-11-19)

### Fixed
- The General, the Blacksmith and army leaders invented troop types. Their knowledge now says the army has exactly
  four (soldiers, warriors, archers, crossbowmen), with battlemages and Dwemer machines only once researched. The
  same goes for the recruiting action and the knowledge pack.

## 1.8.0 (2026-11-19)

### Changed
- Requests: one study can bring several at once. SkyrimNet may write up to three (one JSON object per line);
  the rules make up to two. Village Leaders ask for their villages and sign as "Leader of <village>".
- Duplicates are dropped: never a second waiting request of the same kind for the same town (same material for
  trade, same building for upgrades, same army for security), and not the same thing again within a day of a
  decision. Six waiting requests are still the most.
- MCM > Requests says which SkyrimNet model writes them: the Dialogue LLM.

## 1.7.9 (2026-11-19)

### Fixed
- With "Keep the game paused" off, keys typed into the faction screen (culture, army names...) also reached other
  mods' hotkeys (SKSE Menu Framework and the like). While a text box has focus the game is now held paused, which
  those hotkeys respect, and it runs again as soon as you leave the box. Needs the rebuilt UI plugin.
- Appointing a jarl or village leader in CoS's dialogue ("I want you to be the leader of Riverwood") now asks for
  confirmation like the faction's own appointments (MCM > Confirmations > Appointments).

### Added
- CSN_BecomeTownOfficial: appoint someone Jarl, village Leader, Steward or Housecarl of a town you rule in
  conversation, with the confirmation. Offices already held must be freed first.

## 1.7.8 (2026-11-18)

### Fixed
- Debug "Hold owner" and "Fort owner" buttons did nothing: they read the dropdowns with a helper that only exists
  inside the screen's script ("Can't find variable: $" in the UI log), so the click never reached the game.

## 1.7.7 (2026-11-18)

### Added
- Debug (Settings tab) "Hold owner": hand a hold's city and its roads (land superiority) to your faction, the
  Imperials or the Stormcloaks. The city goes through CoS's city transfer; Imperial and Stormcloak cities are
  swapped by way of your faction. The roads change the way CoS changes them after a camp battle: the old side
  loses them and its war camp there, and the new side establishes them. The list shows each hold's current city
  owner and roads.

## 1.7.6 (2026-11-18)

### Fixed
- Debug "Fort owner" did nothing. Forts and cities now change hands by calling CoS's own transfer directly, the
  way its story event handler does (transfer, then stop the quest), instead of going through the Story Manager. This
  also covers forts sold by jarls, Tullius or Ulfric, and cities handed over by jarls.
- A compile error from 1.7.0 in the Imperial/Stormcloak trade code stopped the build.

## 1.7.5 (2026-11-18)

### Added
- The faction screen shows the mod's version under its title.
- The build names the mod zip after the version (ConquestOfSkyrimNet_v1.7.5.zip).

## 1.7.4 (2026-11-18)

### Added
- "Get in formation" / "Break formation" in conversation (CSN_ArmyFormUp, CSN_ArmyBreakFormation), for the army
  marching with you. They do what the dialogue's "Form up!" and "Break formation!" do.
- An army's own uniform in conversation (CSN_ArmyUniform): CoS's per-army equipment, worn by that army's troops over
  the troop-type outfits. You choose whether to edit it, or whether the leader wears it too. It says plainly that
  it is one uniform for men and women. CoS keeps a gender split only for the Blacksmith's troop-type outfits.

## 1.7.3 (2026-11-18)

### Added
- Star ranks: every star is a rank. Army leaders know who outranks them, who is level with them and who is below,
  never take orders from a leader with fewer stars, and respect those above them.
- Debug (Settings tab): hand any fort to your faction, the Imperials or the Stormcloaks through CoS's own fort
  transfer. Imperial and Stormcloak forts are swapped by way of your faction, so the fort counts and markers stay right.

## 1.7.2 (2026-11-18)

### Added
- Upgrade requests: a town's steward or jarl asks for better barracks (cities), farms, lumber mills or mines, only
  when no upgrade is under way there. Accepting shows the usual cost confirmation and starts it; denying costs
  2 loyalty. From SkyrimNet (kind "upgrade") or the built-in rules (farms where food runs short, barracks where
  unrest grows, otherwise the weaker of mills and mines).

### Fixed
- "Upgrade buildings…" on the Steward tab only said "Working" and opened CoS's menu once every screen was closed.
  CoS works out upgrade costs on a timer that stands still while a menu pauses the game. The button now
  shows a list of that town's buildings with level, gold, wood and hours, then the confirmation, then brings the
  faction screen back.

### Changed
- Lands: the towns you rule are listed first.
- Officers: the Captains section only shows when an army slot is waiting for a captain.

## 1.7.1 (2026-11-18)

### Added
- Security requests: once one of your army leaders has a star, cities ask for a famous commander to be stationed
  with them, e.g. "Station 3-star Commander Aerina and the Iron Wolves (Army 2) at Solitude's garrison" or "... at
  Fort Neugrad". Accepting sends that army there and raises the town's loyalty (more stars, more loyalty).
  Denying lowers it. They come from SkyrimNet (prompt conquestofskyrimnet/requests, kind "security") or from the
  built-in rules. MCM > Requests > Security requests.

### Fixed
- Answering a request didn't update the Requests tab. Accepting a tax or trade request ran a full economy update
  (fixed in 1.7.0), which waits on game time and so stalled while the screen was open. The tab now also changes as
  soon as you click, and the game's answer follows.
- The requests context is now normalised by the plugin even when no screen is open.

## 1.7.0 (2026-11-18)

### Fixed
- Asking the General, Steward, Blacksmith or Court Wizard (or a jarl, town steward or housecarl) to change outfits
  opened the commanders' outfit templates. It now does what CS_FactionGovernment's dialogue does: their position's
  outfit chest opens to edit, and they change into it when it closes. They can also wear the standard outfit of
  their position, or whatever they wish. The Officers tab's outfit button does the same. Outfit templates are for
  army leaders only.
- The economy update ("Economy Updated") ran after every trade, tax change, guard hire and faction trade made through
  this mod, and each run also paid out a day's income. Those now only refresh the daily figures. The economy updates
  once a day, as in Conquest of Skyrim.
- Government requests failed with "Failed to render template". The request prompt's JSON examples started lines
  with "{", which SkyrimNet's template engine rejects, and the context sent "False" instead of false. Papyrus
  changes a string's case to match one already in the game. Booleans now go out as 1 or 0.

## 1.6.9 (2026-11-18)

### Fixed
- "Export 10 food to Riverwood" to the faction's Steward did nothing: town trade was only offered to a town's own
  jarl or steward. The faction's Steward can now set it for any city or village the faction rules (CSN_ProposeCityTrade
  takes the town and the direction: export to the town, import from it, or stop). Trade with the Imperials and
  Stormcloaks stays a separate action.

### Changed
- The town trade confirmation says "This will halt all current <material> exports to <town>" (or imports from it)
  when the new order goes the other way. It doesn't show that line otherwise. Wording on the Cities tab and in
  confirmations is now from the faction's side: export to a town, import from it.

## 1.6.8 (2026-11-18)

### Added
- Army names (25 letters at most) and an optional purpose, goal or mantra, from the Armies and War Table tabs or in
  conversation (CSN_NameArmy). Army leaders, their soldiers and the General know them, and orders accept them.
- War camp plans in conversation (CSN_WarCampPlans): commanders at a war camp, or the General, show the targets in
  the hold (city, fort, enemy war camps). A reason such as "control the roads of Whiterun first" is shown before
  anything closes. Conquest of Skyrim's own army selection and confirmation follow.
- Direct attack orders (CSN_OrderAttack): "send Army 1 and Army 2 to attack Fort Greymoor", with a confirmation of
  every detail. The General can give them; commanders at the camp can propose them.
- Begin the attack (CSN_BeginAttack) and call it off (CSN_CallOffAttack) in conversation, as the commanders' dialogue
  does. New confirmation on MCM > Confirmations.
- Every attack the faction launches becomes Skyrim-wide news and part of the town's history.

### Changed
- Patrolling or making camp in a hold that already has a war camp of yours joins that camp, the way the war map
  does, instead of setting up a new one.

## 1.6.7 (2026-11-18)

### Fixed
- A jarl's hold hand-over now goes through Conquest of Skyrim's own story event (CS_StoryTransferHoldingCity), as a
  surrender does. The old jarl and court join CS_JarlCitizens and leave the palace for the city's inn. The city's
  invasion objective is marked done. Forts use CS_StoryTransferHoldingFort.
- 1.6.6 called the transfer directly, which left CoS's transfer quest running and blocked later conquests. It is now
  stopped on load and before each hand-over.

## 1.6.6 (2026-11-18)

### Fixed
- The 1.6.5 scripts didn't compile (a function was defined twice), so the build stopped at step 2.
- The UI plugin build could skip recompiling the plugin's source (only relinking it), so plugin changes since 1.6
  never reached the game. build_dll.bat now always copies and rebuilds it.

### Changed
- A jarl handing over their hold is handled as Conquest of Skyrim handles any change of hands (they don't stay on).

## 1.6.5 (2026-11-18)

### Fixed
- **The hotkey stopped opening the faction screen** after loading a save made while the screen was open. The screen's
  state is reset on every load, and the hotkey checks with the UI plugin whether the screen is really open.

### Added
- **Steward actions** (your Steward for any town you rule; a town's steward or jarl for their own town):
  - **Upgrade buildings**: "upgrade the lumber mills in Riverwood" (barracks, farms, lumber mills, mines; villages have
    no barracks). The confirmation shows the current level, the cost in gold and wood, the time, and your gold, wood and food.
  - **Hire guards**: "hire 3 guards for Whiterun". The confirmation shows crime, guards now / most, cost and food.
  - **Taxes** only accept Conquest of Skyrim's rates (0, 10, 20, 30, 40, 50%); anything else, or a rate already at the
    top or bottom, is refused with the reason.
- Stewards know each town's crime, guards (and how many more can be hired), taxes and building levels: town stewards
  for their own town, your Steward for every town you rule.
- **General Tullius and Ulfric Stormcloak** can hand over forts their side holds while at peace with you, for gold,
  wood, metal and food (same minimum as a jarl's fort). They never learn what your faction holds.

### Changed
- Guards cost what MCM > Economy > "Guard cost" says (Conquest of Skyrim had 250 gold built in).

## 1.6.4 (2026-11-18)

### Fixed
- **A jarl agreeing to hand over their hold did nothing.** The hand-over used the wrong faction number for your faction;
  the city and hold now change hands.
- **Forts you hold were never recognised as yours** (wrong owner check), which also blocked "garrison a fort" orders.

### Added
- **A jarl can hand over their hold's main fort** in conversation, for any agreed mix of gold, food, metal and wood
  (at least MCM > Economy > "Price of a hold's fort", 8,000 by default, with supplies counted at the trade price).
- Jarls and the courts of holds you don't rule know who holds their roads and countryside and who holds their main fort.

### Changed
- Jarls never learn how much gold or supplies your faction has. If a deal falls through they're only told the faction
  couldn't raise enough gold (or metal, wood, food); you see the exact shortfall.

## 1.6.3 (2026-11-18)

### Changed
- **Confirmations for things asked in conversation have three answers**: the action itself, **Not now** and
  **Decline (silent)**. "Not now" lets the person know it was called off (they acknowledge it briefly and move on, no
  questioning); "Decline (silent)" just cancels, and they are told nothing. This covers garrisons, camps, recruiting,
  setting and applying troop templates through the General, imports and exports through the Steward, deposits and
  withdrawals, and every other confirmation that comes from conversation. Esc is the silent option. Confirmations you
  turned off in the MCM simply go ahead, so nothing is said either way. Dashboard confirmations keep two buttons.

## 1.6.2 (2026-11-18)

### Fixed
- **Choosing an outfit template didn't change what a Captain, Commander or officer wore** (Conquest of Skyrim only
  dressed them on the next cell load). They now change into it as soon as you close the template's inventory.

### Added
- **"Wear outfit template 1"** in conversation (Captains, Commanders and officers): opens that template's inventory to
  fill or adjust it, and they change into it when you close it. "Wear something different" still opens the template
  picker.

## 1.6.1 (2026-11-18)

### Fixed
- **Culture reached too few people.** Everyone in your faction's Conquest of Skyrim factions (army, guards, fort
  commanders, the General's and government factions, court mage) now counts as a member: they get the culture,
  leadership style and conduct, and the fighting ones the military doctrine. The culture is framed as their own beliefs,
  under its own heading in the character prompt.
- **Asking a commander about "culture" opened their outfit menu.** The outfit action is now only for plain requests
  to change clothes or armour, and opening an outfit menu from conversation asks first
  (MCM > Confirmations > Opening an outfit menu in conversation).

### Changed
- Guardrails for your people: the General, captains, commanders and soldiers never fret about gold (that's the
  leader's and the Steward's business); the Steward sticks to the treasury, supplies, trade, taxes and towns and leaves
  defence to the General; clearing bandit camps is never described as profitable; reputation and honour aren't
  talked about (nothing measures them). Also in the request prompt and the knowledge pack.

## 1.6.0 (2026-11-18)

### Fixed
- **The faction screen took about 4 seconds to appear** (it looked as if it only opened after the pause menu). It now
  opens at once with the header and fills in the tab a moment later; each tab only gathers what it shows.
- **Clicking "Done" in a menu opened from the dashboard closed the dashboard too.** Troop outfits, armour upgrades,
  town upgrades and commander outfits now open over the dashboard and return to it. When Conquest of Skyrim opens an
  inventory (to dress a troop type, say), the screen steps aside and comes back afterwards.
- **Slow or missing feedback on the dashboard**: every action says "Working…" at once and then shows the result in green,
  or the reason it failed in red (declaring war, trades, deposits, orders, taxes, stars...). The race and gender ticks
  on the Blacksmith tab, tax buttons and settings change on screen immediately.
- "Saved" messages are green, not red.
- **Actions that could not be done**: the reason shows top left and on the screen, and the NPC is told it did not happen
  (or that you said no in the confirmation), so they don't carry on as if it had.

### Added
- **Recruit through the General**: "Recruit 5 archers and 10 soldiers for Army 5" (or name the army's Captain or
  Commander). Any troop or creature kind your faction can raise; several kinds at once. The confirmation lists each kind
  with its cost, the total gold, the extra food a day and how many can still be recruited today. The General and every
  Captain and Commander know today's recruiting limit (it changes daily).
- **Troop templates**: "Put 10 soldiers, 7 archers and 2 crossbowmen in template 1" (General or Blacksmith). Replaces
  what the template held, costs nothing, asks first. "Apply template 1 to Army 3" shows the full mix before applying.
  The General and the Blacksmith know all five templates; the War Table and Blacksmith tabs list them.
- **Buying supplies in conversation**: people who like you, or have good reason to trade (merchants), sell up to 50
  food, metal or wood at 20 gold each (at least), paid from the treasury. Remembered like sales; buying from outlaws gets
  talked about and makes the next few town grants worth less loyalty. MCM > Economy.
- MCM > Confirmations: "Recruiting troops in conversation".

### Changed
- **Your people are on your side**: officers, captains, commanders, jarls and stewards speak positively and
  constructively, criticise you only when something is truly at stake (once, briefly), stop asking you for decisions
  they can make themselves, and carry out repeated requests about trade, troops, templates and uniforms without complaint.
  Under a Dictatorship, sternness is directed down the ranks, not at you.

### Note
- The crash at Halted Stream Camp happened in the game's physics while loading a bandit from Bandit War.esp, with
  SkyBuild.dll on the stack; Conquest of SkyrimNet was not involved.

## 1.5.0 (2026-11-18)

### Fixed
- **No ConquestOfSkyrimNet.log.** The UI plugin now writes its logs next to `skse64.log` (it looks for that file
  instead of trusting the folder SKSE reports) and starts the log as soon as the game loads. The exact path is shown on
  the faction screen's Settings tab. Script messages still need MCM > Debug > Debug logging.
- **Wrong troop counts per army** (3 troops showed as 2 soldiers, 2 warriors, 2 archers): troops waiting to spawn were
  counted twice. The dashboard and what officers know now match Conquest of Skyrim's own count.
- **Asking the Blacksmith to manage troop equipment opened the commander outfit menu.** The Blacksmith now opens the
  troop equipment menu: troop type (soldiers, warriors, archers, crossbowmen, city guards, battlemages), then one outfit for
  all or separate outfits for men and women, as in Conquest of Skyrim.
- **Captains and Commanders following you never made requests.** An army marching with you now counts as something
  notable, the LLM is told which armies are with you, and without SkyrimNet (or when it doesn't answer) army leaders
  can still ask for weapon repairs, drills, rations or iron.
- Trading from the dashboard's Steward tab no longer opens a second confirmation; only trades proposed in conversation do.
- The AI calls the faction's food, metal and wood its **supplies**, not "stores".
- Fixed two Conquest of Skyrim bugs: removing a race from the second page of the race list removed the wrong race, and
  "Disable gendered outfits" for battlemages turned them on.

### Added
- **Culture tab**: what your faction is and does (general knowledge across Skyrim), a **leadership style**
  (Laissez-faire, Democratic, Dictatorship or your own words) that your officers, captains, soldiers, jarls and stewards
  follow in how they speak to you and to each other, and a **military doctrine** for the General, captains, commanders and
  soldiers. Kept in your save. Leadership style is also in the MCM (Culture page). SkyrimNet decorator: `csn_culture`.
- **Blacksmith tab** (next to your Blacksmith): outfits by troop type, better standard armour, and which races and
  genders may join your army, with a button to apply the change to current troops.
- **Leaving office** in conversation: the leader can remove a General, Steward, Blacksmith, Court Wizard, Captain or
  Commander, or the jarl or steward of one of your towns, and they can ask to step down of their own accord (you can
  refuse). The General can remove a Captain or Commander on your orders. Confirmation switches for both.
- **Appointments made in conversation ask first** (General, Steward, Blacksmith, Court Wizard, Captain). Switch:
  MCM > Confirmations > Appointments in conversation.
- **Selling supplies in conversation**: people of means who like you (merchants, a jarl's court, mill and mine owners, a
  camp's chief) buy up to 50 food, metal or wood at 10 gold each, straight into the treasury. The deal is remembered;
  selling to bandits, the Forsworn or thieves gets talked about and makes the next few town requests worth less loyalty,
  honest trade makes them worth a little more. Price, limit and how much they must like you: MCM > Economy.
- **Top-left messages** for everything done in conversation: appointments, orders (including orders the General passes
  on), trades, war, removals, sales.
- **Header quick view** on every tab: treasury, food, metal, wood and the gold you carry.
- **Pause the game while menus are open** (MCM > General, or the Settings tab). Off by default.
- Converted Conquest of Skyrim menus put Back / Previous / Next / Done in their own row at the bottom, styled apart from
  the choices.

### Changed
- **Battle size** is now 8 v 8, 16 v 16 or 32 v 32 (MCM and Settings tab) instead of a slider.
- "Dismiss" and "Relieve" on the dashboard say they ask first ("Dismiss…"); the Armies tab explains that an army's
  "Set outfit" overrides the troop-type outfits from the Blacksmith tab.

## 1.4.0 (2026-11-18)

### Fixed
- **Faction menu hotkey did nothing.** MCM Helper saves its settings file with a byte-order mark, so the UI plugin
  never found the `[Hotkeys]` section. Fixed, and the key is now also registered in Papyrus (`RegisterForKey`), so it
  opens the faction screen however the settings file is written. Esc or the key closes it.
- **MCM Difficulty page was empty.** The MCM script refreshed the menu while it was opening; that is gone, and the
  difficulty values are synced from the game on every load instead.
- **"Import 3 food from the Imperials" only opened the Steward tab.** The Steward now opens the trade confirmation
  straight away, filled in with side, material, direction and amount. Numbers like "3 units" are understood.
- **Towns no longer complain about taxes at 0%.** Requests never ask to lower taxes below 0% or raise them above 50%
  (rules and LLM alike), and townsfolk are told when their taxes are at the lowest level.
- SkyrimNet knowledge conditions written with `||` (not understood by SkyrimNet's templates) now use `or`.
- The UI plugin's own log (`ConquestOfSkyrimNetUI.log`) is written again; its folder is found even when SKSE can't report it.

### Changed
- **Captains**: an army leader with no stars is a **Captain** ("Captain Faendal"), and a **Commander** once awarded a
  star. Screens, knowledge and the recruit dialogue ("I want you to lead my troops as a Captain!") and the
  tutorial objective ("Recruit your first captain") say so. Army leaders know whether they are a Captain or, say, a
  3-star Commander, and who their rivals are.
- **Trade confirmation** (conversation and Steward tab): an amount picker with -100, -10, -1, +1, +10, +100 and typing,
  showing the daily cost or income.
- The "Manage" button next to claims is gone.

### Added
- **Stars (medals)**: the leader (War Table or Armies tab) or the General (in conversation) awards a Captain or Commander
  a star for 10,000 gold from the treasury, up to five each. Each star gives that army's troops +10% health and stamina.
  Dismissing an army leader removes their stars. Confirmation switch: MCM > Confirmations.
- **The General knows each army's post** (task and where its leader is now), rank, stars and troops.
- **Knowledge for every Conquest of Skyrim faction** (`CS_PlayerArmyFaction`, `CS_PlayerGuardFaction`,
  `CS_PlayerArmyCommanders`, `CS_ASICFaction`, `CS_StewardFaction`, `CS_JarlFaction`, `CS_CourtMageFaction`,
  `CS_HousecarlFaction`, `CS_PlayerFactionGovernment`, army duty factions, enemy commanders, prisoners...): who they are,
  whom they obey, whom they command, and which orders they can give or carry out and what they need to know for it
  (for example the General names the army leader and the fort to garrison).
- **Requests decided by SkyrimNet**: "How often should it study events to create requests?" (every N hours or days),
  with "Skip if nothing notable happened". The dialogue model reads the faction's state and recent events and picks
  the most fitting request, or none (prompt `conquestofskyrimnet/requests` in a small always-installed SkyrimNet bundle).
  Without SkyrimNet, or with the option off, the fixed rules still make tax and trade requests.
- **Town grants**: a city, minor city or village asks for a one-time sum of gold, food or metal for a festival, parade,
  memorial or cause (never something built), stating the loyalty it would earn. Meet in the middle pays half for half.
- **Army requests**: captains, commanders and the General ask for gold, food or metal for drills, sharpening weapons,
  a veteran instructor and the like. Roleplay only, a way to spend late-game riches; the asker remembers your answer.
- **Debug log file**: `Documents\My Games\Skyrim Special Edition\SKSE\ConquestOfSkyrimNet.log` (MCM > Debug >
  Debug logging), shown in the MCM and on the Settings tab. Nothing is written to the Papyrus log any more.

## 1.3.0 (2026-11-17)

### Added
- **Taxes per town**: raise or lower taxes (0-50%, steps of 10%) in any village, minor city or major city you rule.
  Steward tab buttons, or ask in conversation (SkyrimNet action `CSN_SetTaxes`: your Steward for any town, a town's
  steward or jarl for their own). Confirmation switch on MCM > Confirmations. Taxes are shown on the Lands tab and
  are part of what stewards and jarls know.
- **Requests from your government**: town stewards, jarls and your Steward ask to lower or raise taxes, send or take
  food, or take spare metal and wood, based on the town's real loyalty, food balance and production.
  - **Requests tab** (history log): every request with who asked, why, and its status; Accept, Deny, or Meet in the
    middle where a number in between exists. Denying costs 2 loyalty in that town; unanswered requests are withdrawn
    after 10 days. Decisions become town news and SkyrimNet memories, and the person who asked remembers.
  - **Physical Letters** (optional, https://github.com/zevck/Physical-Letters): requests arrive as letters written by
    the person asking, by courier. Reading one opens the decision; writing back works too (the writer acts on your
    answer through the letter action `csn_request_answer`).
  - Without Physical Letters: the notification "A new request has come in from (your faction)".
  - MCM page **Requests**: on/off, days between requests, send as letters.
- **FOMOD**: the package is now a FOMOD installer (core, optional SkyrimNet knowledge, and an "Optional requirements"
  page that lists Physical Letters and marks it Recommended when installed).
- Three-button choice dialog in the UI plugin (`OpenChoice`).
- Knowledge pack: what stewards and jarls may ask for.

## 1.2.0 (2026-11-17)

### Fixed
- **Faction name, player name and dates missing from menus.** Titles like "The Economy of <Alias=FactionName>"
  and law texts ("<Alias=Player>, Leader of ... on <Global.WeekDay=GameDaysPassed>...") now show the real
  names and date. The UI plugin fills `<Alias=...>`, `<Alias.Pronoun/Cap/...=...>` and `<Global.Day/MonthWord/
  Year/WeekDay=...>` in titles, text and buttons, the same as the game does.
- **War Table and Steward tabs didn't highlight or open.** Papyrus could hand the tab name back capitalised
  ("General"), which matched nothing. Tab names are now compared case-insensitively.
- SkyrimNet actions were registered without their parameter list, so orders like "garrison Fort Greymoor" lost
  their target. Every action now declares its parameters.

### Removed
- **Command Seal** (hotkey, screen and MCM entry).
- **Friends-only commanders.** Anyone who isn't hostile can lead an army or hold an office (the dialogue condition
  and the script check are gone; the tutorial objective now reads "Recruit your first commander").

### Changed
- **Redesigned faction screen**: dark and light themes (MCM or Settings tab), clearer cards, tables and buttons,
  Yes/No confirmation dialogs, line breaks in CoS messages.
- **Tabs**: Overview, Officers, Armies, Lands and Settings are always there. **Steward** only appears when the
  screen is opened next to your Steward, a town steward or one of your jarls; **War Table** only next to your General.
- **Officers** are appointed in conversation or from a list of people nearby (Officers tab).
- **NPC Name Distributor**: names it gives are kept; titles are added in front and removed cleanly.
- Order "Patrol a hold" is now what it always did: **Garrison a city** (cities you rule).

### Added
- **Treasury**: deposit any amount from your purse (refused if you don't carry it) or withdraw any amount, through
  any steward of the faction (screen or SkyrimNet).
- **Make camp**: the General (or a commander) sets up an army camp, or an attack camp in land you don't hold yet,
  in any hold your armies can reach.
- **Garrison a city / a fort** you control, from the War Table or by asking the General or the commander.
- **Outfits** for the General, Steward, Blacksmith, Court Wizard and commanders (same menu as "I want you to wear a
  different outfit" > "Let me edit what you need to wear").
- **Town trade offers**: jarls and stewards of your towns propose sending more or less food, metal or wood
  to or from their town; also set by hand on the Steward tab, with building upgrades per town.
- **Buying a city**: a jarl whose side is at peace with you can bring their city over to your faction for gold
  from the treasury (least price on MCM > Economy; minor cities ask half).
- **Confirmations** for all of the above, each switchable on MCM > Confirmations.
- **Difficulty** (MCM and Settings tab): battle size per side (4-40, e.g. 8 v 8, 16 v 16, 32 v 32), reinforcement
  speed, hours before enemy armies return and refill. Kept in sync with CoS's own settings.
- **Debug**: win or lose the current battle (MCM and Settings tab).
- **Skip tutorial** (MCM and Settings tab): jumps the faction questline to declaring war.
- **What officers know** (SkyrimNet decorator `csn_officer_knowledge`, exact figures, never guessed):
  - Steward, General, Blacksmith, Court Wizard: treasury, food, metal, wood, daily changes, trade agreements, towns ruled.
  - Your Steward: buildings (barracks, farms, lumber mills, mines) and trade of every town you rule;
    town stewards and jarls: their own town.
  - General: every commander, troop mix (soldiers, warriors, archers, crossbowmen, mages...), task, and the battering
    rams, ladders and catapults ready.
  - Blacksmith: each army's equipment.
  - Commanders: their own troops, plus the cities and forts they can be sent to.
- **New laws are memory events**: conscription, crime punishments and religion decrees become town news,
  SkyrimNet memories and lasting knowledge for the people they affect.
- Knowledge pack: General's duties, town trade, jarls changing sides; stewards' treasury duties.

## 1.1.0 (2026-11-17)

### Renamed
- **Faction Forge is now Conquest of SkyrimNet.** Plugin `ConquestOfSkyrimNet.esp`, UI plugin
  `SKSE/Plugins/ConquestOfSkyrimNetUI.dll`, menus in `PrismaUI/views/ConquestOfSkyrimNet/`, scripts `CSN_*`
  (CSN_Core, CSN_World, CSN_SkyrimNet, CSN_Config, CSN_MCM, CSN_Native, CSNP), SkyrimNet actions `CSN_*`.
- Because the plugin file name changed, saves made with `FactionForge.esp` do not carry over. Uninstall
  Faction Forge and start a new game (or a clean save made without it).

### Fixed
- **Ledger hotkey opened an empty PrismaUI screen with the cursor stuck on it.** Papyrus stores strings
  case-insensitively, so the menu data it built could come out as `True`/`Name` instead of `true`/`name`,
  which broke the data the screen received. The UI plugin now cleans the data (lower-case keys, JSON
  true/false/null) before it reaches the screen, and the screen shows a message instead of going blank
  if anything still fails.
- **You can always get out of a screen.** Esc, or the ledger hotkey again, now closes the faction screens
  from the UI plugin itself, even if the page has an error.
- Screen errors are written to `Documents/My Games/Skyrim Special Edition/SKSE/ConquestOfSkyrimNetUI.log`
  (the plugin did not write a log before).

### Changed
- **Hotkeys are unbound by default.** Set "Faction ledger" and "Command Seal" in the MCM.
- Economy values (trade price, hunting food, guard and miner cost) moved from
  `StorageUtilData/FactionForge/config.json` to the MCM.

### Added
- **MCM menu** (needs MCM Helper and SkyUI), four pages:
  - General: ledger and Command Seal hotkeys, use PrismaUI menus on/off, big-news notifications, "Open the ledger now".
  - Economy: trade price, food per hunting soldier, guard cost, miner cost.
  - SkyrimNet: SkyrimNet features on/off, town news, townsfolk opinion, how long news lasts,
    how big a loyalty change people notice.
  - About: version and debug logging.
- **Townsfolk know who rules them.** Every NPC who lives in (or is standing in) a Conquest of Skyrim town
  knows which faction controls it and who sits as Jarl.
- **Townsfolk mood and liking.** Each town's CoS loyalty (0-100) becomes a mood the locals share
  (devoted, content, uneasy, resentful, close to revolt). In towns you don't rule, locals also have an
  opinion of your faction: it rises when you fund their town and falls if you're at war with a ruler they're loyal to.
- **SkyrimNet knowledge pack** (`SKSE/Plugins/SkyrimNet/external/conquestofskyrimnet.skyrimnet/`, a SkyrimNet bundle
  that shows on SkyrimNet's package page). `knowledge/conquest_of_skyrimnet.sknpack` covers how the war of conquest
  works, how town loyalty works, your faction's ranks and chain of command, and what Commanders, the Steward and a
  conquered town's Jarl do. Each entry is always known to the people it concerns (your soldiers, commanders,
  officers, guards and jarls, by their Conquest of Skyrim factions); anyone else recalls it when the conversation
  turns to it.
- **Dynamic knowledge at runtime.** When a town changes hands or a Jarl is named, a dated entry is added to
  SkyrimNet's world knowledge (`AddWorldKnowledge`), known to the people of that hold (by crime faction), e.g.
  "On the 12th of Frostfall, 4E 201: Whiterun has fallen under the control of ...".
- **Town news and memory events.** These become news that townsfolk talk about for 14 in-game days
  (adjustable), and are recorded as SkyrimNet memory events (`RegisterPersistentEvent`: remembered, without
  making anyone start talking):
  - a town changing hands (also a corner notification);
  - a new Jarl being named or removed;
  - loyalty rising or falling noticeably;
  - farms, lumber mills, mines or barracks being funded, with the Jarl's court named when a Jarl helps
    (for example "The farms of Whiterun are being expanded, paid for by ... with the help of Jarl ...'s court");
  - battles, sieges, raids, ambushes, coups and protests starting and ending. A battle starting is also
    narrated to the people nearby (`DirectNarration`), so they react out loud.
- **Faction ranks and hierarchy in SkyrimNet.** New `csn_hierarchy` knowledge tells the people who would
  know (your officers, commanders, soldiers, friends, and the townsfolk of towns you rule) how your faction
  is organised:
  - the leader;
  - the four officers and what each does;
  - who answers to whom;
  - the current office holders and commanders;
  - the NPC's own place in it.
- New SkyrimNet decorators `csn_town_context` and `csn_hierarchy`, used with `csn_faction_context` by the bundle's
  character bio module `prompts/submodules/character_bio/0650_conquestofskyrimnet.prompt` (now in the bundle
  instead of SkyrimNet's prompts override folder).
- User guide: `Docs/ConquestOfSkyrimNet/UserGuide.md`.

### Requirements
- Unchanged: SKSE, PapyrusUtil, PrismaUI, SkyUI.
- New: **MCM Helper** (for the menu; without it the defaults apply and hotkeys stay unbound).
- Optional: SkyrimNet 0.25 or newer.

## 1.0.0 (2026-11-17) - as Faction Forge
- Standalone fork of Conquest of Skyrim 0.3.9: every menu drawn in PrismaUI.
- Added:
  - officer titles (General, Steward, Blacksmith, Court Wizard) and Commander titles;
  - friends-only commander hiring;
  - the faction dashboard (overview, claims, war table, steward ledger);
  - steward trade at 10 gold per unit;
  - SkyrimNet actions for appointments, hiring, army orders and steward business.
