# Conquest of SkyrimNet - User Guide (2.1.15)

The full version of this guide is kept online; this is the in-game-folder copy.

## Install
Requires SKSE, PapyrusUtil, SkyUI + MCM Helper (settings menu), PrismaUI (menus).
Optional: SkyrimNet (conversation, knowledge, memories); Physical Letters (requests arrive as letters).
1. Remove Conquest of Skyrim (conquerskyrim.esp) if installed: this mod replaces it.
2. Install ConquestOfSkyrimNet_v<version>.zip and enable ConquestOfSkyrimNet.esp.
3. Installer: keep "SkyrimNet knowledge" ticked if you use SkyrimNet. The "Optional requirements" page shows
   whether Physical Letters was found (it is marked Recommended when it is).
4. Start a new game, or continue a save made with an earlier version of Conquest of SkyrimNet.

## First steps
- Read "Start my Faction": pick a faction name, army prefix and banner.
- MCM > Conquest of SkyrimNet > General: bind "Faction menu" (unbound by default). Pick dark or light there too.
- Want to skip the founding tutorial? MCM > Debug > "Skip the tutorial", or Settings tab > Skip.

## The faction screen (your hotkey)
The hotkey opens the tab you had open last, wherever you closed it from (kept in your save); a Steward, War Table or Blacksmith tab whose
officer you no longer have opens on the Overview instead.
It opens at once with the last known figures, marked "Updating content…" until fresh ones arrive; other tabs load
in the background while you read, so switching between them is instant.
The header always shows your treasury, food, metal, wood and the gold you carry.
Always there: Overview, Requests, Officers, Armies, Lands, Unrest & Intrigue, Settlements, Culture, Settings.
- Lands: every town you rule as a card with four tiles (gold, food, metal, wood): what is in store, the daily surplus
  or deficit, and what you trade with it. Beside your Steward, a town steward or one of your jarls the books open on
  the same tab: Take / Send on each tile sets the daily trade (Set seals it), Take / Take all / Send move gold once,
  taxes and upgrades sit on each card, and the Treasury (deposit / withdraw), War and Trade abroad (with the
  Imperials and Stormcloaks) sub-tabs appear.
- Armies: every army with its leader, stars and troops. Beside your General the War Table opens on the same tab:
  siege equipment, recruiting, orders (follow, hunt, return home, garrison a city or fort, make camp in a hold),
  troop upkeep and templates.
- Blacksmith tab: open it next to your Blacksmith. Outfits by troop type (one for all, or men and women apart),
  better standard armour, and which races and genders may join your army ("Apply to current troops" re-raises them).
  An army's own "Set outfit" (Armies tab) overrides the troop-type outfits for that army.
Trades agreed in the books are sealed at once; a trade the Steward proposes in conversation asks for the amount
(-100/-10/-1/+1/+10/+100 or typing) first. Esc or the hotkey closes the screen. Every action shows "Working…" and then its result in green, or in red why it
couldn't be done; menus opened from the screen return to it when you click Done.
MCM > General > "Pause the game while menus are open" (or the Settings tab) pauses the game behind every menu.

## Claims
Clear a claimable camp, cave, tower, mine, fort or farm (87 places, listed in README.md) of every enemy (bandits,
Forsworn, necromancers, warlocks, giants, Thalmor, bears), stand in it and use the Place Banner power. Each claim opens
an army slot (up to 30); the first is your base. Activate the banner to hire guards (any claim), miners (mines: +2
metal a day each) or farmhands (farms: +2 food a day each), or to make it your base of operations.
New in 2.0.0: Fort Frostmoth, Northwatch Keep, Northwind Mine, Sarethi Farm, Honeystrand Cave, Alchemist's Shack and
Lost Prospect Mine.

## Culture
Culture tab: pick a title if you want one (Supreme Leader, Jarl, High Priest, Master, or type your own); your
troops, officers and subjects then call you by it ("Supreme Leader", "Supreme Leader Trey"). Only your own people
(your faction, Thanes and housecarls, and the people of towns you rule) know the title; outsiders use your name.
Leave it on None for your name alone. write what your faction is and does (everyone in Skyrim knows it), pick a leadership style and write
your military doctrine (known to your General, captains, commanders and soldiers). Everything is kept in your save.
- Laissez-faire: your people are casual with you and each other and speak their minds.
- Democratic: order and hierarchy, sir and ma'am for higher ranks, opinions through proper channels.
- Dictatorship: strict and stern iron-fist rule; orders obeyed at once, harsh criticism is normal.
- Other: describe it in your own words.
The leadership style is also on MCM > Culture.

## Officers
- Appoint in conversation (CoS dialogue or SkyrimNet), or Officers tab > Appoint... > pick someone nearby.
  Anyone who isn't hostile can serve; commanders no longer need to be your friends.
- Outfit button (officers and commanders) opens the same outfit menu as "I want you to wear a different outfit".
- Names from NPC Name Distributor are kept; titles go in front ("Steward Ysolda").
- Outfits: "wear something different" opens the outfit template picker; "wear outfit template 2" opens that
  template to fill in. Either way they change into it when you close the inventory.
- Appointments made in conversation ask you first.
- Removing someone: tell them in conversation that they are relieved (officers, Captains, Commanders, and the jarls and
  stewards of your towns), or ask your General to remove a Captain or Commander, or use Relieve / Dismiss on the
  dashboard. Anyone can also ask to step down; you can accept or refuse.

## Thanes
Name a Thane of a hold your faction controls (you rule its city) for 1,000 gold, up to 3 per hold plus 1 for each settlement founded in it (abandoning one takes the extra place away): tell them in
conversation ("I name you Thane of Whiterun"), or Officers tab > Name a Thane… (pick someone nearby and the hold).
Anyone who is a friend of yours can be named (any race, even people who serve the Empire or the Stormcloaks), but
not guards, prisoners or people already in your faction's service; officers, Captains, Commanders, jarls, stewards
and housecarls can't. Thanes carry "Thane" before their
name, know their hold and wear its Thane outfit: Officers tab > "<Hold> outfit" opens a chest; put in what they
should wear and close it. Relieve them on the Officers tab or in conversation.
Thanes bring investment proposals (Requests tab): a private venture of theirs needs gold and often food, metal and
wood up front, and pays the faction back 110-135% of it (valued in gold) a little every day for 15-30 days. It's all
or nothing: no meeting in the middle. A venture stops paying if you lose that hold's capital (to another faction or
to an uprising). Your Steward, General, jarls and town stewards know every venture.
Lose the hold's capital and the hold loses all its Thanes: they go back to their own name and clothes, and their
ventures stop.

## Captains, Commanders and stars
Each army is led by a Captain. Award a star (10,000 gold and 100 food, up to five) on the War Table or Armies
tab, in conversation tell the Captain or Commander you are awarding them one, or ask your General to award it: the
Captain becomes a Commander, their troops get +10% health and stamina per star, and the army's morale rises by 15 at
once.
Army leaders know their rank and their rivals'. Every star is a rank: leaders never take orders from one with fewer
stars and respect those with more. Dismissing one removes their stars.
Orders given in conversation, including those your General passes on, show a message top left.

## Army names
Give any army a name (25 letters at most) and, if you like, a purpose, goal or mantra: **Name army…** on the Armies
or Armies tab, or say it in conversation ("call your army the Iron Wolves", or to the General: "name Army 2 the
Iron Wolves, sworn to free the Reach"). The army leader, its soldiers and the General all know the name and purpose,
and you can use the name in orders ("send the Iron Wolves to attack Fort Greymoor"). An empty name gives it back its
number.

## Camps and attacks in conversation
- **Patrol or make camp in a hold**: if your faction already has a war camp there, the army joins it. It marches
  there with the same checks as sending an army to a camp on the war map.
- **War camp plans**: say "let me make war camp plans" to a Captain or Commander at a war camp, or to the General (name
  the hold). You see the targets in that hold (its city, its fort, enemy war camps). If one can't be attacked yet
  (for example you need to control the roads of the hold first), the reason is shown and you can pick another.
  After that comes Conquest of Skyrim's own army selection, siege equipment and battle plan, then the attack starts.
- **Direct orders**: "send Army 1 and Army 2 to attack Fort Greymoor". The armies must be camped or garrisoned in that
  hold. A confirmation lists the target, armies and troops. This order brings no siege equipment; use war camp plans
  for that. Commanders at the camp can propose such an attack for you to confirm.
- **Begin / call off**: while the armies wait at the staging ground, tell a commander in the attack (or the General)
  "it's time to begin the attack", or have them call it off.
- Every attack your faction launches, however you started it, becomes news across Skyrim.

## Stewards in conversation
Ask a steward to upgrade a town's barracks, farms, lumber mills or mines, to hire guards, or to set taxes (0-50% in
steps of 10). Each asks you first with the figures (level and cost, or crime and guards). Your Steward can do it for any
town; a town's steward or jarl only for their own.

Ask the faction's Steward to trade with any city or village you rule ("export 10 food to Riverwood", "import 5 wood
from Whiterun", "stop the metal trade with Dawnstar"); a town's own jarl or steward can do it for their town. If the
new order goes the other way, the confirmation tells you it halts the current exports or imports.

## Taxes
Every town you rule (major city, minor city or village) has a tax rate from 0% to 50% in steps of 10%.
Lower taxes: loyalty rises 10 per step, less gold. Higher taxes: more gold, loyalty falls 10 per step.
Set them on the Lands tab (beside your Steward or a jarl), or ask in conversation: your Steward can change any town's taxes, a town's
steward or jarl only their own ("Lower the taxes in Riverwood to 10%").

## Requests from your government
Every N hours or days (MCM > Requests > "How often should it study events to create requests?") the government
studies what has happened. With SkyrimNet, its Dialogue LLM (prompt conquestofskyrimnet/requests) decides whether someone would ask you for something,
and what; "Skip if nothing notable happened" saves the study when all was quiet. Kinds:
- taxes (never lower than 0% or higher than 50%) and trade with a town;
- town grants: a one-time sum of gold, food or metal for a festival, parade or cause, with the loyalty it would earn;
- army requests from captains, commanders or the General: drills, sharpening weapons and the like (roleplay only).
- security requests (once a leader has a star): a city asks for a famous commander's army in its garrison or at its
  hold's fort. Accepting sends them and earns loyalty; denying costs some.
- upgrade requests: better barracks, farms, lumber mills or mines for a town with no upgrade under way.
Armies marching with you count as something notable, so their leaders ask too. Without SkyrimNet, fixed rules make
tax, trade, army and security requests.
Requests about an army change that army's morale, and the card (and the confirmation in conversation) shows by
how much: an army leader's own request +6 accepted, +3 met halfway, -8 denied; a town asking for a famous army +4 if
you send them, -3 if you refuse. If an upgrade request can't be carried out (not enough gold or wood, an upgrade
already under way), the reason shows on the faction screen and stays on the request's card.
Each request goes into the Requests tab with Accept, Deny and, where there is a number in between, Meet in the middle
(half the sum for half the loyalty). Denying a town costs 2 loyalty. Unanswered requests are withdrawn after 10 days.
- In conversation: tell the person who asked that you accept, deny or meet them in the middle; a confirmation
  follows ("Decline (silent)" leaves no trace).
- With Physical Letters: the request arrives as a letter by courier; reading it asks you to decide, or write back.
  The courier takes a day: the request shows on the Requests tab a day after it was written (or as soon as you read
  the letter), with a notice "A request from ... has reached the faction screen".
- Without it: a notification says "A new request has come in from (your faction)".

## Unrest and uprisings in your towns
Every day each town you rule is checked. Below the unrest threshold (MCM > Rebellion, default 20 loyalty) and with a
grievance, people take to the streets. Grievances: hunger (the town or the faction is out of food), heavy taxes (40%
and up), no garrison to keep order, court cases nobody hears, or plain anger (loyalty under 10).
- Day 1, unrest: a warning and news. If loyalty climbs 5 above the threshold or the grievance goes, it dies down.
- Day 2, uprising: armed townsfolk led by a rebel leader hold the town (CoS's own rebel soldiers and, where CoS
  picked one, a real townsperson as leader). No taxes reach the treasury while they hold it, and loyalty falls by 3 a
  day.
- Ending it:
  - Send an army (Unrest tab, or tell your General, a Captain or Commander): it marches there (some hours, by
    distance) and the fight is decided when it arrives; the army loses troops either way, more if it loses. Crushing it by force costs 5 loyalty.
  - Meet their demands (Unrest tab, or tell the rebel leader or the town's jarl or steward you'll meet them):
    gold for the families, food if they're hungry, and taxes one step lower. Loyalty rises by 15.
  - Crush it: go there and kill the rebel leader. The rest lay down their arms.
  - Garrison it: a garrison at least twice the rebels' number breaks the rising the next day, but loyalty drops by 5.
- Left alone for the set days (MCM, default 3) the rebels open the gates to whichever side is at war with you (or the
  town's old allegiance). Each town gets a few calm days after a rising ends.

### In your journal
- "Unrest in <town>": starts with the unrest (calm it; the town is marked on your map), moves on when the town rises
  (end the uprising; defeat its leader, marked once known; leaving the town fails that step until you return), adds "defend the town" when the rebels storm it, and is completed when it
  ends, or failed when the town is lost. Up to three towns at once.
- "Deserters at <place>": when an army breaks away (deal with them; defeat their leader, marked), with "defend your
  city" while they attack; completed when they are beaten, paid off or recognised. Up to two at once.
- The coup ("The Coup"): after confronting the jarl, the journal follows the guards' choice (waiting for them,
  turning on the jarl, siding with you) and the fight if they stand by the jarl.
Trouble that began before these quests existed gets its journal entry when you next load.

### Rebel attacks on your cities
The rebels get a turn of their own, like the Imperials and Stormcloaks: once a day, when the economy updates, every
rebel force may attack one of your hold cities, fought in Conquest of Skyrim's own city battle with its rebel
soldiers (quest CSN_DefendCityRebels).
- Who attacks: a hold city that has risen up storms itself; a free company attacks a city you hold in its own hold,
  else the least-garrisoned one in a bordering hold.
- Chance: MCM > Rebellion > base chance (25%), +10 for each day an uprising has lasted, +1 for every 4 soldiers of a
  free company, +10 if the city has no garrison, +10 once a company has proclaimed its realm, up to 90%. The most
  eager force is the one that tries.
- As with CoS's own attacks, only one battle runs at a time: nothing starts while a city, fort or camp is under
  attack.
- Defend it in person or let it be decided for you by your garrison. Held: an uprising is broken, a company loses its
  dead (and breaks up under 5). Lost: the city goes to the Imperials or the Stormcloaks, and a company carries off a
  tenth of your treasury.
- With rebel attacks on, a city uprising that is never resolved hands the city over after twice the set days;
  villages (no city battle in CoS) still go after the set days. Turn rebel attacks off in the MCM to go back to that
  for every town.

## Army morale and free companies
Each army has morale (0-100), shown on the Unrest tab. Every day it drops for unpaid wages (an empty treasury, or one
the day's costs would empty), empty bellies (no food) and refused
requests from its leader. With no complaints it climbs back. A star for the leader gives +15 at once (shown in the
confirmation), a granted request +6, a refused one -8. Captains and Commanders know their army's morale, its
complaints and what last changed it.
- Under 30 the troops grumble openly (you are told, and their leader talks about it).
- Under the breaking point (MCM, default 15, 2 lower for every star the leader holds) with a complaint, the army may
  break away. Its leader and troops leave the faction as a free company that holds the fort, town or hold where it
  was posted, and is hostile to you.
- A free company raids you every day (20 gold and half a food per soldier), costs loyalty in the hold, may lure other
  unhappy armies to join, and after 3 days proclaims its own free realm and keeps recruiting.
- Dealing with them (Unrest tab, or in conversation):
  - Go to where they hold and kill their leader.
  - Send a loyal army: the odds depend on troops, stars and morale; win and they are destroyed, lose and your army
    falls back with its morale shaken.
  - Pay their arrears (150 gold and 1 food per soldier): the leader swears back in as a Captain (the army is raised
    again from scratch).
  - Recognise their realm: the raids stop and they keep what they hold, but every town you rule loses 5 loyalty.

## Bribery, persuasion and coups
In each hold city ruled by the Imperials or the Stormcloaks two measures are kept (Unrest tab > Intrigue): how ready
the guards are to betray the jarl, and how much the nobles and citizens back you. A loyal city starts with loyal
guards; the people start from how much they like your faction.
- Bribe guards or fund supporters from your own purse, on the tab or in conversation with a guard, noble, merchant or
  citizen ("take this gold and remember who your friends are"). Court members and merchants cost half. Each payment
  can be reported to the jarl (the risk is shown; better Speech lowers it): half of it is wasted and support drops.
- Or ask your Steward or General ("have our agents bribe the guards of Solitude", "fund the nobles of Markarth",
  "tell your agents to plan the coup on Riften"): their agents pay from the treasury instead of your purse. Bribing in person means
  talking to a guard of that city; funding means talking to a noble, merchant or citizen of that city (not its jarl).
- Persuade people in conversation for free: once a day per person, decided by your Speech, their opinion of you and
  how loyal the city is.
- Plan a coup once the guards or the people are at 40 or more (on the tab, or ask a guard or noble who's on your side
  to set it in motion). This starts Conquest of Skyrim's own coup: go to the jarl's hall, the crowd gathers with
  torches (more the more people back you) and you confront the jarl. In Whiterun this happens in the Wind District
  outside Dragonsreach, where CoS set it up; in the other cities the crowd and guards gather around the jarl, wherever
  the jarl is (usually the throne). Then:
  - guards 80+ and people 40+: the guards arrest the jarl;
  - guards 40+ and people 60+: the guards argue, then side with you;
  - otherwise the guards stand by the jarl and you fight them, the citizens at your side (a hostile takeover).
  While the guards choose, the jarl is marked; if their talk doesn't play out within a minute, they act on their choice.
  Win and the city is yours. Lose and you are arrested; you can try again in 7 days with half the support left.
- Taking a city of a side you're at peace with this way will not go unnoticed (you're warned before it starts).

## Settlements
Found settlements on open land and build them up (MCM > Settlements; Settlements tab).
- Founding: stand outdoors in a hold whose city or roads your faction holds, away from towns and other settlements,
  and press Found it (or ask your Steward or General to found a settlement here). It costs 2,000 gold and 40 wood
  (MCM). A banner post marks its heart; you can build about 70 paces around it. Up to 8 settlements.
  Each settlement gets a map marker with its name (renaming it renames the marker), so you can fast travel there;
  abandoning it removes the marker.
- Building: go there and open the Settlements tab. Your settlement's card lists everything you can build, by group,
  with its cost (gold, wood, metal) and what it gives; what you can't afford yet is greyed out. Press Build, place it.
  (The Build menu button, or asking your Steward, General or a settler, opens the same choice as a menu.)
  Every building gives the settlement something it counts:
  - Homes: tent (comes with two bedrolls), bedroll, farmhouse, large farmhouse, longhouse: beds, so more settlers.
  - Food: cabbage, potato and wheat fields (nine harvestable plants), beehive, windmill, farm shed.
  - Industry: lumber mill (with its log pile and saw) and chopping block (wood); smelter, smithy and forge (metal);
    anvil, tanning rack, alchemy lab, enchanter (gold).
  - Trade: inn, market stall (gold). Comfort: well and campfire (food, happiness), banner (gold, happiness).
  - Defense: watchtower (+5 defence, tolls), stockade wall, barricade, training dummy, archery target (defence, a
    little gold).
  - Storage: storage chest (food, wood), fine chest and strongbox (gold), weapon rack (defence, gold). They are real
    containers you can use.
- Ready-made layouts (same card): starter camp, farmstead, lumber camp, mining camp, outpost, market square. Place the
  first building: the whole layout floats in front of you, outlined, and is set in one go at the listed total cost.
  Page Up/Down raise or lower all of it. Pick fairly flat, open ground.
- Snapping (same card, or while placing): grid off / 1 / 2 / 4 paces (Home), turns free / 15 / 45 degrees (End), so
  walls and fences line up.
- Buildings here: the card lists your settlement's buildings nearest first, with Move and Take down. Moving is free:
  the building is picked up into build mode; Backspace puts it back where it was. Take down returns half the cost.
  Build mode: a box lists the controls first (Start placing / Cancel); the building then floats in front of you,
  outlined with a glow, and a reminder of the controls shows now and then. Walk and turn to move it, Left/Right arrows
  rotate it, Up/Down move it farther or nearer, Page Up/Down raise or lower it, Enter or Activate places it, Backspace
  cancels. The cost (gold from the treasury, wood and metal from the supplies) is paid when it is placed.
  Everything is from Skyrim and Hearthfire, so no extra downloads are needed.
- Settlers arrive (1-2 a day) while there are free beds and happiness is 40 or more, and leave when it falls under 25.
  Up to eight of them live there (wandering, sitting, sleeping, using fires and workbenches); the rest are counted. They fill the jobs; buildings with jobs produce in
  proportion.
- Who moves in depends on what you build: farmers for fields, beehives, windmills and farm sheds (some always come);
  woodsmen for the lumber mill and chopping block; miners and smiths for the smelter, smithy, forge and anvil;
  traders for the inn and market stalls; an alchemist for the alchemy lab; sellswords for watchtowers, walls,
  barricades and training targets. Each settlement's card shows who it draws ("mostly woodsmen, some farmers").
- The lumber mill comes with its log pile and working saw, like the mills in Skyrim.
- Update navmesh (Settlements tab): asks SkyBuild to rebuild the navmesh around you so settlers, soldiers and
  followers walk around what you built; progress and the result show top left. Needs SkyBuild installed and the
  installer's SkyBuild option ticked, with Conquest of SkyrimNet loading after SkyBuild.
  Your settlement's buildings are added to SkyBuild's own placed objects, so the new navmesh goes around them.
- The banner: a settlement's heart is the same banner as a claim's. Activate it to hire up to five guards (250 gold,
  then 10 gold and 1 food a day, +3 defence each) or dismiss them.
- Armies: each settlement lets you raise one more army. Once that army is raised, the settlement can't be abandoned,
  and every bandit raid that wins there lowers the army's morale.
- Fix settlers (Settlements tab): if settlers just stand around or wandered off, this brings them back to the banner
  post, gets them going again and replaces any that went missing.
- Each day the settlement's food (after the settlers eat), wood, metal and gold (plus 2 gold tax per settler) go to the
  faction's stores.
- Defence: watchtower +5; stockade wall, barricade, training dummy and archery target +1 each; +1 for every 4
  settlers.
- Raids: each day the chance is 10% minus the defence, plus 1 for every 10 happiness under 50 (at least 2% once
  anything is built), and never within 3 days of the last raid. The Settlements tab and your officers know the risk.
  If you are there you fight the bandits; if not, the settlement holds when defence x3 (plus a little luck) beats
  bandits x4, cheering people up, or loses a building and two settlers.
- Your Steward, General, and the jarls, village leaders and stewards of your towns know how settlements and raids
  work and how each settlement is doing; any of them (or a settler) can open the build menu where you stand.

## Recruiting and troop templates
Ask your General: "Recruit 5 archers and 10 soldiers for Army 5" (or "for Captain Aerina's army"). Several kinds at
once; the confirmation lists each kind and its cost, the total gold, the extra food a day and how many troops can still
be recruited today (a limit that resets daily). The War Table shows today's limit.
Templates (General or Blacksmith): "Put 10 soldiers, 7 archers and 2 crossbowmen in template 1" replaces that template
(it costs nothing). "Apply template 1 to Army 3" shows the mix first; the army then refills to it.

## Selling supplies
In conversation, people of means who like you (merchants, a jarl's court, mill and mine owners, a camp's chief) buy
up to 50 food, metal or wood at 10 gold each; the gold goes straight into the treasury. They remember it. Selling to
bandits, the Forsworn or thieves gets talked about and makes your next few town grants worth less loyalty; honest
trade makes them worth a little more. You can also buy: up to 50 at 20 gold each from the treasury. Working people sell what they produce to anyone:
food from farm folk (every farm and farm household in Skyrim and Solstheim, the Battle-Borns, people who buy wheat
for favours), metal from mine folk (miners, mine owners and their households, Raven Rock and Kolbjorn), wood from
lumber camps and mills (mill owners and workers, Hearthfire's lumber sellers, people who buy firewood). Merchants
sell all three; anyone else only if they like you. MCM > Economy: prices, limits, how much they must like you.

## Confirmations
Deposits, withdrawals, camps (and joining a camp), beginning or calling off an attack, city/fort garrisons, city trade offers, tax changes, buying a city, appointments in
conversation, removals, resignations and sales each ask first.
Turn any of them off on MCM > Confirmations. When the request came from conversation you get three answers: go ahead,
"Not now" (they're told it's called off and let it go) or "Decline (silent)" (cancelled, nothing said; also Esc).

## Difficulty and debug
MCM > Difficulty or Settings tab: battle size (8 v 8, 16 v 16 or 32 v 32), reinforcement speed,
hours before enemy armies return and refill. Debug: win or lose the current battle.

## SkyrimNet
- Ask NPCs to take posts, leave them, lead armies, follow orders, garrison, make camp, change outfits, take or pay
  out gold, raise or lower taxes, buy your supplies; ask your Blacksmith to manage troop equipment or armour.
- Officers know the exact treasury and supplies; the General knows every army's troops and the siege equipment;
  the Blacksmith knows each army's equipment; commanders know their own troops; stewards know the buildings and
  trade of their towns (your Steward knows all of them).
- Jarls and stewards of your towns may offer to change what your faction sends to or takes from their town.
- A jarl of a side you're at peace with may sell you their city and hold, or their hold's main fort; General Tullius
  and Ulfric Stormcloak can likewise sell forts their side holds while at peace with you. Each names their own asking
  price (never under 500,000 gold for a hold or 80,000 gold for a fort, MCM > Diplomacy), plus any food, metal and
  wood they want, and remembers it: ask again later and you hear the same price, unless they change it for a
  reason (a notice tells you when they name or change one). The deal is always made at that remembered price.
  A jarl may also hand it over for free, at their discretion: under duress, for a great favour, or in partnership.
  None of them learn what your treasury holds.
- Unrest and plots: townsfolk know when their town is restless or has risen; rebel leaders, jarls and stewards can
  accept your terms; soldiers know their army's morale and complaints; deserters know their company and what they
  want; guards and nobles of enemy cities take bribes, can be persuaded and can set a coup in motion; settlers know
  their settlement, and your Steward and General know them all.
- Memory events: towns changing hands, new jarls, loyalty shifts, funded upgrades, battles, new laws
  (conscription, punishments, religion), deposits, orders.

## Troubleshooting
- Hotkey does nothing: set it in the MCM; found your faction first. Turn on MCM > Debug > Debug logging and look in
  ConquestOfSkyrimNet.log, next to skse64.log (the full path is on the Settings tab) for "hotkey pressed".
- No requests: MCM > Requests must be on, and a town you rule has to need something (low loyalty, a food
  shortage, spare goods). No letters: check MCM > Requests > "Send them as letters" and that Physical Letters is active.
- No books on Lands / no War Table on Armies: stand closer to your Steward or General (MCM > General > Officer reach).
- Vanilla boxes instead of PrismaUI: PrismaUI or ConquestOfSkyrimNetUI.dll missing, or MCM option off.
- Blank/stuck screen: Esc or hotkey; send Documents/My Games/Skyrim Special Edition/SKSE/ConquestOfSkyrimNetUI.log.
- Don't uninstall mid-save; start a new game.

## Festivals (with the Holidays mod)
With Holidays by isoku installed (Holidays.esp), the lore's holidays are celebrated in Skyrim's towns: townsfolk gather
in temples, inns, shops or outside, with decorations and fireworks. On such a day, the nearest town your faction rules
that celebrates it gives you an optional quest, "Attend the Festival in <Town>", with a map marker. Be in the town
that day to complete it: its loyalty rises by 5. If the day ends first, the quest quietly closes. Holidays itself
pauses its celebrations after the Battle of Whiterun until the civil war is over.

Festivals you pay for: accept a town's request for a festival grant and the festival is held the next day, with the
same attend quest. With Holidays, its decorations and festivities run that day too, in the style that fits (warriors'
festival at the smiths and town centre, merchants' at the shops, prayer at the temple, harvest at the inns...).
Its festivities are switched on only while you are in the festival town, so other towns stay as they are. Holidays turns all celebrations off while Skyrim's civil war is under way (after the Battle of Whiterun).
