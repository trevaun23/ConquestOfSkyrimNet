// Generic dialogs driven by ConquestOfSkyrimNetUI.dll:
//   window.csnMessage({token,title,text,buttons:[{i,text,visible}]})  - any CoS Message form
//   window.csnTextInput({token,title,initial})                          - replaces SkyUILib text input
//   window.csnList({token,title,options,start,default})                 - replaces SkyUILib list
// Answers go back with window.csnResult("token|index|text").
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const queue = [];
  let current = null;
  window.csnDialogOpen = false;

  function answer(index, text) {
    if (!current) return;
    const tok = current.token;
    current = null;
    window.csnDialogOpen = false;
    $("dialogLayer").classList.add("hidden");
    if (typeof window.csnResult === "function") window.csnResult(`${tok}|${index}|${text || ""}`);
    else console.log("csnResult", tok, index, text);
    next();
  }

  function next() {
    if (current || !queue.length) return;
    current = queue.shift();
    window.csnDialogOpen = true;
    $("dialogLayer").classList.remove("hidden");
    current.render();
  }

  function push(token, render) {
    queue.push({ token, render });
    next();
  }

  function button(label, onClick, cls) {
    const b = document.createElement("button");
    b.textContent = label;
    if (cls) b.className = cls;
    b.addEventListener("click", onClick);
    return b;
  }

  // "Back", "Previous Page", "Next Page", "Done", "Exit"... -> prev | back | next | done ("" = an ordinary choice)
  function navKind(t) {
    const x = String(t || "").trim().toLowerCase().replace(/[.!]+$/, "");
    if (/^(previous|prev)( page)?$/.test(x)) return "prev";
    if (/^(back|go back|return)$/.test(x)) return "back";
    if (/^(next|next page|more)$/.test(x)) return "next";
    if (/^(done|exit|close|finish|finished|leave|nevermind|never mind|cancel)$/.test(x)) return "done";
    return "";
  }

  window.csnMessage = function (m) {
    push(m.token, () => {
      $("dlgTitle").textContent = m.title || "";
      $("dlgBody").textContent = m.text || "";
      const box = $("dlgButtons");
      box.innerHTML = "";
      box.classList.toggle("confirm", !!m.confirm);
      // Conquest of Skyrim pages carry their navigation as ordinary buttons ("Back", "Next Page", "Done"...).
      // Those go in their own row at the bottom: going back on the left, onward and finishing on the right.
      const nav = { back: [], fwd: [] };
      // "Not now||Decline (silent)" from a conversation confirmation becomes two buttons (index 1 and 2)
      let btns = (m.buttons || []).filter((b) => b.visible);
      if (m.confirm) {
        btns = btns.flatMap((b) => String(b.text).includes("||")
          ? String(b.text).split("||").map((t, k) => ({ i: b.i + k, text: t, visible: true }))
          : [b]);
        box.dataset.silent = btns.some((b) => b.i === 2) ? "1" : "";
      }
      btns.forEach((b) => {
        const kind = m.confirm ? "" : navKind(b.text);
        if (!kind) { box.appendChild(button(b.text, () => answer(b.i))); return; }
        const label = kind === "prev" ? "\u2039 " + b.text : kind === "next" ? b.text + " \u203a" : b.text;
        const el = button(label, () => answer(b.i), "nav nav-" + kind);
        (kind === "prev" || kind === "back" ? nav.back : nav.fwd).push(el);
      });
      if (nav.back.length || nav.fwd.length) {
        const row = document.createElement("div");
        row.className = "navrow";
        const left = document.createElement("div");
        const right = document.createElement("div");
        nav.back.forEach((b) => left.appendChild(b));
        nav.fwd.forEach((b) => right.appendChild(b));
        row.appendChild(left);
        row.appendChild(right);
        box.appendChild(row);
      }
      const first = box.querySelector("button:not(.nav)") || box.querySelector("button");
      if (first) first.focus();
    });
  };

  window.csnTextInput = function (d) {
    push(d.token, () => {
      $("dlgButtons").classList.remove("confirm");
      $("dlgTitle").textContent = d.title || "";
      $("dlgBody").innerHTML = "";
      const input = document.createElement("input");
      input.type = "text";
      input.maxLength = 60;
      input.value = d.initial || "";
      $("dlgBody").appendChild(input);
      const box = $("dlgButtons");
      box.innerHTML = "";
      const row = document.createElement("div");
      row.className = "row-actions";
      const ok = () => answer(0, input.value.replace(/[|]/g, ""));
      row.appendChild(button("Cancel", () => answer(-1, ""), ""));
      row.appendChild(button("Accept", ok, "primary"));
      box.appendChild(row);
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") ok(); });
      input.focus();
      input.select();
    });
  };

  window.csnList = function (d) {
    push(d.token, () => {
      $("dlgButtons").classList.remove("confirm");
      $("dlgTitle").textContent = d.title || "";
      $("dlgBody").textContent = "";
      const box = $("dlgButtons");
      box.innerHTML = "";
      (d.options || []).forEach((o, i) => {
        if (i < (d.start || 0)) return;
        const b = button(o, () => answer(i));
        if (i === d.default) b.classList.add("focus");
        box.appendChild(b);
      });
      const row = document.createElement("div");
      row.className = "row-actions";
      row.appendChild(button("Cancel", () => answer(-1)));
      box.appendChild(row);
    });
  };

  // Amount picker: -100/-10/-1/+1/+10/+100 and typing. Answers index 0 with the amount as text, or 1 = cancel.
  window.csnAmount = function (d) {
    push(d.token, () => {
      $("dlgButtons").classList.remove("confirm");
      $("dlgTitle").textContent = d.title || "";
      const body = $("dlgBody");
      body.innerHTML = "";
      const p = document.createElement("div");
      p.textContent = d.text || "";
      body.appendChild(p);
      const min = Number.isFinite(d.min) ? d.min : 0;
      const max = Number.isFinite(d.max) && d.max > 0 ? d.max : 1000000;
      const row = document.createElement("div");
      row.className = "stepper";
      const input = document.createElement("input");
      input.type = "number";
      input.min = min;
      input.max = max;
      input.value = d.initial || min || 1;
      const info = document.createElement("div");
      info.className = "stepinfo";
      const clamp = (v) => Math.max(min, Math.min(max, Math.round(Number(v) || 0)));
      const refresh = () => {
        const n = clamp(input.value);
        info.textContent = d.price ? (d.priceLabel || "{n} units · {g} gold").replace("{n}", n.toLocaleString("en-US"))
          .replace("{g}", (n * d.price).toLocaleString("en-US")) : "";
      };
      [-100, -10, -1].forEach((k) => row.appendChild(button(String(k), () => { input.value = clamp(clamp(input.value) + k); refresh(); }, "step")));
      row.appendChild(input);
      [1, 10, 100].forEach((k) => row.appendChild(button("+" + k, () => { input.value = clamp(clamp(input.value) + k); refresh(); }, "step")));
      body.appendChild(row);
      body.appendChild(info);
      input.addEventListener("input", refresh);
      refresh();
      const box = $("dlgButtons");
      box.innerHTML = "";
      const act = document.createElement("div");
      act.className = "row-actions";
      const ok = () => {
        const n = clamp(input.value);
        if (n < min || n <= 0 && min > 0) return;
        answer(0, String(n));
      };
      String(d.no || "Cancel").split("||").forEach((t, k) => act.appendChild(button(t, () => answer(1 + k, ""), k ? "quiet" : "")));
      act.appendChild(button(d.yes || "Agree", ok, "primary"));
      box.appendChild(act);
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") ok(); });
      input.focus();
      input.select();
    });
  };

  // Called by the DLL when it hides the view.
  window.csnHideAll = function () {
    $("dialogLayer").classList.add("hidden");
    $("backdrop").classList.add("hidden");
  };

  document.addEventListener("keydown", (e) => {
    if (!current || e.key !== "Escape") return;
    // Yes/No questions: Esc answers No.
    if ($("dlgButtons").classList.contains("confirm")) { answer($("dlgButtons").dataset.silent ? 2 : 1, ""); return; }
    // Text input and lists can be cancelled; CoS message boxes can't (same as vanilla).
    if ($("dlgBody").querySelector("input") || $("dlgButtons").querySelector(".row-actions")) answer(-1, "");
  });
})();
