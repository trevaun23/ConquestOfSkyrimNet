// Conquest of SkyrimNet faction screen.
// Papyrus (CSN_Core via ConquestOfSkyrimNetUI.dll) calls window.csnOpen(screen, state) / window.csnUpdate(screen, state).
// The view answers with window.csnSend("cmd|a|b|...") and window.csnClose("").
// Every other Conquest of Skyrim menu is drawn by dialogs.js.
// Note: keys arrive lower-case (the DLL normalises JSON built in Papyrus), and short string values such as
// tab names can come back with different capitalisation, so compare those case-insensitively.

(function () {
  "use strict";

  window.addEventListener("error", (e) => {
    try { if (typeof window.csnLog === "function") window.csnLog(String(e.message) + " @" + e.lineno); } catch (_) {}
  });

  const SIDES = { 1: "the Imperials", 2: "the Stormcloaks" };
  const MATS = ["Food", "Metal", "Wood"];
  const BUILDINGS = ["Barracks", "Farms", "Lumber mills", "Mines"];
  const ORDERS = [
    { k: 2, label: "Follow me" },
    { k: 1, label: "Hunt for food" },
    { k: 0, label: "Return to home holding" },
    { k: 3, label: "Garrison a city", needs: "city" },
    { k: 4, label: "Garrison a fort", needs: "fort" },
    { k: 5, label: "Make camp in a hold", needs: "hold" },
  ];

  let state = {};
  let screen = "";
  let tab = "overview";
  let lastTab = "";       // the tab shown when the screen was last closed (this session)
  let picking = -1;      // office being filled from the people nearby (-1 none, 9 = commander)

  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const num = (n) => (Number(n) || 0).toLocaleString("en-US");
  const lc = (s) => String(s || "").toLowerCase();

  // Tell the plugin when a text box has focus, so the faction-menu key types a letter instead of closing.
  const typingEl = (el) => el && (el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && el.type === "text"));
  // While typing, the plugin also holds the game paused (when "keep the game paused" is off), so other mods' hotkeys
  // don't fire. Leaving the box is reported a moment later, so a box-to-box move or a refocus doesn't flicker.
  let typingNow = false, lastTypingEl = null, typingTimer = 0;
  const tellTyping = (on) => { typingNow = on; if (typeof window.csnTyping === "function") window.csnTyping(on ? "1" : "0"); };
  document.addEventListener("focusin", (e) => { if (typingEl(e.target)) { lastTypingEl = e.target; clearTimeout(typingTimer); tellTyping(true); } });
  document.addEventListener("focusout", (e) => {
    if (!typingEl(e.target)) return;
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => { if (!typingEl(document.activeElement)) tellTyping(false); }, 200);
  });
  // the plugin refocused the view (to pause or unpause): put the caret back in the box being typed in
  window.csnRestoreTyping = () => {
    if (typingNow && lastTypingEl && document.body.contains(lastTypingEl) && document.activeElement !== lastTypingEl) {
      try { lastTypingEl.focus(); } catch (err) { /* gone */ }
    }
  };

  function send(cmd) {
    if (typeof window.csnSend === "function") window.csnSend(cmd);
    else console.log("csnSend", cmd);
  }
  // Commands that change something: say "working" at once, the game answers with csnToast and fresh data.
  const QUIET = /^(openTab|scan|close|setting\|theme)/;
  window.csnCmd = (cmd) => { if (!QUIET.test(cmd)) toast("Working…", "busy"); send(cmd); };

  function close(fromGame) {
    $("backdrop").classList.add("hidden");
    screen = "";
    picking = -1;
    if (fromGame !== true && typeof window.csnClose === "function") window.csnClose("");
  }
  window.csnCloseScreen = close;

  // Feedback line at the bottom: kind "ok" (green), "err" (red) or "busy" (neutral, while the game works).
  let toastTimer = 0;
  function toast(msg, kind) {
    const t = $("toast");
    t.textContent = msg || "";
    t.className = msg ? (kind || "err") : "";
    clearTimeout(toastTimer);
    if (msg && kind === "ok") toastTimer = setTimeout(() => { if (t.textContent === msg) { t.textContent = ""; t.className = ""; } }, 6000);
  }
  // From the game: the result of an action (success or the reason it failed).
  window.csnToast = (msg, err) => toast(msg, err ? "err" : "ok");

  window.csnSetTheme = function (t) {
    const light = lc(t) === "light" || t === 1 || t === "1";
    document.body.classList.toggle("theme-light", light);
    document.body.classList.toggle("theme-dark", !light);
  };

  window.csnOpen = function (scr, data) {
    state = (data && typeof data === "object") ? data : {};
    screen = scr;
    picking = -1;
    tab = lc(state.ctx && state.ctx.tab) || "overview";
    // opened with the faction-menu key: back to the tab shown last (the game remembers it too, across loads)
    if (state.ctx && state.ctx.hotkey && lastTab && lastTab !== tab) { tab = lastTab; tabPending = tab; setTimeout(() => send(`openTab|${tab}`), 0); }
    lastTab = tab;
    cultureDraft = null;
    toast("");
    if (state.theme !== undefined) window.csnSetTheme(state.theme);
    $("backdrop").classList.remove("hidden");
    safeRender();
  };

  window.csnUpdate = function (scr, data) {
    // updates carry the current tab's parts only: keep the rest from before
    if (data && typeof data === "object") { state = Object.assign({}, state, data); if (!data.loading) delete state.loading; }
    if ($("toast").className === "busy") toast("");
    if (scr) screen = scr;
    if (data && typeof data === "object" && !data.loading) tabPending = "";
    if (state.theme !== undefined) window.csnSetTheme(state.theme);
    safeRender();
  };

  function safeRender() {
    try { render(); } catch (err) {
      $("content").innerHTML = `<div class="empty">Something went wrong drawing this page. Press Esc to close.</div>`;
      if (typeof window.csnLog === "function") window.csnLog("render: " + err + " " + (err && err.stack));
    }
  }

  $("closeBtn").addEventListener("click", () => close());
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !window.csnDialogOpen && screen) {
      if (picking >= 0) { picking = -1; safeRender(); return; }
      close();
    }
  });

  // ---------------------------------------------------------------- tabs
  function tabs() {
    const pending = state.requests ? state.requests.filter((r) => r.status === 0).length : (state.pending || 0);
    const t = [["overview", "Overview"], ["requests", pending ? `Requests (${pending})` : "Requests"], ["officers", "Officers"], ["armies", "Armies"], ["holdings", "Lands"]];
    if (state.neargeneral) t.push(["general", "War Table", "General " + state.neargeneral]);
    if (state.nearsteward) t.push(["steward", "Steward", state.nearsteward]);
    if (state.nearblacksmith) t.push(["blacksmith", "Blacksmith", state.nearblacksmith]);
    const realm = state.realm || {};
    const alarm = (realm.towns || []).some((x) => x.stage > 0) || (realm.bands || []).some((b) => !b.peace);
    t.push(["realm", alarm ? "Unrest ⚠" : "Unrest & Intrigue"]);
    t.push(["settle", "Settlements"]);
    t.push(["culture", "Culture"]);
    t.push(["settings", "Settings"]);
    return t;
  }

  function renderTabs() {
    const list = tabs();
    if (!list.some(([k]) => k === tab)) tab = "overview";
    $("tabs").innerHTML = list.map(([k, n, who]) =>
      `<button class="${k === tab ? "active" : ""}" onclick="csnTab('${k}')">${n}${who ? `<span class="who">${esc(who)}</span>` : ""}</button>`).join("");
  }
  // which part of the game's data each tab draws from; until it arrives the tab shows a spinner
  const TAB_NEEDS = { requests: "requests", holdings: "cities", general: "holds", steward: "cities", settings: "settings",
    realm: "realm", settle: "settle", blacksmith: "smith" };
  let tabPending = "";
  window.csnTab = (k) => { if (tab === "culture") readCulture(); tab = lc(k); lastTab = tab; picking = -1; toast(""); tabPending = tab; safeRender(); send(`openTab|${tab}`); };

  function render() {
    if (screen !== "dashboard") { $("content").innerHTML = ""; return; }
    $("tabs").classList.remove("hidden");
    $("title").textContent = state.name || "Your faction";
    $("crest").textContent = (state.name || "C").trim().charAt(0).toUpperCase();
    $("subtitle").textContent = (state.founded ? `Led by ${state.leader || "you"} · ${warLine(true)}` : "Not founded yet") + (state.version ? ` · Conquest of SkyrimNet v${state.version}` : "");
    renderQuick();
    renderTabs();
    const c = $("content");
    if (!state.founded) {
      c.innerHTML = `<div class="empty"><h3>Your faction isn't founded yet</h3>Read <b>Start my Faction</b> to found it. This screen fills up as your faction grows.</div>`;
      return;
    }
    if (state.loading) { c.innerHTML = loadingBox("Opening the books…"); return; }
    const need = TAB_NEEDS[tab];
    if (need && (tabPending === tab || state[need] === undefined)) { c.innerHTML = loadingBox(); return; }
    const page = {
      overview: pageOverview, requests: pageRequests, officers: pageOfficers, armies: pageArmies, holdings: pageLands,
      general: pageWarTable, steward: pageSteward, settings: pageSettings, culture: pageCulture, blacksmith: pageBlacksmith,
      realm: pageRealm, settle: pageSettle,
    }[tab] || pageOverview;
    c.innerHTML = page();
    bind();
  }

  // Treasury, supplies and your purse next to the faction name, on every tab.
  function renderQuick() {
    const q = $("quick");
    if (!state.founded) { q.classList.add("hidden"); return; }
    q.classList.remove("hidden");
    q.innerHTML = `<span class="q-gold" title="Faction treasury">Treasury <b>${num(state.gold)}</b> gold</span><span class="sep"></span>
      <span title="Faction supplies">Food <b>${num(state.food)}</b></span><span title="Faction supplies">Metal <b>${num(state.metal)}</b></span>
      <span title="Faction supplies">Wood <b>${num(state.wood)}</b></span><span class="sep"></span>
      <span title="Gold you carry">Your purse <b>${num(state.purse)}</b> gold</span>`;
  }

  // ---------------------------------------------------------------- helpers
  function stat(label, value, delta) {
    let d = "";
    if (delta !== undefined) {
      const n = Number(delta) || 0;
      d = `<div class="delta ${n > 0 ? "up" : n < 0 ? "down" : ""}">${n > 0 ? "+" : ""}${num(n)} a day</div>`;
    }
    return `<div class="stat"><div class="label">${label}</div><div class="value">${value}</div>${d}</div>`;
  }

  function warLine(plain) {
    const w = state.war || [false, false];
    let s = "At peace";
    if (w[0] && w[1]) s = "At war with the Imperials and the Stormcloaks";
    else if (w[0]) s = "At war with the Imperials";
    else if (w[1]) s = "At war with the Stormcloaks";
    return plain ? s : (w[0] || w[1] ? `<span class="warn">${s}</span>` : s);
  }

  const officers = () => state.officers || [];
  const armies = () => (state.armies || []);
  const ourCities = () => (state.cities || []).filter((c) => c.ours);

  // a part of the page the game hasn't sent yet: a spinner instead of an empty page
  function loadingBox(what) { return `<div class="loadingbox"><span class="spinner"></span>${what ? esc(what) : "Loading…"}</div>`; }
  function empty(title, text) { return `<div class="empty"><h3>${title}</h3>${text}</div>`; }

  // ---------------------------------------------------------------- overview
  function pageOverview() {
    const cities = ourCities();
    let h = realmAlerts() + `<div class="grid">
      ${stat("Treasury", num(state.gold) + " gold", state.goldday)}
      ${stat("Food", num(state.food), state.foodday)}
      ${stat("Metal", num(state.metal), state.metalday)}
      ${stat("Wood", num(state.wood), state.woodday)}
    </div>
    <div class="grid" style="margin-top:12px">
      ${stat("Towns ruled", cities.length)}
      ${stat("Claims", (state.claims || []).length)}
      ${stat("Armies", armies().length)}
      ${stat("Soldiers", num(armies().reduce((a, b) => a + (b.troops || 0), 0)))}
    </div>
    <h2>Wars</h2><p>${warLine()}.</p>`;
    const waiting = (state.requests || []).filter((r) => r.status === 0).length;
    if (waiting) h += `<div class="card"><div class="card-head"><h3>${waiting} request${waiting > 1 ? "s" : ""} waiting for you</h3>
      <button class="btn small" onclick="csnTab('requests')">Open requests</button></div></div>`;
    h += `<h2>Officers</h2><table><tr><th>Office</th><th>Holder</th></tr>
      ${officers().map((o) => `<tr><td>${esc(o.role)}</td><td>${o.name ? esc(o.name) : '<span class="muted">Vacant</span>'}</td></tr>`).join("")}</table>`;
    if (!state.nearsteward || !state.neargeneral) {
      h += `<p class="muted small" style="margin-top:14px">Open this screen next to your Steward or one of your jarls to manage the treasury and trade, or next to your General for the war table.</p>`;
    }
    return h;
  }

  // ---------------------------------------------------------------- requests (history log)
  const STATUS = [["Waiting for you", "warn"], ["Accepted", "ok"], ["Denied", ""], ["Met in the middle", "ok"], ["Withdrawn", ""]];

  function pageRequests() {
    const list = state.requests || [];
    let h = `<p class="lead">Your stewards and jarls ask for what their towns need. ${state.letters
      ? "Requests arrive as letters by courier; reading one lets you decide on the spot."
      : "Install Physical Letters to receive them as letters."}</p>`;
    if (!list.length) return h + empty("No requests yet", "When something happens that calls for it, your stewards, jarls, captains, commanders or General will ask you here: taxes, trade, a town's festival or cause, their troops' training, a famous commander to stand guard in their town, or better barracks, farms, mills or mines.");
    list.forEach((r) => {
      const st = STATUS[r.status] || STATUS[4];
      const ago = r.daysago <= 0 ? "today" : r.daysago === 1 ? "yesterday" : `${r.daysago} days ago`;
      const tag = ["Taxes", "Trade", "Town grant", "Army", "Security", "Upgrade"][r.kind || 0] || "Request";
      h += `<div class="card"><div class="card-head"><h3>${esc(r.text)}</h3><span><span class="pill">${tag}</span><span class="pill ${st[1]}">${st[0]}</span></span></div>
        <p class="small muted">${esc(r.from)} · ${esc(r.town)} · ${ago}</p>
        <p>${esc(r.why)}</p>`;
      if (r.marmy && r.status === 0) {
        const sg = (n) => (n > 0 ? "+" + n : "" + n);
        h += `<p class="small">Morale in ${esc(r.marmy)} (now ${r.mnow}): <span class="up">${sg(r.mup)} if accepted</span>${r.canmiddle ? `, ${sg(r.mmid)} if met halfway` : ""}, <span class="warn">${sg(r.mdown)} if denied</span></p>`;
      }
      if (r.block && r.status === 0) h += `<p class="small warn">Couldn't be done: ${esc(r.block)}</p>`;
      if (r.status === 0) {
        const security = r.kind === 4;
        h += `<div class="row"><button class="btn" onclick="csnDecide(${r.id}, 0)">${security ? "Accept: send them" : "Accept"}</button>
          ${security ? "" : `<button class="btn secondary" ${r.canmiddle ? "" : "disabled title='No middle ground for this one'"} onclick="csnDecide(${r.id}, 2)">Meet in the middle${r.canmiddle ? ": " + esc(r.middle) : ""}</button>`}
          <button class="btn danger" onclick="csnDecide(${r.id}, 1)">Deny</button>
          ${security ? `<span class="muted small">Denying costs ${Math.max(2, Math.floor((r.loy || 0) / 2))} loyalty there.</span>` : ""}</div>`;
      }
      h += `</div>`;
    });
    return h;
  }


  // ---------------------------------------------------------------- unrest, deserters and intrigue (1.9.0)
  function realmAlerts() {
    const r = state.realm || {};
    const lines = [];
    (r.towns || []).forEach((t) => {
      if (t.stage === 2) lines.push(`<b>${esc(t.name)}</b> has risen up (${t.rebels} rebels, ${t.left} day(s) before they hand it over)`);
      else if (t.stage === 1) lines.push(`Unrest in <b>${esc(t.name)}</b> over ${esc(t.why)}`);
    });
    (r.bands || []).forEach((b) => { if (!b.peace) lines.push(`<b>${esc(b.name)}</b> (${b.troops} deserters) holds ${esc(b.seat)}`); });
    if (!lines.length) return "";
    return `<div class="card warnbox"><div class="card-head"><h3>Trouble in the realm</h3><button class="btn small" onclick="csnTab('realm')">Deal with it</button></div><p>${lines.join("<br>")}</p></div>`;
  }

  const bar = (v, max) => `<div class="bar"><i style="width:${Math.max(0, Math.min(100, (v / (max || 100)) * 100))}%"></i></div>`;
  const STAGE = ["Calm", "Unrest", "Uprising"];
  const OUTLOOK = ["Guards would arrest the jarl", "Guards would argue, then side with you", "Guards would stand by the jarl (a fight)"];

  function pageRealm() {
    const r = state.realm || {};
    const it = state.intrigue || {};
    let h = `<p class="lead">How content your people and troops are, soldiers who have broken away, and cities you are turning against their jarls.</p>`;

    h += `<h2>Your towns</h2>`;
    const towns = r.towns || [];
    if (!r.civil) h += `<p class="muted small">Civilian uprisings are turned off in the MCM.</p>`;
    if (!towns.length) h += empty("No towns yet", "Towns you rule appear here with their loyalty and any grievances.");
    else {
      h += `<p class="muted small">Below ${r.threshold} loyalty with a grievance (hunger, heavy taxes, no garrison, unheard court cases) a town has a day of unrest, then rises. While it is up no taxes are paid. End it by meeting their demands, by killing the rebel leader yourself, or with a garrison twice their number.</p>`;
      h += `<table><tr><th>Town</th><th>Loyalty</th><th>State</th><th>Grievances</th><th></th></tr>`;
      towns.forEach((t) => {
        const pill = t.stage === 2 ? "warn" : t.stage === 1 ? "warn" : "ok";
        let act = "";
        if (t.stage > 0) act = `<button class="btn small" onclick="csnCmd('reb|appease|${t.i}')">Meet demands: ${num(t.gold)} gold${t.food ? ", " + t.food + " food" : ""}…</button>`;
        let st = STAGE[t.stage] || "";
        if (t.stage === 2) st += ` · ${t.rebels} rebels vs ${t.garrison} garrison · ${t.left} day(s) left`;
        h += `<tr><td>${esc(t.name)}</td><td>${t.loyalty}${bar(t.loyalty)}</td><td><span class="pill ${pill}">${st}</span></td><td class="small">${esc(t.why) || '<span class="muted">none</span>'}</td><td>${act}</td></tr>`;
      });
      h += `</table>`;
    }

    h += `<h2>Army morale</h2>`;
    const ar = r.armies || [];
    if (!r.military) h += `<p class="muted small">Desertion is turned off in the MCM.</p>`;
    if (!ar.length) h += `<p class="muted">No armies yet.</p>`;
    else {
      h += `<p class="muted small">Unpaid wages (an empty treasury), empty bellies, long postings and refused requests wear morale down; stars, granted requests, pay and food lift it. Under the breaking point an army may leave the faction.</p>`;
      h += `<table><tr><th>Army</th><th>Troops</th><th>Morale</th><th>Complaints</th></tr>`;
      ar.forEach((a) => {
        const low = a.morale < 30;
        h += `<tr><td>${esc(a.name)}<div class="small muted">${esc(a.leader)}</div></td><td>${a.troops}</td><td>${a.morale}${bar(a.morale)}<div class="small ${low ? "warn" : "muted"}">breaks under ${Math.max(0, a.limit)}</div></td><td class="small">${esc(a.why) || '<span class="muted">none</span>'}</td></tr>`;
      });
      h += `</table>`;
    }

    const bands = r.bands || [];
    if (bands.length) {
      h += `<h2>Free companies</h2>`;
      bands.forEach((b) => {
        const opts = ar.map((a) => `<option value="${a.i}">${esc(a.name)} (${a.troops})</option>`).join("");
        h += `<div class="card"><div class="card-head"><h3>${esc(b.name)}</h3><span class="pill ${b.peace ? "ok" : "warn"}">${b.peace ? "At peace" : b.free ? "Free realm, raiding" : "Raiding"}</span></div>
          <p>${esc(b.leader)} · ${b.troops} soldiers · holds ${esc(b.seat)}${b.realm ? " · proclaimed " + esc(b.realm) : ""}</p>`;
        if (!b.peace) {
          h += `<p class="small muted">Go to ${esc(b.seat)} and kill their leader, send a loyal army, pay what they say they are owed, or recognise them.</p>
          <div class="row">${opts ? `<select id="bandArmy${b.w}">${opts}</select><button class="btn small" onclick="csnSendBand(${b.w})">Send army…</button>` : ""}
          <button class="btn small secondary" onclick="csnCmd('reb|pay|${b.w}')">Pay arrears: ${num(b.gold)} gold, ${b.food} food…</button>
          <button class="btn small danger" onclick="csnCmd('reb|grant|${b.w}')">Recognise them…</button></div>`;
        }
        h += `</div>`;
      });
    }

    h += `<h2>Intrigue</h2>`;
    const cities = it.cities || [];
    if (!it.on) h += `<p class="muted small">Intrigue is turned off in the MCM.</p>`;
    else if (!cities.length) h += `<p class="muted">No city ruled by the Imperials or Stormcloaks has a jarl to overthrow.</p>`;
    else {
      h += `<p class="muted small">Bribe guards and fund nobles and citizens (you pay from your own purse), or win them over in conversation. When enough stand with you, plan a coup: Conquest of Skyrim's coup plays out in the jarl's hall.</p>`;
      cities.forEach((c) => {
        h += `<div class="card"><div class="card-head"><h3>${esc(c.name)} <span class="muted small">Jarl ${esc(c.jarl)} · ${SIDES[c.owner === 11 ? 1 : 2]}</span></h3><span class="pill ${c.outlook === 2 ? "warn" : "ok"}">${OUTLOOK[c.outlook]}</span></div>
          <div class="split"><div><div class="small muted">Guards ready to betray the jarl</div>${c.guards}/100 ${bar(c.guards)}</div>
          <div><div class="small muted">Nobles and citizens behind you</div>${c.people}/100 ${bar(c.people)}</div></div>
          <p class="small muted">${num(c.gp)} gold a point for guards, ${num(c.pp)} for citizens (nobles half). ${c.risk}% risk each payment is reported. About ${c.crowd} citizens would gather.${c.spent ? " Spent so far: " + num(c.spent) + " gold." : ""}</p>
          <div class="row"><button class="btn small" onclick="csnCmd('intr|guards|${c.i}')">Bribe guards…</button>
          <button class="btn small" onclick="csnCmd('intr|people|${c.i}')">Fund supporters…</button>
          <button class="btn small ${c.block ? "secondary" : "danger"}" ${c.block ? `disabled title="${esc(c.block)}"` : ""} onclick="csnCmd('intr|coup|${c.i}')">Plan a coup…</button></div>
          ${c.block ? `<p class="small muted">${esc(c.block)}</p>` : ""}</div>`;
      });
    }
    return h;
  }
  window.csnSendBand = (w) => { const el = $("bandArmy" + w); if (el) csnCmd(`reb|send|${w}|${el.value}`); };

  // ---------------------------------------------------------------- settlements (1.9.0)
  function pageSettle() {
    const st = state.settle || {};
    let h = `<p class="lead">Found settlements on open land in holds you control, build homes, fields and workshops, and settlers come to work them. What they make goes into the faction's stores every day.</p>`;
    if (!st.on) return h + empty("Settlements are off", "Turn them on in the MCM (Settlements page).");
    h += `<div class="card"><div class="card-head"><h3>Found a settlement here</h3></div>
      <p class="small muted">Costs ${num(st.gold)} gold and ${st.wood} wood. Outdoors, in a hold whose city or roads you hold, away from towns and other settlements.</p>
      <div class="row"><button class="btn" ${st.block ? `disabled title="${esc(st.block)}"` : ""} onclick="csnCmd('st|found')">Found it…</button>${st.block ? `<span class="small muted">${esc(st.block)}</span>` : ""}</div></div>`;
    const list = st.list || [];
    if (!list.length) return h + empty("No settlements yet", "Stand somewhere open and found one. Build mode: walk and turn to move the building, arrow keys rotate it and move it nearer or farther, Page Up/Down raise or lower it, Enter or Activate places it, Backspace cancels.");
    list.forEach((s) => {
      const here = st.here === s.k;
      h += `<div class="card"><div class="card-head"><h3>${esc(s.name)} <span class="muted small">${esc(s.hold)}</span></h3>${here ? '<span class="pill ok">You are here</span>' : ""}</div>
        <div class="grid">${stat("Settlers", `${s.pop} / ${s.beds} beds`)}${stat("Happiness", s.happy)}${stat("Defence", s.def)}${stat("Jobs", `${s.jobs} (${s.staffed}% filled)`)}</div>
        <p class="small">A day: food ${s.food >= 0 ? "+" : ""}${s.food} · wood +${s.woodday} · metal +${s.metalday} · gold +${s.goldday}</p>
        <p class="small muted">${esc(s.buildings)}</p>
        <div class="row"><button class="btn small" ${here ? "" : 'disabled title="Go there to build"'} onclick="csnCmd('st|build|${s.k}')">Build…</button>
        <button class="btn small secondary" onclick="csnCmd('st|remove|${s.k}')">Take down…</button>
        <button class="btn small secondary" onclick="csnCmd('st|rename|${s.k}')">Rename…</button>
        <button class="btn small danger" onclick="csnCmd('st|abandon|${s.k}')">Abandon…</button></div></div>`;
    });
    return h;
  }

  // Answer at once on screen; the game's refresh that follows has the final word (and puts it back if it failed).
  window.csnDecide = (id, choice) => {
    const r = (state.requests || []).find((x) => x.id === id);
    if (r) { r.status = choice === 1 ? 2 : choice === 2 ? 3 : 1; safeRender(); }
    csnCmd(`decide|${id}|${choice}`);
  };

  const taxText = (lv) => (lv >= 0 ? lv * 10 + "%" : "—");

  // ---------------------------------------------------------------- officers
  function pageOfficers() {
    if (picking >= 0) return pagePicker();
    let h = `<p class="lead">Appoint officers in conversation, or pick someone standing nearby. Anyone who isn't hostile can serve.</p><div class="split">`;
    officers().forEach((o, i) => {
      h += `<div class="card"><div class="card-head"><h3>${esc(o.role)}</h3>${o.name ? "" : '<span class="pill warn">Vacant</span>'}</div>
        <p>${o.name ? esc(o.name) : '<span class="muted">No one holds this office.</span>'}</p>
        <p class="muted small">${roleText(i)}</p>
        <div class="row">
          <button class="btn small" onclick="csnPick(${i})">${o.name ? "Replace" : "Appoint"}…</button>
          ${o.name ? `<button class="btn small secondary" onclick="csnCmd('outfit|${i}')">Outfit</button>
          <button class="btn small danger" onclick="csnCmd('dismissOfficer|${i}')">Relieve…</button>` : ""}
        </div></div>`;
    });
    h += `</div>`;
    // only when there is a captain to choose: the Armies tab lists the ones you have
    if (state.freeslot >= 0) {
      h += `<h2>Captains</h2><p>Army ${state.freeslot + 1} has no captain yet. A captain who earns a star becomes a Commander.</p><div class="row"><button class="btn" onclick="csnPick(9)">Choose a captain…</button></div>`;
    }
    return h;
  }

  function roleText(i) {
    return ["Runs the war table and every captain and commander.", "Keeps the treasury, supplies, trade and declarations of war.",
      "Arms and armours your troops.", "Gives magical counsel."][i] || "";
  }

  window.csnPick = (i) => { picking = i; toast(""); send("scan"); safeRender(); };

  function pagePicker() {
    const office = picking === 9 ? `captain of Army ${state.freeslot + 1}` : (officers()[picking] || {}).role;
    const people = state.candidates || [];
    let h = `<div class="card-head"><h2>Who should be ${esc(office)}?</h2><button class="btn small secondary" onclick="csnPick(-1)">Back</button></div>
      <p class="lead">People near you right now.</p>`;
    if (!people.length) return h + empty("No one nearby", "Stand near the person you want and open this screen again, or ask them in conversation.");
    h += `<div class="people">` + people.map((p) => {
      let note = "";
      if (p.role >= 0) note = "Already " + ((officers()[p.role] || {}).role || "an officer");
      else if (p.army >= 0) note = "Leads Army " + (p.army + 1);
      const cmd = picking === 9 ? `hire|${p.i}` : `appoint|${picking}|${p.i}`;
      const blocked = picking === 9 && (p.role >= 0 || p.army >= 0);
      return `<button class="person" ${blocked ? "disabled" : ""} onclick="csnChoose('${cmd}')">${esc(p.name)}${note ? `<span class="muted">${note}</span>` : ""}</button>`;
    }).join("") + `</div>`;
    return h;
  }
  window.csnChoose = (cmd) => { picking = -1; send(cmd); };

  const starRow = (n) => `<span class="stars" title="${n} of 5 stars">${"★".repeat(n)}${"☆".repeat(5 - n)}</span>`;
  const leader = (a) => `${esc(a.rank || "Captain")} ${esc(a.name)}`;
  // "Iron Wolves · Army 3" once named, otherwise "Army 3"
  const armyTitle = (a) => a.aname ? `${esc(a.aname)} <span class="muted small">Army ${a.i + 1}</span>` : `Army ${a.i + 1}`;
  const mottoLine = (a) => a.motto ? `<p class="small"><i>“${esc(a.motto)}”</i></p>` : "";
  // Name & purpose editor, folded away until asked for
  const nameEditor = (a) => `<div id="nm${a.i}" class="hidden">
      <div class="row"><input type="text" id="nmName${a.i}" maxlength="25" placeholder="Army name (25 letters at most)" value="${esc(a.aname || "")}"></div>
      <div class="row"><textarea id="nmMotto${a.i}" rows="2" maxlength="200" placeholder="Purpose, goal or mantra (optional)">${esc(a.motto || "")}</textarea></div>
      <div class="row"><button class="btn small" onclick="csnArmyName(${a.i})">Save name</button>
      <button class="btn small secondary" onclick="csnArmyNameToggle(${a.i})">Cancel</button>
      <span class="muted small">Leave the name empty to go back to Army ${a.i + 1}.</span></div></div>`;
  const nameButton = (a) => `<button class="btn small secondary" onclick="csnArmyNameToggle(${a.i})">${a.aname ? "Rename…" : "Name army…"}</button>`;
  window.csnArmyNameToggle = (i) => { const el = $("nm" + i); if (el) el.classList.toggle("hidden"); };
  window.csnArmyName = (i) => {
    const strip = (t) => String(t || "").replace(/[|\r\n\t"]/g, " ").replace(/\s+/g, " ").trim();
    const n = strip($("nmName" + i).value).slice(0, 25);
    const m = strip($("nmMotto" + i).value).slice(0, 200);
    // "~" stands for empty: the game's splitter drops empty fields
    csnCmd(`armyName|${i}|${n || "~"}|${m || "~"}`);
  };
  function starButton(a) {
    if ((a.stars || 0) >= 5) return `<span class="pill ok">Five stars</span>`;
    const cost = (state.settings && state.settings.starcost) || 10000;
    return `<button class="btn small" ${state.gold >= cost ? "" : "disabled title='Not enough gold in the treasury'"} onclick="csnCmd('star|${a.i}')">Award a star (${num(cost)} gold)</button>`;
  }

  // ---------------------------------------------------------------- armies (read only)
  function mixLine(a) {
    const m = a.mix || [];
    const names = ["soldiers", "warriors", "archers", "crossbowmen"];
    const parts = names.map((n, i) => `<span><b>${num(m[i])}</b> ${n}</span>`).join("");
    return `<div class="mix">${parts}</div>`;
  }

  function pageArmies() {
    const list = armies();
    if (!list.length) return empty("No armies yet", "Claim a holding to open an army slot, then choose a captain on the Officers tab.");
    return `<p class="lead">Orders go through your General: open this screen beside them for the War Table. A Captain becomes a Commander with their first star; each star gives their troops +10% health and stamina (five at most).</p>
      <div class="note"><b>Set outfit</b> dresses one army's leader and troops in a look of your own. It overrides the outfits set for each troop type on the Blacksmith tab, for that army only.</div>` +
      list.map((a) => `<div class="card"><div class="card-head"><h3>${armyTitle(a)} · ${leader(a)}</h3>
        <span>${starRow(a.stars || 0)} · ${num(a.troops)} troops${a.dead ? ' <span class="pill warn">Leader fallen</span>' : ""}</span></div>
        ${mottoLine(a)}${mixLine(a)}<p class="muted small">Posted: ${esc(a.post || a.task)}</p>
        <div class="row">${starButton(a)}<span class="spacer"></span>${nameButton(a)}<button class="btn small secondary" onclick="csnCmd('troops|${a.i}')">Troops &amp; recruits</button>
        <button class="btn small secondary" title="Overrides the troop-type outfits from the Blacksmith tab for this army" onclick="csnCmd('outfit|-1|${a.i}')">Set outfit</button></div>${nameEditor(a)}</div>`).join("");
  }

  // ---------------------------------------------------------------- lands
  function levels(c) {
    return `<div class="levels">${(c.lv || []).map((v, k) => v >= 0 ? `<span class="level">${BUILDINGS[k]} <b>${v}</b></span>` : "").join("")}</div>`;
  }
  function loyaltyBar(v) { return `<div class="bar" title="${v} / 100"><i style="width:${Math.max(0, Math.min(100, v))}%"></i></div>`; }

  function pageLands() {
    const cl = state.claims || [];
    let h = `<h2>Towns</h2><table><tr><th>Town</th><th>Ruled by</th><th>Loyalty</th><th class="num">Taxes</th><th>Buildings</th></tr>` +
      // yours first, then the rest in their usual order
      (state.cities || []).slice().sort((a, b) => (b.ours ? 1 : 0) - (a.ours ? 1 : 0) || a.i - b.i).map((c) => `<tr><td>${esc(c.name)}${c.ours ? '<span class="pill ok">Yours</span>' : ""}</td>
        <td>${esc(c.owner)}</td><td>${c.ours ? loyaltyBar(c.loyalty) : '<span class="muted">—</span>'}</td>
        <td class="num">${c.ours ? taxText(c.tax) : '<span class="muted">—</span>'}</td><td>${c.ours ? levels(c) : ""}</td></tr>`).join("") + `</table>`;
    h += `<h2>Claims</h2>`;
    if (!cl.length) return h + empty("No claims yet", "Clear a camp, mine or fort, then use the Place Banner power.");
    h += `<table><tr><th>Holding</th><th class="num">Guards</th><th class="num">Workers</th></tr>
      ${cl.map((c) => `<tr><td>${esc(c.name)}${c.base ? '<span class="pill">Base</span>' : ""}${c.mine ? '<span class="pill">Mine</span>' : ""}${c.farm ? '<span class="pill">Farm</span>' : ""}</td>
        <td class="num">${c.guards} / 5</td><td class="num">${c.mine ? c.miners + " miners / 5" : c.farm ? c.farmhands + " farmhands / 5" : "—"}</td></tr>`).join("")}</table>`;
    return h;
  }

  // ---------------------------------------------------------------- war table (next to the General)
  function targets(needs) {
    if (needs === "city") return ourCities().filter((c) => c.city).map((c) => [c.i, c.name]);
    if (needs === "fort") return (state.forts || []).filter((f) => f.owned).map((f) => [f.i, f.name]);
    if (needs === "hold") return (state.holds || []).filter((x) => x.camp).map((x) => [x.i, x.name + (x.attack ? " (attack camp)" : "")]);
    return [];
  }

  function pageWarTable() {
    const s = state.siege || [0, 0, 0];
    let h = `<p class="lead">General ${esc(state.neargeneral)} keeps the war table. ${warLine()}.</p>
      <div class="grid">${stat("Battering rams", s[0])}${stat("Ladders", s[1])}${stat("Catapults", s[2])}</div>`;
    if (state.recruitlimit !== undefined) h += `<p class="small">Troops that can still be recruited today: <b>${num(state.recruittoday)}</b> of ${num(state.recruitlimit)}. Ask General ${esc(state.neargeneral)} in conversation, e.g. "recruit 5 archers and 10 soldiers for Army 1".</p>`;
    h += templatesBlock();
    const list = armies();
    if (!list.length) return h + `<h2>Armies</h2>` + empty("No captains yet", "Choose a captain on the Officers tab.");
    h += `<h2>Armies</h2>`;
    list.forEach((a) => {
      h += `<div class="card"><div class="card-head"><h3>${armyTitle(a)} · ${leader(a)}</h3><span>${starRow(a.stars || 0)} · ${num(a.troops)} troops</span></div>
        ${mottoLine(a)}${mixLine(a)}<p class="muted small">Posted: ${esc(a.post || a.task)}</p>
        <div class="row">
          <select id="ord${a.i}" onchange="csnOrderChanged(${a.i})">${ORDERS.map((o) => `<option value="${o.k}">${o.label}</option>`).join("")}</select>
          <select id="arg${a.i}" class="hidden"></select>
          <button class="btn" onclick="csnOrder(${a.i})">Give order</button>
          <span class="spacer"></span>
          ${starButton(a)}
          <button class="btn small secondary" onclick="csnCmd('troops|${a.i}')">Troops</button>
          <button class="btn small secondary" title="Overrides the troop-type outfits from the Blacksmith tab for this army" onclick="csnCmd('outfit|-1|${a.i}')">Set outfit</button>
          ${nameButton(a)}
          <button class="btn small danger" onclick="csnCmd('fire|${a.i}')">Dismiss…</button>
        </div>${nameEditor(a)}</div>`;
    });
    return h;
  }

  window.csnOrderChanged = (i) => {
    const o = ORDERS.find((x) => x.k === parseInt($("ord" + i).value, 10));
    const sel = $("arg" + i);
    if (!o || !o.needs) { sel.classList.add("hidden"); sel.innerHTML = ""; return; }
    const t = targets(o.needs);
    sel.innerHTML = t.length ? t.map(([v, n]) => `<option value="${v}">${esc(n)}</option>`).join("") : `<option value="-1">Nowhere yet</option>`;
    sel.classList.remove("hidden");
  };
  window.csnOrder = (i) => {
    const o = parseInt($("ord" + i).value, 10);
    const needs = (ORDERS.find((x) => x.k === o) || {}).needs;
    const a = needs ? parseInt($("arg" + i).value, 10) : -1;
    if (needs && !(a >= 0)) { toast("Pick where they should go first."); return; }
    toast("");
    csnCmd(`order|${i}|${o}|${a}`);
  };

  // ---------------------------------------------------------------- steward (next to a steward or jarl)
  function pageSteward() {
    const w = state.war || [false, false];
    const tr = state.trade || [[0, 0, 0], [0, 0, 0]];
    let h = `<p class="lead">${esc(state.nearsteward)} keeps the books.</p>
      <div class="grid">${stat("Treasury", num(state.gold) + " gold", state.goldday)}${stat("Your purse", num(state.purse) + " gold")}
      ${stat("Food", num(state.food), state.foodday)}${stat("Metal", num(state.metal), state.metalday)}${stat("Wood", num(state.wood), state.woodday)}</div>
      <h2>Treasury</h2>
      <div class="row">
        <input type="number" id="goldAmt" min="1" step="100" value="1000">
        <button class="btn small secondary" onclick="csnGoldPreset(100)">100</button>
        <button class="btn small secondary" onclick="csnGoldPreset(1000)">1,000</button>
        <button class="btn small secondary" onclick="csnGoldPreset(10000)">10,000</button>
        <span class="spacer"></span>
        <button class="btn" onclick="csnGold('deposit')">Deposit</button>
        <button class="btn secondary" onclick="csnGold('withdraw')">Withdraw</button>
      </div>`;

    h += `<h2>War</h2><table>${[1, 2].map((side) => `<tr><td>${SIDES[side].replace("the ", "The ")}</td>
        <td>${w[side - 1] ? '<span class="pill warn">At war</span>' : '<span class="pill ok">At peace</span>'}</td>
        <td class="num">${w[side - 1] ? '<span class="muted small">Peace comes through peace talks.</span>' : `<button class="btn small danger" onclick="csnCmd('war|${side}')">Declare war…</button>`}</td></tr>`).join("")}</table>`;

    h += `<h2>Trade with the Imperials and Stormcloaks</h2>
      <p class="muted small">${state.tradeprice} gold per unit per day. You can't import and export the same material with the same side. "Agree" seals it straight away.</p>
      <div class="row">
        <select id="trDir"><option value="1">Import</option><option value="-1">Export</option></select>
        <input type="number" id="trAmt" min="1" value="1">
        <select id="trMat">${MATS.map((m, i) => `<option value="${i}">${m}</option>`).join("")}</select>
        <span>a day with</span>
        <select id="trSide">${[1, 2].map((side) => `<option value="${side}" ${w[side - 1] ? "disabled" : ""}>${SIDES[side]}</option>`).join("")}</select>
        <button class="btn" onclick="csnTrade()">Agree</button>
        <span id="trCost" class="muted small"></span>
      </div><table style="margin-top:8px"><tr><th>Side</th><th>Material</th><th>Per day</th><th></th></tr>`;
    let any = false;
    [1, 2].forEach((side) => MATS.forEach((m, mat) => {
      const v = (tr[side - 1] || [])[mat];
      if (!v) return;
      any = true;
      h += `<tr><td>${SIDES[side]}</td><td>${m}</td><td>${v > 0 ? "Importing " + v : "Exporting " + -v}</td>
        <td class="num"><button class="btn small secondary" onclick="csnCmd('tradeCancel|${side}|${mat}|${v > 0 ? 1 : -1}')">End</button></td></tr>`;
    }));
    if (!any) h += `<tr><td colspan="4" class="muted">No agreements yet.</td></tr>`;
    h += `</table>`;

    const towns = ourCities();
    h += `<h2>Your towns</h2>`;
    if (!towns.length) {
      h += empty("No towns yet", "Conquer a city or village and it appears here with its buildings and trade.");
    } else {
      towns.forEach((c) => {
        const t = c.tr || [0, 0, 0];
        h += `<div class="card"><div class="card-head"><h3>${esc(c.name)}</h3><span class="small muted loyal">Loyalty ${c.loyalty} / 100${loyaltyBar(c.loyalty)}</span></div>
          ${levels(c)}
          <div class="row"><span>Taxes</span>
            <div class="seg">${[0, 1, 2, 3, 4, 5].map((lv) => `<button class="${c.tax === lv ? "on" : ""}" onclick="csnTax(${c.i}, ${lv})">${lv * 10}%</button>`).join("")}</div>
            <span class="muted small">Lower taxes, more loyalty. Higher taxes, more gold.</span></div>
          <p class="small" style="margin-top:8px">${MATS.map((m, k) => t[k] > 0 ? `You export ${t[k]} ${m.toLowerCase()} a day to it` : t[k] < 0 ? `You import ${-t[k]} ${m.toLowerCase()} a day from it` : "").filter(Boolean).join(" · ") || '<span class="muted">No trade with the faction.</span>'}</p>
          <div class="row">
            <select id="ctMat${c.i}">${MATS.map((m, k) => `<option value="${k}">${m}</option>`).join("")}</select>
            <select id="ctDir${c.i}"><option value="1">Export to the town</option><option value="-1">Import from the town</option><option value="0">Stop</option></select>
            <input type="number" id="ctAmt${c.i}" min="0" value="10">
            <button class="btn small" onclick="csnCityTrade(${c.i})">Set</button>
            <span class="spacer"></span>
            <button class="btn small secondary" onclick="csnCmd('upgrades|${c.i}')">Upgrade buildings…</button>
          </div></div>`;
      });
    }
    h += `<div class="row" style="margin-top:16px"><button class="btn secondary" onclick="csnCmd('economyMenu')">Full economy ledger (taxes, guards)…</button></div>`;
    return h;
  }

  window.csnTax = (town, lv) => {
    const c = (state.cities || []).find((x) => x.i === town);
    const before = c ? c.tax : -1;
    if (c) { c.tax = lv; safeRender(); }
    toast("Working…", "busy");
    send(`tax|${town}|${lv}`);
    if (c) c.tax = before;   // the game's answer decides (a confirmation can still say no)
  };
  window.csnGoldPreset = (n) => { const i = $("goldAmt"); if (i) i.value = n; };
  window.csnGold = (kind) => {
    const n = parseInt($("goldAmt").value, 10);
    if (!(n > 0)) { toast("Enter an amount of gold."); return; }
    if (kind === "deposit" && n > (state.purse || 0)) { toast(`You only carry ${num(state.purse)} gold.`); return; }
    if (kind === "withdraw" && n > (state.gold || 0)) { toast(`The treasury only holds ${num(state.gold)} gold.`); return; }
    toast("");
    csnCmd(`${kind}|${n}`);
  };
  window.csnCityTrade = (i) => {
    const mat = parseInt($("ctMat" + i).value, 10);
    const dir = parseInt($("ctDir" + i).value, 10);
    const amt = Math.max(0, parseInt($("ctAmt" + i).value, 10) || 0);
    csnCmd(`cityTrade|${i}|${mat}|${dir * amt}`);
  };
  window.csnTrade = () => {
    const side = parseInt($("trSide").value, 10), mat = parseInt($("trMat").value, 10);
    const dir = parseInt($("trDir").value, 10), amt = parseInt($("trAmt").value, 10);
    if (!(amt > 0)) { toast("Enter an amount."); return; }
    const cur = ((state.trade || [])[side - 1] || [])[mat] || 0;
    if (cur && Math.sign(cur) !== dir) {
      toast(`You already ${cur > 0 ? "import" : "export"} ${MATS[mat].toLowerCase()} with ${SIDES[side]}. End that agreement first.`);
      return;
    }
    toast("");
    csnCmd(`trade|${side}|${mat}|${dir}|${amt}`);
  };
  function updateTradeCost() {
    if (!$("trAmt")) return;
    const a = parseInt($("trAmt").value, 10) || 0;
    const d = parseInt($("trDir").value, 10);
    const g = a * (state.tradeprice || 10);
    $("trCost").textContent = d > 0 ? `costs ${num(g)} gold a day` : `earns ${num(g)} gold a day`;
  }

  // ---------------------------------------------------------------- settings
  function slider(key, label, help, min, max, step, value, unit) {
    return `<div class="setting"><div class="what"><div>${label}</div><div class="muted">${help}</div></div>
      <input type="range" min="${min}" max="${max}" step="${step}" value="${value}" oninput="csnSlide(this,'${unit}')" onchange="csnSet('${key}', this.value)">
      <div class="val">${value}${unit}</div></div>`;
  }
  window.csnSlide = (el, unit) => { el.nextElementSibling.textContent = el.value + unit; };
  window.csnSet = (key, v) => {
    const st = state.settings || (state.settings = {});
    const map = { battleSize: "battlesize", battleSpeed: "battlespeed", pause: "pause" };
    if (map[key]) { st[map[key]] = key === "pause" ? !!parseInt(v, 10) : parseInt(v, 10); safeRender(); }
    send(`setting|${key}|${parseInt(v, 10)}`);
    toast("Saved.", "ok");
  };

  function pageSettings() {
    const st = state.settings || {};
    const light = document.body.classList.contains("theme-light");
    const speed = st.battlespeed || 2;
    let h = `<h2>Look</h2>
      <div class="setting"><div class="what"><div>Theme</div><div class="muted">Also in the MCM.</div></div>
        <div class="seg"><button class="${light ? "" : "on"}" onclick="csnTheme(0)">Dark</button><button class="${light ? "on" : ""}" onclick="csnTheme(1)">Light</button></div></div>
      <div class="setting"><div class="what"><div>Pause the game while menus are open</div><div class="muted">Applies from the next menu you open. Also in the MCM.</div></div>
        <div class="seg"><button class="${st.pause ? "" : "on"}" onclick="csnSet('pause', 0)">Off</button><button class="${st.pause ? "on" : ""}" onclick="csnSet('pause', 1)">On</button></div></div>
      <h2>Difficulty</h2>
      <div class="setting"><div class="what"><div>Battle size</div><div class="muted">Troops on the field for each side at any one time. Big battles are heavy on older PCs.</div></div>
        <div class="seg">${[[0, "8 v 8"], [1, "16 v 16"], [2, "32 v 32"]].map(([v, n]) => `<button class="${(st.battlesize || 0) === v ? "on" : ""}" onclick="csnSet('battleSize', ${v})">${n}</button>`).join("")}</div></div>
      <div class="setting"><div class="what"><div>Reinforcement speed</div><div class="muted">How quickly fallen troops are replaced in battle.</div></div>
        <div class="seg">${[[1, "Slow"], [2, "Normal"], [4, "Fast"]].map(([v, n]) => `<button class="${speed === v ? "on" : ""}" onclick="csnSet('battleSpeed', ${v})">${n}</button>`).join("")}</div></div>
      ${slider("enemyRespawn", "Enemy armies return after", "Hours before a destroyed enemy army is raised again. Lower is harder.", 6, 240, 6, st.enemyrespawn || 24, " h")}
      ${slider("enemyRecovery", "Enemy armies refill after", "Hours an enemy army needs to recover after a battle. Lower is harder.", 6, 240, 6, st.enemyrecovery || 24, " h")}
      <h2>Questline</h2>
      <div class="setting"><div class="what"><div>Skip the tutorial</div><div class="muted">Jump straight to declaring war on the Imperials or Stormcloaks.</div></div>
        <button class="btn secondary" ${st.tutorialdone ? "disabled" : ""} onclick="csnCmd('skipTutorial')">${st.tutorialdone ? "Done" : "Skip"}</button></div>
      <h2>Debug</h2>
      <div class="setting"><div class="what"><div>Debug log ${st.debuglog ? '<span class="pill ok">On</span>' : '<span class="pill">Off: turn on in MCM &gt; Debug</span>'}</div>
        <div class="muted">File: ${esc(st.logpath || "Documents\\My Games\\Skyrim Special Edition\\SKSE\\ConquestOfSkyrimNet.log")}</div></div></div>
      <div class="setting"><div class="what"><div>Current battle</div><div class="muted">${st.battle ? "A battle is being fought." : "No battle is being fought right now."}</div></div>
        <button class="btn small secondary" ${st.battle ? "" : "disabled"} onclick="csnCmd('winBattle')">Win</button>
        <button class="btn small danger" ${st.battle ? "" : "disabled"} onclick="csnCmd('loseBattle')">Lose</button></div>
      <div class="setting"><div class="what"><div>Hold owner</div><div class="muted">Hand a hold's city and its roads to anyone, through Conquest of Skyrim's own transfers.</div></div>
        <select id="dbgHold">${(st.holdowners || []).map((x, i) => `<option value="${i}">${esc(x.name)}: ${esc(x.city)} ${SIDE_NAMES[x.owner] || "?"}, roads ${SIDE_NAMES[x.roads] || "nobody"}</option>`).join("")}</select>
        <select id="dbgHoldOwner"><option value="1">${esc(state.name || "Your faction")}</option><option value="11">Imperial Legion</option><option value="12">Stormcloaks</option></select>
        <button class="btn small secondary" onclick="csnDebugGive('debugHold', 'dbgHold', 'dbgHoldOwner')">Give</button></div>
      <div class="setting"><div class="what"><div>Fort owner</div><div class="muted">Hand any fort to anyone, through Conquest of Skyrim's own transfer.</div></div>
        <select id="dbgFort">${(st.forts || []).map((f, i) => `<option value="${i}">${esc(f.name)} (${OWNER_NAMES[f.owner] || "?"})</option>`).join("")}</select>
        <select id="dbgOwner"><option value="1">${esc(state.name || "Your faction")}</option><option value="11">Imperial Legion</option><option value="12">Stormcloaks</option></select>
        <button class="btn small secondary" onclick="csnDebugGive('debugFort', 'dbgFort', 'dbgOwner')">Give</button></div>`;
    return h;
  }
  // inline onclick runs outside this file's scope, where $ doesn't exist: read the dropdowns here
  window.csnDebugGive = (cmd, whatId, ownerId) => {
    const w = $(whatId), o = $(ownerId);
    if (!w || !o) return;
    csnCmd(`${cmd}|${w.value}|${o.value}`);
  };
  const OWNER_NAMES = { 1: "Imperials", 2: "Stormcloaks", 69: "yours" };
  // holds: city owner and roads (CoS: 1 the player's faction, 11 Imperials, 12 Stormcloaks)
  const SIDE_NAMES = { 1: "yours", 11: "Imperial", 12: "Stormcloak" };
  // ---------------------------------------------------------------- culture
  const STYLES = [
    ["Laissez-faire", "A light hand. Your people are casual with you and each other and speak their minds."],
    ["Democratic", "Order and hierarchy. Formalities, sir and ma'am for higher ranks; opinions through proper channels."],
    ["Dictatorship", "Iron-fist rule. Strict and stern; orders obeyed at once, harsh criticism is normal."],
    ["Other", "Describe your own way of ruling below."],
  ];
  let cultureDraft = null;   // unsaved edits survive redraws

  function pageCulture() {
    const c = state.culture || {};
    if (!cultureDraft) cultureDraft = { text: c.text || "", doctrine: c.doctrine || "", style: c.style >= 0 ? c.style : 1, other: c.other || "" };
    const d = cultureDraft;
    return `<p class="lead">Who your faction is, how you lead it, and how it makes war. SkyrimNet characters use this: everyone in Skyrim knows what your faction is, its people follow your leadership style, and its soldiers and officers follow your doctrine.</p>
      <h2>What the ${esc(state.name || "faction")} is and does</h2>
      <p class="muted small">General knowledge across Skyrim. Its purpose, beliefs, customs, symbols, reputation.</p>
      <textarea id="cuText" maxlength="1500" placeholder="A company of free swords sworn to drive both the Legion and the Stormcloaks out of Skyrim. We protect the common folk and take no part in the old feuds…">${esc(d.text)}</textarea>
      <h2>Leadership style</h2>
      <p class="muted small">How you rule, and so how your officers, captains, soldiers, jarls and stewards speak to you and to each other. Also in the MCM.</p>
      <div class="styles">${STYLES.map(([n, t], i) => `<button class="style-card ${d.style === i ? "on" : ""}" onclick="csnStyle(${i})"><b>${n}</b><span class="muted">${t}</span></button>`).join("")}</div>
      <div class="${d.style === 3 ? "" : "hidden"}" style="margin-top:10px"><textarea id="cuOther" maxlength="1500" placeholder="I rule as first among equals: my captains vote on campaigns, but my word ends every argument…">${esc(d.other)}</textarea></div>
      <h2>Military doctrine</h2>
      <p class="muted small">Known to your General, captains, commanders and soldiers. How you fight, train and treat the enemy.</p>
      <textarea id="cuDoctrine" maxlength="1500" placeholder="Strike fast and at night. Never leave the wounded behind. Spare those who surrender, burn nothing that farmers need…">${esc(d.doctrine)}</textarea>
      <div class="row" style="margin-top:14px"><span class="spacer"></span><button class="btn" onclick="csnSaveCulture()">Save</button></div>`;
  }

  function readCulture() {
    if (!cultureDraft) return;
    ["cuText", "cuDoctrine", "cuOther"].forEach((id, k) => {
      const el = $(id);
      if (el) cultureDraft[["text", "doctrine", "other"][k]] = el.value;
    });
  }
  window.csnStyle = (i) => { readCulture(); cultureDraft.style = i; safeRender(); };
  const clean = (t) => String(t || "").replace(/[|]/g, "/").replace(/\s*[\r\n]+\s*/g, " ").trim().slice(0, 1500);
  window.csnSaveCulture = () => {
    readCulture();
    const d = cultureDraft;
    send(`culture|culture|${clean(d.text)}`);
    send(`culture|doctrine|${clean(d.doctrine)}`);
    send(`culture|other|${clean(d.other)}`);
    send(`culture|style|${d.style}`);
    send("cultureSaved");
    cultureDraft = null;
    toast("Saved. Your people will act on it from their next conversation.", "ok");
  };

  // ---------------------------------------------------------------- blacksmith (next to the faction's Blacksmith)
  const RACES = ["Argonian", "Breton", "Dark Elf", "High Elf", "Imperial", "Khajiit", "Nord", "Orc", "Redguard", "Wood Elf"];
  const TROOPS = ["Soldiers", "Warriors", "Archers", "Crossbowmen", "City guards"];
  const MAGES = ["Fire mages", "Frost mages", "Shock mages", "Healers", "Conjurers", "Alteration mages"];

  function templatesBlock() {
    const t = state.templates;
    if (!t) return "";
    return `<h2>Troop templates</h2><p class="muted small">Ask your General or Blacksmith: "put 10 soldiers and 7 archers in template 1", "apply template 1 to Army 2". Templates cost nothing; an army refills to its template.</p>
      <table>${t.map((x, i) => `<tr><td>Template ${i + 1}</td><td>${esc(x)}</td></tr>`).join("")}</table>`;
  }

  function pageBlacksmith() {
    const b = state.smith || {};
    const races = b.races || [], genders = b.genders || [], gen = b.gendered || [];
    let h = `<p class="lead">Blacksmith ${esc(state.nearblacksmith)} keeps your troops armed and dressed.</p>
      <h2>Outfits by troop type</h2>
      <p class="muted small">Pick a troop type, then dress them all alike or set separate outfits for men and women. An army's own <b>Set outfit</b> (Armies tab) overrides these for that army.</p>
      <div class="split">${TROOPS.map((t, i) => `<div class="card"><div class="card-head"><h3>${t}</h3><span class="pill">${gen[i] ? "Men and women apart" : "One outfit for all"}</span></div>
        <div class="row"><button class="btn small" onclick="csnCmd('bsOutfit|${i}')">Manage equipment…</button></div></div>`).join("")}</div>`;
    if (b.mages) h += `<div class="row" style="margin-top:8px">${MAGES.map((t, i) => `<button class="btn small secondary" onclick="csnCmd('bsOutfit|${10 + i}')">${t}</button>`).join("")}</div>`;
    h += `<div class="row" style="margin-top:12px"><button class="btn secondary" onclick="csnCmd('bsUpgrade')">Buy better standard armour…</button>
      <span class="muted small">Iron to Dragonplate, paid from the treasury and metal.</span></div>
      <h2>Who may join your army</h2>
      <p class="muted small">New recruits are drawn from the races and genders you allow.</p>
      <div class="chips">${RACES.map((r, i) => `<button class="chip ${races[i] ? "on" : ""}" onclick="csnToggle('races', ${i}, 'bsRace')">${races[i] ? "✓ " : ""}${r}</button>`).join("")}</div>
      <div class="chips" style="margin-top:10px">${["Men", "Women"].map((g, i) => `<button class="chip ${genders[i] ? "on" : ""}" onclick="csnToggle('genders', ${i}, 'bsGender')">${genders[i] ? "✓ " : ""}${g}</button>`).join("")}</div>`;
    h += templatesBlock();
    if (b.pending) h += `<div class="note">You changed who may serve. Apply it to re-raise your current troops with the new races and genders (this can take a while).</div>
      <div class="row"><button class="btn" onclick="csnCmd('bsApply')">Apply to current troops</button></div>`;
    return h;
  }

  // Tick/untick at once on screen; the game catches up in the background.
  window.csnToggle = (list, i, cmd) => {
    const b = state.smith || (state.smith = {});
    const arr = b[list] || (b[list] = []);
    arr[i] = !arr[i];
    b.pending = true;
    safeRender();
    send(`${cmd}|${i}|${arr[i] ? 1 : 0}`);
  };

  window.csnTheme = (v) => { window.csnSetTheme(v); send(`setting|theme|${v}`); safeRender(); };

  // ---------------------------------------------------------------- after drawing
  function bind() {
    if (tab === "general") armies().forEach((a) => window.csnOrderChanged(a.i));
    if (tab === "steward" && $("trSide")) {
      const p = state.ctx && state.ctx.proposal;
      if (p) { $("trSide").value = p.side; $("trMat").value = p.mat; $("trDir").value = p.dir; $("trAmt").value = p.amount; }
      ["trAmt", "trDir"].forEach((id) => $(id).addEventListener("input", updateTradeCost));
      updateTradeCost();
    }
  }
})();
