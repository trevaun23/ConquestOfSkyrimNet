// Conquest of SkyrimNet faction screen.
// Papyrus (CSN_Core via ConquestOfSkyrimNetUI.dll) calls window.csnOpen(screen, state) / window.csnUpdate(screen, state).
// The view answers with window.csnSend("cmd|a|b|...") and window.csnClose("").
// Every other Conquest of Skyrim menu is drawn by dialogs.js.
// Note: keys arrive lower-case (the DLL normalises JSON built in Papyrus), and short string values such as
// tab names can come back with different capitalisation, so compare those case-insensitively.

(function () {
  "use strict";

  window.addEventListener("error", (e) => {
    try { if (typeof window.csnLog === "function") window.csnLog(String(e.message) + " @" + e.lineno); } catch (_) {}
  });

  const SIDES = { 1: "the Imperials", 2: "the Stormcloaks" };
  const MATS = ["Food", "Metal", "Wood"];
  const BUILDINGS = ["Barracks", "Farms", "Lumber mills", "Mines"];
  const ORDERS = [
    { k: 2, label: "Follow me" },
    { k: 1, label: "Hunt for food" },
    { k: 0, label: "Return to home holding" },
    { k: 3, label: "Garrison a city", needs: "city" },
    { k: 4, label: "Garrison a fort", needs: "fort" },
    { k: 5, label: "Make camp in a hold", needs: "hold" },
  ];

  let state = {};
  let screen = "";
  let tab = "overview";
  // Everything the game has sent (kept between openings, and in the page's storage between sessions), so a tab
  // shows at once with what was last known while fresh figures are fetched.
  const CACHE_KEY = "csn_dash_cache_v1";
  let known = {};
  try { const c = window.localStorage && localStorage.getItem(CACHE_KEY); if (c) known = JSON.parse(c) || {}; } catch (_) { known = {}; }
  let saveTimer = 0;
  function remember(d) {
    const copy = Object.assign({}, d);
    ["ctx", "loading", "prefetch", "candidates", "tab"].forEach((k) => delete copy[k]);
    Object.assign(known, copy);
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { try { if (window.localStorage) localStorage.setItem(CACHE_KEY, JSON.stringify(known)); } catch (_) {} }, 800);
  }
  let updating = false;        // what's shown is from before; fresh figures are on their way
  let fresh = new Set();       // tabs whose data arrived since the screen opened
  let prefetching = "";        // the tab whose data is being fetched in the background
  // While nothing else is going on, fetch the other tabs one at a time so moving between them is instant.
  function prefetchNext() {
    if (prefetching || tabPending || updating || screen !== "dashboard" || !state.founded) return;
    const next = tabs().map(([k]) => k).find((k) => TAB_NEEDS[k] && k !== tab && !fresh.has(k));
    if (!next) return;
    prefetching = next;
    send(`prefetch|${next}`);
  }
  let lastTab = "";       // the tab shown when the screen was last closed (this session)
  // the War Table is part of Armies and the Steward's books part of Lands (older saves and calls still say the old names)
  const normTab = (k) => { const t = lc(k); return t === "general" ? "armies" : t === "steward" ? "holdings" : t; };
  let picking = -1;      // office being filled from the people nearby (-1 none, 9 = commander)

  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const num = (n) => (Number(n) || 0).toLocaleString("en-US");

  // ---- hover details: any element with data-tip shows a panel by the cursor. Lines: "# title", "- bullet", text.
  const tipAttr = (lines) => `data-tip="${esc([].concat(lines).filter((x) => x !== "" && x != null).join("\n"))}"`;
  const info = (lines) => `<span class="info" ${tipAttr(lines)}>i</span>`;
  const clip = (text, empty) => text ? `<span class="clip" ${tipAttr(text)}>${esc(text)}</span>` : `<span class="muted">${empty || "none"}</span>`;
  const tipEl = document.createElement("div");
  tipEl.id = "tip";
  tipEl.className = "hidden";
  document.body.appendChild(tipEl);
  function tipHtml(t) {
    return String(t).split("\n").map((l) => {
      if (l.startsWith("# ")) return `<b>${esc(l.slice(2))}</b>`;
      if (l.startsWith("- ")) return `<div class="tip-li">${esc(l.slice(2))}</div>`;
      return `<div>${esc(l)}</div>`;
    }).join("");
  }
  function placeTip(e) {
    if (tipEl.classList.contains("hidden")) return;
    const pad = 14, w = tipEl.offsetWidth, h = tipEl.offsetHeight;
    let x = e.clientX + pad, y = e.clientY + pad;
    if (x + w > window.innerWidth - 8) x = e.clientX - w - pad;
    if (y + h > window.innerHeight - 8) y = e.clientY - h - pad;
    tipEl.style.left = Math.max(8, x) + "px";
    tipEl.style.top = Math.max(8, y) + "px";
  }
  let tipFor = null;
  document.addEventListener("mouseover", (e) => {
    const t = e.target && e.target.closest ? e.target.closest("[data-tip]") : null;
    if (!t) { tipFor = null; tipEl.classList.add("hidden"); return; }
    if (t !== tipFor) { tipFor = t; tipEl.innerHTML = tipHtml(t.getAttribute("data-tip")); }
    tipEl.classList.remove("hidden");
    placeTip(e);
  });
  document.addEventListener("mousemove", placeTip);
  document.addEventListener("mousedown", () => tipEl.classList.add("hidden"));
  const lc = (s) => String(s || "").toLowerCase();

  // Tell the plugin when a text box has focus, so the faction-menu key types a letter instead of closing.
  const TEXTY = ["text", "number", "search", "email", "password", "tel", "url", ""];
  const typingEl = (el) => el && (el.tagName === "TEXTAREA" || el.isContentEditable || (el.tagName === "INPUT" && TEXTY.includes(lc(el.getAttribute("type") || ""))));
  // While typing, the plugin also holds the game paused (when "keep the game paused" is off), so other mods' hotkeys
  // don't fire. Leaving the box is reported a moment later, so a box-to-box move or a refocus doesn't flicker.
  let typingNow = false, lastTypingEl = null, typingTimer = 0;
  const tellTyping = (on) => { typingNow = on; if (typeof window.csnTyping === "function") window.csnTyping(on ? "1" : "0"); };
  document.addEventListener("focusin", (e) => { if (typingEl(e.target)) { lastTypingEl = e.target; clearTimeout(typingTimer); tellTyping(true); } });
  document.addEventListener("focusout", (e) => {
    if (!typingEl(e.target)) return;
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => { if (!typingEl(document.activeElement)) tellTyping(false); }, 200);
  });
  // the plugin refocused the view (to pause or unpause): put the caret back in the box being typed in
  window.csnRestoreTyping = () => {
    if (typingNow && lastTypingEl && document.body.contains(lastTypingEl) && document.activeElement !== lastTypingEl) {
      try { lastTypingEl.focus(); } catch (err) { /* gone */ }
    }
  };

  function send(cmd) {
    if (typeof window.csnSend === "function") window.csnSend(cmd);
    else console.log("csnSend", cmd);
  }
  // Commands that change something: say "working" at once, the game answers with csnToast and fresh data.
  const QUIET = /^(openTab|scan|close|setting\|theme)/;
  window.csnCmd = (cmd) => { if (!QUIET.test(cmd)) toast("Working…", "busy"); send(cmd); };

  function close(fromGame) {
    $("backdrop").classList.add("hidden");
    screen = "";
    picking = -1;
    if (fromGame !== true && typeof window.csnClose === "function") window.csnClose("");
  }
  window.csnCloseScreen = close;

  // Feedback line at the bottom: kind "ok" (green), "err" (red) or "busy" (neutral, while the game works).
  let toastTimer = 0;
  function toast(msg, kind) {
    const t = $("toast");
    t.textContent = msg || "";
    t.className = msg ? (kind || "err") : "";
    clearTimeout(toastTimer);
    if (msg && kind === "ok") toastTimer = setTimeout(() => { if (t.textContent === msg) { t.textContent = ""; t.className = ""; } }, 6000);
  }
  // From the game: the result of an action (success or the reason it failed).
  window.csnToast = (msg, err) => toast(msg, err ? "err" : "ok");

  window.csnSetTheme = function (t) {
    const light = lc(t) === "light" || t === 1 || t === "1";
    document.body.classList.toggle("theme-light", light);
    document.body.classList.toggle("theme-dark", !light);
  };

  window.csnOpen = function (scr, data) {
    const d = (data && typeof data === "object") ? data : {};
    // another faction (a different save): what we knew belongs to it, not to this one
    if (known.name && d.name && known.name !== d.name) known = {};
    state = Object.assign({}, known, d);
    remember(d);
    updating = !!d.loading;
    fresh = new Set();
    prefetching = "";
    screen = scr;
    picking = -1;
    tab = normTab(state.ctx && state.ctx.tab) || "overview";
    if (state.ctx && state.ctx.proposal) subSel.holdings = "Trade abroad";
    // opened with the faction-menu key: back to the tab shown last (the game remembers it too, across loads)
    if (state.ctx && state.ctx.hotkey && lastTab && lastTab !== tab) { tab = lastTab; tabPending = tab; setTimeout(() => send(`openTab|${tab}`), 0); }
    lastTab = tab;
    cultureDraft = null;
    toast("");
    if (state.theme !== undefined) window.csnSetTheme(state.theme);
    $("backdrop").classList.remove("hidden");
    safeRender();
  };

  window.csnUpdate = function (scr, data) {
    if (data && typeof data === "object" && data.prefetch !== undefined) {
      // another tab's data, fetched in the background: keep it for when that tab opens; don't redraw this one
      const pt = lc(data.prefetch);
      const keepCtx = state.ctx;
      remember(data);
      state = Object.assign({}, state, data, { ctx: keepCtx });
      delete state.prefetch;
      fresh.add(pt);
      prefetching = "";
      try { renderQuick(); renderTabs(); } catch (_) {}
      setTimeout(prefetchNext, 50);
      return;
    }
    // updates carry the current tab's parts only: keep the rest from before
    if (data && typeof data === "object") {
      state = Object.assign({}, state, data); if (!data.loading) delete state.loading;
      remember(data);
      if (!data.loading) { updating = false; fresh.add(lc(data.tab) || tab); }
    }
    if ($("toast").className === "busy") toast("");
    if (scr) screen = scr;
    if (data && typeof data === "object" && !data.loading) tabPending = "";
    if (state.theme !== undefined) window.csnSetTheme(state.theme);
    safeRender();
    setTimeout(prefetchNext, 50);
  };

  function safeRender() {
    try { render(); } catch (err) {
      $("content").innerHTML = `<div class="empty">Something went wrong drawing this page. Press Esc to close.</div>`;
      if (typeof window.csnLog === "function") window.csnLog("render: " + err + " " + (err && err.stack));
    }
  }

  $("closeBtn").addEventListener("click", () => close());
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !window.csnDialogOpen && screen) {
      if (picking >= 0) { picking = -1; safeRender(); return; }
      close();
    }
  });

  // ---------------------------------------------------------------- tabs
  function tabs() {
    const pending = state.requests ? state.requests.filter((r) => r.status === 0).length : (state.pending || 0);
    const t = [["overview", "Overview"], ["requests", pending ? `Requests (${pending})` : "Requests"], ["officers", "Officers"], ["armies", "Armies", state.neargeneral ? "War Table · " + state.neargeneral : ""], ["holdings", "Lands", state.nearsteward ? "Books · " + state.nearsteward : ""]];

    if (state.nearblacksmith) t.push(["blacksmith", "Blacksmith", state.nearblacksmith]);
    const realm = state.realm || {};
    const alarm = (realm.towns || []).some((x) => x.stage > 0) || (realm.bands || []).some((b) => !b.peace);
    t.push(["realm", alarm ? "Unrest ⚠" : "Unrest & Intrigue"]);
    t.push(["settle", "Settlements"]);
    t.push(["culture", "Culture"]);
    t.push(["settings", "Settings"]);
    return t;
  }

  function renderTabs() {
    const list = tabs();
    if (!list.some(([k]) => k === tab)) tab = "overview";
    $("tabs").innerHTML = list.map(([k, n, who]) =>
      `<button class="${k === tab ? "active" : ""}" onclick="csnTab('${k}')">${n}${who ? `<span class="who">${esc(who)}</span>` : ""}</button>`).join("");
  }
  // which part of the game's data each tab draws from; until it arrives the tab shows a spinner
  const TAB_NEEDS = { requests: "requests", holdings: "cities", settings: "settings",
    realm: "realm", settle: "settle", blacksmith: "smith" };
  let tabPending = "";
  window.csnTab = (k) => { if (tab === "culture") readCulture(); tab = normTab(k); lastTab = tab; picking = -1; toast(""); tabPending = tab; tipEl.classList.add("hidden"); safeRender(); $("content").scrollTop = 0; send(`openTab|${tab}`); };

  let renderedTab = "";
  // Sub-tabs: every section of a page that starts with its own <h2> header gets a sub-tab of its own; what comes
  // before the first header stays on top of every sub-tab. The choice is kept per tab.
  const subSel = {};
  let subTitles = [];
  window.csnSub = (i) => { if (tab === "culture") readCulture(); subSel[tab] = subTitles[i]; safeRender(); $("content").scrollTop = 0; };
  function secTitle(h2) {
    let t = "";
    h2.childNodes.forEach((n) => { if (n.nodeType === 3) t += n.textContent; else if (n.nodeType === 1 && !n.classList.contains("info") && !n.classList.contains("muted")) t += n.textContent; });
    return t.replace(/\s+/g, " ").trim() || h2.textContent.trim();
  }
  function subtabify(html) {
    const box = document.createElement("div");
    box.innerHTML = html;
    const intro = [], secs = [];
    let cur = null;
    Array.from(box.childNodes).forEach((n) => {
      if (n.nodeType === 1 && n.tagName === "H2") { cur = { title: secTitle(n), pref: n.getAttribute("data-pref") === "1", nodes: [n] }; secs.push(cur); }
      else if (cur) cur.nodes.push(n);
      else intro.push(n);
    });
    if (secs.length < 2) { subTitles = []; return html; }
    subTitles = secs.map((x) => x.title);
    let sel = subSel[tab];
    if (!subTitles.includes(sel)) { const p = secs.find((x) => x.pref); sel = p ? p.title : subTitles[0]; }
    const outer = (nodes) => nodes.map((n) => (n.nodeType === 1 ? n.outerHTML : n.nodeType === 3 ? n.textContent : "")).join("");
    const chosen = secs.find((x) => x.title === sel);
    const bar = `<div class="subtabs">${secs.map((x, i) => `<button class="${x.title === sel ? "on" : ""}" onclick="csnSub(${i})">${esc(x.title)}</button>`).join("")}</div>`;
    return outer(intro) + bar + `<div class="subtab-body">${outer(chosen.nodes)}</div>`;
  }
  function render() {
    if (screen !== "dashboard") { $("content").innerHTML = ""; return; }
    $("tabs").classList.remove("hidden");
    $("title").textContent = state.name || "Your faction";
    $("crest").textContent = (state.name || "C").trim().charAt(0).toUpperCase();
    if ($("today")) $("today").textContent = state.now !== undefined ? tamrielDate(state.now) : "";
    $("subtitle").textContent = (state.founded ? `Led by ${state.leader || "you"} · ${warLine(true)}` : "Not founded yet") + (state.version ? ` · Conquest of SkyrimNet v${state.version}` : "");
    renderQuick();
    renderTabs();
    const c = $("content");
    if (!state.founded) {
      c.innerHTML = `<div class="empty"><h3>Your faction isn't founded yet</h3>Read <b>Start my Faction</b> to found it. This screen fills up as your faction grows.</div>`;
      return;
    }
    // nothing known yet (the very first opening): a spinner; otherwise the last known figures, marked as updating
    if (state.loading && state.armies === undefined) { c.innerHTML = loadingBox("Opening the books…"); return; }
    const need = TAB_NEEDS[tab];
    if (need && state[need] === undefined) { c.innerHTML = loadingBox(); return; }
    const stale = updating || state.loading || (tabPending === tab && !fresh.has(tab));
    const page = {
      overview: pageOverview, requests: pageRequests, officers: pageOfficers, armies: pageArmies, holdings: pageLands,
      settings: pageSettings, culture: pageCulture, blacksmith: pageBlacksmith,
      realm: pageRealm, settle: pageSettle,
    }[tab] || pageOverview;
    // a redraw keeps your place on the page (only switching tabs goes back to the top)
    const keep = renderedTab === tab ? c.scrollTop : 0;
    c.innerHTML = (stale ? `<div class="updating"><span class="spinner sm"></span>Updating content…</div>` : "") + subtabify(page());
    renderedTab = tab;
    c.scrollTop = keep;
    bind();
  }

  // Treasury, supplies and your purse next to the faction name, on every tab.
  function renderQuick() {
    const q = $("quick");
    if (!state.founded) { q.classList.add("hidden"); return; }
    q.classList.remove("hidden");
    q.innerHTML = `<span class="q-gold" title="Faction treasury">Treasury <b>${num(state.gold)}</b> gold</span><span class="sep"></span>
      <span title="Faction supplies">Food <b>${num(state.food)}</b></span><span title="Faction supplies">Metal <b>${num(state.metal)}</b></span>
      <span title="Faction supplies">Wood <b>${num(state.wood)}</b></span><span class="sep"></span>
      <span title="Gold you carry">Your purse <b>${num(state.purse)}</b> gold</span>`;
  }

  // ---------------------------------------------------------------- helpers
  function stat(label, value, delta) {
    let d = "";
    if (delta !== undefined) {
      const n = Number(delta) || 0;
      d = `<div class="delta ${n > 0 ? "up" : n < 0 ? "down" : ""}">${n > 0 ? "+" : ""}${num(n)} a day</div>`;
    }
    return `<div class="stat"><div class="label">${label}</div><div class="value">${value}</div>${d}</div>`;
  }

  function warLine(plain) {
    const w = state.war || [false, false];
    let s = "At peace";
    if (w[0] && w[1]) s = "At war with the Imperials and the Stormcloaks";
    else if (w[0]) s = "At war with the Imperials";
    else if (w[1]) s = "At war with the Stormcloaks";
    return plain ? s : (w[0] || w[1] ? `<span class="warn">${s}</span>` : s);
  }

  const officers = () => state.officers || [];
  const armies = () => (state.armies || []);
  const ourCities = () => (state.cities || []).filter((c) => c.ours);

  // a part of the page the game hasn't sent yet: a spinner instead of an empty page
  function loadingBox(what) { return `<div class="loadingbox"><span class="spinner"></span>${what ? esc(what) : "Loading…"}</div>`; }
  function empty(title, text) { return `<div class="empty"><h3>${title}</h3>${text}</div>`; }

  // ---------------------------------------------------------------- overview
  function pageOverview() {
    const cities = ourCities();
    let h = realmAlerts() + `<div class="grid">
      ${stat("Treasury", num(state.gold) + " gold", state.goldday)}
      ${stat("Food", num(state.food), state.foodday)}
      ${stat("Metal", num(state.metal), state.metalday)}
      ${stat("Wood", num(state.wood), state.woodday)}
    </div>
    <div class="grid" style="margin-top:12px">
      ${stat("Towns ruled", cities.length)}
      ${stat("Claims", (state.claims || []).length)}
      ${stat("Armies", armies().length)}
      ${stat("Soldiers", num(armies().reduce((a, b) => a + (b.troops || 0), 0)))}
    </div>`;
    const waiting = (state.requests || []).filter((r) => r.status === 0).length;
    if (waiting) h += `<div class="card"><div class="card-head"><h3>${waiting} request${waiting > 1 ? "s" : ""} waiting for you</h3>
      <button class="btn small" onclick="csnTab('requests')">Open requests</button></div></div>`;
    h += `<h2>Officers</h2><table><tr><th>Office</th><th>Holder</th></tr>
      ${officers().map((o) => `<tr><td>${esc(o.role)}</td><td>${o.name ? esc(o.name) : '<span class="muted">Vacant</span>'}</td></tr>`).join("")}</table>`;
    h += `<h2>Wars</h2><p>${warLine()}.</p>`;
    if (!state.nearsteward || !state.neargeneral) {
      h += `<p class="muted small" style="margin-top:14px">Open this screen beside your Steward or one of your jarls for the books on the Lands tab (taxes, trade, gold, the treasury), or beside your General for the War Table on the Armies tab.</p>`;
    }
    return h;
  }

  // ---------------------------------------------------------------- requests (history log)
  const STATUS = [["Waiting for you", "warn"], ["Accepted", "ok"], ["Denied", ""], ["Met in the middle", "ok"], ["Withdrawn", ""]];

  // ---- the Tamrielic calendar (365 days, 4E): dates for requests
  const MONTHS = ["Morning Star", "Sun's Dawn", "First Seed", "Rain's Hand", "Second Seed", "Midyear", "Sun's Height", "Last Seed", "Hearthfire", "Frostfall", "Sun's Dusk", "Evening Star"];
  const MDAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const WEEK = ["Sundas", "Morndas", "Tirdas", "Middas", "Turdas", "Fredas", "Loredas"];
  const ordOf = (y, m, d) => { let o = y * 365; for (let k = 0; k < m; k++) o += MDAYS[k]; return o + d; };
  const ORD_MORNDAS = ordOf(201, 7, 31);   // the 31st of Last Seed, 4E 201 was a Morndas
  function tamrielDate(t) {
    const dt = state.date, now = state.now;
    if (!dt || now === undefined || t === undefined) return "";
    let o = ordOf(dt[0], dt[1], dt[2]) - (Math.floor(now) - Math.floor(t));
    const wd = WEEK[(((o - ORD_MORNDAS + 1) % 7) + 7) % 7];
    let y = Math.floor((o - 1) / 365), r = o - y * 365, m = 0;
    while (m < 11 && r > MDAYS[m]) { r -= MDAYS[m]; m++; }
    const nth = (n) => n + (n % 10 === 1 && n !== 11 ? "st" : n % 10 === 2 && n !== 12 ? "nd" : n % 10 === 3 && n !== 13 ? "rd" : "th");
    const hr = Math.floor((t - Math.floor(t)) * 24), ap = hr < 12 ? "AM" : "PM", h12 = ((hr + 11) % 12) + 1;
    return `${wd}, ${h12} ${ap}, ${nth(r)} of ${MONTHS[m]}, 4E ${y}`;
  }
  let reqView = "open";
  window.csnReqView = (v) => { reqView = v; safeRender(); $("content").scrollTop = 0; };

  function pageRequests() {
    const all = (state.requests || []).slice().sort((a, b) => (b.t || 0) - (a.t || 0));
    const running = (r) => r.kind === 6 && r.status === 1 && r.invleft > 0;
    const open = all.filter((r) => r.status === 0), going = all.filter(running), done = all.filter((r) => r.status !== 0 && !running(r));
    const list = reqView === "done" ? done : reqView === "going" ? going : open;
    let h = `<p class="lead">Your stewards and jarls ask for what their towns need. ${state.letters
      ? "Requests arrive as letters by courier; reading one lets you decide on the spot."
      : "Install Physical Letters to receive them as letters."}</p>`;
    h += `<div class="seg" style="margin-bottom:12px"><button class="${reqView !== "done" && reqView !== "going" ? "on" : ""}" onclick="csnReqView('open')">Waiting (${open.length})</button><button class="${reqView === "going" ? "on" : ""}" onclick="csnReqView('going')">Ongoing (${going.length})</button><button class="${reqView === "done" ? "on" : ""}" onclick="csnReqView('done')">Finished (${done.length})</button></div>`;
    if (!all.length) return h + empty("No requests yet", "When something happens that calls for it, your stewards, jarls, captains, commanders or General will ask you here: taxes, trade, a town's festival or cause, their troops' training, a famous commander to stand guard in their town, or better barracks, farms, mills or mines.");
    if (!list.length) return h + `<p class="muted">${reqView === "done" ? "Nothing answered yet." : reqView === "going" ? "No investments paying out right now. Invest in a Thane's venture and it shows here until it has paid back." : "Nothing waiting for you."}</p>`;
    list.forEach((r) => {
      const st = STATUS[r.status] || STATUS[4];
      const ago = r.daysago <= 0 ? "today" : r.daysago === 1 ? "yesterday" : `${r.daysago} days ago`;
      const tag = ["Taxes", "Trade", "Town grant", "Army", "Security", "Upgrade", "Investment"][r.kind || 0] || "Request";
      h += `<div class="card"><div class="card-head"><h3>${esc(r.text)}</h3><span><span class="pill">${tag}</span><span class="pill ${st[1]}">${st[0]}</span></span></div>
        <p class="small muted">${esc(r.from)} · ${esc(r.town)} · <span ${tipAttr([ago])}>${esc(tamrielDate(r.t) || ago)}</span></p>
        <p>${esc(r.why)}</p>`;
      if (r.marmy && r.status === 0) {
        const sg = (n) => (n > 0 ? "+" + n : "" + n);
        h += `<p class="small">Morale in ${esc(r.marmy)} (now ${r.mnow}): <span class="up">${sg(r.mup)} if accepted</span>${r.canmiddle ? `, ${sg(r.mmid)} if met halfway` : ""}, <span class="warn">${sg(r.mdown)} if denied</span></p>`;
      }
      if (r.kind === 6) {
        const pct = r.invin ? Math.round((r.invout / r.invin) * 100) : 0;
        h += `<div class="grid">${stat("You put in", esc(r.invcost))}${stat("It pays back", esc(r.invret))}${stat("Return", `${num(r.invout)} for ${num(r.invin)} (${pct}%)`)}</div>`;
        if (r.status === 1 && r.invleft > 0) h += `<p class="small up">Paying out into ${esc(r.town)}'s treasury: ${r.invleft} day(s) to go.</p>${bar(r.invdays - r.invleft, r.invdays)}`;
        else if (r.status === 1 && r.block) h += `<p class="small warn">${esc(r.block)}</p>`;
        else if (r.status === 1) h += `<p class="small muted">Paid back in full.</p>`;
      }
      if (r.block && r.status === 0) h += `<p class="small warn">Couldn't be done: ${esc(r.block)}</p>`;
      if (r.status === 0) {
        const security = r.kind === 4;
        const invest = r.kind === 6;
        h += `<div class="row"><button class="btn" onclick="csnDecide(${r.id}, 0)">${security ? "Accept: send them" : invest ? "Invest…" : "Accept"}</button>
          ${security || invest ? "" : `<button class="btn secondary" ${r.canmiddle ? "" : "disabled title='No middle ground for this one'"} onclick="csnDecide(${r.id}, 2)">Meet in the middle${r.canmiddle ? ": " + esc(r.middle) : ""}</button>`}
          <button class="btn danger" onclick="csnDecide(${r.id}, 1)">Deny</button>
          ${security ? `<span class="muted small">Denying costs ${Math.max(2, Math.floor((r.loy || 0) / 2))} loyalty there.</span>` : ""}</div>`;
      }
      h += `</div>`;
    });
    return h;
  }


  // ---------------------------------------------------------------- unrest, deserters and intrigue (1.9.0)
  function realmAlerts() {
    const r = state.realm || {};
    const lines = [];
    (r.towns || []).forEach((t) => {
      if (t.stage === 2) lines.push(`<b>${esc(t.name)}</b> has risen up (${t.rebels} rebels, ${t.left} day(s) before they hand it over)`);
      else if (t.stage === 1) lines.push(`Unrest in <b>${esc(t.name)}</b> over ${esc(t.why)}`);
    });
    (r.bands || []).forEach((b) => { if (!b.peace) lines.push(`<b>${esc(b.name)}</b> (${b.troops} deserters) holds ${esc(b.seat)}`); });
    if (!lines.length) return "";
    return `<div class="card warnbox"><div class="card-head"><h3>Trouble in the realm</h3><button class="btn small" onclick="csnTab('realm')">Deal with it</button></div><p>${lines.join("<br>")}</p></div>`;
  }

  const bar = (v, max) => `<div class="bar"><i style="width:${Math.max(0, Math.min(100, (v / (max || 100)) * 100))}%"></i></div>`;
  const STAGE = ["Calm", "Unrest", "Uprising"];
  const OUTLOOK = ["Guards would arrest the jarl", "Guards would argue, then side with you", "Guards would stand by the jarl (a fight)"];

  function pageRealm() {
    const r = state.realm || {};
    const it = state.intrigue || {};
    let h = `<p class="lead">How content your people and troops are, soldiers who have broken away, and cities you are turning against their jarls. Hover over anything for details.</p>`;

    h += `<h2>Your towns ${info(["# Unrest and uprisings", `Below ${r.threshold} loyalty with a grievance a town has a day of unrest, then rises.`, "- Grievances: hunger, heavy taxes (40%+), no garrison, unheard court cases, anger (loyalty under 10)", "- While it is up, no taxes reach the treasury and loyalty falls 3 a day", "- End it: meet their demands, kill the rebel leader yourself, or garrison twice their number"])}</h2>`;
    const towns = r.towns || [];
    if (!r.civil) h += `<p class="muted small">Civilian uprisings are turned off in the MCM.</p>`;
    if (!towns.length) h += empty("No towns yet", "Towns you rule appear here with their loyalty and any grievances.");
    else {
      h += `<table class="fixed"><tr><th style="width:22%">Town</th><th style="width:16%">Loyalty</th><th style="width:14%">State</th><th>Grievances</th><th style="width:150px"></th></tr>`;
      towns.forEach((t) => {
        const pill = t.stage > 0 ? "warn" : "ok";
        const stTip = t.stage === 2 ? ["# Uprising", `${t.rebels} armed rebels hold the town; your garrison: ${t.garrison}.`, `${t.left} day(s) before they open the gates to your enemies.`, "- No taxes while they hold it; loyalty falls 3 a day", "- A garrison of twice their number breaks it the next day (loyalty -5)", "- Killing their leader ends it too"]
          : t.stage === 1 ? ["# Unrest", "People gather in the streets. If nothing changes they rise tomorrow.", `It dies down if loyalty climbs 5 above ${r.threshold} or the grievance goes.`]
          : ["# Calm", `Loyalty ${t.loyalty}/100.`];
        let act = "";
        if (t.stage > 0) {
          act = `<button class="btn small" ${tipAttr(["# Meet their demands", `- ${num(t.gold)} gold for the families (treasury)`, t.food ? `- ${num(t.food)} food for the hungry` : "", "- Taxes one step lower", "- Loyalty +15; the unrest ends", "You confirm before anything is paid."])} onclick="csnCmd('reb|appease|${t.i}')">Meet demands…</button>`;
        }
        const sub = t.stage === 2 ? `<div class="small warn">${t.rebels} rebels · ${t.left}d left</div>` : "";
        h += `<tr><td>${esc(t.name)}${sub}</td><td>${t.loyalty}${bar(t.loyalty)}</td><td><span class="pill ${pill}" ${tipAttr(stTip)}>${STAGE[t.stage] || ""}</span></td><td class="small">${clip(t.why)}</td><td class="right">${act}</td></tr>`;
        // an uprising: send one of your armies to put it down
        const armyList = (r.armies || []).filter((a) => a.troops > 0 && !a.march);
        if (t.stage === 2 && armyList.length) {
          h += `<tr class="subrow"><td colspan="5"><div class="row right-row"><span class="small muted">Put it down by force:</span>
            <select id="quell${t.i}">${armyList.map((a) => `<option value="${a.i}">${esc(a.name)} (${a.troops} troops, morale ${a.morale})</option>`).join("")}</select>
            <button class="btn small danger" ${tipAttr(["# Send an army", `Against ${t.rebels} rebels. The army marches there (a few hours or more, by distance); the fight is decided when it arrives, by troops, stars and morale.`, "- Win: the uprising ends (loyalty -5); the army loses a few troops", "- Lose: the army loses many troops and morale; the rising goes on", "You confirm first and see the odds."])} onclick="csnQuell(${t.i})">Send army…</button></div></td></tr>`;
        }
      });
      h += `</table>`;
    }

    h += `<h2>Army morale ${info(["# Morale (0-100)", "- Down: unpaid wages (an empty treasury), empty bellies, refused requests", "- Up: stars (+15 at once), granted requests, pay and food", "Under its breaking point, with a complaint, an army may leave the faction as a free company."])}</h2>`;
    const ar = r.armies || [];
    if (!r.military) h += `<p class="muted small">Desertion is turned off in the MCM.</p>`;
    if (!ar.length) h += `<p class="muted">No armies yet.</p>`;
    else {
      h += `<table class="fixed"><tr><th style="width:34%">Army</th><th style="width:12%">Troops</th><th style="width:20%">Morale</th><th>Complaints</th></tr>`;
      ar.forEach((a) => {
        const low = a.morale < 30;
        h += `<tr><td><span ${tipAttr([`# ${a.name}`, a.leader])}>${esc(a.name)}</span><div class="small muted clip">${esc(a.leader)}</div>${a.march ? `<div class="small warn clip" ${tipAttr([a.march])}>${esc(a.march)}</div>` : ""}</td><td>${a.troops}</td><td><span ${tipAttr([`# Morale ${a.morale}/100`, `Breaks under ${Math.max(0, a.limit)}.`, low ? "The troops grumble openly." : ""])}>${a.morale}${bar(a.morale)}</span></td><td class="small">${clip(a.why)}</td></tr>`;
      });
      h += `</table>`;
    }

    const bands = r.bands || [];
    if (bands.length) {
      h += `<h2>Free companies ${info(["# Deserters", "An army that broke away holds a fort, town or hold, raids you every day and may lure other unhappy armies.", "- Kill their leader where they hold", "- Send a loyal army (troops, stars and morale decide)", "- Pay their arrears: the leader swears back in", "- Recognise their realm: raids stop, every town -5 loyalty"])}</h2>`;
      bands.forEach((b) => {
        const opts = ar.filter((a) => !a.march).map((a) => `<option value="${a.i}">${esc(a.name)} (${a.troops})</option>`).join("");
        h += `<div class="card"><div class="card-head"><h3>${esc(b.name)} <span class="muted small">${esc(b.leader)} · ${b.troops} soldiers · ${esc(b.seat)}</span></h3><span class="pill ${b.peace ? "ok" : "warn"}" ${b.realm ? tipAttr(["Proclaimed " + b.realm]) : ""}>${b.peace ? "At peace" : b.free ? "Free realm" : "Raiding"}</span></div>`;
        if (!b.peace) {
          h += `<div class="row">${opts ? `<select id="bandArmy${b.w}">${opts}</select><button class="btn small" ${tipAttr(["# Send an army", "The army marches there first; the battle is decided when it arrives, by troops, stars and morale. Win: they are destroyed. Lose: your army falls back, its morale shaken."])} onclick="csnSendBand(${b.w})">Send army…</button>` : ""}
          <button class="btn small secondary" ${tipAttr(["# Pay their arrears", `- ${num(b.gold)} gold and ${b.food} food`, "The leader swears back in as a Captain (the army is raised again)."])} onclick="csnCmd('reb|pay|${b.w}')">Pay arrears…</button>
          <button class="btn small danger" ${tipAttr(["# Recognise their realm", "The raids stop and they keep what they hold.", "- Every town you rule loses 5 loyalty"])} onclick="csnCmd('reb|grant|${b.w}')">Recognise…</button></div>`;
        }
        h += `</div>`;
      });
    }

    h += `<h2>Intrigue ${info(["# Turning a city", "Bribe guards and fund nobles and citizens (from your purse), win them over in conversation, or have your Steward or General's agents do it from the treasury.", "When the guards or the people stand at 40+, plan a coup: it plays out in the jarl's hall."])}</h2>`;
    const cities = it.cities || [];
    if (!it.on) h += `<p class="muted small">Intrigue is turned off in the MCM.</p>`;
    else if (!cities.length) h += `<p class="muted">No city ruled by the Imperials or Stormcloaks has a jarl to overthrow.</p>`;
    else {
      h += `<div class="split">`;
      cities.forEach((c) => {
        const coupTip = c.block ? ["# Not yet", c.block] : ["# Plan a coup", `If it happened now: ${OUTLOOK[c.outlook]}.`, `About ${c.crowd} citizens would gather with torches.`];
        h += `<div class="card"><div class="card-head"><h3>${esc(c.name)} <span class="muted small">${esc(c.jarl)} · ${SIDES[c.owner === 11 ? 1 : 2]}</span></h3><span class="pill ${c.outlook === 2 ? "warn" : "ok"}" ${tipAttr([OUTLOOK[c.outlook]])}>${c.outlook === 0 ? "Arrest" : c.outlook === 1 ? "Side with you" : "Fight"}</span></div>
          <div class="split"><div ${tipAttr(["# Guards ready to betray", `${c.guards}/100`, "80+ (with people 40+): they arrest the jarl"])}><div class="small muted">Guards</div>${c.guards}/100 ${bar(c.guards)}</div>
          <div ${tipAttr(["# Nobles and citizens behind you", `${c.people}/100`, "60+ (with guards 40+): the guards side with you after arguing"])}><div class="small muted">People</div>${c.people}/100 ${bar(c.people)}</div></div>
          <div class="row"><button class="btn small" ${tipAttr(["# Bribe guards", `${num(c.gp)} gold a point (from your purse).`, `${c.risk}% risk each payment is reported to the jarl.`, c.spent ? `Spent so far: ${num(c.spent)} gold.` : ""])} onclick="csnCmd('intr|guards|${c.i}')">Bribe guards…</button>
          <button class="btn small" ${tipAttr(["# Fund supporters", `${num(c.pp)} gold a point (nobles half).`, `${c.risk}% risk each payment is reported.`])} onclick="csnCmd('intr|people|${c.i}')">Fund supporters…</button>
          <span ${tipAttr(coupTip)}><button class="btn small ${c.block ? "secondary" : "danger"}" ${c.block ? "disabled" : ""} onclick="csnCmd('intr|coup|${c.i}')">Plan a coup…</button></span></div></div>`;
      });
      h += `</div>`;
    }
    return h;
  }
  window.csnQuell = (t) => { const el = $("quell" + t); if (el) csnCmd(`reb|quell|${t}|${el.value}`); };
  window.csnSendBand = (w) => { const el = $("bandArmy" + w); if (el) csnCmd(`reb|send|${w}|${el.value}`); };

  // ---------------------------------------------------------------- settlements (1.9.0)
  function pageSettle() {
    const st = state.settle || {};
    let h = `<p class="lead">Found settlements on open land in holds you control, build homes, fields and workshops, and settlers come to work them. What they make goes into the faction's stores every day.</p>`;
    if (!st.on) return h + empty("Settlements are off", "Turn them on in the MCM (Settlements page).");
    // who moves in, and the navmesh
    const WHO = ["# Who moves in", "Settlers come for the work your buildings offer:",
      "- Farmers: fields, beehives, windmills, farm sheds (some always come)",
      "- Woodsmen: lumber mill, chopping block",
      "- Miners and smiths: smelter, smithy, forge, anvil",
      "- Traders: inn, market stalls",
      "- An alchemist: alchemy lab",
      "- Sellswords: watchtower, walls, barricades, training dummies, archery targets",
      "They need free beds (homes) and happiness of 40 or more."];
    const NAV = st.nav === 2 ? ["# Update navmesh", "SkyBuild rebuilds the navmesh around you, so settlers, soldiers and followers walk around what you built. Stand in the settlement; progress shows top left."]
      : st.nav === 1 ? ["# Update navmesh", "SkyBuild can't be asked from here yet: reinstall Conquest of SkyrimNet with the installer's SkyBuild option ticked, and load it after SkyBuild in your mod manager. Or use SkyBuild's hammer wheel > Navmesh."]
      : ["# Update navmesh", "Needs SkyBuild (an SKSE plugin) installed."];
    h += `<div class="row" style="margin:4px 0 10px"><span class="small muted">Who moves in ${info(WHO)}</span><span class="spacer"></span>
      <span ${tipAttr(NAV)}><button class="btn small secondary" ${st.nav === 2 ? "" : "disabled"} onclick="csnCmd('st|navmesh')">Update navmesh</button></span></div>`;
    h += `<h2>Found a settlement</h2><div class="card"><div class="card-head"><h3>Found a settlement here</h3></div>
      <div class="row"><span ${tipAttr(["# Found a settlement", `Costs ${num(st.gold)} gold and ${st.wood} wood.`, "Outdoors, in a hold whose city or roads you hold, away from towns and other settlements.", st.block ? "Not here: " + st.block : ""])}><button class="btn" ${st.block ? "disabled" : ""} onclick="csnCmd('st|found')">Found it…</button></span>${st.block ? `<span class="small muted clip">${esc(st.block)}</span>` : ""}</div></div>`;
    const list = st.list || [];
    if (!list.length) return h + empty("No settlements yet", "Stand somewhere open and found one. Build mode: walk and turn to move the building, arrow keys rotate it and move it nearer or farther, Page Up/Down raise or lower it, Enter or Activate places it, Backspace cancels.");
    list.forEach((s) => {
      const here = st.here === s.k;
      h += `<h2 ${here ? 'data-pref="1"' : ""}>${esc(s.name)}${here ? " ●" : ""}</h2><div class="card"><div class="card-head"><h3>${esc(s.name)} <span class="muted small">${esc(s.hold)}</span></h3>${here ? '<span class="pill ok">You are here</span>' : ""}</div>
        <div class="grid">${stat("Settlers", `${s.pop} / ${s.beds} beds`)}${stat("Happiness", s.happy)}${stat("Defence", s.def)}${stat("Jobs", `${s.jobs} (${s.staffed}% filled)`)}${stat("Guards", `${s.guards || 0} / 5`)}</div>
        <p class="small muted">${s.armyslot >= 0 ? (s.raised ? `Army ${s.armyslot + 1} was raised thanks to ${esc(s.name)}: bandit raids here lower its morale, and it can't be abandoned while that army stands.` : `${esc(s.name)} lets you raise one more army.`) : ""} Activate its banner to hire or dismiss guards.</p>
        <p class="small">A day: food ${s.food >= 0 ? "+" : ""}${s.food} · wood +${s.woodday} · metal +${s.metalday} · gold +${s.goldday}</p>
        <p class="small muted">${clip(s.buildings, "nothing built yet")}</p>
        <p class="small"><span ${tipAttr(WHO)}>Drawn here: ${esc(s.mix || "farmers")}</span></p>
        ${here ? settleBuildBlock(st, s) : ""}
        <div class="row"><button class="btn small secondary" ${here ? "" : 'disabled title="Go there to build"'} onclick="csnCmd('st|build|${s.k}')">Build menu…</button>
        <button class="btn small secondary" ${here ? "" : 'disabled title="Go there to move buildings"'} onclick="csnCmd('st|move|${s.k}')">Move…</button>
        <button class="btn small secondary" onclick="csnCmd('st|remove|${s.k}')">Take down…</button>
        <span ${tipAttr(["# Fix settlers", "If settlers just stand around or wandered off: brings them back to the banner post, gives them their settlement life again (wander, sit, sleep, work the fires, blocks and benches) and replaces any that went missing."])}><button class="btn small secondary" ${s.pop > 0 ? "" : "disabled"} onclick="csnCmd('st|fix|${s.k}')">Fix settlers</button></span>
        <button class="btn small secondary" onclick="csnCmd('st|rename|${s.k}')">Rename…</button>
        <span ${tipAttr(s.raised ? ["# Can't abandon it", `Army ${s.armyslot + 1} was raised thanks to it. Dismiss that army first.`] : ["# Abandon", "Takes everything down; the settlers and guards leave."])}><button class="btn small danger" ${s.raised ? "disabled" : ""} onclick="csnCmd('st|abandon|${s.k}')">Abandon…</button></span></div></div>`;
    });
    return h;
  }

  // ---- building where you stand: catalogue with costs, layouts, snapping, the buildings here nearest first
  let settleGroup = "Homes";
  window.csnSettleGroup = (g) => { settleGroup = g; safeRender(); };
  const settleOpen = { build: true, lay: false, bl: false };
  window.csnSettleOpen = (k) => { settleOpen[k] = !settleOpen[k]; safeRender(); };
  const acc = (k, title, extra) => `<button class="acc ${settleOpen[k] ? "open" : ""}" onclick="csnSettleOpen('${k}')"><span class="chev">${settleOpen[k] ? "▾" : "▸"}</span>${title}${extra ? ` <span class="muted small">${extra}</span>` : ""}</button>`;
  function settleBuildBlock(st, s) {
    const cat = st.cat || [], lay = st.lay || [];
    const tg = st.tg || 0, tw = st.tw || 0, tm = st.tm || 0;
    const short = (o) => (tg < o.g ? `${num(o.g - tg)} more gold` : tw < o.w ? `${num(o.w - tw)} more wood` : tm < o.m ? `${num(o.m - tm)} more metal` : "");
    const cost = (o) => `${num(o.g)} gold${o.w ? ` · ${num(o.w)} wood` : ""}${o.m ? ` · ${num(o.m)} metal` : ""}`;
    const groups = [...new Set(cat.map((c) => c.grp))];
    if (!groups.includes(settleGroup)) settleGroup = groups[0] || "Homes";
    let h = acc("build", "Build here", `treasury ${num(tg)} gold · wood ${num(tw)} · metal ${num(tm)}`);
    if (settleOpen.build) h += `<div class="acc-body">
      <div class="chips">${groups.map((g) => `<button class="chip ${g === settleGroup ? "on" : ""}" onclick="csnSettleGroup('${esc(g)}')">${esc(g)}</button>`).join("")}</div>
      <table style="margin-top:8px"><tr><th>Building</th><th>Cost</th><th>Gives</th><th></th></tr>
      ${cat.filter((c) => c.grp === settleGroup).map((c) => { const no = short(c); return `<tr style="${no ? "opacity:.45" : ""}"><td>${esc(c.n)}</td><td class="small">${cost(c)}</td><td class="small">${esc(c.gives)}</td>
        <td><span ${tipAttr(no ? ["# Can't afford it", "Needs " + no + "."] : ["# " + c.n, "Place it yourself; paid when placed."])}><button class="btn small" ${no ? "disabled" : ""} onclick="csnCmd('st|place|${s.k}|${c.t}')">Build</button></span></td></tr>`; }).join("")}</table></div>`;
    h += acc("lay", "Ready-made layouts", `${lay.length} packs`);
    if (settleOpen.lay) h += `<div class="acc-body"><p class="small muted">The whole layout floats in front of you, outlined; it is placed in one go. Pick fairly flat, open ground. Any piece can be moved afterwards.</p>
      <table><tr><th>Layout</th><th>Cost</th><th>Gives</th><th></th></tr>
      ${lay.map((l) => { const no = short(l); return `<tr style="${no ? "opacity:.45" : ""}"><td><span ${tipAttr(["# " + l.n, l.why, "Has: " + l.has])}>${esc(l.n)}</span></td><td class="small">${cost(l)}</td><td class="small">${esc(l.gives)}</td>
        <td><span ${tipAttr(no ? ["# Can't afford it", "Needs " + no + "."] : ["# " + l.n, l.has])}><button class="btn small" ${no ? "disabled" : ""} onclick="csnCmd('st|layout|${s.k}|${l.l}')">Build</button></span></td></tr>`; }).join("")}</table></div>`;
    const G = [[0, "Off"], [70, "1 pace"], [140, "2 paces"], [280, "4 paces"]], T = [[0, "Free"], [15, "15°"], [45, "45°"]];
    h += `<div class="row" style="margin-top:10px"><span class="small" ${tipAttr(["# Snapping", "Grid: buildings lock to a grid around the banner post, so walls and fences line up.", "Turn: they turn in steps.", "While placing: Home changes the grid, End the turn steps."])}>Snap to grid</span>
      <div class="chips">${G.map(([v, n]) => `<button class="chip ${st.grid === v ? "on" : ""}" onclick="csnCmd('st|grid|${v}')">${n}</button>`).join("")}</div>
      <span class="small" style="margin-left:12px">Turn</span>
      <div class="chips">${T.map(([v, n]) => `<button class="chip ${st.turn === v ? "on" : ""}" onclick="csnCmd('st|turn|${v}')">${n}</button>`).join("")}</div></div>`;
    const bl = s.bl || [];
    h += acc("bl", "Buildings here", `${bl.length} · nearest first`);
    if (settleOpen.bl) h += bl.length ? `<div class="acc-body"><table><tr><th>Building</th><th class="num">Paces</th><th></th></tr>
      ${bl.map((b) => `<tr><td>${esc(b.n)}</td><td class="num">${b.d >= 0 ? num(b.d) : "out of sight"}</td>
        <td><button class="btn small secondary" ${b.d >= 0 ? "" : "disabled"} onclick="csnCmd('st|move|${s.k}|${b.i}')">Move</button>
        <button class="btn small danger" onclick="csnCmd('st|take|${s.k}|${b.i}')">Take down</button></td></tr>`).join("")}</table></div>` : `<p class="small muted">Nothing built yet.</p>`;
    return h;
  }

  // Answer at once on screen; the game's refresh that follows has the final word (and puts it back if it failed).
  window.csnDecide = (id, choice) => {
    const r = (state.requests || []).find((x) => x.id === id);
    if (r) { r.status = choice === 1 ? 2 : choice === 2 ? 3 : 1; safeRender(); }
    csnCmd(`decide|${id}|${choice}`);
  };

  const taxText = (lv) => (lv >= 0 ? lv * 10 + "%" : "—");

  // ---------------------------------------------------------------- officers
  function pageOfficers() {
    if (picking >= 0) return pagePicker();
    let h = `<p class="lead">Appoint officers in conversation, or pick someone standing nearby. Anyone who isn't hostile can serve.</p><div class="split">`;
    officers().forEach((o, i) => {
      h += `<div class="card"><div class="card-head"><h3>${esc(o.role)} ${info(roleText(i).replace(/<[^>]+>/g, ""))}</h3>${o.name ? "" : '<span class="pill warn">Vacant</span>'}</div>
        <p>${o.name ? esc(o.name) : '<span class="muted">No one holds this office.</span>'}</p>
        <div class="row">
          <button class="btn small" onclick="csnPick(${i})">${o.name ? "Replace" : "Appoint"}…</button>
          ${o.name ? `<button class="btn small secondary" onclick="csnCmd('outfit|${i}')">Outfit</button>
          <button class="btn small danger" onclick="csnCmd('dismissOfficer|${i}')">Relieve…</button>` : ""}
        </div></div>`;
    });
    h += `</div>`;
    // Thanes of the holds you control
    const thanes = state.thanes || [], tholds = state.thaneholds || [];
    h += `<h2>Thanes ${info(["# Thanes", "Landed notables of a hold you control (you rule its city). Naming one costs 1,000 gold.", "- They carry \"Thane\" before their name and know their hold", "- They wear their hold's Thane outfit", "- They bring you private ventures to invest in (Requests tab): pay up front, get 110-135% back over 15-30 days", "Officers, Captains, Commanders, jarls, stewards and housecarls can't be Thanes. Up to 3 per hold, plus 1 for each settlement founded in it."])}</h2>`;
    if (!tholds.length) h += `<p class="muted small">Thanes are named in holds your faction controls. Take a hold's city first.</p>`;
    else {
      if (thanes.length) {
        h += `<table class="fixed"><tr><th>Thane</th><th>Hold</th><th style="width:220px"></th></tr>` + thanes.map((t) => `<tr><td>Thane ${esc(t.name)}</td><td>${esc(t.holdname)}</td>
          <td class="right"><button class="btn small danger" onclick="csnCmd('thane|remove|${t.i}')">Relieve…</button></td></tr>`).join("") + `</table>`;
      } else h += `<p class="muted small">No Thanes yet. Ask someone in conversation ("I name you Thane of Whiterun") or pick someone nearby.</p>`;
      h += `<div class="row" style="margin-top:8px"><button class="btn small" onclick="csnPick(20)">Name a Thane…</button>
        ${tholds.map((x) => `<button class="btn small secondary" ${tipAttr([`# ${x.name} Thane Outfit`, x.outfit ? `${x.outfit} pieces set.` : "Not set yet: the Thanes wear what they like.", "Opens a chest: put in what they should wear, then close it.", `${x.n} of ${x.max || 3} Thanes in ${x.name}.`])} onclick="csnCmd('thane|outfit|${x.h}')">${esc(x.name)} outfit</button>`).join("")}</div>`;
    }
    // only when there is a captain to choose: the Armies tab lists the ones you have
    if (state.freeslot >= 0) {
      h += `<h2>Captains</h2><p>Army ${state.freeslot + 1} has no captain yet. A captain who earns a star becomes a Commander.</p><div class="row"><button class="btn" onclick="csnPick(9)">Choose a captain…</button></div>`;
    }
    return h;
  }

  function roleText(i) {
    return ["Runs the war table and every captain and commander.", "Keeps the treasury, supplies, trade and declarations of war.",
      "Arms and armours your troops.", "Gives magical counsel."][i] || "";
  }

  window.csnPick = (i) => { picking = i; toast(""); send("scan"); safeRender(); };

  function pagePicker() {
    const office = picking === 9 ? `captain of Army ${state.freeslot + 1}` : picking === 20 ? "Thane" : (officers()[picking] || {}).role;
    const people = state.candidates || [];
    let h = `<div class="card-head"><h2>Who should be ${esc(office)}?</h2><button class="btn small secondary" onclick="csnPick(-1)">Back</button></div>
      <p class="lead">People near you right now.</p>`;
    if (picking === 20) {
      const tholds = state.thaneholds || [];
      if (!tholds.length) return h + empty("No hold to name a Thane in", "Thanes are named in holds your faction controls.");
      h += `<div class="row"><span class="small muted">Thane of</span><select id="thaneHold">${tholds.map((x) => `<option value="${x.h}">${esc(x.name)} (${x.n} of ${x.max || 3})</option>`).join("")}</select><span class="small muted">· 1,000 gold</span></div>`;
    }
    if (!people.length) return h + empty("No one nearby", "Stand near the person you want and open this screen again, or ask them in conversation.");
    h += `<div class="people">` + people.map((p) => {
      let note = "";
      if (p.role >= 0) note = "Already " + ((officers()[p.role] || {}).role || "an officer");
      else if (p.army >= 0) note = "Leads Army " + (p.army + 1);
      const cmd = picking === 9 ? `hire|${p.i}` : picking === 20 ? `thane|appoint|${p.i}|` : `appoint|${picking}|${p.i}`;
      const blocked = (picking === 9 || picking === 20) && (p.role >= 0 || p.army >= 0);
      return `<button class="person" ${blocked ? "disabled" : ""} onclick="csnChoose('${cmd}')">${esc(p.name)}${note ? `<span class="muted">${note}</span>` : ""}</button>`;
    }).join("") + `</div>`;
    return h;
  }
  window.csnChoose = (cmd) => {
    // a Thane: the hold picked above goes on the end
    if (cmd.startsWith("thane|appoint|")) { const sel = $("thaneHold"); cmd += sel ? sel.value : ""; }
    picking = -1; send(cmd);
  };

  const starRow = (n) => `<span class="stars" title="${n} of 5 stars">${"★".repeat(n)}${"☆".repeat(5 - n)}</span>`;
  const leader = (a) => `${esc(a.rank || "Captain")} ${esc(a.name)}`;
  // "Iron Wolves · Army 3" once named, otherwise "Army 3"
  const armyTitle = (a) => a.aname ? `${esc(a.aname)} <span class="muted small">Army ${a.i + 1}</span>` : `Army ${a.i + 1}`;
  const mottoLine = (a) => a.motto ? `<p class="small"><i>“${esc(a.motto)}”</i></p>` : "";
  // Name & purpose editor, folded away until asked for
  const nameEditor = (a) => `<div id="nm${a.i}" class="hidden">
      <div class="row"><input type="text" id="nmName${a.i}" maxlength="25" placeholder="Army name (25 letters at most)" value="${esc(a.aname || "")}"></div>
      <div class="row"><textarea id="nmMotto${a.i}" rows="2" maxlength="200" placeholder="Purpose, goal or mantra (optional)">${esc(a.motto || "")}</textarea></div>
      <div class="row"><button class="btn small" onclick="csnArmyName(${a.i})">Save name</button>
      <button class="btn small secondary" onclick="csnArmyNameToggle(${a.i})">Cancel</button>
      <span class="muted small">Leave the name empty to go back to Army ${a.i + 1}.</span></div></div>`;
  const nameButton = (a) => `<button class="btn small secondary" onclick="csnArmyNameToggle(${a.i})">${a.aname ? "Rename…" : "Name army…"}</button>`;
  window.csnArmyNameToggle = (i) => { const el = $("nm" + i); if (el) el.classList.toggle("hidden"); };
  window.csnArmyName = (i) => {
    const strip = (t) => String(t || "").replace(/[|\r\n\t"]/g, " ").replace(/\s+/g, " ").trim();
    const n = strip($("nmName" + i).value).slice(0, 25);
    const m = strip($("nmMotto" + i).value).slice(0, 200);
    // "~" stands for empty: the game's splitter drops empty fields
    csnCmd(`armyName|${i}|${n || "~"}|${m || "~"}`);
  };
  function starButton(a) {
    if ((a.stars || 0) >= 5) return `<span class="pill ok">Five stars</span>`;
    const cost = (state.settings && state.settings.starcost) || 10000;
    const ok = state.gold >= cost && state.food >= 100;
    return `<span ${tipAttr(["# Award a star", `${num(cost)} gold and 100 food.`, "- The Captain becomes a Commander (or gains a rank)", "- +10% health and stamina for their troops", "- +15 morale at once", ok ? "" : "Not enough gold or food."])}><button class="btn small" ${ok ? "" : "disabled"} onclick="csnCmd('star|${a.i}')">Award a star…</button></span>`;
  }

  // ---------------------------------------------------------------- armies (read only)
  function mixLine(a) {
    const m = a.mix || [];
    const names = ["soldiers", "warriors", "archers", "crossbowmen"];
    const parts = names.map((n, i) => `<span><b>${num(m[i])}</b> ${n}</span>`).join("");
    return `<div class="mix">${parts}</div>`;
  }

  function pageArmies() {
    const list = armies();
    const gen = state.neargeneral;   // the War Table: only beside the General (or someone who may open it)
    const up = state.upkeep ?? 10, cg = state.claimguards || 0;
    let h = gen
      ? `<p class="lead">General ${esc(gen)} keeps the war table. ${warLine()}.</p>`
      : `<p class="lead">Your armies. Stand beside your General to open the War Table: orders, siege engines, recruiting, upkeep and templates.</p>`;
    if (gen) {
      const sg = state.siege || [0, 0, 0];
      h += `<div class="grid">${stat("Battering rams", sg[0])}${stat("Ladders", sg[1])}${stat("Catapults", sg[2])}</div>`;
      if (state.recruitlimit !== undefined) h += `<p class="small">Troops that can still be recruited today: <b>${num(state.recruittoday)}</b> of ${num(state.recruitlimit)}. Ask General ${esc(gen)} in conversation, e.g. "recruit 5 archers and 10 soldiers for Army 1".</p>`;
    }
    h += `<h2>Armies</h2>`;
    if (!list.length) h += empty("No armies yet", "Claim a holding or found a settlement to open an army slot, then choose a captain on the Officers tab.");
    list.forEach((a) => {
      h += `<div class="card"><div class="card-head"><h3>${armyTitle(a)} · ${leader(a)}</h3>
        <span>${starRow(a.stars || 0)} · ${num(a.troops)} troops${gen ? ` · ${num((a.troops || 0) * up)} gold a day` : ""}${a.dead ? ' <span class="pill warn">Leader fallen</span>' : ""}</span></div>
        ${mottoLine(a)}${mixLine(a)}<p class="muted small">Posted: ${esc(a.post || a.task)}</p>`;
      if (gen) {
        h += `<div class="row">
          <select id="ord${a.i}" onchange="csnOrderChanged(${a.i})">${ORDERS.map((o) => `<option value="${o.k}">${o.label}</option>`).join("")}</select>
          <select id="arg${a.i}" class="hidden"></select>
          <button class="btn" onclick="csnOrder(${a.i})">Give order</button>
          <span class="spacer"></span>
          ${starButton(a)}
          <button class="btn small secondary" onclick="csnCmd('troops|${a.i}')">Troops</button>
          <button class="btn small secondary" title="Overrides the troop-type outfits from the Blacksmith tab for this army" onclick="csnCmd('outfit|-1|${a.i}')">Set outfit</button>
          ${nameButton(a)}
          <button class="btn small danger" onclick="csnCmd('fire|${a.i}')">Dismiss…</button>
        </div>`;
      } else {
        h += `<div class="row">${starButton(a)}<span class="spacer"></span>${nameButton(a)}<button class="btn small secondary" onclick="csnCmd('troops|${a.i}')">Troops &amp; recruits</button>
          <button class="btn small secondary" title="Overrides the troop-type outfits from the Blacksmith tab for this army" onclick="csnCmd('outfit|-1|${a.i}')">Set outfit</button></div>`;
      }
      h += `${nameEditor(a)}</div>`;
    });
    if (gen && (list.length || cg)) h += `<h2>Troop upkeep ${info(["# Troop upkeep", `Every troop and claim or settlement guard is paid ${num(up)} gold a day from the treasury (MCM > Economy).`, "Dismissing troops or guards lowers it."])}</h2>
      <table><tr><th>Army</th><th class="num">Troops</th><th class="num">Gold a day</th></tr>
      ${list.map((a) => `<tr><td>${armyTitle(a)} · ${leader(a)}</td><td class="num">${num(a.troops)}</td><td class="num">${num((a.troops || 0) * up)}</td></tr>`).join("")}
      ${cg ? `<tr><td>Claim and settlement guards</td><td class="num">${num(cg)}</td><td class="num">${num(cg * up)}</td></tr>` : ""}
      <tr><td><b>Total</b></td><td class="num"><b>${num(list.reduce((t, a) => t + (a.troops || 0), 0) + cg)}</b></td><td class="num"><b>${num(list.reduce((t, a) => t + (a.troops || 0), 0) * up + cg * up)}</b></td></tr></table>`;
    if (gen) h += templatesBlock();
    h += decreesBlock(gen);
    return h;
  }

  // Decrees (CoS laws): conscription, crime and punishment, religion. Anyone sees the laws; beside the General
  // they can be changed (each change confirms in game and is remembered by the people for a while).
  const DEITY_ST = ["Outlawed", "Allowed", "Mandatory"];
  function decreesBlock(gen) {
    const L = state.laws;
    if (!L) return "";
    let h = `<h2>Decrees ${info(["# Decrees", "The faction's laws, as the General's law menu sets them.", "- Conscription: how many of the able-bodied may be called up (more troops to recruit; loyalty falls 2 for every 10% more)", "- Crime and punishment: what each crime costs the guilty", "- Religion: outlawed gods lose their shrines and statues", `A new decree is the talk of your lands for ${L.days} days; your officers, jarls and stewards always know the standing laws.`])}</h2>`;
    if (!gen) h += `<p class="small muted">Stand beside your General to pass a new decree, or ask them (or your Steward or a jarl) in conversation.</p>`;
    h += `<div class="card"><div class="card-head"><h3>Conscription</h3><span class="pill">${L.consc}%</span></div>
      <p class="small muted">Up to ${L.consc}% of the able-bodied in your lands may be called up into your armies.</p>
      ${gen ? `<div class="seg">${[0, 25, 50, 75, 100].map((v) => `<button class="${L.consc === v ? "on" : ""}" onclick="csnCmd('law|consc|${v}')">${v}%</button>`).join("")}</div>` : ""}</div>`;
    const sentences = L.sentences || [];
    h += `<div class="card"><div class="card-head"><h3>Crime and punishment</h3></div><table><tr><th>Crime</th><th>Punishment</th></tr>
      ${(L.crimes || []).map((c, i) => `<tr><td>${esc(c.n)}</td><td>${gen
        ? `<select onchange="csnCmd('law|crime|${i}|' + this.value)"><option value="-1" ${c.s < 0 ? "selected" : ""}>No law</option>${sentences.map((n, k) => `<option value="${k}" ${c.s === k ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>`
        : esc(c.s >= 0 ? sentences[c.s] || "" : "No law")}</td></tr>`).join("")}</table></div>`;
    h += `<div class="card"><div class="card-head"><h3>Religion</h3></div><table><tr><th>God</th><th>Law</th></tr>
      ${(L.deities || []).map((d, i) => `<tr><td>${esc(d.n)}</td><td>${gen
        ? `<div class="seg">${DEITY_ST.map((n, k) => `<button class="${d.st === k ? "on" : ""}" onclick="csnCmd('law|deity|${i}|${k}')">${n}</button>`).join("")}</div>`
        : `<span class="pill ${d.st === 0 ? "warn" : d.st === 2 ? "ok" : ""}">${d.st >= 0 ? DEITY_ST[d.st] : "No law"}</span>`}</td></tr>`).join("")}</table></div>`;
    const rec = L.recent || [];
    h += `<div class="card"><div class="card-head"><h3>Recent decrees</h3></div>${rec.length
      ? rec.map((r) => `<p class="small"><span class="muted">${r.ago <= 0 ? "Today" : r.ago === 1 ? "Yesterday" : r.ago + " days ago"}:</span> ${esc(r.t)}</p>`).join("")
      : `<p class="small muted">No decrees in the last ${L.days} days.</p>`}</div>`;
    return h;
  }


  // ---------------------------------------------------------------- lands
  function levels(c) {
    return `<div class="levels">${(c.lv || []).map((v, k) => v >= 0 ? `<span class="level">${BUILDINGS[k]} <b>${v}</b></span>` : "").join("")}</div>`;
  }
  // a town's own stores and its day: gold, food, metal, wood (stored, then made / needed / traded)
  function ecoLines(c) {
    const e = c.eco;
    if (!e) return ["No figures for this town."];
    const sg = (n) => (n > 0 ? "+" : "") + num(n);
    const line = (name, a) => {
      const [stored, made, need, imp, exp] = a;
      const net = made + imp - need - exp;
      const parts = [`makes ${num(made)}`];
      if (need) parts.push(`needs ${num(need)}`);
      if (imp) parts.push(`gets ${num(imp)} from you`);
      if (exp) parts.push(`sends ${num(exp)} to you`);
      return `- ${name}: ${num(stored)} in store, ${sg(net)} a day (${parts.join(", ")})`;
    };
    return [`# ${c.name}: stores and the day`, `- Gold: ${num(e.gs)} in its coffers, ${sg(e.gd)} a day`, line("Food", e.f), line("Metal", e.m), line("Wood", e.w), e.pop ? `Population ${num(e.pop)}.` : ""];
  }
  function loyaltyBar(v) { return `<div class="bar" title="${v} / 100"><i style="width:${Math.max(0, Math.min(100, v))}%"></i></div>`; }

  // ---- Lands: every town at a glance (what it has, what it makes or lacks each day), trade with it in a click;
  // the Steward's books (taxes, trade, gold, the treasury, war, trade abroad) beside your Steward or a jarl.
  const landPend = {};   // "town:material" -> the daily trade being set up (+ you send to the town, - you take)
  window.csnLandStep = (i, k, d) => {
    const c = ourCities().find((x) => x.i === i) || {}, t = c.tr || [0, 0, 0];
    const key = i + ":" + k, cur = landPend[key] !== undefined ? landPend[key] : t[k];
    landPend[key] = Math.max(-200, Math.min(200, cur + d));
    safeRender();
  };
  window.csnLandSet = (i, k) => { const key = i + ":" + k; const v = landPend[key]; delete landPend[key]; csnCmd(`cityTrade|${i}|${k}|${v || 0}`); };
  window.csnLandUndo = (i, k) => { delete landPend[i + ":" + k]; safeRender(); };
  window.csnLandGold = (i, n) => { csnCmd(n === "all" ? `townGold|${i}|all` : `townGold|${i}|${n}`); };
  function landTile(c, k, steward) {
    const e = c.eco || {}, t = c.tr || [0, 0, 0];
    const sg = (n) => (n > 0 ? "+" : n < 0 ? "−" : "±") + num(Math.abs(n));
    if (k === "gold") {
      const stored = e.gs || 0, day = e.gd || 0, inv = e.inv || [];
      const gtip = [`# ${c.name}: gold`, `${num(stored)} in the town's treasury`, `Taxes: ${sg(e.gtax !== undefined ? e.gtax : day)} a day`];
      if (inv.length) {
        gtip.push(`Investments: ${sg(e.ginv || 0)} a day`);
        inv.forEach((v) => gtip.push(`- ${v.n}: +${num(v.g)} a day, ${v.left} day${v.left === 1 ? "" : "s"} left`));
      } else gtip.push("No investments running here");
      return `<div class="tile" ${tipAttr(gtip)}><div class="tile-name">Gold</div><div class="tile-val">${num(stored)}</div>
        <div class="tile-day ${day > 0 ? "up" : day < 0 ? "down" : ""}">${sg(day)} a day</div>
        ${steward ? `<div class="tile-ctl"><button class="btn tiny" ${stored > 0 ? "" : "disabled"} onclick="csnLandGold(${c.i}, ${Math.min(1000, stored)})">Take ${num(Math.min(1000, stored) || 1000)}</button>
          <button class="btn tiny" ${stored > 0 ? "" : "disabled"} onclick="csnLandGold(${c.i}, 'all')">Take all</button>
          <button class="btn tiny secondary" ${(state.gold || 0) >= 1000 ? "" : "disabled"} onclick="csnLandGold(${c.i}, -1000)">Send 1,000</button></div>` : ""}</div>`;
    }
    const a = [e.f, e.m, e.w][k] || [0, 0, 0, 0, 0];
    const [stored, made, need, imp, exp] = a;
    const net = made + imp - need - exp;
    const key = c.i + ":" + k, pend = landPend[key], v = pend !== undefined ? pend : t[k];
    const flow = (x) => (x > 0 ? `you send ${num(x)}/day` : x < 0 ? `you take ${num(-x)}/day` : "no trade");
    let ctl = "";
    if (steward) {
      ctl = `<div class="tile-ctl"><button class="btn tiny secondary" title="Take more from the town each day" onclick="csnLandStep(${c.i}, ${k}, -5)">◀ Take</button>
        <span class="tile-flow ${v !== t[k] ? "changed" : ""}">${v > 0 ? "Send " + num(v) : v < 0 ? "Take " + num(-v) : "None"}</span>
        <button class="btn tiny secondary" title="Send more to the town each day" onclick="csnLandStep(${c.i}, ${k}, 5)">Send ▶</button>
        ${pend !== undefined && pend !== t[k] ? `<button class="btn tiny" onclick="csnLandSet(${c.i}, ${k})">Set</button><button class="btn tiny secondary" onclick="csnLandUndo(${c.i}, ${k})">×</button>` : ""}</div>`;
    }
    return `<div class="tile" ${tipAttr([`# ${c.name}: ${MATS[k]}`, `${num(stored)} in store`, `Makes ${num(made)}${need ? `, needs ${num(need)}` : ""}${imp ? `, gets ${num(imp)} from you` : ""}${exp ? `, sends ${num(exp)} to you` : ""}`, `${net >= 0 ? "Surplus" : "Deficit"}: ${sg(net)} a day`])}>
      <div class="tile-name">${MATS[k]}</div><div class="tile-val">${num(stored)}</div>
      <div class="tile-day ${net > 0 ? "up" : net < 0 ? "down" : ""}">${net > 0 ? "Surplus " : net < 0 ? "Deficit " : ""}${sg(net)} a day</div>
      <div class="tile-sub">${flow(t[k])}</div>${ctl}</div>`;
  }
  function pageLands() {
    const cl = state.claims || [];
    const stew = state.nearsteward;
    const towns = ourCities();
    let h = `<div class="grid">${stat("Treasury", num(state.gold) + " gold", state.goldday)}${stat("Food", num(state.food), state.foodday)}${stat("Metal", num(state.metal), state.metalday)}${stat("Wood", num(state.wood), state.woodday)}</div>`;
    h += stew ? `<p class="small muted" style="margin-top:10px">${esc(stew)} keeps the books: change taxes, trade and gold right on each town. ◀ Take / Send ▶ set what goes each day; Set seals it.</p>`
      : `<p class="small muted" style="margin-top:10px">Stand beside your Steward or one of your jarls to change taxes, trade and gold, and for the treasury, war and trade abroad.</p>`;
    h += `<h2>Your towns</h2>`;
    if (!towns.length) h += empty("No towns yet", "Conquer a city or village and it appears here with what it makes and needs.");
    towns.forEach((c) => {
      const lvl = levels(c);
      h += `<div class="card town"><div class="card-head"><h3>${esc(c.name)}</h3>
          <span class="pill">${taxText(c.tax)} taxes</span><span class="spacer"></span><span class="small muted loyal">Loyalty ${c.loyalty} / 100${loyaltyBar(c.loyalty)}</span></div>
        <div class="tiles">${landTile(c, "gold", stew)}${[0, 1, 2].map((k) => landTile(c, k, stew)).join("")}</div>
        <div class="row" style="margin-top:8px">${lvl}<span class="spacer"></span>
          ${stew ? `<span class="small">Taxes</span><div class="seg">${[0, 1, 2, 3, 4, 5].map((lv) => `<button class="${c.tax === lv ? "on" : ""}" onclick="csnTax(${c.i}, ${lv})">${lv * 10}%</button>`).join("")}</div>
          <button class="btn small secondary" onclick="csnCmd('upgrades|${c.i}')">Upgrade…</button>` : ""}</div></div>`;
    });
    const others = (state.cities || []).filter((c) => !c.ours);
    if (others.length) h += `<h2>Other towns</h2><table><tr><th>Town</th><th>Ruled by</th></tr>${others.map((c) => `<tr><td>${esc(c.name)}</td><td>${esc(c.owner)}</td></tr>`).join("")}</table>`;
    h += `<h2>Claims</h2>`;
    if (!cl.length) h += empty("No claims yet", "Clear a camp, mine or fort, then use the Place Banner power.");
    else h += `<table><tr><th>Holding</th><th class="num">Guards</th><th class="num">Workers</th></tr>
      ${cl.map((c) => `<tr><td>${esc(c.name)}${c.base ? '<span class="pill">Base</span>' : ""}${c.mine ? '<span class="pill">Mine</span>' : ""}${c.farm ? '<span class="pill">Farm</span>' : ""}</td>
        <td class="num">${c.guards} / 5${c.guards ? ` <span class="muted small">(${num(c.guards * (state.upkeep ?? 10))} gold a day)</span>` : ""}</td><td class="num">${c.mine ? c.miners + " miners / 5" : c.farm ? c.farmhands + " farmhands / 5" : "—"}</td></tr>`).join("")}</table>`;
    if (stew) h += stewardBooks();
    return h;
  }
  // the Steward's own business: the treasury, war, trade with the Imperials and Stormcloaks
  function stewardBooks() {
    const w = state.war || [false, false];
    const tr = state.trade || [[0, 0, 0], [0, 0, 0]];
    let h = `<h2>Treasury</h2>
      <div class="grid">${stat("Treasury", num(state.gold) + " gold", state.goldday)}${stat("Your purse", num(state.purse) + " gold")}</div>
      <div class="row" style="margin-top:10px">
        <input type="number" id="goldAmt" min="1" step="100" value="1000">
        <button class="btn small secondary" onclick="csnGoldPreset(100)">100</button>
        <button class="btn small secondary" onclick="csnGoldPreset(1000)">1,000</button>
        <button class="btn small secondary" onclick="csnGoldPreset(10000)">10,000</button>
        <span class="spacer"></span>
        <button class="btn" onclick="csnGold('deposit')">Deposit</button>
        <button class="btn secondary" onclick="csnGold('withdraw')">Withdraw</button>
      </div>
      <div class="row" style="margin-top:10px"><button class="btn secondary small" onclick="csnCmd('economyMenu')">Full economy ledger (taxes, guards)…</button></div>`;
    h += `<h2>War</h2><table>${[1, 2].map((side) => `<tr><td>${SIDES[side].replace("the ", "The ")}</td>
        <td>${w[side - 1] ? '<span class="pill warn">At war</span>' : '<span class="pill ok">At peace</span>'}</td>
        <td class="num">${w[side - 1] ? '<span class="muted small">Peace comes through peace talks.</span>' : `<button class="btn small danger" onclick="csnCmd('war|${side}')">Declare war…</button>`}</td></tr>`).join("")}</table>`;
    h += `<h2>Trade abroad</h2>
      <p class="muted small">With the Imperials or Stormcloaks: ${state.tradeprice} gold per unit per day. You can't import and export the same material with the same side. "Agree" seals it straight away.</p>
      <div class="row">
        <select id="trDir"><option value="1">Import</option><option value="-1">Export</option></select>
        <input type="number" id="trAmt" min="1" value="1">
        <select id="trMat">${MATS.map((m, i) => `<option value="${i}">${m}</option>`).join("")}</select>
        <span>a day with</span>
        <select id="trSide">${[1, 2].map((side) => `<option value="${side}" ${w[side - 1] ? "disabled" : ""}>${SIDES[side]}</option>`).join("")}</select>
        <button class="btn" onclick="csnTrade()">Agree</button>
        <span id="trCost" class="muted small"></span>
      </div><table style="margin-top:8px"><tr><th>Side</th><th>Material</th><th>Per day</th><th></th></tr>`;
    let any = false;
    [1, 2].forEach((side) => MATS.forEach((m, mat) => {
      const v = (tr[side - 1] || [])[mat];
      if (!v) return;
      any = true;
      h += `<tr><td>${SIDES[side]}</td><td>${m}</td><td>${v > 0 ? "Importing " + v : "Exporting " + -v}</td>
        <td class="num"><button class="btn small secondary" onclick="csnCmd('tradeCancel|${side}|${mat}|${v > 0 ? 1 : -1}')">End</button></td></tr>`;
    }));
    if (!any) h += `<tr><td colspan="4" class="muted">No agreements yet.</td></tr>`;
    return h + `</table>`;
  }


  // ---------------------------------------------------------------- war table (next to the General)
  function targets(needs) {
    if (needs === "city") return ourCities().filter((c) => c.city).map((c) => [c.i, c.name]);
    if (needs === "fort") return (state.forts || []).filter((f) => f.owned).map((f) => [f.i, f.name]);
    if (needs === "hold") return (state.holds || []).filter((x) => x.camp).map((x) => [x.i, x.name + (x.attack ? " (attack camp)" : "")]);
    return [];
  }




  window.csnOrderChanged = (i) => {
    const o = ORDERS.find((x) => x.k === parseInt($("ord" + i).value, 10));
    const sel = $("arg" + i);
    if (!o || !o.needs) { sel.classList.add("hidden"); sel.innerHTML = ""; return; }
    const t = targets(o.needs);
    sel.innerHTML = t.length ? t.map(([v, n]) => `<option value="${v}">${esc(n)}</option>`).join("") : `<option value="-1">Nowhere yet</option>`;
    sel.classList.remove("hidden");
  };
  window.csnOrder = (i) => {
    const o = parseInt($("ord" + i).value, 10);
    const needs = (ORDERS.find((x) => x.k === o) || {}).needs;
    const a = needs ? parseInt($("arg" + i).value, 10) : -1;
    if (needs && !(a >= 0)) { toast("Pick where they should go first."); return; }
    toast("");
    csnCmd(`order|${i}|${o}|${a}`);
  };

  // ---------------------------------------------------------------- steward (next to a steward or jarl)


  window.csnTax = (town, lv) => {
    const c = (state.cities || []).find((x) => x.i === town);
    const before = c ? c.tax : -1;
    if (c) { c.tax = lv; safeRender(); }
    toast("Working…", "busy");
    send(`tax|${town}|${lv}`);
    if (c) c.tax = before;   // the game's answer decides (a confirmation can still say no)
  };
  window.csnGoldPreset = (n) => { const i = $("goldAmt"); if (i) i.value = n; };
  window.csnGold = (kind) => {
    const n = parseInt($("goldAmt").value, 10);
    if (!(n > 0)) { toast("Enter an amount of gold."); return; }
    if (kind === "deposit" && n > (state.purse || 0)) { toast(`You only carry ${num(state.purse)} gold.`); return; }
    if (kind === "withdraw" && n > (state.gold || 0)) { toast(`The treasury only holds ${num(state.gold)} gold.`); return; }
    toast("");
    csnCmd(`${kind}|${n}`);
  };
  window.csnTownGold = (i, dir) => {
    const n = parseInt($("tgAmt" + i).value, 10);
    if (!(n > 0)) { toast("Enter an amount of gold."); return; }
    const c = ourCities().find((x) => x.i === i) || {}, has = (c.eco || {}).gs || 0;
    if (dir > 0 && n > has) { toast(`${c.name} only holds ${num(has)} gold.`); return; }
    if (dir < 0 && n > (state.gold || 0)) { toast(`The treasury only holds ${num(state.gold)} gold.`); return; }
    toast("");
    csnCmd(`townGold|${i}|${dir * n}`);
  };
  window.csnCityTrade = (i) => {
    if ($("ctMat" + i).value === "gold") {
      // gold moves once: export sends treasury gold to the town, import brings the town's gold into the treasury
      const dir = parseInt($("ctDir" + i).value, 10), n = Math.max(0, parseInt($("ctAmt" + i).value, 10) || 0);
      const c = ourCities().find((x) => x.i === i) || {}, has = (c.eco || {}).gs || 0;
      if (dir === 0) { toast("Gold moves once, so there is no gold trade to stop."); return; }
      if (!(n > 0)) { toast("Enter an amount of gold."); return; }
      if (dir < 0 && n > has) { toast(`${c.name} only holds ${num(has)} gold.`); return; }
      if (dir > 0 && n > (state.gold || 0)) { toast(`The treasury only holds ${num(state.gold)} gold.`); return; }
      toast("");
      csnCmd(`townGold|${i}|${-dir * n}`);
      return;
    }
    const mat = parseInt($("ctMat" + i).value, 10);
    const dir = parseInt($("ctDir" + i).value, 10);
    const amt = Math.max(0, parseInt($("ctAmt" + i).value, 10) || 0);
    csnCmd(`cityTrade|${i}|${mat}|${dir * amt}`);
  };
  window.csnTrade = () => {
    const side = parseInt($("trSide").value, 10), mat = parseInt($("trMat").value, 10);
    const dir = parseInt($("trDir").value, 10), amt = parseInt($("trAmt").value, 10);
    if (!(amt > 0)) { toast("Enter an amount."); return; }
    const cur = ((state.trade || [])[side - 1] || [])[mat] || 0;
    if (cur && Math.sign(cur) !== dir) {
      toast(`You already ${cur > 0 ? "import" : "export"} ${MATS[mat].toLowerCase()} with ${SIDES[side]}. End that agreement first.`);
      return;
    }
    toast("");
    csnCmd(`trade|${side}|${mat}|${dir}|${amt}`);
  };
  function updateTradeCost() {
    if (!$("trAmt")) return;
    const a = parseInt($("trAmt").value, 10) || 0;
    const d = parseInt($("trDir").value, 10);
    const g = a * (state.tradeprice || 10);
    $("trCost").textContent = d > 0 ? `costs ${num(g)} gold a day` : `earns ${num(g)} gold a day`;
  }

  // ---------------------------------------------------------------- settings
  function slider(key, label, help, min, max, step, value, unit) {
    return `<div class="setting"><div class="what"><div>${label}</div><div class="muted">${help}</div></div>
      <input type="range" min="${min}" max="${max}" step="${step}" value="${value}" oninput="csnSlide(this,'${unit}')" onchange="csnSet('${key}', this.value)">
      <div class="val">${value}${unit}</div></div>`;
  }
  window.csnSlide = (el, unit) => { el.nextElementSibling.textContent = el.value + unit; };
  window.csnSet = (key, v) => {
    const st = state.settings || (state.settings = {});
    const map = { battleSize: "battlesize", battleSpeed: "battlespeed", pause: "pause" };
    if (map[key]) { st[map[key]] = key === "pause" ? !!parseInt(v, 10) : parseInt(v, 10); safeRender(); }
    send(`setting|${key}|${parseInt(v, 10)}`);
    toast("Saved.", "ok");
  };

  function pageSettings() {
    const st = state.settings || {};
    const light = document.body.classList.contains("theme-light");
    const speed = st.battlespeed || 2;
    let h = `<h2>Look</h2>
      <div class="setting"><div class="what"><div>Theme</div><div class="muted">Also in the MCM.</div></div>
        <div class="seg"><button class="${light ? "" : "on"}" onclick="csnTheme(0)">Dark</button><button class="${light ? "on" : ""}" onclick="csnTheme(1)">Light</button></div></div>
      <div class="setting"><div class="what"><div>Pause the game while menus are open</div><div class="muted">Applies from the next menu you open. Also in the MCM.</div></div>
        <div class="seg"><button class="${st.pause ? "" : "on"}" onclick="csnSet('pause', 0)">Off</button><button class="${st.pause ? "on" : ""}" onclick="csnSet('pause', 1)">On</button></div></div>
      <h2>Difficulty</h2>
      <div class="setting"><div class="what"><div>Battle size</div><div class="muted">Troops on the field for each side at any one time. Big battles are heavy on older PCs.</div></div>
        <div class="seg">${[[0, "8 v 8"], [1, "16 v 16"], [2, "32 v 32"]].map(([v, n]) => `<button class="${(st.battlesize || 0) === v ? "on" : ""}" onclick="csnSet('battleSize', ${v})">${n}</button>`).join("")}</div></div>
      <div class="setting"><div class="what"><div>Reinforcement speed</div><div class="muted">How quickly fallen troops are replaced in battle.</div></div>
        <div class="seg">${[[1, "Slow"], [2, "Normal"], [4, "Fast"]].map(([v, n]) => `<button class="${speed === v ? "on" : ""}" onclick="csnSet('battleSpeed', ${v})">${n}</button>`).join("")}</div></div>
      ${slider("enemyRespawn", "Enemy armies return after", "Hours before a destroyed enemy army is raised again. Lower is harder.", 6, 240, 6, st.enemyrespawn || 24, " h")}
      ${slider("enemyRecovery", "Enemy armies refill after", "Hours an enemy army needs to recover after a battle. Lower is harder.", 6, 240, 6, st.enemyrecovery || 24, " h")}
      <h2>Questline</h2>
      <div class="setting"><div class="what"><div>Skip the tutorial</div><div class="muted">Jump straight to declaring war on the Imperials or Stormcloaks.</div></div>
        <button class="btn secondary" ${st.tutorialdone ? "disabled" : ""} onclick="csnCmd('skipTutorial')">${st.tutorialdone ? "Done" : "Skip"}</button></div>
      <h2>Debug</h2>
      <div class="setting"><div class="what"><div>Debug log ${st.debuglog ? '<span class="pill ok">On</span>' : '<span class="pill">Off: turn on in MCM &gt; Debug</span>'}</div>
        <div class="muted">File: ${esc(st.logpath || "Documents\\My Games\\Skyrim Special Edition\\SKSE\\ConquestOfSkyrimNet.log")}</div></div></div>
      <div class="setting"><div class="what"><div>Current battle</div><div class="muted">${st.battle ? "A battle is being fought." : "No battle is being fought right now."}</div></div>
        <button class="btn small secondary" ${st.battle ? "" : "disabled"} onclick="csnCmd('winBattle')">Win</button>
        <button class="btn small danger" ${st.battle ? "" : "disabled"} onclick="csnCmd('loseBattle')">Lose</button></div>
      <div class="setting"><div class="what"><div>Hold owner</div><div class="muted">Hand a hold's city and its roads to anyone, through Conquest of Skyrim's own transfers.</div></div>
        <select id="dbgHold">${(st.holdowners || []).map((x, i) => `<option value="${i}">${esc(x.name)}: ${esc(x.city)} ${SIDE_NAMES[x.owner] || "?"}, roads ${SIDE_NAMES[x.roads] || "nobody"}</option>`).join("")}</select>
        <select id="dbgHoldOwner"><option value="1">${esc(state.name || "Your faction")}</option><option value="11">Imperial Legion</option><option value="12">Stormcloaks</option></select>
        <button class="btn small secondary" onclick="csnDebugGive('debugHold', 'dbgHold', 'dbgHoldOwner')">Give</button></div>
      <div class="setting"><div class="what"><div>Fort owner</div><div class="muted">Hand any fort to anyone, through Conquest of Skyrim's own transfer.</div></div>
        <select id="dbgFort">${(st.forts || []).map((f, i) => `<option value="${i}">${esc(f.name)} (${OWNER_NAMES[f.owner] || "?"})</option>`).join("")}</select>
        <select id="dbgOwner"><option value="1">${esc(state.name || "Your faction")}</option><option value="11">Imperial Legion</option><option value="12">Stormcloaks</option></select>
        <button class="btn small secondary" onclick="csnDebugGive('debugFort', 'dbgFort', 'dbgOwner')">Give</button></div>`;
    return h;
  }
  // inline onclick runs outside this file's scope, where $ doesn't exist: read the dropdowns here
  window.csnDebugGive = (cmd, whatId, ownerId) => {
    const w = $(whatId), o = $(ownerId);
    if (!w || !o) return;
    csnCmd(`${cmd}|${w.value}|${o.value}`);
  };
  const OWNER_NAMES = { 1: "Imperials", 2: "Stormcloaks", 69: "yours" };
  // holds: city owner and roads (CoS: 1 the player's faction, 11 Imperials, 12 Stormcloaks)
  const SIDE_NAMES = { 1: "yours", 11: "Imperial", 12: "Stormcloak" };
  // ---------------------------------------------------------------- culture
  const STYLES = [
    ["Laissez-faire", "A light hand. Your people are casual with you and each other and speak their minds."],
    ["Democratic", "Order and hierarchy. Formalities, sir and ma'am for higher ranks; opinions through proper channels."],
    ["Dictatorship", "Iron-fist rule. Strict and stern; orders obeyed at once, harsh criticism is normal."],
    ["Other", "Describe your own way of ruling below."],
  ];
  let cultureDraft = null;   // unsaved edits survive redraws

  function pageCulture() {
    const c = state.culture || {};
    if (!cultureDraft) cultureDraft = { text: c.text || "", doctrine: c.doctrine || "", style: c.style >= 0 ? c.style : 1, other: c.other || "", title: c.title || 0, titleother: c.titleother || "" };
    const d = cultureDraft;
    return `<p class="lead">Who your faction is, how you lead it, and how it makes war. SkyrimNet characters use this: everyone in Skyrim knows what your faction is, its people follow your leadership style, and its soldiers and officers follow your doctrine.</p>
      <h2>Your title ${info(["# Your title (optional)", "Your troops, captains, commanders, officers, jarls, stewards and subjects address you by it, or put it before your name.", "No title: they use your name as usual."])}</h2>
      <div class="seg titles">${TITLES.map((t, i) => `<button class="${d.title === i ? "on" : ""}" onclick="csnTitle(${i})">${t}</button>`).join("")}</div>
      <div class="${d.title === 5 ? "" : "hidden"}" style="margin-top:10px"><input type="text" id="cuTitle" maxlength="40" style="width:280px" placeholder="Your own title, e.g. Warlord" value="${esc(d.titleother)}"></div>
      <p class="small muted" style="margin-top:8px">${d.title > 0 && (d.title < 5 || d.titleother) ? `They will call you <b>${esc(d.title === 5 ? d.titleother : TITLES[d.title])}</b> or <b>${esc((d.title === 5 ? d.titleother : TITLES[d.title]) + " " + (state.leader || ""))}</b>.` : "No title: they use your name."}</p>
      <h2>What the ${esc(state.name || "faction")} is and does</h2>
      <p class="muted small">General knowledge across Skyrim. Its purpose, beliefs, customs, symbols, reputation.</p>
      <textarea id="cuText" maxlength="1500" placeholder="A company of free swords sworn to drive both the Legion and the Stormcloaks out of Skyrim. We protect the common folk and take no part in the old feuds…">${esc(d.text)}</textarea>
      <h2>Leadership style</h2>
      <p class="muted small">How you rule, and so how your officers, captains, soldiers, jarls and stewards speak to you and to each other. Also in the MCM.</p>
      <div class="styles">${STYLES.map(([n, t], i) => `<button class="style-card ${d.style === i ? "on" : ""}" onclick="csnStyle(${i})"><b>${n}</b><span class="muted">${t}</span></button>`).join("")}</div>
      <div class="${d.style === 3 ? "" : "hidden"}" style="margin-top:10px"><textarea id="cuOther" maxlength="1500" placeholder="I rule as first among equals: my captains vote on campaigns, but my word ends every argument…">${esc(d.other)}</textarea></div>
      <h2>Military doctrine</h2>
      <p class="muted small">Known to your General, captains, commanders and soldiers. How you fight, train and treat the enemy.</p>
      <textarea id="cuDoctrine" maxlength="1500" placeholder="Strike fast and at night. Never leave the wounded behind. Spare those who surrender, burn nothing that farmers need…">${esc(d.doctrine)}</textarea>
      <div class="row" style="margin-top:14px"><span class="spacer"></span><button class="btn" onclick="csnSaveCulture()">Save</button></div>`;
  }

  const TITLES = ["None", "Supreme Leader", "Jarl", "High Priest", "Master", "Other"];
  window.csnTitle = (i) => { readCulture(); cultureDraft.title = i; safeRender(); };
  function readCulture() {
    if (!cultureDraft) return;
    const ti = $("cuTitle");
    if (ti) cultureDraft.titleother = ti.value;
    ["cuText", "cuDoctrine", "cuOther"].forEach((id, k) => {
      const el = $(id);
      if (el) cultureDraft[["text", "doctrine", "other"][k]] = el.value;
    });
  }
  window.csnStyle = (i) => { readCulture(); cultureDraft.style = i; safeRender(); };
  const clean = (t) => String(t || "").replace(/[|]/g, "/").replace(/\s*[\r\n]+\s*/g, " ").trim().slice(0, 1500);
  window.csnSaveCulture = () => {
    readCulture();
    const d = cultureDraft;
    send(`culture|culture|${clean(d.text)}`);
    send(`culture|doctrine|${clean(d.doctrine)}`);
    send(`culture|other|${clean(d.other)}`);
    send(`culture|style|${d.style}`);
    send(`culture|titleother|${clean(d.titleother).slice(0, 40)}`);
    send(`culture|title|${d.title === 5 && !clean(d.titleother) ? 0 : d.title}`);
    send("cultureSaved");
    cultureDraft = null;
    toast("Saved. Your people will act on it from their next conversation.", "ok");
  };

  // ---------------------------------------------------------------- blacksmith (next to the faction's Blacksmith)
  const RACES = ["Argonian", "Breton", "Dark Elf", "High Elf", "Imperial", "Khajiit", "Nord", "Orc", "Redguard", "Wood Elf"];
  const TROOPS = ["Soldiers", "Warriors", "Archers", "Crossbowmen", "City guards"];
  const MAGES = ["Fire mages", "Frost mages", "Shock mages", "Healers", "Conjurers", "Alteration mages"];

  function templatesBlock() {
    const t = state.templates;
    if (!t) return "";
    return `<h2>Troop templates</h2><p class="muted small">Ask your General or Blacksmith: "put 10 soldiers and 7 archers in template 1", "apply template 1 to Army 2". Templates cost nothing; an army refills to its template.</p>
      <table>${t.map((x, i) => `<tr><td>Template ${i + 1}</td><td>${esc(x)}</td></tr>`).join("")}</table>`;
  }

  function pageBlacksmith() {
    const b = state.smith || {};
    const races = b.races || [], genders = b.genders || [], gen = b.gendered || [];
    let h = `<p class="lead">Blacksmith ${esc(state.nearblacksmith)} keeps your troops armed and dressed.</p>
      <h2>Outfits by troop type</h2>
      <p class="muted small">Pick a troop type, then dress them all alike or set separate outfits for men and women. An army's own <b>Set outfit</b> (Armies tab) overrides these for that army.</p>
      <div class="split">${TROOPS.map((t, i) => `<div class="card"><div class="card-head"><h3>${t}</h3><span class="pill">${gen[i] ? "Men and women apart" : "One outfit for all"}</span></div>
        <div class="row"><button class="btn small" onclick="csnCmd('bsOutfit|${i}')">Manage equipment…</button></div></div>`).join("")}</div>`;
    if (b.mages) h += `<div class="row" style="margin-top:8px">${MAGES.map((t, i) => `<button class="btn small secondary" onclick="csnCmd('bsOutfit|${10 + i}')">${t}</button>`).join("")}</div>`;
    h += `<div class="row" style="margin-top:12px"><button class="btn secondary" onclick="csnCmd('bsUpgrade')">Buy better standard armour…</button>
      <span class="muted small">Iron to Dragonplate, paid from the treasury and metal.</span></div>
      <h2>Who may join your army</h2>
      <p class="muted small">New recruits are drawn from the races and genders you allow.</p>
      <div class="chips">${RACES.map((r, i) => `<button class="chip ${races[i] ? "on" : ""}" onclick="csnToggle('races', ${i}, 'bsRace')">${races[i] ? "✓ " : ""}${r}</button>`).join("")}</div>
      <div class="chips" style="margin-top:10px">${["Men", "Women"].map((g, i) => `<button class="chip ${genders[i] ? "on" : ""}" onclick="csnToggle('genders', ${i}, 'bsGender')">${genders[i] ? "✓ " : ""}${g}</button>`).join("")}</div>`;
    h += templatesBlock();
    if (b.pending) h += `<div class="note">You changed who may serve. Apply it to re-raise your current troops with the new races and genders (this can take a while).</div>
      <div class="row"><button class="btn" onclick="csnCmd('bsApply')">Apply to current troops</button></div>`;
    return h;
  }

  // Tick/untick at once on screen; the game catches up in the background.
  window.csnToggle = (list, i, cmd) => {
    const b = state.smith || (state.smith = {});
    const arr = b[list] || (b[list] = []);
    arr[i] = !arr[i];
    b.pending = true;
    safeRender();
    send(`${cmd}|${i}|${arr[i] ? 1 : 0}`);
  };

  window.csnTheme = (v) => { window.csnSetTheme(v); send(`setting|theme|${v}`); safeRender(); };

  // ---------------------------------------------------------------- after drawing
  function bind() {
    if (tab === "armies") armies().forEach((a) => { if ($("ord" + a.i)) window.csnOrderChanged(a.i); });
    if (tab === "holdings" && $("trSide")) {
      const p = state.ctx && state.ctx.proposal;
      if (p) { $("trSide").value = p.side; $("trMat").value = p.mat; $("trDir").value = p.dir; $("trAmt").value = p.amount; }
      ["trAmt", "trDir"].forEach((id) => $(id).addEventListener("input", updateTradeCost));
      updateTradeCost();
    }
  }
})();
